"""Integration coverage for the User Dashboard API and personalized feed."""

from __future__ import annotations

import sys
import unittest
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, Bookmark, Category, Comment, Reaction, ScraperConfig, User, db
from services.article_service import get_feed_articles
from services.time_service import vietnam_now


class DashboardApiTestCase(unittest.TestCase):
    """Exercise dashboard routes with an isolated authenticated account."""

    def setUp(self) -> None:
        self.app = create_app(
            {
                "TESTING": True,
                "SECRET_KEY": "dashboard-test",
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SQLALCHEMY_ENGINE_OPTIONS": {},
            }
        )
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()
            self.user = self._user("reader", "reader@example.com")
            self.other = self._user("other", "other@example.com")
            self.tech = Category(name="Technology")
            self.business = Category(name="Business")
            self.source = ScraperConfig(
                source_name="Trusted News",
                source_domain="trusted.example",
                target_url="https://trusted.example",
                article_list_selector="article",
                title_selector="h1",
                description_selector="p",
                content_selector="main",
            )
            db.session.add_all([self.user, self.other, self.tech, self.business, self.source])
            db.session.commit()
            self.user_id = self.user.id
            self.other_id = self.other.id
            self.session_version = self.user.session_version
            self.tech_id = self.tech.id
            self.business_id = self.business.id
            self.source_id = self.source.id

    def tearDown(self) -> None:
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    @staticmethod
    def _user(username: str, email: str) -> User:
        user = User(username=username, email=email, role="user")
        user.set_password("Password123")
        return user

    def login(self, user_id: int | None = None, session_version: int | None = None) -> None:
        with self.client.session_transaction() as session:
            session["user_id"] = user_id or self.user_id
            session["role"] = "user"
            session["session_version"] = session_version if session_version is not None else self.session_version

    def article(self, title: str, category: Category, *, deleted: bool = False, days_old: int = 0) -> Article:
        timestamp = vietnam_now() - timedelta(days=days_old)
        item = Article(
            title=title,
            description=f"Description for {title}",
            raw_content=f"Content for {title}",
            source_url=f"https://news.example/{title.lower().replace(' ', '-')}",
            published_at=timestamp,
            scraped_at=timestamp,
            is_deleted=deleted,
        )
        item.categories.append(category)
        db.session.add(item)
        db.session.flush()
        return item

    def test_dashboard_api_endpoints_require_authentication(self) -> None:
        requests = [
            ("get", "/api/dashboard/preferences"),
            ("put", "/api/dashboard/preferences"),
            ("get", "/api/dashboard/bookmarks"),
            ("delete", "/api/dashboard/bookmarks/1"),
            ("get", "/api/dashboard/brief/preferences"),
            ("put", "/api/dashboard/brief/preferences"),
            ("get", "/api/dashboard/brief/latest"),
            ("post", "/api/dashboard/brief/generate-today"),
            ("get", "/api/dashboard/brief/history"),
            ("post", "/api/dashboard/brief/mark-read"),
            ("get", "/api/dashboard/comments"),
            ("delete", "/api/dashboard/comments/1"),
            ("get", "/api/dashboard/reactions"),
            ("delete", "/api/dashboard/reactions/1"),
        ]
        for method, path in requests:
            with self.subTest(method=method, path=path):
                self.assertEqual(getattr(self.client, method)(path).status_code, 401)

    def test_preferences_load_replace_and_ignore_invalid_ids(self) -> None:
        self.login()
        tech_id = self.tech_id
        business_id = self.business_id
        source_id = self.source_id
        initial = self.client.get("/api/dashboard/preferences").get_json()["data"]
        self.assertFalse(initial["categories"][0]["is_subscribed"])

        response = self.client.put(
            "/api/dashboard/preferences",
            json={"category_ids": [tech_id, 99999, "bad"], "source_ids": [source_id, -1]},
        )
        self.assertEqual(response.status_code, 200)
        data = response.get_json()["data"]
        self.assertEqual([item["id"] for item in data["categories"] if item["is_subscribed"]], [tech_id])
        self.assertEqual([item["id"] for item in data["sources"] if item["is_subscribed"]], [source_id])

        response = self.client.put("/api/dashboard/preferences", json={"category_ids": [business_id], "source_ids": []})
        self.assertEqual(response.status_code, 200)
        with self.app.app_context():
            user = db.session.get(User, self.user_id)
            self.assertEqual([category.id for category in user.subscribed_categories], [business_id])
            self.assertEqual(user.subscribed_sources, [])

    def test_bookmarks_sort_search_delete_and_preserve_soft_deleted_article(self) -> None:
        with self.app.app_context():
            oldest = self.article("Alpha bookmark", self.tech)
            newest = self.article("Beta bookmark", self.tech)
            removed = self.article("Deleted bookmark", self.business, deleted=True)
            db.session.add_all([
                Bookmark(user_id=self.user_id, article_id=oldest.id, created_at=vietnam_now() - timedelta(hours=2)),
                Bookmark(user_id=self.user_id, article_id=newest.id, created_at=vietnam_now()),
                Bookmark(user_id=self.user_id, article_id=removed.id, created_at=vietnam_now() - timedelta(hours=1)),
                Bookmark(user_id=self.other_id, article_id=newest.id),
            ])
            db.session.commit()
            own_bookmark_id = Bookmark.query.filter_by(user_id=self.user_id, article_id=newest.id).first().id
            other_bookmark_id = Bookmark.query.filter_by(user_id=self.other_id).first().id
        self.login()

        newest_first = self.client.get("/api/dashboard/bookmarks?per_page=2").get_json()["data"]
        self.assertEqual([item["article"]["title"] for item in newest_first["items"]], ["Beta bookmark", "Deleted bookmark"])
        oldest_first = self.client.get("/api/dashboard/bookmarks?sort=oldest&q=Alpha").get_json()["data"]
        self.assertEqual([item["article"]["title"] for item in oldest_first["items"]], ["Alpha bookmark"])
        self.assertFalse(next(item for item in newest_first["items"] if item["article"]["title"] == "Deleted bookmark")["article"]["is_article_available"])
        self.assertEqual(self.client.delete(f"/api/dashboard/bookmarks/{own_bookmark_id}").status_code, 200)
        self.assertEqual(self.client.delete(f"/api/dashboard/bookmarks/{other_bookmark_id}").status_code, 404)

    def test_comments_validate_escape_and_enforce_ownership(self) -> None:
        with self.app.app_context():
            article = self.article("Commented article", self.tech)
            foreign = Comment(user_id=self.other_id, article_id=article.id, content="Other user")
            db.session.add(foreign)
            db.session.commit()
            foreign_id = foreign.id
            article_id = article.id
        self.login()

        self.assertEqual(self.client.post(f"/api/articles/{article_id}/comments", json={"content": ""}).status_code, 400)
        self.assertEqual(self.client.post(f"/api/articles/{article_id}/comments", json={"content": "x" * 2001}).status_code, 400)
        created = self.client.post(f"/api/articles/{article_id}/comments", json={"content": "<script>alert(1)</script>"})
        self.assertEqual(created.status_code, 201)
        self.assertIn("&lt;script&gt;", created.get_json()["comment"]["content"])
        comment_id = created.get_json()["comment"]["id"]
        self.assertEqual(self.client.delete(f"/api/dashboard/comments/{foreign_id}").status_code, 403)
        self.assertEqual(self.client.delete(f"/api/dashboard/comments/{comment_id}").status_code, 200)
        with self.app.app_context():
            self.assertTrue(db.session.get(Comment, comment_id).is_deleted)

    def test_reactions_toggle_summary_and_remove_owned_reaction(self) -> None:
        with self.app.app_context():
            article = self.article("Reaction article", self.tech)
            foreign = Reaction(user_id=self.other_id, article_id=article.id, reaction_type="like")
            db.session.add(foreign)
            db.session.commit()
            foreign_id = foreign.id
            article_id = article.id
        self.login()

        created = self.client.post(f"/api/articles/{article_id}/reactions", json={"reaction_type": "like"})
        self.assertEqual(created.status_code, 200)
        self.assertEqual(created.get_json()["action"], "created")
        summary = self.client.get(f"/api/articles/{article_id}/reactions/summary").get_json()["data"]
        self.assertEqual(summary["count"], 2)
        self.assertTrue(summary["user_reacted"])
        removed = self.client.post(f"/api/articles/{article_id}/reactions", json={"reaction_type": "like"})
        self.assertEqual(removed.get_json()["action"], "removed")
        self.assertEqual(self.client.delete(f"/api/dashboard/reactions/{foreign_id}").status_code, 403)
        self.client.post(f"/api/articles/{article_id}/reactions", json={"reaction_type": "like"})
        with self.app.app_context():
            own_reaction_id = Reaction.query.filter_by(user_id=self.user_id, article_id=article_id).first().id
        self.assertEqual(self.client.delete(f"/api/dashboard/reactions/{own_reaction_id}").status_code, 200)

    def test_personalized_feed_orders_preferred_before_general_and_category_overrides(self) -> None:
        with self.app.app_context():
            self.user.subscribed_categories.append(self.tech)
            preferred = self.article("Preferred technology", self.tech, days_old=1)
            general = self.article("Newer business", self.business)
            db.session.commit()

            feed, _, _ = get_feed_articles(user_id=self.user_id)
            business_only, _, _ = get_feed_articles(category="Business", user_id=self.user_id)

            self.assertEqual(feed[0]["id"], preferred.id)
            self.assertEqual([item["id"] for item in business_only], [general.id])


if __name__ == "__main__":
    unittest.main()
