import unittest
import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

# Add src folder to sys path to resolve imports correctly
sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app, db
from models import Article, Category, ScraperConfig, User


class RoutesTestCase(unittest.TestCase):
    def setUp(self):
        """Setup test Flask app and in-memory SQLite database."""
        self.app = create_app({
            "TESTING": True,
            "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
            "SQLALCHEMY_ENGINE_OPTIONS": {}
        })
        self.client = self.app.test_client()

        with self.app.app_context():
            db.create_all()

    def tearDown(self):
        """Clean up database session and drop all tables."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def test_homepage_route(self):
        """Verify GET / successfully responds with 200 OK."""
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)

    def test_health_check_route(self):
        """Verify GET /health successfully responds with 200 OK and status JSON."""
        response = self.client.get("/health")
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode("utf-8"))
        self.assertEqual(data["status"], "ok")

    def test_api_articles_empty(self):
        """Verify GET /api/articles returns an empty JSON list when database is empty."""
        response = self.client.get("/api/articles")
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode("utf-8"))
        self.assertEqual(len(data), 0)

    def test_api_articles_with_data(self):
        """Verify GET /api/articles successfully serializes Article ORM fields to expected JSON keys."""
        with self.app.app_context():
            category = Category(name="Science & Technology")
            article = Article(
                title="Discovery of Kepler-XYZ",
                description="A new planet with liquid water was discovered.",
                raw_content="Paragraph 1 content.\n\nParagraph 2 content.",
                source_url="https://vnexpress.net/khoa-hoc/article-1.html",
                cover_image_url="https://i-khoahoc.vnecdn.net/cover.jpg",
                truth_score=0.92
            )
            article.categories.append(category)
            db.session.add(category)
            db.session.add(article)
            db.session.commit()

        response = self.client.get("/api/articles")
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode("utf-8"))
        self.assertEqual(len(data), 1)
        
        # Verify JSON mapping
        art = data[0]
        self.assertEqual(art["title"], "Discovery of Kepler-XYZ")
        self.assertEqual(art["category"], "Science & Technology")
        self.assertEqual(art["summary"], "A new planet with liquid water was discovered.")
        self.assertIn("/api/image-proxy?url=", art["image"])
        self.assertIn("cover.jpg", art["image"])
        self.assertEqual(art["confidenceScore"], 92)
        self.assertEqual(len(art["paragraphs"]), 2)
        self.assertEqual(art["paragraphs"][0], "Paragraph 1 content.")
        self.assertEqual(art["paragraphs"][1], "Paragraph 2 content.")
        self.assertIn("keyTakeaways", art)

    def test_article_page_renders_images_and_captions_as_separate_blocks(self):
        with self.app.app_context():
            article = Article(
                title="Photo story",
                raw_content="Before the photo.\n\nAfter the photo.",
                content_blocks_json=json.dumps([
                    {"type": "paragraph", "text": "Before the photo."},
                    {"type": "image", "url": "https://vnexpress.net/photo.jpg", "alt": "A photo", "caption": "Photo credit"},
                    {"type": "paragraph", "text": "After the photo."},
                    {"type": "image", "url": "https://vnexpress.net/second-photo.jpg", "alt": "Another photo", "caption": "Second photo credit"},
                ]),
                source_url="https://vnexpress.net/photo-story.html",
            )
            db.session.add(article)
            db.session.commit()
            article_id = article.id

        response = self.client.get(f"/articles/{article_id}")
        page = response.data.decode("utf-8")
        self.assertEqual(response.status_code, 200)
        self.assertIn("article-inline-figure", page)
        self.assertNotIn("Photo credit</figcaption>", page)
        self.assertIn("Second photo credit", page)
        self.assertIn("Before the photo.", page)
        self.assertIn("Original article", page)
        self.assertIn("https://vnexpress.net/photo-story.html", page)

    def test_image_proxy_allowed_domain(self):
        """Verify image proxy blocks non-allowlisted domains and allows valid ones."""
        # 1. Blocked domain
        resp_blocked = self.client.get("/api/image-proxy?url=https://attacker.com/evil.png")
        self.assertEqual(resp_blocked.status_code, 403)

        # 2. Invalid URL scheme
        resp_invalid = self.client.get("/api/image-proxy?url=invalid-url")
        self.assertEqual(resp_invalid.status_code, 400)

        # 3. Missing URL parameter (returns fallback SVG placeholder)
        resp_missing = self.client.get("/api/image-proxy")
        self.assertEqual(resp_missing.status_code, 200)
        self.assertEqual(resp_missing.headers.get("Content-Type"), "image/svg+xml")

    @patch("routes.urllib.request.urlopen")
    def test_image_proxy_allows_thanh_nien_media_cdn(self, urlopen):
        with self.app.app_context():
            db.session.add(ScraperConfig(
                source_name="Thanh Nien",
                source_domain="thanhnien.vn",
                target_url="https://thanhnien.vn",
                article_list_selector="a.article",
                title_selector="h1",
                description_selector=".description",
                content_selector=".detail-content",
                image_cdn_domains="thanhnien.mediacdn.vn",
            ))
            db.session.commit()
        source = MagicMock()
        source.headers.get.return_value = "image/jpeg"
        source.read.return_value = b"image-bytes"
        urlopen.return_value.__enter__.return_value = source

        response = self.client.get(
            "/api/image-proxy?url=https%3A%2F%2Fthanhnien.mediacdn.vn%2Fposter.jpeg"
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.data, b"image-bytes")
        self.assertEqual(response.headers.get("Content-Type"), "image/jpeg")

    def test_admin_can_delete_source_configuration(self):
        with self.app.app_context():
            admin = User(email="admin@example.com", role="admin")
            admin.set_password("Admin123")
            config = ScraperConfig(
                source_name="Disposable Source",
                source_domain="example.com",
                target_url="https://example.com",
                article_list_selector="a.article",
                title_selector="h1",
                description_selector=".description",
                content_selector=".content",
            )
            db.session.add_all([admin, config])
            db.session.commit()
            config_id = config.id

        login = self.client.post("/api/auth/login", json={
            "identity": "admin@example.com", "password": "Admin123",
        })
        self.assertEqual(login.status_code, 200)
        response = self.client.delete(f"/api/admin/pipeline/config/{config_id}")
        self.assertEqual(response.status_code, 200)
        with self.app.app_context():
            self.assertIsNone(db.session.get(ScraperConfig, config_id))

    @patch("routes.summarize_article")
    def test_gemini_summarize_endpoint(self, summarize_article):
        """Verify the summary endpoint delegates to the Gemini service."""
        summarize_article.return_value = {
            "summary": ["A model-generated summary."],
            "keyTakeaways": ["A model-generated takeaway."],
            "confidenceScore": 91,
            "fallback": False,
        }
        payload = {"title": "Quantum Computing breakthrough", "text": "Full text of dispatch."}
        response = self.client.post(
            "/api/gemini/summarize",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode("utf-8"))
        self.assertIn("summary", data)
        self.assertIn("keyTakeaways", data)
        self.assertEqual(data["confidenceScore"], 91)
        summarize_article.assert_called_once_with(
            "Quantum Computing breakthrough", "Full text of dispatch."
        )

    @patch("services.ai_service.summarize_article")
    def test_article_summary_is_persisted_and_reused(self, summarize_article):
        summarize_article.return_value = {
            "summary": ["Persisted model summary."],
            "keyTakeaways": ["Persisted takeaway."],
            "confidenceScore": 88,
            "fallback": False,
        }
        with self.app.app_context():
            article = Article(
                title="Stored article",
                description="Stored description",
                raw_content="Stored full article text",
                source_url="https://example.com/stored-article",
            )
            db.session.add(article)
            db.session.commit()
            article_id = article.id

        first = self.client.post(
            "/api/gemini/summarize",
            json={"article_id": article_id, "title": "Untrusted title", "text": "Untrusted text"},
        )
        self.assertEqual(first.status_code, 200)
        self.assertFalse(first.get_json()["cached"])
        summarize_article.assert_called_once_with("Stored article", "Stored full article text")

        with self.app.app_context():
            stored = json.loads(db.session.get(Article, article_id).ai_summary)
            self.assertEqual(stored["summary"], ["Persisted model summary."])
            self.assertEqual(stored["keyTakeaways"], ["Persisted takeaway."])

        summarize_article.reset_mock()
        second = self.client.post("/api/gemini/summarize", json={"article_id": article_id})
        self.assertEqual(second.status_code, 200)
        self.assertTrue(second.get_json()["cached"])
        self.assertEqual(second.get_json()["summary"], ["Persisted model summary."])
        summarize_article.assert_not_called()

    @patch("services.ai_service.summarize_article")
    def test_article_summary_fallback_is_not_cached(self, summarize_article):
        summarize_article.return_value = {
            "summary": ["AI summary is unavailable."],
            "keyTakeaways": ["Try again later."],
            "confidenceScore": 0,
            "fallback": True,
        }
        with self.app.app_context():
            article = Article(
                title="Retryable article",
                raw_content="Full article text",
                source_url="https://example.com/retryable-article",
            )
            db.session.add(article)
            db.session.commit()
            article_id = article.id

        response = self.client.post("/api/gemini/summarize", json={"article_id": article_id})
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["fallback"])
        with self.app.app_context():
            self.assertIsNone(db.session.get(Article, article_id).ai_summary)

    @patch("routes.summarize_article")
    def test_gemini_summarize_dialogue_fallback(self, summarize_article):
        """Verify dialogue context uses the same Gemini summary service."""
        summarize_article.return_value = {
            "summary": ["The Turing test concerns reasoning in language."],
            "keyTakeaways": [],
            "confidenceScore": 73,
            "fallback": False,
        }
        payload = {"title": "Dialogue Context: Tell me about AI Turing test", "text": "Dialogue prompt."}
        response = self.client.post(
            "/api/gemini/summarize",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode("utf-8"))
        self.assertIn("summary", data)
        self.assertTrue(len(data["summary"]) > 0)
        summarize_article.assert_called_once_with(
            "Dialogue Context: Tell me about AI Turing test", "Dialogue prompt."
        )
        self.assertIn("Turing", data["summary"][0])

    @patch("routes.fact_check_article")
    def test_gemini_factcheck_endpoint(self, fact_check_article):
        """Verify the fact-check endpoint delegates to the Gemini service."""
        fact_check_article.return_value = {
            "confidenceScore": 64,
            "verifiedClaims": ["Supported by the supplied text."],
            "unverifiedClaims": [],
            "fallback": False,
        }
        payload = {"title": "Test Title", "text": "Test body."}
        response = self.client.post(
            "/api/gemini/factcheck",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode("utf-8"))
        self.assertIn("verifiedClaims", data)
        self.assertIn("unverifiedClaims", data)
        fact_check_article.assert_called_once_with("Test Title", "Test body.")

    def test_gemini_chat_endpoint(self):
        """Verify POST /api/gemini/chat returns conversational dialog response."""
        payload = {"message": "Hello assistant"}
        response = self.client.post(
            "/api/gemini/chat",
            data=json.dumps(payload),
            content_type="application/json"
        )
        self.assertEqual(response.status_code, 200)
        data = json.loads(response.data.decode("utf-8"))
        self.assertIn("response", data)


if __name__ == "__main__":
    unittest.main()
