"""Tests for lazy, cached verification and ambiguity scoring."""

import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import Mock, patch

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import AmbiguousWord, Article, ArticleStoryMembership, ArticleTruthScore, StoryCluster, db
from services.clarity_service import _cluster_evidence, _tavily_evidence, get_or_create_article_fact_check
from services.truth_score_service import score_article_and_cluster


class ClarityServiceTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:", "SQLALCHEMY_ENGINE_OPTIONS": {}, "SECRET_KEY": "clarity-test"})
        with self.app.app_context():
            db.create_all()
            db.session.add(AmbiguousWord(term="có thể", language="vi", severity="medium", explanation="Thiếu điều kiện hoặc bằng chứng."))
            self.article = self._article("Target có thể thay đổi", "target", 0)
            first = self._article("Highest evidence", "first", 1)
            second = self._article("Second evidence", "second", 2)
            third = self._article("Third evidence", "third", 3)
            cluster = StoryCluster()
            db.session.add_all([self.article, first, second, third, cluster])
            db.session.flush()
            for item in (self.article, first, second, third):
                db.session.add(ArticleStoryMembership(article_id=item.id, cluster_id=cluster.id, match_confidence=0.9, status="accepted"))
            db.session.commit()
            self.article_id, self.peer_ids = self.article.id, [first.id, second.id, third.id]
            score_article_and_cluster(self.article_id)
            # Make ordering explicit and independent of source metadata.
            for score, article_id in zip((50, 70, 60), self.peer_ids):
                ArticleTruthScore.query.filter_by(article_id=article_id).one().base_score = score
            db.session.commit()

    @staticmethod
    def _article(title, token, offset):
        return Article(title=title, description=f"Description for {token}. " * 10, raw_content=(f"Evidence body for {token}. " * 40), source_url=f"https://{token}.example/story", canonical_url=f"https://{token}.example/story", published_at=datetime.utcnow() - timedelta(minutes=offset), content_hash=f"clarity-{token}")

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    @patch("services.clarity_service.verify_article_against_evidence")
    @patch("services.clarity_service.is_configured", return_value=True)
    def test_cluster_uses_three_highest_base_score_and_caches_result(self, _configured, verify):
        verify.return_value = {"verification_score": 85, "report": "Two related reports support the core claims.", "claim_results": []}
        with self.app.app_context():
            first = get_or_create_article_fact_check(self.article_id)
            second = get_or_create_article_fact_check(self.article_id)
            detail = ArticleTruthScore.query.filter_by(article_id=self.article_id).one()

            sent_evidence = verify.call_args.args[2]
            self.assertEqual([item["article_id"] for item in sent_evidence], [str(self.peer_ids[1]), str(self.peer_ids[2]), str(self.peer_ids[0])])
            self.assertEqual(first["verification_source_type"], "cluster")
            self.assertEqual(first["verification_score"], 85)
            self.assertEqual(first["ambiguity_penalty"], 6)
            self.assertEqual(first["clarity_score"], 79)
            self.assertEqual(first["clarity_points"], 16)
            self.assertEqual(second["final_truth_score"], first["final_truth_score"])
            self.assertEqual(detail.clarity_status, "completed")
            verify.assert_called_once()

    def test_cluster_prefers_other_domains_then_similarity_then_base_score(self):
        with self.app.app_context():
            second = db.session.get(Article, self.peer_ids[1])
            second.source_url = second.canonical_url = "https://target.example/related"
            ArticleStoryMembership.query.filter_by(article_id=self.peer_ids[0]).one().match_confidence = 0.71
            db.session.commit()

            evidence = _cluster_evidence(db.session.get(Article, self.article_id))

            self.assertEqual([item["article_id"] for item in evidence], [str(self.peer_ids[2]), str(self.peer_ids[0]), str(self.peer_ids[1])])

    @patch("services.clarity_service.verify_article_against_evidence")
    @patch("services.clarity_service.is_configured", return_value=True)
    @patch("services.clarity_service.requests.post")
    def test_without_cluster_uses_tavily_search_only(self, post, _configured, verify):
        verify.return_value = {"verification_score": 80, "report": "Search snippets offer partial support.", "claim_results": []}
        response = Mock()
        response.json.return_value = {"results": [{"title": "Duplicate", "url": "https://target.example/story?utm_source=tavily", "content": "Target có thể thay đổi"}, {"title": "Target có thể thay đổi - Result one", "url": "https://evidence.example/1", "content": "Target có thể thay đổi according to report one."}, {"title": "Target có thể thay đổi - Result two", "url": "https://evidence.example/2", "content": "Target có thể thay đổi according to report two."}, {"title": "Target có thể thay đổi - Result three", "url": "https://evidence.example/3", "content": "Target có thể thay đổi according to report three."}]}
        post.return_value = response
        with self.app.app_context():
            ArticleStoryMembership.query.filter_by(article_id=self.article_id).delete()
            db.session.commit()
            with patch.dict("os.environ", {"TAVILY_API_KEY": "test-key"}, clear=False):
                result = get_or_create_article_fact_check(self.article_id)

            self.assertEqual(result["verification_source_type"], "tavily")
            self.assertEqual(len(result["citations"]), 3)
            self.assertNotIn("https://target.example/story", [item["url"] for item in result["citations"]])
            self.assertEqual(post.call_args.args[0], "https://api.tavily.com/search")
            self.assertEqual(post.call_args.kwargs["headers"]["Authorization"], "Bearer test-key")
            self.assertFalse(post.call_args.kwargs["json"]["include_raw_content"])
            self.assertEqual(post.call_args.kwargs["json"]["max_results"], 5)
            self.assertEqual(post.call_args.kwargs["json"]["query"], '"Target có thể thay đổi"')
            self.assertEqual(post.call_args.kwargs["json"]["topic"], "news")

    @patch("services.clarity_service.requests.post")
    def test_tavily_rejects_broad_topic_results(self, post):
        response = Mock()
        response.json.return_value = {"results": [
            {"title": "Quy định phòng cháy chữa cháy nhà xưởng", "url": "https://evidence.example/rules", "content": "General fire safety regulations."},
            {"title": "Bắt tạm giam chủ xưởng gỗ sau vụ cháy 3 người chết ở Hà Nội", "url": "https://evidence.example/match", "content": "The specific Hanoi factory fire incident."},
        ]}
        post.return_value = response
        with self.app.app_context(), patch.dict("os.environ", {"TAVILY_API_KEY": "test-key"}, clear=False):
            article = db.session.get(Article, self.article_id)
            article.title = "Tạm giam chủ xưởng gỗ liên quan vụ cháy làm 3 người chết ở Hà Nội"
            db.session.commit()
            evidence = _tavily_evidence(article)

        self.assertEqual([item["url"] for item in evidence], ["https://evidence.example/match"])

    @patch("services.clarity_service.requests.post")
    def test_tavily_retries_an_unquoted_headline_after_exact_query_only_finds_target(self, post):
        exact_response, fallback_response = Mock(), Mock()
        exact_response.json.return_value = {"results": [
            {"title": "Original", "url": "https://target.example/story", "content": "Dịp 2-9, chú ý nhiều lộ trình thay thế khi đi về hướng Đồng Nai"},
        ]}
        fallback_response.json.return_value = {"results": [
            {"title": "Các lộ trình thay thế về Đồng Nai dịp 2-9", "url": "https://evidence.example/dong-nai", "content": "Người dân đi về hướng Đồng Nai dịp 2-9 cần chú ý nhiều lộ trình thay thế."},
        ]}
        post.side_effect = [exact_response, fallback_response]
        with self.app.app_context(), patch.dict("os.environ", {"TAVILY_API_KEY": "test-key"}, clear=False):
            article = db.session.get(Article, self.article_id)
            article.title = "Dịp 2-9, chú ý nhiều lộ trình thay thế khi đi về hướng Đồng Nai"
            db.session.commit()
            evidence = _tavily_evidence(article)

        self.assertEqual([item["url"] for item in evidence], ["https://evidence.example/dong-nai"])
        self.assertEqual(post.call_count, 2)
        self.assertEqual(post.call_args_list[0].kwargs["json"]["query"], '"Dịp 2-9, chú ý nhiều lộ trình thay thế khi đi về hướng Đồng Nai"')
        self.assertEqual(post.call_args_list[1].kwargs["json"]["query"], "Dịp 2-9, chú ý nhiều lộ trình thay thế khi đi về hướng Đồng Nai")

    @patch("services.clarity_service.requests.post")
    def test_tavily_accepts_a_high_confidence_cross_language_match(self, post):
        response = Mock()
        response.json.return_value = {"results": [
            {"title": "UK base attack risk discussed", "url": "https://evidence.example/uk-base", "content": "Officials discussed the risk of an attack on a British military base.", "score": 0.91},
        ]}
        post.return_value = response
        with self.app.app_context(), patch.dict("os.environ", {"TAVILY_API_KEY": "test-key"}, clear=False):
            article = db.session.get(Article, self.article_id)
            article.title = "Nga nêu khả năng tấn công căn cứ quân sự Anh"
            db.session.commit()
            evidence = _tavily_evidence(article)

        self.assertEqual([item["url"] for item in evidence], ["https://evidence.example/uk-base"])

    @patch("services.clarity_service.requests.post")
    def test_tavily_uses_advanced_general_recall_after_basic_news_has_no_match(self, post):
        no_match, recall = Mock(), Mock()
        no_match.json.return_value = {"results": [
            {"title": "Unrelated coverage", "url": "https://evidence.example/unrelated", "content": "A broad unrelated report."},
        ]}
        recall.json.return_value = {"results": [
            {"title": "Target có thể thay đổi — Independent report", "url": "https://evidence.example/recall", "content": "Target có thể thay đổi according to an independent report."},
        ]}
        post.side_effect = [no_match, no_match, recall]
        with self.app.app_context(), patch.dict("os.environ", {"TAVILY_API_KEY": "test-key", "TAVILY_SEARCH_DEPTH": "basic", "TAVILY_TOPIC": "news"}, clear=False):
            evidence = _tavily_evidence(db.session.get(Article, self.article_id))

        self.assertEqual([item["url"] for item in evidence], ["https://evidence.example/recall"])
        recall_payload = post.call_args_list[-1].kwargs["json"]
        self.assertEqual(recall_payload["search_depth"], "advanced")
        self.assertEqual(recall_payload["topic"], "general")
        self.assertNotIn("time_range", recall_payload)

    @patch("services.clarity_service.is_configured", return_value=False)
    def test_missing_gemini_does_not_assign_clarity_points(self, _configured):
        with self.app.app_context():
            result = get_or_create_article_fact_check(self.article_id)
            self.assertEqual(result["status"], "unavailable")
            self.assertEqual(result["clarity_points"], 0)
            self.assertEqual(result["verification_score"], 0)

    @patch("services.clarity_service.is_configured", return_value=True)
    def test_missing_tavily_key_is_reported_as_unconfigured(self, _configured):
        with self.app.app_context(), patch.dict("os.environ", {"TAVILY_API_KEY": ""}, clear=False):
            ArticleStoryMembership.query.filter_by(article_id=self.article_id).delete()
            db.session.commit()
            result = get_or_create_article_fact_check(self.article_id)

        self.assertEqual(result["verification_source_type"], "tavily-unconfigured")
        self.assertIn("not configured", result["report"])

    def test_processing_result_includes_a_retry_delay(self):
        with self.app.app_context():
            detail = ArticleTruthScore.query.filter_by(article_id=self.article_id).one()
            detail.clarity_status = "processing"
            db.session.commit()

            result = get_or_create_article_fact_check(self.article_id)

            self.assertEqual(result["status"], "processing")
            self.assertEqual(result["retry_after_ms"], 1200)

    @patch("services.clarity_service.verify_article_against_evidence")
    @patch("services.clarity_service.is_configured", return_value=True)
    def test_detail_fact_check_endpoint_returns_verification_fields(self, _configured, verify):
        verify.return_value = {"verification_score": 75, "report": "Evidence compared.", "claim_results": []}
        response = self.app.test_client().post(f"/api/articles/{self.article_id}/fact-check")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()["data"]
        self.assertEqual(data["verification_score"], 75)
        self.assertIn("ambiguity_penalty", data)

    def test_public_truth_score_endpoint_returns_component_breakdown(self):
        response = self.app.test_client().get(f"/api/articles/{self.article_id}/truth-score")

        self.assertEqual(response.status_code, 200)
        data = response.get_json()["data"]
        self.assertIn("source_reliability_score", data)
        self.assertIn("content_score", data)
        self.assertEqual(data["base_score"], 77)
