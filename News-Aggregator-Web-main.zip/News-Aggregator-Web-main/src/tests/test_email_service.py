"""SMTP unit tests for Daily Brief delivery."""

import os
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))

from services.email_service import send_daily_brief_email


class DailyBriefEmailTestCase(unittest.TestCase):
    @patch.dict(os.environ, {
        "MAIL_SERVER": "smtp.example.com", "MAIL_PORT": "587",
        "MAIL_USERNAME": "mailer", "MAIL_PASSWORD": "secret",
        "MAIL_FROM": "Tell Me More <no-reply@example.com>",
        "APP_BASE_URL": "https://app.example.com",
    }, clear=False)
    @patch("services.email_service.smtplib.SMTP")
    def test_sends_html_brief_with_dispatch_links(self, smtp_class):
        self.assertTrue(send_daily_brief_email("reader@example.com", "- Update [2000]", "2026-08-21", [2000]))
        message = smtp_class.return_value.__enter__.return_value.send_message.call_args.args[0]
        self.assertEqual(message["To"], "reader@example.com")
        self.assertIn("Daily Brief", message["Subject"])
        self.assertIn("https://app.example.com/articles/2000", message.get_body("html").get_content())


if __name__ == "__main__":
    unittest.main()
