import sys
import json
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, Category, DailyBrief, ScraperConfig, User, UserBriefPreference, db
from services.brief_service import generate_daily_brief, get_brief_history, get_brief_preferences
from services.time_service import vietnam_today


class DailyBriefServiceTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app({
            "TESTING": True,
            "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
            "SQLALCHEMY_ENGINE_OPTIONS": {},
        })
        with self.app.app_context():
            db.create_all()
            user = User(email="brief@example.com", role="user")
            user.set_password("Password123")
            article = Article(
                title="Recent dispatch",
                description="A recent story.",
                source_url="https://example.com/recent",
                published_at=datetime.utcnow(),
            )
            db.session.add_all([user, article])
            db.session.commit()
            self.user_id = user.id

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    @patch("services.brief_service.generate_daily_brief_content")
    def test_generates_and_persists_a_brief(self, generate_content):
        generate_content.return_value = "- AI-generated daily brief"
        with self.app.app_context():
            brief = generate_daily_brief(self.user_id)
            self.assertEqual(brief.content, "- AI-generated daily brief")
            self.assertEqual(brief.user_id, self.user_id)
            self.assertEqual(DailyBrief.query.filter_by(user_id=self.user_id).count(), 1)
            generate_content.assert_called_once()

    def test_history_returns_prior_briefs_newest_first(self):
        with self.app.app_context():
            db.session.add_all([
                DailyBrief(user_id=self.user_id, content="Older", source_article_ids="[]", brief_date=vietnam_today() - timedelta(days=1)),
                DailyBrief(user_id=self.user_id, content="Newer", source_article_ids="[]", brief_date=vietnam_today()),
            ])
            db.session.commit()
            history = get_brief_history(self.user_id)
            self.assertEqual([item["content"] for item in history], ["Newer", "Older"])

    def test_daily_brief_and_email_delivery_are_opt_in_by_default(self):
        with self.app.app_context():
            self.assertFalse(UserBriefPreference(user_id=self.user_id).is_enabled)
            self.assertEqual(
                get_brief_preferences(self.user_id),
                {"is_enabled": False, "delivery_time": "07:00", "frequency": "daily", "email_delivery": False},
            )

    @patch("services.brief_service.generate_daily_brief_content")
    def test_uses_selected_topics_and_sources_when_present(self, generate_content):
        generate_content.return_value = "Personalized brief"
        with self.app.app_context():
            technology = Category(name="Technology")
            sports = Category(name="Sports")
            preferred_source = ScraperConfig(
                source_name="Preferred", source_domain="preferred.example",
                target_url="https://preferred.example", article_list_selector="a",
                title_selector="h1", description_selector="p", content_selector="article",
            )
            other_source = ScraperConfig(
                source_name="Other", source_domain="other.example",
                target_url="https://other.example", article_list_selector="a",
                title_selector="h1", description_selector="p", content_selector="article",
            )
            db.session.add_all([technology, sports, preferred_source, other_source])
            db.session.flush()
            user = db.session.get(User, self.user_id)
            user.subscribed_categories = [technology]
            user.subscribed_sources = [preferred_source]
            matching = Article(title="Matching", source_url="https://preferred.example/match", published_at=datetime.utcnow())
            wrong_topic = Article(title="Wrong topic", source_url="https://preferred.example/sports", published_at=datetime.utcnow())
            wrong_source = Article(title="Wrong source", source_url="https://other.example/technology", published_at=datetime.utcnow())
            matching.categories.append(technology)
            wrong_topic.categories.append(sports)
            wrong_source.categories.append(technology)
            db.session.add_all([matching, wrong_topic, wrong_source])
            db.session.commit()

            brief = generate_daily_brief(self.user_id)

            self.assertEqual(json.loads(brief.source_article_ids), [matching.id])

    @patch("services.brief_service.send_daily_brief_email")
    @patch("services.brief_service.generate_daily_brief_content")
    def test_sends_email_when_brief_email_delivery_is_enabled(self, generate_content, send_email):
        generate_content.return_value = "Daily content"
        with self.app.app_context():
            db.session.add(UserBriefPreference(user_id=self.user_id, email_delivery=True))
            db.session.commit()
            brief = generate_daily_brief(self.user_id)
            user = db.session.get(User, self.user_id)
            send_email.assert_called_once_with(user.email, brief.content, vietnam_today().isoformat(), [1])


if __name__ == "__main__":
    unittest.main()
