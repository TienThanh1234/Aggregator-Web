"""Unit tests for Gemini response parsing and safe AI fallbacks."""

import unittest
from pathlib import Path
import sys
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))

from services.ai_service import fact_check_article, generate_daily_brief, summarize_article


class AIServiceTestCase(unittest.TestCase):
    """Keep AI presentation contracts stable without calling an external API."""

    @patch("services.ai_service._request_json", return_value=None)
    def test_summary_has_a_safe_fallback_when_gemini_is_unavailable(self, _request) -> None:
        result = summarize_article("A story", "Article text")
        self.assertTrue(result["fallback"])
        self.assertEqual(result["confidenceScore"], 0)
        self.assertTrue(result["summary"])

    @patch(
        "services.ai_service._request_json",
        return_value={
            "summary": ["A concise finding."],
            "confidenceScore": 91,
            "keyTakeaways": ["A useful takeaway."],
        },
    )
    def test_summary_serializes_gemini_json(self, _request) -> None:
        result = summarize_article("A story", "Article text")
        self.assertFalse(result["fallback"])
        self.assertEqual(result["confidenceScore"], 91)
        self.assertEqual(result["summary"], ["A concise finding."])

    @patch("services.ai_service._request_json", return_value=None)
    def test_fact_check_never_claims_external_verification_when_unavailable(self, _request) -> None:
        result = fact_check_article("A story", "Article text")
        self.assertTrue(result["fallback"])
        self.assertIn("No external verification", result["unverifiedClaims"][0]["analysis"])

    @patch("services.ai_service._request_json", return_value={"bullets": ["One update."]})
    def test_daily_brief_starts_with_requested_date(self, request_json) -> None:
        result = generate_daily_brief("ARTICLE ID: 2000\nTITLE: Story", "2026-08-21")
        self.assertEqual(result, "Daily Brief — 2026-08-21\n- One update.")
        self.assertIn("Daily Brief — 2026-08-21", request_json.call_args.args[0])
        self.assertIn("[2000]", request_json.call_args.args[0])


if __name__ == "__main__":
    unittest.main()
