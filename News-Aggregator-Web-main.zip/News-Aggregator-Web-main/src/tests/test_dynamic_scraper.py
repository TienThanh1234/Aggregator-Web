import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))

from scraper.dynamic_scraper import DynamicScraper


class DynamicScraperContentBlocksTestCase(unittest.TestCase):
    def test_scrape_skips_existing_links_and_keeps_going_until_limit(self):
        progress = []
        scraper = DynamicScraper({
            "source_name": "Example", "source_domain": "example.com",
            "target_url": "https://example.com/latest", "max_articles_per_run": 2,
            "article_list_selector": "a.article",
        }, progress_callback=progress.append)
        listing = "".join(
            f'<a class="article" href="/{name}">{name}</a>'
            for name in ("old", "new-one", "new-two")
        )

        with patch.object(scraper, "fetch_page", side_effect=[listing, "one", "two"]) as fetch_page, \
             patch.object(scraper, "_extract_article_data", side_effect=[
                 {"source_url": "https://example.com/new-one", "title": "New one"},
                 {"source_url": "https://example.com/new-two", "title": "New two"},
             ]), \
             patch("scraper.dynamic_scraper.ScraperService.article_exists", side_effect=lambda url: url.endswith("/old")), \
             patch("scraper.dynamic_scraper.ScraperService.raw_article_exists", return_value=False):
            articles = scraper.scrape()

        self.assertEqual([article["title"] for article in articles], ["New one", "New two"])
        self.assertEqual([article["title"] for article in progress], ["New one", "New two"])
        self.assertEqual(fetch_page.call_count, 3)

    def test_extracts_all_figures_with_captions_and_uses_first_as_cover(self):
        scraper = DynamicScraper({
            "source_name": "Example", "source_domain": "example.com",
            "content_selector": ".article-content", "title_selector": "h1",
        })
        data = scraper._extract_article_data("https://example.com/news/story", """
            <html><head><meta property="og:image" content="https://example.com/social.jpg"></head>
            <body><h1>A story</h1><div class="article-content">
                <p>Opening paragraph.</p>
                <figure><img src="/one.jpg" alt="First image"><figcaption>First caption</figcaption></figure>
                <p>Middle paragraph.</p>
                <figure><img data-src="/two.jpg"><figcaption>Second caption</figcaption></figure>
            </div></body></html>
        """)

        self.assertEqual(data["cover_image_url"], "https://example.com/one.jpg")
        self.assertEqual(data["raw_content"], "Opening paragraph.\n\nMiddle paragraph.")
        blocks = json.loads(data["content_blocks_json"])
        self.assertEqual([block["type"] for block in blocks], ["paragraph", "image", "paragraph", "image"])
        self.assertEqual(blocks[1]["caption"], "First caption")
        self.assertEqual(blocks[3]["caption"], "Second caption")

    def test_ignores_related_news_widget_inside_content_container(self):
        scraper = DynamicScraper({
            "source_name": "Example", "source_domain": "example.com",
            "content_selector": ".article-content", "title_selector": "h1",
        })
        data = scraper._extract_article_data("https://example.com/news/story", """
            <html><body><h1>Cash preparedness</h1><article class="article-content">
                <p>The EU recommends households keep emergency supplies.</p>
                <figure><img src="/cash.jpg" alt="Cash exchange"></figure>
                <aside class="related-news-card">
                    <img src="/eclipse.jpg" alt="Eclipse">
                    <h3>Total eclipse draws crowds</h3>
                    <p>Unrelated eclipse teaser text.</p>
                </aside>
                <div class="kbwscwl-relatedbox"><p>Another unrelated teaser.</p></div>
                <div class="VCSortableInPreviewMode">
                    <img src="/heat.jpg" alt="Heatwave">
                    <h3>Heatwave teaser</h3><p>Another embedded related report.</p>
                </div>
                <p>Cash should not be the only contingency plan.</p>
            </article></body></html>
        """)

        self.assertEqual(
            data["raw_content"],
            "The EU recommends households keep emergency supplies.\n\n"
            "Cash should not be the only contingency plan.",
        )
        blocks = json.loads(data["content_blocks_json"])
        self.assertEqual(blocks, [
            {"type": "paragraph", "text": "The EU recommends households keep emergency supplies."},
            {"type": "image", "url": "https://example.com/cash.jpg", "alt": "Cash exchange", "caption": ""},
            {"type": "paragraph", "text": "Cash should not be the only contingency plan."},
        ])

    def test_source_configured_excluded_selectors_remove_matching_subtrees(self):
        scraper = DynamicScraper({
            "source_name": "Example", "source_domain": "example.com",
            "content_selector": ".article-content",
            "excluded_html_selectors": ".publisher-specific-widget",
        })
        data = scraper._extract_article_data("https://example.com/news/story", """
            <article class="article-content">
                <p>Keep this report paragraph.</p>
                <div class="publisher-specific-widget"><p>Discard this widget paragraph.</p><img src="/widget.jpg"></div>
            </article>
        """)

        self.assertEqual(data["raw_content"], "Keep this report paragraph.")
        self.assertEqual(json.loads(data["content_blocks_json"]), [
            {"type": "paragraph", "text": "Keep this report paragraph."},
        ])


if __name__ == "__main__":
    unittest.main()
