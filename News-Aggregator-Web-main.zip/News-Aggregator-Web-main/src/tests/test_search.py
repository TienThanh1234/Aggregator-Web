"""Contract tests for Hybrid MPA article search."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, Category, SearchLog, User, db


class SearchRouteTestCase(unittest.TestCase):
    """Use SQLite for route coverage; PostgreSQL FTS is covered by migration review."""

    def setUp(self) -> None:
        self.app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:", "SQLALCHEMY_ENGINE_OPTIONS": {}, "SECRET_KEY": "search-test"})
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()
            category = Category(name="Technology")
            title_match = Article(title="AI Dispatch", description="A technology story", raw_content="Context", source_url="https://news.example/ai")
            body_match = Article(title="Other Dispatch", description="Other story", raw_content="AI appears only in the body", source_url="https://news.example/other")
            title_match.categories.append(category)
            db.session.add_all([category, title_match, body_match])
            db.session.commit()

    def tearDown(self) -> None:
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def test_html_search_is_shareable_and_renders_results(self) -> None:
        response = self.client.get("/search?q=AI&category=Technology")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"AI Dispatch", response.data)
        self.assertIn(b"/articles/", response.data)
        self.assertIn(b'name="q" value="AI"', response.data)

    def test_api_search_validates_and_ranks_title_match_first(self) -> None:
        invalid = self.client.get("/api/search")
        self.assertEqual(invalid.status_code, 400)
        response = self.client.get("/api/search?q=AI")
        self.assertEqual(response.status_code, 200)
        data = response.get_json()["data"]
        self.assertEqual(data["articles"][0]["title"], "AI Dispatch")
        self.assertEqual(data["articles"][0]["canonical_path"], "/articles/1")

    def test_search_logs_and_trends(self) -> None:
        self.client.get("/api/search?q=AI")
        with self.app.app_context():
            self.assertEqual(SearchLog.query.count(), 1)
        response = self.client.get("/api/search/trending?limit=5")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["data"]["trending"][0]["keyword"], "ai")

    def test_search_suggestions_are_isolated_by_account(self) -> None:
        with self.app.app_context():
            first = User(username="first", email="first@example.com", role="user")
            second = User(username="second", email="second@example.com", role="user")
            first.set_password("Password123")
            second.set_password("Password123")
            db.session.add_all([first, second])
            db.session.commit()
            first_id, second_id = first.id, second.id
            first_version, second_version = first.session_version, second.session_version

        with self.client.session_transaction() as active_session:
            active_session["user_id"] = first_id
            active_session["role"] = "user"
            active_session["session_version"] = first_version
        self.client.get("/api/search?q=AI")
        first_terms = self.client.get("/api/search/trending?limit=5").get_json()["data"]
        self.assertEqual(first_terms["trending"][0]["keyword"], "ai")

        with self.client.session_transaction() as active_session:
            active_session["user_id"] = second_id
            active_session["role"] = "user"
            active_session["session_version"] = second_version
        second_terms = self.client.get("/api/search/trending?limit=5").get_json()["data"]
        self.assertEqual(second_terms["trending"], [])
        self.assertEqual(second_terms["recent_searches"], [])

    def test_authenticated_user_can_delete_one_search_history_entry(self) -> None:
        with self.app.app_context():
            user = User(username="history_user", email="history@example.com", role="user")
            user.set_password("Password123")
            db.session.add(user)
            db.session.flush()
            db.session.add_all([
                SearchLog(keyword="ai", user_id=user.id),
                SearchLog(keyword="space", user_id=user.id),
            ])
            db.session.commit()
            user_id, session_version = user.id, user.session_version

        with self.client.session_transaction() as active_session:
            active_session["user_id"] = user_id
            active_session["role"] = "user"
            active_session["session_version"] = session_version
        response = self.client.delete("/api/search/history", json={"keyword": "AI"})
        self.assertEqual(response.status_code, 200)
        with self.app.app_context():
            self.assertEqual(SearchLog.query.filter_by(user_id=user_id, keyword="ai").count(), 0)
            self.assertEqual(SearchLog.query.filter_by(user_id=user_id, keyword="space").count(), 1)


if __name__ == "__main__":
    unittest.main()
