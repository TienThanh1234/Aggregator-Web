"""Integration tests for public filtering of soft-deleted articles."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, db


class PublicFilteringTestCase(unittest.TestCase):
    """Verify that soft-deleted articles are hidden from public endpoints."""

    def setUp(self) -> None:
        """Create a test app and fresh in-memory database for each test."""
        self.app = create_app({
            "TESTING": True,
            "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
            "SQLALCHEMY_ENGINE_OPTIONS": {}
        })
        self.client = self.app.test_client()

        with self.app.app_context():
            db.create_all()
            
            # Create a normal article
            self.normal_article = Article(
                title="Normal Article",
                description="This is a normal article.",
                source_url="https://example.com/normal",
                is_deleted=False
            )
            
            # Create a soft-deleted article
            self.deleted_article = Article(
                title="Deleted Article",
                description="This article was soft-deleted.",
                source_url="https://example.com/deleted",
                is_deleted=True
            )
            
            db.session.add(self.normal_article)
            db.session.add(self.deleted_article)
            db.session.commit()
            
            self.normal_id = self.normal_article.id
            self.deleted_id = self.deleted_article.id

    def tearDown(self) -> None:
        """Clean up database session and drop all tables."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def test_fetch_soft_deleted_by_id_returns_404(self):
        """Verify fetching a soft-deleted article by ID returns 404."""
        response = self.client.get(f"/articles/{self.deleted_id}")
        self.assertEqual(response.status_code, 404)
        
        # Verify normal article returns 200
        response_normal = self.client.get(f"/articles/{self.normal_id}")
        self.assertEqual(response_normal.status_code, 200)

    def test_soft_deleted_hidden_from_public_feed(self):
        """Verify soft-deleted articles do not appear in the paginated public feeds."""
        response = self.client.get("/api/articles")
        self.assertEqual(response.status_code, 200)
        
        data = response.get_json()
        article_ids = [int(a["id"]) for a in data]
        
        self.assertIn(self.normal_id, article_ids)
        self.assertNotIn(self.deleted_id, article_ids)

    def test_soft_deleted_hidden_from_search_results(self):
        """Verify searching for keywords in a soft-deleted article does not return it."""
        response = self.client.get("/api/search?q=Article")
        self.assertEqual(response.status_code, 200)
        
        data = response.get_json()["data"]
        article_ids = [int(a["id"]) for a in data["articles"]]
        
        self.assertIn(self.normal_id, article_ids)
        self.assertNotIn(self.deleted_id, article_ids)


if __name__ == "__main__":
    unittest.main()
