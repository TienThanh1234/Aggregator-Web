import sys
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, db
from services.story_cluster_service import assign_article_to_cluster
from services.truth_score_service import score_article


class StoryClusterTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:", "SQLALCHEMY_ENGINE_OPTIONS": {}, "SECRET_KEY": "story-test"})
        with self.app.app_context(): db.create_all()

    def tearDown(self):
        with self.app.app_context(): db.session.remove(); db.drop_all()

    def test_exact_hash_reports_share_cluster_and_truth_corroboration(self):
        with self.app.app_context():
            common = {"title": "Bao cao ve su kien", "description": "Mo ta su kien giong nhau " * 5, "raw_content": "x" * 600, "published_at": datetime.utcnow(), "content_hash": "same"}
            first = Article(source_url="https://one.example/a", canonical_url="https://one.example/a", **common)
            second = Article(source_url="https://two.example/b", canonical_url="https://two.example/b", **common)
            db.session.add_all([first, second]); db.session.flush()
            assign_article_to_cluster(first); assign_article_to_cluster(second); score_article(first); db.session.commit()
            db.session.expire_all()
            self.assertEqual(first.story_membership.cluster_id, second.story_membership.cluster_id)
            self.assertEqual(first.truth_score, 72)
            self.assertEqual(first.story_membership.cluster.independent_domain_count, 2)
            cluster_id = first.story_membership.cluster_id

            client = self.app.test_client()
            feed_response = client.get("/")
            self.assertEqual(feed_response.status_code, 200)
            self.assertIn(b"See similar titles and other perspectives", feed_response.data)

            detail_response = client.get(f"/articles/{first.id}")
            self.assertEqual(detail_response.status_code, 200)
            self.assertIn(b"See similar titles and other perspectives", detail_response.data)

            cluster_response = client.get(f"/story-clusters/{cluster_id}")
            self.assertEqual(cluster_response.status_code, 200)
            self.assertIn(b"Similar titles and other perspectives", cluster_response.data)
            self.assertIn(f'/articles/{first.id}'.encode(), cluster_response.data)
            self.assertIn(f'/articles/{second.id}'.encode(), cluster_response.data)

            self.assertEqual(client.get("/story-clusters/999999").status_code, 404)

    def test_generic_vietnamese_words_do_not_join_unrelated_stories(self):
        with self.app.app_context():
            common = {"raw_content": "x" * 600, "published_at": datetime.utcnow()}
            tax = Article(
                title="Phạt tới 100 triệu nếu không cung cấp thông tin cho cơ quan thuế",
                description="Người nộp thuế không cung cấp dữ liệu có thể bị xử phạt 100 triệu đồng.",
                source_url="https://one.example/tax", canonical_url="https://one.example/tax", **common,
            )
            cabbage = Article(
                title="Cây cải thảo hút hàng triệu lượt khách tham quan",
                description="Cải thảo ngọc tại bảo tàng Đài Bắc thu hút đông khách du lịch.",
                source_url="https://two.example/cabbage", canonical_url="https://two.example/cabbage", **common,
            )
            related_tax = Article(
                title="Cơ quan thuế có thể phạt 100 triệu đồng nếu không cung cấp dữ liệu",
                description="Quy định mới xử phạt người nộp thuế không cung cấp dữ liệu cho cơ quan quản lý.",
                source_url="https://three.example/tax", canonical_url="https://three.example/tax", **common,
            )
            db.session.add_all([tax, cabbage, related_tax]); db.session.flush()
            assign_article_to_cluster(tax)
            assign_article_to_cluster(cabbage)
            assign_article_to_cluster(related_tax)
            db.session.commit()

            self.assertNotEqual(tax.story_membership.cluster_id, cabbage.story_membership.cluster_id)
            self.assertEqual(tax.story_membership.cluster_id, related_tax.story_membership.cluster_id)

    def test_same_organization_but_different_events_do_not_share_cluster(self):
        with self.app.app_context():
            common = {"raw_content": "x" * 600, "published_at": datetime.utcnow()}
            accident_warning = Article(
                title="Bộ Công an: Không chia sẻ thông tin chưa kiểm chứng vụ tai nạn trên đường Nguyễn Huy Tự",
                description="Người dân cần tỉnh táo, không chia sẻ thông tin chưa kiểm chứng về vụ tai nạn.",
                source_url="https://one.example/accident", canonical_url="https://one.example/accident", **common,
            )
            accident_report = Article(
                title="Công an Hà Nội nói về vụ tai nạn giao thông ở phố Nguyễn Huy Tự",
                description="Công an lên tiếng về vụ tai nạn tại Nguyễn Huy Tự và đề nghị không chia sẻ tin chưa kiểm chứng.",
                source_url="https://two.example/accident", canonical_url="https://two.example/accident", **common,
            )
            police_book = Article(
                title="Ra mắt bộ sách về người đứng đầu lực lượng Công an nhân dân qua các thời kỳ",
                description="Bộ sách tôn vinh những người đứng đầu lực lượng Công an nhân dân qua nhiều thời kỳ.",
                source_url="https://three.example/book", canonical_url="https://three.example/book", **common,
            )
            db.session.add_all([accident_warning, accident_report, police_book])
            db.session.flush()
            assign_article_to_cluster(accident_warning)
            assign_article_to_cluster(accident_report)
            assign_article_to_cluster(police_book)
            db.session.commit()

            self.assertEqual(accident_warning.story_membership.cluster_id, accident_report.story_membership.cluster_id)
            self.assertNotEqual(accident_warning.story_membership.cluster_id, police_book.story_membership.cluster_id)


if __name__ == "__main__": unittest.main()
