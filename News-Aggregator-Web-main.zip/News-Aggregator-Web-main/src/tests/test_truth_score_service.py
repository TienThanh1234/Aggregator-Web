"""Tests for deterministic article evidence-confidence scoring."""

import sys
import unittest
from datetime import datetime
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, ArticleTruthScore, ScraperConfig, db
from services.truth_score_service import calculate_score, score_article_and_cluster


class TruthScoreServiceTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app({"TESTING": True, "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:", "SQLALCHEMY_ENGINE_OPTIONS": {}, "SECRET_KEY": "truth-score-test"})
        with self.app.app_context():
            db.create_all()

    def tearDown(self):
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    @staticmethod
    def article(url="https://example.com/story", content_hash=None):
        return Article(
            title="A complete article",
            description="x" * 80,
            raw_content="x" * 500,
            source_url=url,
            canonical_url=url,
            published_at=datetime.utcnow(),
            content_hash=content_hash,
        )

    @staticmethod
    def source(domain):
        return ScraperConfig(
            source_name=domain, source_domain=domain, target_url=f"https://{domain}",
            article_list_selector="article", title_selector="h1", description_selector="p", content_selector="main",
            reliability_score=100,
        )

    def test_complete_single_source_scores_70(self):
        article = self.article()
        result = calculate_score(article, [article], self.source("example.com"))
        self.assertEqual(result["base_score"], 70)
        self.assertEqual(result["corroboration_score"], 0)

    def test_exact_hash_independent_sources_add_corroboration(self):
        with self.app.app_context():
            first = self.article("https://one.example/story", "same-content")
            second = self.article("https://two.example/story", "same-content")
            db.session.add_all([first, second, self.source("one.example"), self.source("two.example")])
            db.session.commit()
            score_article_and_cluster(first.id)
            db.session.refresh(first)
            db.session.refresh(second)
            self.assertEqual(first.truth_score, 75)
            self.assertEqual(second.truth_score, 75)
            self.assertIsNone(first.primary_article_id)
            self.assertEqual(second.primary_article_id, first.id)
            self.assertEqual(ArticleTruthScore.query.filter_by(article_id=first.id).one().corroboration_score, 5)

    def test_same_domain_does_not_count_as_independent(self):
        first = self.article("https://news.example/a", "same-content")
        second = self.article("https://news.example/b", "same-content")
        self.assertEqual(calculate_score(first, [first, second])["corroboration_score"], 0)


if __name__ == "__main__":
    unittest.main()
