"""Integration tests for authenticated profile-management API endpoints."""

import tempfile
import unittest
from io import BytesIO
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import User, db
from services.profile_service import MAX_AVATAR_SIZE_BYTES


class ProfileManagementTestCase(unittest.TestCase):
    """Exercise profile flows against an isolated SQLite database and upload path."""

    def setUp(self) -> None:
        """Create an authenticated test client with isolated persistence."""
        self.app = create_app(
            {
                "TESTING": True,
                "SECRET_KEY": "test-only-secret",
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SQLALCHEMY_ENGINE_OPTIONS": {},
            }
        )
        self.upload_directory = tempfile.TemporaryDirectory(
            prefix="profile-test-", dir=self.app.static_folder
        )
        self.app.config["PROFILE_AVATAR_UPLOAD_DIR"] = self.upload_directory.name
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()
            self.user = self._create_user("profile_user", "profile@example.com")
            db.session.commit()
            self.user_id = self.user.id
        self.login()

    def tearDown(self) -> None:
        """Remove database state and temporary avatar uploads after each test."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
        self.upload_directory.cleanup()

    @staticmethod
    def _create_user(username: str, email: str) -> User:
        """Build and stage a user with known credentials for a test."""
        user = User(
            username=username,
            email=email,
            full_name="Profile User",
            role="user",
            is_active=True,
        )
        user.set_password("Current1234")
        db.session.add(user)
        return user

    def login(self, password: str = "Current1234") -> None:
        """Authenticate the primary test user into the current test client."""
        response = self.client.post(
            "/api/auth/login",
            json={"identity": "profile_user", "password": password},
        )
        self.assertEqual(response.status_code, 200)

    def test_get_profile_excludes_password_hash(self) -> None:
        """Authenticated profile reads return public data only."""
        response = self.client.get("/api/profile")
        payload = response.get_json()

        self.assertEqual(response.status_code, 200)
        self.assertEqual(payload["profile"]["email"], "profile@example.com")
        self.assertNotIn("password_hash", payload["profile"])

    def test_update_profile_persists_name_and_email(self) -> None:
        """A valid profile update is persisted and returned to the client."""
        response = self.client.patch(
            "/api/profile",
            json={"full_name": "Updated Profile", "email": "updated@example.com"},
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["profile"]["full_name"], "Updated Profile")
        with self.app.app_context():
            user = db.session.get(User, self.user_id)
            self.assertEqual(user.email, "updated@example.com")

    def test_update_profile_rejects_duplicate_email(self) -> None:
        """An email belonging to another account produces a clear 400 response."""
        with self.app.app_context():
            self._create_user("other_user", "taken@example.com")
            db.session.commit()

        response = self.client.patch(
            "/api/profile",
            json={"full_name": "Updated Profile", "email": "taken@example.com"},
        )

        self.assertEqual(response.status_code, 400)
        self.assertIn("already in use", response.get_json()["message"])

    def test_update_profile_rejects_malformed_email(self) -> None:
        """Malformed emails are rejected before database persistence."""
        response = self.client.patch(
            "/api/profile",
            json={"full_name": "Updated Profile", "email": "not-an-email"},
        )

        self.assertEqual(response.status_code, 400)
        self.assertIn("valid email", response.get_json()["message"])

    def test_change_password_rotates_credentials_and_invalidates_session(self) -> None:
        """A valid password change persists the hash and revokes the old session."""
        response = self.client.post(
            "/api/profile/password",
            json={
                "current_password": "Current1234",
                "new_password": "NewPassword1234",
                "confirm_password": "NewPassword1234",
            },
        )

        self.assertEqual(response.status_code, 200)
        self.assertEqual(self.client.get("/api/profile").status_code, 401)
        self.login("NewPassword1234")
        with self.app.app_context():
            user = db.session.get(User, self.user_id)
            self.assertTrue(user.check_password("NewPassword1234"))
            self.assertEqual(user.session_version, 1)

    def test_change_password_rejects_wrong_current_password(self) -> None:
        """An incorrect current password does not change stored credentials."""
        response = self.client.post(
            "/api/profile/password",
            json={
                "current_password": "Incorrect1234",
                "new_password": "NewPassword1234",
                "confirm_password": "NewPassword1234",
            },
        )

        self.assertEqual(response.status_code, 401)
        with self.app.app_context():
            self.assertTrue(db.session.get(User, self.user_id).check_password("Current1234"))

    def test_change_password_rejects_weak_password(self) -> None:
        """A weak replacement password is rejected with a validation error."""
        response = self.client.post(
            "/api/profile/password",
            json={
                "current_password": "Current1234",
                "new_password": "weak",
                "confirm_password": "weak",
            },
        )

        self.assertEqual(response.status_code, 400)
        self.assertIn("Password must be", response.get_json()["message"])

    def test_upload_avatar_persists_metadata_and_file_reference(self) -> None:
        """A valid avatar upload stores the file reference and safe metadata."""
        response = self.client.post(
            "/api/profile/avatar",
            data={"avatar": (BytesIO(b"test-png-content"), "portrait.png", "image/png")},
            content_type="multipart/form-data",
        )
        payload = response.get_json()

        self.assertEqual(response.status_code, 200)
        self.assertTrue(payload["avatar_url"].startswith("/static/"))
        self.assertEqual(payload["profile"]["avatar_mime_type"], "image/png")
        self.assertIsNotNone(payload["profile"]["avatar_uploaded_at"])
        self.assertEqual(len(list(Path(self.upload_directory.name).iterdir())), 1)

    def test_upload_avatar_rejects_invalid_type_and_oversized_file(self) -> None:
        """Unsafe file types and files above the size limit are rejected."""
        invalid_type = self.client.post(
            "/api/profile/avatar",
            data={"avatar": (BytesIO(b"not-an-image"), "avatar.exe", "application/octet-stream")},
            content_type="multipart/form-data",
        )
        oversized = self.client.post(
            "/api/profile/avatar",
            data={
                "avatar": (
                    BytesIO(b"x" * (MAX_AVATAR_SIZE_BYTES + 1)),
                    "avatar.png",
                    "image/png",
                )
            },
            content_type="multipart/form-data",
        )

        self.assertEqual(invalid_type.status_code, 400)
        self.assertEqual(oversized.status_code, 400)
        self.assertIn("5 MB", oversized.get_json()["message"])
        self.assertEqual(list(Path(self.upload_directory.name).iterdir()), [])


if __name__ == "__main__":
    unittest.main()
