"""Integration tests for Account Authentication API endpoints."""

import sys
import unittest
from datetime import datetime, timedelta
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import SearchLog, User, db


class AuthTestCase(unittest.TestCase):
    """Exercise authentication routes against an isolated SQLite database."""

    def setUp(self) -> None:
        """Create a test app and fresh in-memory database for each test."""
        self.app = create_app(
            {
                "TESTING": True,
                "SECRET_KEY": "test-only-secret",
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SQLALCHEMY_ENGINE_OPTIONS": {},
            }
        )
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()

    def tearDown(self) -> None:
        """Remove sessions and tables so test data cannot leak between tests."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    @staticmethod
    def registration_payload(**overrides: str) -> dict[str, str]:
        """Return a valid registration payload with optional overridden fields."""
        payload = {
            "username": "reader_one",
            "email": "reader@example.com",
            "password": "Reader1234",
            "full_name": "Reader One",
        }
        payload.update(overrides)
        return payload

    def register(self, **overrides: str):
        """Register a user through the public API."""
        return self.client.post("/api/auth/register", json=self.registration_payload(**overrides))

    def login(self, identity: str = "reader_one", password: str = "Reader1234"):
        """Authenticate through the public API."""
        return self.client.post("/api/auth/login", json={"identity": identity, "password": password})

    def request_reset(self, email: str = "reader@example.com"):
        """Request password-reset delivery through the public API."""
        return self.client.post("/api/auth/password-reset/request", json={"email": email})

    def test_register_valid_user(self) -> None:
        """A valid registration persists a user with a non-plaintext password."""
        response = self.register()
        self.assertEqual(response.status_code, 201)
        self.assertEqual(response.get_json()["user"]["username"], "reader_one")

        with self.app.app_context():
            user = User.query.filter_by(email="reader@example.com").one()
            self.assertNotEqual(user.password_hash, "Reader1234")
            self.assertTrue(user.check_password("Reader1234"))

    def test_register_duplicate_email(self) -> None:
        """An existing email is rejected without creating another account."""
        self.assertEqual(self.register().status_code, 201)
        response = self.register(username="reader_two")
        self.assertEqual(response.status_code, 400)
        self.assertIn("already registered", response.get_json()["message"])

    def test_register_duplicate_username(self) -> None:
        """An existing username is rejected without creating another account."""
        self.assertEqual(self.register().status_code, 201)
        response = self.register(email="other@example.com")
        self.assertEqual(response.status_code, 400)
        self.assertIn("already registered", response.get_json()["message"])

    def test_register_weak_password(self) -> None:
        """A weak password is rejected with a password-specific explanation."""
        response = self.register(password="abc")
        self.assertEqual(response.status_code, 400)
        self.assertIn("Password must be", response.get_json()["message"])

    def test_register_invalid_email(self) -> None:
        """An invalid email is rejected before database persistence."""
        response = self.register(email="not-an-email")
        self.assertEqual(response.status_code, 400)
        self.assertIn("Invalid email format", response.get_json()["message"])

    def test_register_missing_fields(self) -> None:
        """Required registration fields cannot be blank."""
        for field in ("username", "email"):
            with self.subTest(field=field):
                response = self.register(**{field: ""})
                self.assertEqual(response.status_code, 400)

    def test_login_valid_credentials(self) -> None:
        """Correct credentials create a session and provide role redirect data."""
        self.register()
        response = self.login()
        data = response.get_json()
        self.assertEqual(response.status_code, 200)
        self.assertEqual(data["redirect_url"], "/dashboard/user")
        self.assertEqual(data["user"]["email"], "reader@example.com")

    def test_login_by_email(self) -> None:
        """The login identity accepts a registered email address."""
        self.register()
        response = self.login(identity="reader@example.com")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json()["user"]["username"], "reader_one")

    def test_login_wrong_password(self) -> None:
        """A wrong password receives the generic authentication error."""
        self.register()
        response = self.login(password="Wrong1234")
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.get_json()["message"], "Invalid username/email or password.")

    def test_login_nonexistent_user(self) -> None:
        """An unknown identity receives the same error as a wrong password."""
        response = self.login(identity="unknown", password="Wrong1234")
        self.assertEqual(response.status_code, 401)
        self.assertEqual(response.get_json()["message"], "Invalid username/email or password.")

    def test_logout_clears_session(self) -> None:
        """Logout invalidates the session used by the test client."""
        self.register()
        self.assertEqual(self.login().status_code, 200)
        self.assertEqual(self.client.post("/api/auth/logout").status_code, 200)
        self.assertEqual(self.client.get("/api/auth/me").get_json(), {"authenticated": False})

    def test_logout_deletes_only_current_users_search_history(self) -> None:
        self.register()
        self.assertEqual(self.login().status_code, 200)
        with self.app.app_context():
            current_user = User.query.filter_by(username="reader_one").one()
            other_user = User(username="reader_two", email="other@example.com", role="user")
            other_user.set_password("Reader1234")
            db.session.add(other_user)
            db.session.flush()
            db.session.add_all([
                SearchLog(keyword="private", user_id=current_user.id),
                SearchLog(keyword="other", user_id=other_user.id),
            ])
            db.session.commit()

        self.assertEqual(self.client.post("/api/auth/logout").status_code, 200)
        with self.app.app_context():
            self.assertEqual(SearchLog.query.filter_by(keyword="private").count(), 0)
            self.assertEqual(SearchLog.query.filter_by(keyword="other").count(), 1)

    def test_auth_me_authenticated(self) -> None:
        """An active session exposes the serialized current user profile."""
        self.register()
        self.login()
        response = self.client.get("/api/auth/me")
        self.assertEqual(response.status_code, 200)
        self.assertTrue(response.get_json()["authenticated"])
        self.assertEqual(response.get_json()["user"]["username"], "reader_one")

    def test_auth_me_unauthenticated(self) -> None:
        """Without a session, the current-user endpoint stays anonymous."""
        response = self.client.get("/api/auth/me")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.get_json(), {"authenticated": False})

    @patch("services.auth_service.send_password_reset_email")
    def test_password_reset_request_is_enumeration_safe(self, send_email) -> None:
        """Active, inactive, and unknown emails receive one identical response."""
        self.register()
        with self.app.app_context():
            inactive = User(username="inactive", email="inactive@example.com", role="user", is_active=False)
            inactive.set_password("Inactive1234")
            db.session.add(inactive)
            db.session.commit()

        responses = [
            self.request_reset("reader@example.com"),
            self.request_reset("inactive@example.com"),
            self.request_reset("unknown@example.com"),
        ]
        expected = "If an active account matches this email, a password-reset link has been sent."
        self.assertTrue(all(response.status_code == 202 for response in responses))
        self.assertTrue(all(response.get_json()["message"] == expected for response in responses))
        self.assertEqual(send_email.call_count, 1)

    @patch("services.auth_service.send_password_reset_email")
    def test_password_reset_token_is_hashed_and_single_use(self, send_email) -> None:
        """Only a hash is persisted, and a valid token cannot be reused."""
        self.register()
        self.request_reset()
        raw_token = send_email.call_args.args[1]
        with self.app.app_context():
            user = User.query.filter_by(email="reader@example.com").one()
            self.assertNotEqual(user.password_reset_token_hash, raw_token)
            self.assertIsNotNone(user.password_reset_expires_at)

        first = self.client.post("/api/auth/password-reset/confirm", json={"token": raw_token, "password": "NewReader1234"})
        second = self.client.post("/api/auth/password-reset/confirm", json={"token": raw_token, "password": "OtherReader1234"})
        self.assertEqual(first.status_code, 200)
        self.assertEqual(second.status_code, 400)
        self.assertEqual(second.get_json()["message"], "This password-reset link is invalid or has expired.")

    @patch("services.auth_service.send_password_reset_email")
    def test_password_reset_rejects_expired_or_invalid_token(self, send_email) -> None:
        """Expired and unknown tokens share the same safe failure response."""
        self.register()
        self.request_reset()
        expired_token = send_email.call_args.args[1]
        with self.app.app_context():
            user = User.query.filter_by(email="reader@example.com").one()
            user.password_reset_expires_at = datetime.utcnow() - timedelta(seconds=1)
            db.session.commit()

        expired = self.client.post("/api/auth/password-reset/confirm", json={"token": expired_token, "password": "NewReader1234"})
        invalid = self.client.post("/api/auth/password-reset/confirm", json={"token": "unknown-token", "password": "NewReader1234"})
        self.assertEqual(expired.status_code, 400)
        self.assertEqual(invalid.status_code, 400)
        self.assertEqual(expired.get_json()["message"], invalid.get_json()["message"])

    @patch("services.auth_service.send_password_reset_email")
    def test_password_reset_changes_credentials_and_invalidates_session(self, send_email) -> None:
        """A reset revokes the existing session and accepts only the new password."""
        self.register()
        self.assertEqual(self.login().status_code, 200)
        self.request_reset()
        raw_token = send_email.call_args.args[1]
        reset = self.client.post("/api/auth/password-reset/confirm", json={"token": raw_token, "password": "NewReader1234"})
        self.assertEqual(reset.status_code, 200)
        self.assertEqual(self.client.get("/api/auth/me").get_json(), {"authenticated": False})
        self.assertEqual(self.login(password="Reader1234").status_code, 401)
        self.assertEqual(self.login(password="NewReader1234").status_code, 200)


if __name__ == "__main__":
    unittest.main()
