"""Integration tests for admin scraper triggering endpoints."""

import sys
import unittest
from pathlib import Path
import threading
import time
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import User, ScraperRun, db
from services.scheduler_service import SchedulerService, _scraper_lock


class ScraperRunsTestCase(unittest.TestCase):
    """Verify concurrency locks, rate limits, and ScraperRun persistence."""

    def setUp(self) -> None:
        """Create a test app, in-memory DB, and an admin user."""
        self.app = create_app({
            "TESTING": True,
            "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
            "SQLALCHEMY_ENGINE_OPTIONS": {}
        })
        self.client = self.app.test_client()
        
        with self.app.app_context():
            db.create_all()
            
            # Reset global state that might have been initialized by app.py import
            SchedulerService._scheduler = None
            SchedulerService.init_app(self.app)
            
            # Create an admin user
            self.admin = User(
                email="admin@test.com",
                role="admin"
            )
            self.admin.set_password("Admin123")
            db.session.add(self.admin)
            db.session.commit()
            
            self.admin_id = self.admin.id

        # Authenticate the test client
        self.client.post("/api/auth/login", json={
            "identity": "admin@test.com",
            "password": "Admin123"
        })

    def tearDown(self) -> None:
        """Clean up database session and drop all tables."""
        with self.app.app_context():
            db.session.remove()
            db.drop_all()
            
            # Reset lock if left locked
            if _scraper_lock.locked():
                _scraper_lock.release()

    @patch('threading.Thread')
    @patch('scraper.dynamic_scraper.DynamicScraper.scrape', return_value=[])
    def test_manual_trigger_logs_scraper_run(self, mock_scraper_run, mock_thread):
        """Verify that triggering manual scrape logs a ScraperRun in DB."""
        def mock_thread_init(*args, **kwargs):
            class MockThreadObj:
                def start(self):
                    kwargs.get('target', lambda **k: None)(**kwargs.get('kwargs', {}))
            return MockThreadObj()
        
        mock_thread.side_effect = mock_thread_init
        
        response = self.client.post("/api/admin/scraper/runs")
        self.assertEqual(response.status_code, 202)
        
        # Wait for the background thread to create the record
        time.sleep(0.5)
        
        with self.app.app_context():
            run = ScraperRun.query.filter_by(trigger_type="manual").first()
            self.assertIsNotNone(run)
            self.assertEqual(run.triggered_by_id, self.admin_id)

    def test_rate_limit_cooldown(self):
        """Verify calling the trigger twice within 60s returns 429."""
        # Manually create a recent run
        with self.app.app_context():
            from services.time_service import vietnam_now
            recent_run = ScraperRun(
                trigger_type="manual",
                triggered_by_id=self.admin_id,
                started_at=vietnam_now(),
                status="completed"
            )
            db.session.add(recent_run)
            db.session.commit()
            
        response = self.client.post("/api/admin/scraper/runs")
        self.assertEqual(response.status_code, 429)
        self.assertIn("Rate limit reached", response.get_json()["message"])

    def test_concurrency_lock(self):
        """Verify triggering while another job is running returns 409."""
        # Simulate an ongoing scraper run by acquiring the lock
        _scraper_lock.acquire()
        
        try:
            response = self.client.post("/api/admin/scraper/runs")
            self.assertEqual(response.status_code, 409)
            self.assertIn("Scraper is already running", response.get_json()["message"])
        finally:
            _scraper_lock.release()


if __name__ == "__main__":
    unittest.main()
