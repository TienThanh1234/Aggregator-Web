"""Tests for deterministic, account-scoped news recommendations."""

from __future__ import annotations

import sys
import unittest
from datetime import timedelta
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import (
    Article,
    ArticleStoryMembership,
    Bookmark,
    Category,
    ScraperConfig,
    StoryCluster,
    User,
    db,
)
from services.recommendation_service import get_recommendations, validate_limit
from services.time_service import vietnam_now


class RecommendationServiceTestCase(unittest.TestCase):
    """Exercise recommendations against an isolated SQLite database."""

    def setUp(self) -> None:
        self.app = create_app(
            {
                "TESTING": True,
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SQLALCHEMY_ENGINE_OPTIONS": {},
                "SECRET_KEY": "recommendation-test",
            }
        )
        with self.app.app_context():
            db.create_all()
            self.tech = Category(name="Technology")
            self.business = Category(name="Business")
            self.user = User(username="reader", email="reader@example.com", role="user")
            self.user.set_password("Password123")
            db.session.add_all([self.tech, self.business, self.user])
            db.session.commit()
            self.user_id = self.user.id

    def tearDown(self) -> None:
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def article(
        self,
        title: str,
        categories: list[Category] | None = None,
        days_old: int = 0,
        deleted: bool = False,
        truth_score: float = 80,
    ) -> Article:
        timestamp = vietnam_now() - timedelta(days=days_old)
        article = Article(
            title=title,
            description=f"Description for {title}",
            raw_content=f"Content for {title}",
            source_url=f"https://{title.lower().replace(' ', '-')}.example/news",
            published_at=timestamp,
            scraped_at=timestamp,
            truth_score=truth_score,
            is_deleted=deleted,
        )
        article.categories.extend(categories or [])
        db.session.add(article)
        db.session.flush()
        return article

    def bookmark(self, article: Article) -> None:
        db.session.add(Bookmark(user_id=self.user_id, article_id=article.id))
        db.session.flush()

    def source(self, domain: str) -> ScraperConfig:
        source = ScraperConfig(
            source_name=domain,
            source_domain=domain,
            target_url=f"https://{domain}",
            article_list_selector="article",
            title_selector="h1",
            description_selector="p",
            content_selector="main",
        )
        db.session.add(source)
        db.session.flush()
        return source

    def accepted_cluster(self, canonical: Article, *members: Article) -> StoryCluster:
        cluster = StoryCluster(
            canonical_article_id=canonical.id,
            accepted_article_count=len(members) + 1,
            independent_domain_count=len(members) + 1,
            trending_score=72,
        )
        db.session.add(cluster)
        db.session.flush()
        for article in (canonical, *members):
            db.session.add(
                ArticleStoryMembership(
                    article_id=article.id,
                    cluster_id=cluster.id,
                    match_confidence=1.0,
                    status="accepted",
                )
            )
        db.session.flush()
        return cluster

    def test_bookmark_topic_and_followed_category_rank_with_reason(self) -> None:
        with self.app.app_context():
            self.user.subscribed_categories.append(self.tech)
            saved = self.article("Saved technology report", [self.tech])
            self.bookmark(saved)
            candidate = self.article("New technology report", [self.tech])
            self.article("Business report", [self.business])
            db.session.commit()

            result = get_recommendations(self.user_id)

            self.assertEqual(result["items"][0]["article"]["id"], candidate.id)
            self.assertEqual(
                result["items"][0]["reason"], "Because you saved similar topics"
            )

    def test_saved_story_has_reason_precedence_and_cluster_diversity(self) -> None:
        with self.app.app_context():
            saved = self.article("Saved event", [self.tech])
            canonical = self.article("Canonical follow-up", [self.tech])
            alternate = self.article("Alternate follow-up", [self.tech])
            self.bookmark(saved)
            self.accepted_cluster(canonical, saved, alternate)
            db.session.commit()

            result = get_recommendations(self.user_id)

            self.assertEqual(len(result["items"]), 1)
            self.assertEqual(result["items"][0]["article"]["id"], canonical.id)
            self.assertEqual(
                result["items"][0]["reason"], "More coverage of a saved story"
            )

    def test_excludes_bookmarked_deleted_and_old_articles(self) -> None:
        with self.app.app_context():
            saved = self.article("Saved article", [self.tech])
            self.bookmark(saved)
            valid = self.article("Current related article", [self.tech])
            self.article("Deleted related article", [self.tech], deleted=True)
            self.article("Old related article", [self.tech], days_old=31)
            db.session.commit()

            result = get_recommendations(self.user_id)
            returned_ids = {item["article"]["id"] for item in result["items"]}

            self.assertEqual(returned_ids, {valid.id})
            self.assertNotIn(saved.id, returned_ids)

    def test_empty_profile_does_not_fall_back_to_global_trending(self) -> None:
        with self.app.app_context():
            self.article("Global article", [self.tech])
            db.session.commit()

            result = get_recommendations(self.user_id)

            self.assertEqual(result["items"], [])
            self.assertEqual(result["meta"]["empty_state"], "no_profile")

    def test_limit_validation_and_repeated_order_are_deterministic(self) -> None:
        with self.app.app_context():
            self.user.subscribed_categories.append(self.tech)
            first = self.article("First technology article", [self.tech])
            second = self.article("Second technology article", [self.tech])
            db.session.commit()

            one = get_recommendations(self.user_id, validate_limit("1"))
            repeat = get_recommendations(self.user_id, 5)

            self.assertEqual(len(one["items"]), 1)
            self.assertEqual(
                [item["article"]["id"] for item in repeat["items"]],
                [second.id, first.id],
            )
            with self.assertRaises(ValueError):
                validate_limit("11")

    def test_followed_source_and_score_cap(self) -> None:
        with self.app.app_context():
            source = self.source("trusted.example")
            self.user.subscribed_sources.append(source)
            self.user.subscribed_categories.append(self.tech)
            saved = self.article("Saved source topic", [self.tech])
            self.bookmark(saved)
            candidate = self.article("Trusted source topic", [self.tech])
            candidate.source_url = "https://trusted.example/follow-up"
            db.session.commit()

            result = get_recommendations(self.user_id)

            item = result["items"][0]
            self.assertEqual(item["article"]["id"], candidate.id)
            self.assertEqual(item["reason"], "Because you saved similar topics")
            self.assertEqual(item["recommendation_score"], 55)

    def test_score_is_capped_at_one_hundred(self) -> None:
        with self.app.app_context():
            source = self.source("trusted.example")
            self.user.subscribed_sources.append(source)
            self.user.subscribed_categories.append(self.tech)
            saved = self.article("Saved event", [self.tech], truth_score=100)
            candidate = self.article("Canonical event", [self.tech], truth_score=100)
            candidate.source_url = "https://trusted.example/follow-up"
            self.bookmark(saved)
            self.accepted_cluster(candidate, saved)
            db.session.commit()

            result = get_recommendations(self.user_id)

            self.assertEqual(result["items"][0]["recommendation_score"], 100)

    def test_cluster_falls_back_when_canonical_is_ineligible(self) -> None:
        with self.app.app_context():
            saved = self.article("Saved cluster event", [self.tech])
            expired_canonical = self.article("Expired canonical", [self.tech], days_old=31)
            follow_up = self.article("Eligible follow up", [self.tech])
            self.bookmark(saved)
            self.accepted_cluster(expired_canonical, saved, follow_up)
            db.session.commit()

            result = get_recommendations(self.user_id)

            self.assertEqual([item["article"]["id"] for item in result["items"]], [follow_up.id])

    def test_unclustered_results_are_account_scoped(self) -> None:
        with self.app.app_context():
            other = User(username="other", email="other@example.com", role="user")
            other.set_password("Password123")
            other.subscribed_categories.append(self.business)
            self.user.subscribed_categories.append(self.tech)
            tech_article = self.article("Account one technology", [self.tech])
            self.article("Other account business", [self.business])
            db.session.add(other)
            db.session.commit()

            result = get_recommendations(self.user_id)

            self.assertEqual([item["article"]["id"] for item in result["items"]], [tech_article.id])

    def test_candidate_query_caps_results_before_scoring(self) -> None:
        with self.app.app_context():
            self.user.subscribed_categories.append(self.tech)
            for index in range(251):
                self.article(f"Candidate {index:03d}", [self.tech])
            db.session.commit()

            result = get_recommendations(self.user_id, limit=10)
            returned_titles = {item["article"]["title"] for item in result["items"]}

            self.assertNotIn("Candidate 000", returned_titles)
            self.assertEqual(len(result["items"]), 10)


if __name__ == "__main__":
    unittest.main()
