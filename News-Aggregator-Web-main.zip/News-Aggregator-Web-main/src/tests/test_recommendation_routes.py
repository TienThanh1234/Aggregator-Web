"""HTTP and server-rendering contracts for Recommended News Feed."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, Category, User, db


class RecommendationRouteTestCase(unittest.TestCase):
    """Set up an authenticated user and simple feed fixture per test."""

    def setUp(self) -> None:
        self.app = create_app(
            {
                "TESTING": True,
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SQLALCHEMY_ENGINE_OPTIONS": {},
                "SECRET_KEY": "recommendation-route-test",
            }
        )
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()
            category = Category(name="Technology")
            user = User(username="route_reader", email="route@example.com", role="user")
            user.set_password("Password123")
            user.subscribed_categories.append(category)
            article = Article(
                title="Recommendation route article",
                description="Safe description",
                raw_content="Safe content",
                source_url="https://route.example/article",
                truth_score=80,
            )
            article.categories.append(category)
            db.session.add_all([category, user, article])
            db.session.commit()
            self.user_id = user.id
            self.session_version = user.session_version

    def tearDown(self) -> None:
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def sign_in_session(self) -> None:
        with self.client.session_transaction() as session:
            session["user_id"] = self.user_id
            session["role"] = "user"
            session["session_version"] = self.session_version

    def test_guest_has_no_panel_and_api_requires_authentication(self) -> None:
        page = self.client.get("/")
        api = self.client.get("/api/recommendations")

        self.assertEqual(page.status_code, 200)
        self.assertNotIn(b"recommended-news-panel", page.data)
        self.assertEqual(api.status_code, 401)

    def test_authenticated_page_and_api_render_private_recommendations(self) -> None:
        self.sign_in_session()

        page = self.client.get("/")
        api = self.client.get("/api/recommendations?limit=1")

        self.assertEqual(page.status_code, 200)
        self.assertIn(b"recommended-news-panel", page.data)
        self.assertIn(b"Recommendation route article", page.data)
        self.assertEqual(api.status_code, 200)
        data = api.get_json()["data"]
        self.assertEqual(len(data["items"]), 1)
        self.assertNotIn("seed_article_ids", data)
        self.assertEqual(data["items"][0]["article"]["canonical_path"], "/articles/1")
        self.assertNotIn("raw_content", data["items"][0]["article"])
        self.assertNotIn("subscribed_category_ids", data)

    def test_ssr_escapes_article_title(self) -> None:
        with self.app.app_context():
            article = Article.query.first()
            article.title = "<script>unsafe()</script>"
            db.session.commit()
        self.sign_in_session()

        response = self.client.get("/")

        self.assertEqual(response.status_code, 200)
        self.assertIn(b"&lt;script&gt;unsafe()&lt;/script&gt;", response.data)
        self.assertNotIn(b"<script>unsafe()</script>", response.data)

    def test_invalid_limit_returns_bad_request(self) -> None:
        self.sign_in_session()
        response = self.client.get("/api/recommendations?limit=11")
        self.assertEqual(response.status_code, 400)

    def test_recommendation_failure_keeps_main_page_available(self) -> None:
        self.sign_in_session()
        with patch("routes.get_recommendations", side_effect=RuntimeError("test")):
            response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Recommendations are temporarily unavailable", response.data)


if __name__ == "__main__":
    unittest.main()
