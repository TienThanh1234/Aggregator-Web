"""Contract tests for the server-rendered hybrid MPA pages."""

from __future__ import annotations

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, Category, User, db


class MpaRouteTestCase(unittest.TestCase):
    """Provide isolated application state for page contract tests."""

    def setUp(self) -> None:
        self.app = create_app(
            {
                "TESTING": True,
                "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:",
                "SQLALCHEMY_ENGINE_OPTIONS": {},
                "SECRET_KEY": "test-secret",
            }
        )
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()

    def tearDown(self) -> None:
        with self.app.app_context():
            db.session.remove()
            db.drop_all()

    def create_article(
        self,
        title: str = "Hybrid MPA Dispatch",
        category: str = "Công nghệ",
    ) -> int:
        with self.app.app_context():
            topic = Category.query.filter_by(name=category).first()
            if topic is None:
                topic = Category(name=category)
                db.session.add(topic)
            article = Article(
                title=title,
                description=f"Summary for {title}",
                raw_content=f"{title} paragraph one.\n\nParagraph two.",
                source_url=f"https://example.com/{title.lower().replace(' ', '-')}",
                truth_score=0.91,
            )
            article.categories.append(topic)
            db.session.add(article)
            db.session.commit()
            return article.id

    def create_user(self) -> tuple[str, str]:
        with self.app.app_context():
            user = User(
                username="mpa_reader",
                email="reader@example.com",
                full_name="MPA Reader",
                role="user",
            )
            user.set_password("SecurePass123")
            db.session.add(user)
            db.session.commit()
        return "mpa_reader", "SecurePass123"

    def sign_in(self) -> None:
        identity, password = self.create_user()
        response = self.client.post(
            "/api/auth/login",
            json={"identity": identity, "password": password},
        )
        self.assertEqual(response.status_code, 200)


class TestArticlePage(MpaRouteTestCase):
    def test_article_page_returns_article_content(self) -> None:
        article_id = self.create_article()
        response = self.client.get(f"/articles/{article_id}")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Hybrid MPA Dispatch", response.data)
        self.assertIn(b"Paragraph two.", response.data)

    def test_article_page_has_og_meta_tags(self) -> None:
        article_id = self.create_article()
        response = self.client.get(f"/articles/{article_id}")
        self.assertIn(b'property="og:title"', response.data)
        self.assertIn(b'property="og:description"', response.data)
        self.assertIn(b'property="og:type" content="article"', response.data)

    def test_article_page_404_for_missing_id(self) -> None:
        response = self.client.get("/articles/99999")
        self.assertEqual(response.status_code, 404)
        self.assertIn(b"Dispatch Not Found", response.data)

    def test_article_page_404_for_invalid_id(self) -> None:
        response = self.client.get("/articles/abc")
        self.assertEqual(response.status_code, 404)

    def test_article_page_has_back_link_to_feed(self) -> None:
        article_id = self.create_article()
        response = self.client.get(f"/articles/{article_id}")
        self.assertIn(b'href="/"', response.data)

    def test_article_page_has_tememo_panel(self) -> None:
        article_id = self.create_article()
        response = self.client.get(f"/articles/{article_id}")
        self.assertIn(b'id="tememo-panel"', response.data)
        self.assertIn(b'data-tab="factcheck"', response.data)

    def test_article_page_loads_article_js(self) -> None:
        article_id = self.create_article()
        response = self.client.get(f"/articles/{article_id}")
        self.assertIn(b"js/article.js", response.data)


class TestFeedPage(MpaRouteTestCase):
    def test_index_returns_html_with_articles(self) -> None:
        self.create_article("Server Rendered Story")
        response = self.client.get("/")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"Server Rendered Story", response.data)
        self.assertIn(b"/articles/", response.data)

    def test_index_category_filter(self) -> None:
        self.create_article("Technology Story", "Công nghệ")
        self.create_article("Economy Story", "Kinh doanh")
        response = self.client.get("/?category=Technology")
        self.assertIn(b"Technology Story", response.data)
        self.assertNotIn(b"Summary for Economy Story", response.data)

    def test_index_pagination(self) -> None:
        for index in range(25):
            self.create_article(f"Story {index:02d}")
        first_page = self.client.get("/")
        second_page = self.client.get("/?page=2")

        self.assertEqual(first_page.status_code, 200)
        self.assertEqual(second_page.status_code, 200)
        self.assertEqual(first_page.data.count(b'class="card-link'), 21)
        self.assertEqual(second_page.data.count(b'class="card-link'), 4)
        self.assertIn(b"Story 04", first_page.data)
        self.assertNotIn(b"Story 04", second_page.data)
        self.assertIn(b"Story 03", second_page.data)
        self.assertIn(b"Page 2 of 2", second_page.data)

    def test_index_empty_state(self) -> None:
        self.create_article()
        response = self.client.get("/?category=Nonexistent")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"No dispatches found", response.data)


class TestCompatibilityEndpoint(MpaRouteTestCase):
    def test_api_articles_backward_compatible(self) -> None:
        self.create_article()
        response = self.client.get("/api/articles")
        self.assertEqual(response.status_code, 200)
        article = response.get_json()[0]
        expected = {
            "id",
            "title",
            "category",
            "author",
            "date",
            "readTime",
            "image",
            "imageAlt",
            "summary",
            "confidenceScore",
            "unverifiedClaim",
            "unverifiedClaimAnalysis",
            "paragraphs",
            "keyTakeaways",
        }
        self.assertTrue(expected.issubset(article))


class TestProfilePage(MpaRouteTestCase):
    def test_profile_page_redirects_unauthenticated(self) -> None:
        response = self.client.get("/profile")
        self.assertEqual(response.status_code, 302)
        self.assertIn("auth_intent=login", response.location)

    def test_profile_page_renders_for_authenticated(self) -> None:
        self.sign_in()
        response = self.client.get("/profile")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b'id="form-profile-details"', response.data)

    def test_profile_page_prefills_user_data(self) -> None:
        self.sign_in()
        response = self.client.get("/profile")
        self.assertIn(b"MPA Reader", response.data)
        self.assertIn(b"reader@example.com", response.data)


class TestSessionContinuity(MpaRouteTestCase):
    def test_session_persists_from_feed_to_article(self) -> None:
        article_id = self.create_article()
        self.sign_in()
        self.assertEqual(self.client.get("/").status_code, 200)
        self.assertEqual(
            self.client.get(f"/articles/{article_id}").status_code, 200
        )
        self.assertTrue(self.client.get("/api/auth/me").get_json()["authenticated"])

    def test_session_persists_from_article_to_profile(self) -> None:
        article_id = self.create_article()
        self.sign_in()
        self.assertEqual(
            self.client.get(f"/articles/{article_id}").status_code, 200
        )
        response = self.client.get("/profile")
        self.assertEqual(response.status_code, 200)
        self.assertIn(b"reader@example.com", response.data)


if __name__ == "__main__":
    unittest.main()
