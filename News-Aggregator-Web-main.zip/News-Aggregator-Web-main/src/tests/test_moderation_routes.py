"""Authorization and contract tests for Community Moderation routes."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, Comment, CommentFilterEvent, CommentProhibitedTerm, User, db


class ModerationRoutesTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app({"TESTING": True, "SECRET_KEY": "test", "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:", "SQLALCHEMY_ENGINE_OPTIONS": {}})
        self.client = self.app.test_client()
        with self.app.app_context():
            db.create_all()
            self.admin = User(username="admin", email="admin@test.local", role="admin")
            self.admin.set_password("Admin1234")
            self.author = User(username="author", email="author@test.local")
            self.author.set_password("Author1234")
            self.reader = User(username="reader", email="reader@test.local")
            self.reader.set_password("Reader1234")
            article = Article(title="Route story", source_url="https://example.com/route")
            db.session.add_all([self.admin, self.author, self.reader, article]); db.session.flush()
            db.session.add(Comment(user_id=self.author.id, article_id=article.id, content="Report this")); db.session.commit()
            self.comment_id = Comment.query.one().id
            self.reader_id = self.reader.id
            self.article_id = article.id

    def tearDown(self):
        with self.app.app_context(): db.session.remove(); db.drop_all()

    def login(self, identity, password):
        return self.client.post("/api/auth/login", json={"identity": identity, "password": password})

    def test_admin_endpoints_are_protected_and_term_crud_works(self):
        self.assertEqual(self.client.get("/api/admin/moderation/comments").status_code, 401)
        self.login("reader", "Reader1234")
        self.assertEqual(self.client.get("/api/admin/moderation/comments").status_code, 403)
        self.client.post("/api/auth/logout")
        self.login("admin", "Admin1234")
        created = self.client.post("/api/admin/moderation/prohibited-terms", json={"term": "forbidden", "category": "spam"})
        self.assertEqual(created.status_code, 201)
        term_id = created.get_json()["data"]["id"]
        self.assertEqual(self.client.patch(f"/api/admin/moderation/prohibited-terms/{term_id}", json={"is_active": False}).status_code, 200)
        with self.app.app_context():
            db.session.add(CommentFilterEvent(
                user_id=self.reader_id,
                article_id=self.article_id,
                prohibited_term_id=term_id,
            ))
            db.session.commit()
        removed = self.client.delete(f"/api/admin/moderation/prohibited-terms/{term_id}")
        self.assertEqual(removed.status_code, 200)
        with self.app.app_context():
            self.assertIsNone(db.session.get(CommentProhibitedTerm, term_id))
            self.assertIsNone(CommentFilterEvent.query.one().prohibited_term_id)

    def test_report_is_private_and_idempotent(self):
        self.login("reader", "Reader1234")
        first = self.client.post(f"/api/comments/{self.comment_id}/reports", json={"reason": "spam"})
        second = self.client.post(f"/api/comments/{self.comment_id}/reports", json={"reason": "spam"})
        self.assertEqual(first.status_code, 201)
        self.assertEqual(second.status_code, 200)
        self.assertNotIn("reporter", second.get_json())
