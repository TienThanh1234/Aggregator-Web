"""Focused tests for comment filtering and moderation service behavior."""

import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent.parent))

from app import create_app
from models import Article, Comment, CommentFilterEvent, CommentProhibitedTerm, User, db
from services.comment_service import create_comment, get_article_comments
from services.moderation_service import (
    create_comment_report,
    delete_comment_permanently,
    get_moderation_comments,
    hide_comment,
    restore_comment,
)


class ModerationServiceTestCase(unittest.TestCase):
    def setUp(self):
        self.app = create_app({"TESTING": True, "SECRET_KEY": "test", "SQLALCHEMY_DATABASE_URI": "sqlite:///:memory:", "SQLALCHEMY_ENGINE_OPTIONS": {}})
        with self.app.app_context():
            db.create_all()
            self.admin = User(username="admin", email="admin@test.local", role="admin")
            self.admin.set_password("Admin1234")
            self.author = User(username="author", email="author@test.local")
            self.author.set_password("Author1234")
            self.reader = User(username="reader", email="reader@test.local")
            self.reader.set_password("Reader1234")
            self.article = Article(title="Moderation story", source_url="https://example.com/moderation")
            db.session.add_all([self.admin, self.author, self.reader, self.article])
            db.session.commit()
            self.admin_id, self.author_id = self.admin.id, self.author.id
            self.reader_id, self.article_id = self.reader.id, self.article.id

    def tearDown(self):
        with self.app.app_context():
            db.session.remove(); db.drop_all()

    def test_prohibited_term_blocks_before_comment_persistence(self):
        with self.app.app_context():
            db.session.add(CommentProhibitedTerm(display_term="bad word", normalized_term="bad word", created_by_id=self.admin_id))
            db.session.commit()
            result, status = create_comment(self.author_id, self.article_id, "This has BAD---word inside.")
            self.assertEqual(status, 400)
            self.assertIn("community guidelines", result["message"])
            self.assertEqual(Comment.query.count(), 0)
            self.assertEqual(CommentFilterEvent.query.count(), 1)

    def test_report_hide_and_restore_control_public_visibility(self):
        with self.app.app_context():
            comment = Comment(user_id=self.author_id, article_id=self.article_id, content="Needs review")
            db.session.add(comment); db.session.commit()
            report, report_status = create_comment_report(self.reader_id, comment.id, {"reason": "spam"})
            self.assertEqual(report_status, 201)
            hidden, hidden_status = hide_comment(comment.id, self.admin_id, {"reason": "spam"})
            self.assertEqual(hidden_status, 200)
            self.assertEqual(get_article_comments(self.article_id)["total"], 0)
            restored, restored_status = restore_comment(comment.id, self.admin_id, {"reason": "reviewed"})
            self.assertEqual(restored_status, 200)
            self.assertEqual(get_article_comments(self.article_id)["total"], 1)

    def test_deleted_comments_are_only_listed_in_deleted_moderation_filter(self):
        with self.app.app_context():
            comment = Comment(user_id=self.author_id, article_id=self.article_id, content="Remove from queue")
            db.session.add(comment)
            db.session.commit()

            result, status = delete_comment_permanently(
                comment.id, self.admin_id, {"reason": "spam", "confirmed": True}
            )

            self.assertEqual(status, 200)
            self.assertEqual(result["status"], "success")
            self.assertEqual(get_moderation_comments({})["items"], [])
            self.assertEqual(
                [item["id"] for item in get_moderation_comments({"status": "deleted"})["items"]],
                [comment.id],
            )
