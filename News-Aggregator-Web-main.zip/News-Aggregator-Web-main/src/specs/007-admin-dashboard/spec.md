# Feature Specification: Admin Dashboard & Control Management System

**Feature Branch**: `007-admin-dashboard`  
**Created**: 2026-08-03  
**Status**: In Progress / Extended  

**Input**: User description: "Scraper Configuration Panel: This admin tool allows the app owner to update the automated BeautifulSoup scripts whenever a news website changes its layout. It is essential because it keeps the web scrapers working smoothly so the site never stops pulling in fresh data. Manual Scraper Controls: This override toggle allows system administrators to manually trigger data-crawling scripts outside of their usual automated times. It helps admins instantly pull in urgent, breaking news updates or fix data pipelines if they stall. Content Cleanup Filters: This dashboard lets site managers hide broken article links, delete duplicate text entries, or remove rude user comments from public view. It is useful because it helps admins keep the platform clean, professional, and friendly for all visitors. User Ban Tools: This control settings page lets system admins block or remove users who repeatedly break community rules. It is vital for site safety because it keeps disruptive behavior under control and protects good users from spam."

---

## User Scenarios & Testing

### User Story 1 - Dynamic Scraper & Pipeline Configuration Panel (Priority: P1)

As an application owner or system administrator, I want to view and update the CSS selectors, active sources, max article limits, and background scheduler frequencies (scraping & cleanup intervals) directly through the Admin Dashboard so that I can control and tune the automated ingestion pipeline without modifying `.env` files or redeploying code.

**Why this priority**: External news site layouts change and system capacity needs change. Dynamic pipeline configuration guarantees system resilience, operational flexibility, and live performance tuning without app server restarts.

**Independent Test**: An admin can open the Pipeline & Scraper Configuration Panel, toggle active news sources, change max articles per crawl, modify the background scraping interval and cleanup schedule, test CSS selectors with live URL preview, and save changes. The background scheduler and scraper engine immediately apply the updated parameters on their next execution cycles.

**Acceptance Scenarios**:
1. **Given** an admin logged into the Admin Dashboard, **When** navigating to the Pipeline Configuration Panel, **Then** a list of configured news sources is displayed with controls to enable/disable specific sources, adjust max article ingestion limits, and edit active CSS selectors.
2. **Given** a news site updates its HTML layout causing scraper errors, **When** the admin modifies the target selector and clicks "Test Configuration", **Then** the system fetches the target page, applies draft selectors, and presents extracted preview fields to verify accuracy before saving.
3. **Given** pipeline scheduling parameters, **When** the admin updates the scraping interval (e.g., every 30 mins) or the database cleanup schedule (e.g., retain 30 days of data), **Then** APScheduler dynamically reschedules background jobs without server restarts.
4. **Given** validated configuration updates, **When** the admin saves settings, **Then** all rules are persisted to the database (`ScraperConfig` & `SystemSetting` models) and dynamically applied to current and future runs.

---

### User Story 2 - Manual Scraper Overrides and Pipeline Controls (Priority: P2)

As a system administrator, I want manual override controls to trigger data-crawling scripts on demand for specific or all news sources, with lock prevention, execution telemetry, cooldown protection, and run history logging so that I can instantly ingest breaking news updates or kickstart data collection if automated pipelines stall.

**Why this priority**: Automated scheduled crawlers (e.g. hourly jobs) might miss fast-breaking news or lag after technical disruptions. Manual execution controls allow admins to intervene instantly during critical news events or pipeline maintenance.

**Independent Test**: An admin clicks "Run Scraper Now" on the Admin Controls page, and the application immediately initiates an asynchronous crawling task under an execution lock, displaying real-time status logs ("running / completed / failed"), total articles parsed, duplicates skipped, and completion status.

**Acceptance Scenarios**:
1. **Given** an active admin user, **When** clicking the "Trigger Scraping Now" (`POST /api/admin/scraper/runs`) override toggle, **Then** the system launches a background scraping task under a concurrency lock and returns a running status indicator. If a run is active, HTTP 409 is returned.
2. **Given** a manual scraping trigger invoked within 60 seconds of a previous run, **When** the admin clicks trigger, **Then** the system enforces a cooldown with HTTP 429 Rate Limit notice.
3. **Given** scraping job execution, **When** the job completes or fails, **Then** a standardized telemetry record is saved to `ScraperRun` log table (`status`, `started_at`, `completed_at`, `articles_scraped`, `articles_created`, `duplicates_found`, `error_count`).

---

### User Story 3 - Content Cleanup Filters & Moderation Dashboard (Priority: P3)

As a site manager, I want a unified moderation dashboard to filter and hide broken article links with strict public 404 suppression, detect and merge duplicate text entries via content hashing, and remove inappropriate user comments from public view, so that the public platform remains clean, accurate, professional, and safe.

**Why this priority**: Automated web scrapers may occasionally ingest dead links, duplicate content, or malformed entries, while public users might post abusive comments. Moderation tools maintain platform content quality and user trust.

**Independent Test**: An admin can search articles in the Content Cleanup view, mark a broken link as "Hidden" or resolve duplicate records in a dedicated Duplicates Console, and verify that those items are immediately suppressed from public feeds, search results, and detail pages (returning public 404).

**Acceptance Scenarios**:
1. **Given** an article with a broken source URL or inappropriate content, **When** an admin selects "Hide Article" in the Content Cleanup Dashboard, **Then** the article's visibility status changes (`is_deleted = True` / `is_visible = False`), an audit log entry (`AdminAuditLog`) is recorded, and the article is suppressed across all public feeds, search indices, and detail pages (returning HTTP 404).
2. **Given** duplicate articles ingested with matching `content_hash` or `title_fingerprint`, **When** an admin views the Duplicate Content Detector panel and selects "Soft-Hide / Merge Duplicates", **Then** secondary records are soft-deleted and linked to the primary article ID with an audit trail.
3. **Given** a user comment reported or identified as abusive/rude, **When** an admin clicks "Delete Comment", **Then** the comment is soft-deleted or permanently removed from the public discussion section.

---

### User Story 4 - User Ban & Access Control Tools (Priority: P4)

As a system administrator, I want tools to manage user account statuses and ban or unban users who violate community guidelines, so that disruptive behavior, spam, and platform abuse are quickly contained.

**Why this priority**: Protecting genuine users from spammers and toxic behavior is critical for maintaining community safety and engagement.

**Independent Test**: An admin searches for a user in the User Ban Tools panel, inputs a ban reason, and toggles "Ban User". The targeted user account status is updated to `banned`, their active sessions are invalidated, and subsequent login or commenting attempts are blocked with an informative message.

**Acceptance Scenarios**:
1. **Given** an admin managing community users, **When** searching by username/email and clicking "Ban User", **Then** the admin is prompted to confirm the action, and account status is updated to `banned`.
2. **Given** a user marked as `banned`, **When** that user attempts to log in or post comments/bookmarks, **Then** access is denied with a clear notification ("Your account has been suspended.").
3. **Given** a banned user account, **When** an admin reviews the user list and clicks "Unban User", **Then** account access is fully restored.

---

## Technical & Requirements Mapping

### Functional Requirements

- **FR-001**: All Admin Dashboard pages (`/dashboard/admin`) and API endpoints (`/api/admin/*`) MUST strictly check `user.role == 'admin'` and deny unauthorized access with HTTP 403 Forbidden.
- **FR-002**: The system MUST provide `ScraperConfig` to store per-source BeautifulSoup CSS/HTML selectors for listing, title, description, content, cover image, and date.
- **FR-003**: The scraper engine MUST support dynamic configuration loading from `ScraperConfig` database rows.
- **FR-004**: The system MUST provide a live selector preview test endpoint (`POST /api/admin/scraper/test`) to validate draft selectors against target URLs.
- **FR-005**: The system MUST provide manual scraper triggers (`POST /api/admin/scraper/runs`) protected by concurrency locks (`_scraper_lock`) and rate-limit cooldowns.
- **FR-006**: The system MUST persist all manual and scheduled scraping runs in a `ScraperRun` log table capturing standardized telemetry (`status`, `started_at`, `completed_at`, `articles_scraped`, `articles_created`, `duplicates_found`, `error_count`).
- **FR-007**: All public query methods in `ArticleService` (`get_feed_articles`, `get_article_detail`, `get_trending_articles`, `get_all_articles_legacy`) and `SearchService` (`search_articles`) MUST strictly filter out articles where `is_deleted = True` or `is_visible = False`. Detail pages for hidden articles MUST return HTTP 404 for non-admin users.
- **FR-008**: The `Article` model MUST support duplicate detection attributes: `content_hash` (SHA-256), `title_fingerprint`, `canonical_url`, and `primary_article_id`.
- **FR-009**: The Content Cleanup Filters MUST include a Duplicates Console to cluster suspect duplicate articles and soft-hide secondary duplicates linked to a designated primary article.
- **FR-010**: The User Ban Tools interface MUST display all registered users, support search and status filtering (`active`, `banned`), allow banning/unbanning users, and invalidate active sessions upon ban.
- **FR-011**: An immutable `AdminAuditLog` table MUST record all administrative actions (`HIDE_ARTICLE`, `RESTORE_ARTICLE`, `BAN_USER`, `UNBAN_USER`, `TRIGGER_SCRAPER`, `UPDATE_SCRAPER_CONFIG`, `RESOLVE_DUPLICATE`).

### Key Entities

```text
ScraperConfig:
- id: Integer, PK
- source_name: String(100)
- domain: String(100), unique
- listing_url: String(1024)
- listing_selector: String(255)
- title_selector: String(255)
- description_selector: String(255)
- content_selector: String(255)
- image_selector: String(255)
- date_selector: String(255)
- is_active: Boolean (default True)

ScraperRun:
- id: Integer, PK
- trigger_type: String(20) ("scheduled", "manual")
- triggered_by_id: Integer, FK -> users.id, nullable
- status: String(20) ("running", "completed", "failed")
- started_at: DateTime
- completed_at: DateTime, nullable
- articles_scraped: Integer (default 0)
- articles_created: Integer (default 0)
- duplicates_found: Integer (default 0)
- error_count: Integer (default 0)
- summary_json: Text / JSON

Article (Extended):
- is_deleted: Boolean / is_visible: Boolean
- content_hash: String(64), index=True
- title_fingerprint: String(128), index=True
- canonical_url: String(1024), nullable
- primary_article_id: Integer, FK -> articles.id, nullable

User (Extended):
- role: String(20) ("user", "admin")
- is_active: Boolean (default True)
- is_banned: Boolean (default False)
- ban_reason: String(255), nullable
- banned_at: DateTime, nullable

AdminAuditLog:
- id: Integer, PK
- admin_id: Integer, FK -> users.id
- action: String(50)
- target_type: String(30)
- target_id: Integer, nullable
- details: Text / JSON
- created_at: DateTime
```

---

## Success Criteria

- **SC-001**: Admins can update and test dynamic scraper selectors via UI in under 1 minute without restarting the application server.
- **SC-002**: Manual scraper triggers execute asynchronously with real-time status reporting, concurrency locking, and full run telemetry logging.
- **SC-003**: 100% suppression rate for hidden/deleted articles across all public feeds, search engines, and detail pages (hidden articles return HTTP 404).
- **SC-004**: Banning a user immediately revokes their session and blocks authentication/posting with 100% enforcement.
- **SC-005**: 100% of administrative actions are recorded in `AdminAuditLog` with timestamp and admin identity.
