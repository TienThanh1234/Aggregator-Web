# Tasks: Admin Dashboard & Control Management System

**Branch**: `007-admin-dashboard` | **Spec**: [spec.md](spec.md) | **Plan**: [plan.md](plan.md)

---

## Phase 1: Foundation, Overview & User Ban Tools (Completed)

- [x] **T001**: Implement admin authentication check `_get_admin_user()` in `routes.py` enforcing `role == 'admin'` and HTTP 403 Forbidden for unauthorized requests.
- [x] **T002**: Implement `get_dashboard_metrics()` in `admin_service.py` and Overview metrics UI in `admin.html`, `frontend.css`, and `admin.js`.
- [x] **T003**: Implement `get_admin_articles()` and `set_article_hidden()` APIs in `routes.py` and `admin_service.py` with UI controls for article search, filter, hide, and restore.
- [x] **T004**: Implement `get_admin_users()` and `set_user_active()` APIs in `routes.py` and `admin_service.py` with UI controls for user search, filter, role/status badges, and ban/unban confirmation modals.
- [x] **T005**: Upgrade admin dashboard frontend with sticky sidebar layout, color-coded stat cards, confirmation dialog modal, slide-in toast notification system, and smooth tab transitions.

---

## Phase 2: Public Moderation & Soft-Hide Enforcement (Completed)

- [x] **T006**: Add `AdminAuditLog` model to `models.py` (fields: `admin_id`, `action`, `target_type`, `target_id`, `details`, `created_at`).
- [x] **T007**: Update `ArticleService` in `article_service.py` to enforce `.filter(Article.is_deleted.is_(False))` across all public query methods (`get_feed_articles`, `get_article_detail`, `get_trending_articles`, `get_all_articles_legacy`).
- [x] **T008**: Update `SearchService` in `search_service.py` to enforce `is_deleted = False` for both PostgreSQL FTS and SQLite fallback queries.
- [x] **T009**: Update `article_page` controller in `routes.py` to return HTTP 404 Not Found when a soft-deleted article is requested.
- [x] **T010**: Update `set_article_hidden()` in `admin_service.py` to record `AdminAuditLog` entries for `HIDE_ARTICLE` and `RESTORE_ARTICLE` actions.

---

## Phase 3: Manual Scraper Controls & Run Telemetry (Completed)

- [x] **T011**: Add `ScraperRun` model to `models.py` (fields: `trigger_type`, `triggered_by_id`, `status`, `started_at`, `completed_at`, `articles_scraped`, `articles_created`, `duplicates_found`, `error_count`, `summary_json`).
- [x] **T012**: Add `_scraper_lock` threading lock in `scheduler_service.py` to prevent simultaneous manual or automated scraper executions.
- [x] **T013**: Refactor `SchedulerService.execute_scraper_run()` to create and update a `ScraperRun` record upon job start, success, or failure.
- [x] **T014**: Implement admin routes in `routes.py`:
  - `POST /api/admin/scraper/runs`: Triggers manual scrape background task under lock & 60s cooldown check.
  - `GET /api/admin/scraper/runs`: Returns active status and recent run history.
- [x] **T015**: Add "Run Scraper Now" button, status badge ("Running / Completed / Failed"), and Scraper Run History table to `admin.html` and `admin.js`.

---

## Phase 4: Duplicate Detection & Moderation Console (Completed)

- [x] **T016**: Extend `Article` model in `models.py` with `content_hash`, `title_fingerprint`, `canonical_url`, and `primary_article_id`.
- [x] **T017**: Add fingerprint generation logic (`compute_content_hash`, `compute_title_fingerprint`) to `scraper_service.py` upon raw article processing.
- [x] **T018**: Implement `get_suspect_duplicates()` and `resolve_duplicates()` functions in `admin_service.py`.
- [x] **T019**: Implement API endpoints in `routes.py`:
  - `GET /api/admin/duplicates`: Returns list of suspect duplicate article clusters.
  - `POST /api/admin/duplicates/resolve`: Soft-hides secondary duplicates and links to designated primary article.
- [x] **T020**: Add "Duplicates" tab and moderation workspace to `admin.html`, `frontend.css`, and `admin.js`.

---

## Phase 5: Dynamic Scraper & Pipeline Configuration (Planned)

- [x] **T021**: Add `ScraperConfig` model (storing per-source CSS selectors, source enabled status, max article limit per run) and `SystemSetting` model (storing dynamic scheduler intervals & retention days) to `models.py`.
- [x] **T022**: Implement dynamic scheduler trigger updates in `SchedulerService` (`scheduler_service.py`) to reschedule scraping and cleanup background jobs without restarting the app.
- [x] **T023**: Implement `DynamicScraper` class in `src/scraper/dynamic_scraper.py` loading database source configurations, selectors, and article limits at runtime.
- [x] **T024**: Implement REST API endpoints in `routes.py`:
  - `GET /api/admin/pipeline/config`: Returns active sources, selectors, limits, and scheduler frequencies.
  - `POST /api/admin/pipeline/config`: Saves updated pipeline settings and reschedules background jobs.
  - `POST /api/admin/scraper/test`: Runs draft selectors against sample HTML URLs with live JSON preview.
- [x] **T025**: Implement Pipeline & Scraper Configuration Panel in `admin.html` and `admin.js` (including source enable/disable toggles, max article limits per source, scraping frequency controls, cleanup schedule controls, selector editor, and live preview).

---

## Phase 6: Automated Testing & Verification

- [x] **T026**: Create test suite `tests/test_public_filtering.py` verifying soft-deleted articles return 404 and are excluded from public feeds/search.
- [x] **T027**: Create test suite `tests/test_scraper_runs.py` verifying concurrency locks, rate limits, and `ScraperRun` log persistence.
- [x] **T028**: Perform full end-to-end manual verification of all Admin Dashboard features.
