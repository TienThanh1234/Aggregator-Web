# Implementation Plan: Admin Dashboard & Control Management System

**Branch**: `007-admin-dashboard` | **Date**: 2026-08-03 | **Spec**: [spec.md](spec.md)

## Summary

This comprehensive implementation plan defines the complete Admin Dashboard for the News Aggregator Web Application. It integrates all core administrative modules:

1. **Overview & System Metrics**: High-level real-time KPI metrics for articles (total/visible/hidden), users (total/active/banned), and scraper staging status (pending/failed raw articles).
2. **User Ban & Access Control Tools**: Complete user list management with search/filter, ban/unban toggles, modal confirmations, and session access control.
3. **Public Moderation & Soft-Hide Filtering [NEXT - PRIORITY 1]**: Fix public query leaks across `article_service.py` and `search_service.py` so soft-hidden articles return HTTP 404 and are omitted from all feeds, trending lists, and search results.
4. **Manual Scraper Controls & Run Telemetry [NEXT - PRIORITY 2]**: Refactor scraper execution to support `POST /api/admin/scraper/runs` with concurrency locks (`_scraper_lock`), cooldown checks, real-time status reporting ("running/completed/failed"), and a `ScraperRun` log table.
5. **Dynamic Scraper Selector Configuration [PLANNED]**: `ScraperConfig` database model, dynamic scraper engine, and live selector preview test endpoint (`POST /api/admin/scraper/test`).
6. **Duplicate Detection & Moderation Console [NEXT - PRIORITY 3]**: SHA-256 `content_hash` and `title_fingerprint` columns on `Article`, a Duplicates Console UI to group suspect duplicates, select a primary record, and soft-hide secondary entries with audit logging.

---

## Technical Context & Constitution Compliance

- **Architecture**: Follows Flask Blueprint thin controller pattern in `routes.py`, delegating logic to `admin_service.py`, `article_service.py`, and `scheduler_service.py`.
- **Security**: Strictly enforces `user.role == 'admin'` via `_get_admin_user()` helper returning 403 Forbidden for non-admins.
- **Frontend UI**: Premium MPA interface built with vanilla JS (`admin.js`), design system tokens (`frontend.css`), inline SVGs, confirmation modal dialogs, and slide-in toast notifications.

---

## Implementation Phases & Progress

### Phase 1 — Dashboard Overview & User Ban Tools (Completed)
- [x] **Admin Authentication**: `_get_admin_user()` check enforcing `role == 'admin'` on `/dashboard/admin` and all `/api/admin/*` endpoints.
- [x] **Overview Metrics**: `get_dashboard_metrics()` API and stat grid UI (total/visible/hidden articles, total/active/banned users, raw article counts).
- [x] **User Management**: `get_admin_users()` and `set_user_active()` APIs with search/filter, role badges (`user`, `admin`), active/banned status badges, ban/unban confirmation modals, and toast notifications.
- [x] **UI Layout Polish**: Premium 2-column sidebar grid with sticky positioning, smooth tab transitions, and responsive mobile breakpoints.

---

### Phase 2 — Public Moderation & Soft-Hide Filtering (Priority 1)
- [ ] **Data Model Extension**: Add `AdminAuditLog` model in `models.py` (`admin_id`, `action`, `target_type`, `target_id`, `details`, `created_at`).
- [ ] **Public Feed Filtering**: Update `ArticleService.get_feed_articles()`, `get_trending_articles()`, and `get_all_articles_legacy()` to include `.filter(Article.is_deleted.is_(False))`.
- [ ] **Public Detail Page 404**: Update `ArticleService.get_article_detail()` and `article_page` controller in `routes.py` so soft-deleted articles return HTTP 404 Not Found.
- [ ] **Search Engine Filtering**: Update `SearchService.search_articles()` to enforce `is_deleted = False` for both PostgreSQL FTS and SQLite fallback queries.
- [ ] **Audit Trail Logging**: Update `set_article_hidden()` in `admin_service.py` to record `HIDE_ARTICLE` and `RESTORE_ARTICLE` events in `AdminAuditLog`.

---

### Phase 3 — Manual Scraper Controls & Run Telemetry (Priority 2)
- [ ] **Data Model Addition**: Add `ScraperRun` model in `models.py` (`trigger_type`, `triggered_by_id`, `status`, `started_at`, `completed_at`, `articles_scraped`, `articles_created`, `duplicates_found`, `error_count`, `summary_json`).
- [ ] **Concurrency Locking**: Implement `_scraper_lock` threading lock in `scheduler_service.py` to prevent simultaneous automated and manual scraper runs.
- [ ] **Telemetry Refactoring**: Refactor `SchedulerService._scraper_job()` to create and update a `ScraperRun` record upon job start, success, or failure.
- [ ] **API Endpoints**:
  - `POST /api/admin/scraper/runs`: Triggers manual scrape background task under lock & 60s cooldown check.
  - `GET /api/admin/scraper/runs`: Returns active execution status and history log.
- [ ] **UI Controls**: Add "Run Scraper Now" button, status indicator badge, and execution history table to `admin.html` and `admin.js`.

---

### Phase 4 — Duplicate Detection & Moderation Console (Priority 3)
- [ ] **Schema Extension**: Add `content_hash` (SHA-256), `title_fingerprint`, `canonical_url`, and `primary_article_id` fields to `Article` in `models.py`.
- [ ] **Fingerprint Generation**: Add automatic content hash and title fingerprint generation in `scraper_service.py` upon raw article ingestion.
- [ ] **Duplicates Service**: Implement `get_suspect_duplicates()` and `resolve_duplicates()` in `admin_service.py`.
- [ ] **API Endpoints**:
  - `GET /api/admin/duplicates`: Returns suspect duplicate article clusters.
  - `POST /api/admin/duplicates/resolve`: Soft-hides secondary duplicates and links to primary article ID with audit logging.
- [ ] **UI Console**: Add "Duplicates" tab and moderation workspace in `admin.html`, `frontend.css`, and `admin.js`.

---

### Phase 5 — Dynamic Scraper & Pipeline Configuration (Planned)
- [ ] **Data Model Additions**:
  - `ScraperConfig` model in `models.py` storing per-source CSS selectors, source enable/disable status, and max articles limit per run.
  - `SystemSetting` model in `models.py` storing key-value pipeline settings (`scraping_interval_minutes`, `cleanup_interval_days`, `retention_days`).
- [ ] **Dynamic Scheduler Engine**: Refactor `SchedulerService` to dynamically update APScheduler job triggers when pipeline interval or retention settings are changed via admin UI.
- [ ] **Dynamic Scraper Engine**: Implement `DynamicScraper` class in `src/scraper/dynamic_scraper.py` loading source configurations, selectors, and article limits from DB at runtime.
- [ ] **Selector & Pipeline APIs**:
  - `GET /api/admin/pipeline/config`: Returns active sources, selectors, limits, and scheduler frequencies.
  - `POST /api/admin/pipeline/config`: Saves updated pipeline settings and reschedules background jobs.
  - `POST /api/admin/scraper/test`: Runs draft selectors against sample HTML URLs with live JSON preview.
- [ ] **UI Pipeline Config Panel**: Add Pipeline & Scraper Configuration panel in `admin.html` and `admin.js` with source toggles, selector editors, article limit inputs, interval controls, and live test preview.

---

## Verification Plan

### Automated Tests
Run pytest in virtual environment:
```powershell
venv\Scripts\python -m pytest tests/test_admin.py -v
```

### Manual Verification
1. Log in as admin -> Verify Overview metrics and User Ban tools work smoothly.
2. Soft-hide an article -> Access `/articles/<id>` -> Confirm 404 page is rendered.
3. Click "Run Scraper Now" -> Verify execution status badge updates to "running" then "completed".
4. Navigate to Duplicates tab -> Inspect duplicate cluster -> Resolve duplicates -> Verify secondary articles are hidden.
