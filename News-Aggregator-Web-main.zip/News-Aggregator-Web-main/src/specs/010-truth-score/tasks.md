# Tasks: Truth Score for Articles

**Branch**: `010-truth-score` | **Spec**: [spec.md](spec.md) | **Plan**: [plan.md](plan.md)

---

## Phase 1: Schema and Additive Migration

- [x] **T001**: Extend `Article` in `src/models.py` with `truth_score_updated_at` and `truth_score_version` (`v1` default). Keep `truth_score` nullable during the initial rollout.
  - **Acceptance**: a newly created Article can retain its legacy nullable score while recording the scoring version/time once calculated.
- [x] **T002**: Extend `ScraperConfig` with non-null `reliability_score` (integer, default 50) and model-level validation/constraint for the inclusive 0–100 range.
  - **Acceptance**: existing and new sources default to neutral 50; invalid values cannot persist.
- [x] **T003**: Add an `ArticleTruthScore` model in `src/models.py` with one unique, cascading FK to `Article`, total/component fields, JSON/text corroboration fields, calculation version, and timestamp.
  - **Acceptance**: each article has at most one current audit record and deleting the article deletes its audit record.
- [x] **T004**: Add model relationships between `Article` and `ArticleTruthScore` (`uselist=False`) without altering existing article relationships.
- [x] **T005**: Create an additive Alembic migration for T001–T004: add columns/table, initialize existing `ScraperConfig.reliability_score` to 50, and add safe lookup indexes for `primary_article_id`, `truth_score`, and `truth_score_updated_at`.
  - **Acceptance**: `flask db upgrade` completes on a database containing existing Articles and DailyBriefs with no data loss.
- [x] **T006**: Add migration tests/checks confirming the additive upgrade preserves existing rows and initializes all source reliability ratings to 50.

---

## Phase 2: Formula and Story-cluster Service

- [x] **T007**: Create `src/services/truth_score_service.py` and define formula constants for v1, component caps, neutral reliability, fallback score, 72-hour window, and backfill batch size.
- [x] **T008**: Implement `normalize_source_domain(url)` to normalize valid HTTP(S) URLs into a comparison domain and return `None` for invalid/missing URLs.
  - **Acceptance**: domains compare case-insensitively; URLs from the same host do not count twice.
- [x] **T009**: Implement pure `calculate_score(article, cluster_members, source_config)` using only the four components in spec §3 and returning total plus an itemized breakdown.
  - **Acceptance**: all component caps and total 0–100 are enforced; a complete neutral, single-source article scores 48.
- [x] **T010**: Implement exact `content_hash` candidate lookup for accepted story clusters, excluding soft-deleted articles and the subject article itself.
- [x] **T011**: Implement 72-hour `title_fingerprint` candidate lookup. Keep title-only matches standalone in v1 until an accepted duplicate-resolution link exists; they must not raise corroboration.
- [x] **T012**: Implement canonical assignment: the oldest accepted cluster article keeps `primary_article_id = NULL`, and all other accepted members point to it.
  - **Acceptance**: canonical selection remains stable when later reports join the cluster.
- [x] **T013**: Implement `upsert_score(article, calculation)` to update Article score/version/timestamp and create/update exactly one `ArticleTruthScore` record in the caller’s transaction.
- [x] **T014**: Implement `score_article_and_cluster(article_id)` to load an article, form/update its accepted cluster, calculate every affected member, and commit atomically.
- [x] **T015**: Implement fallback persistence: recoverable orchestration errors store score 40, version `v1-fallback`, a complete audit row, and a structured warning without article body content.
  - **Acceptance**: no scoring failure leaves a promoted active article with `truth_score = NULL`.
- [x] **T016**: Add unit tests for T008–T015 covering formula boundaries, neutral fallback source rating, metadata/content omissions, duplicate domains, two/three/four independent domains, hash clustering, title-window exclusion, canonical stability, and fallback behaviour.

---

## Phase 3: Scraper, Maintenance, and Backfill

- [x] **T017**: Modify `ScraperService.process_raw_article()` in `src/services/scraper_service.py` to call transaction-aware scoring after `db.session.flush()` and before its final commit.
  - **Acceptance**: one successful promotion commits RawArticle status, Article, accepted cluster links, Article score, and audit record together.
- [x] **T018**: Ensure the scraper promotion path catches only recoverable scoring errors, calls fallback persistence, and still promotes the article; database commit errors retain existing rollback semantics.
- [x] **T019**: Implement `rescore_recent_articles(hours=72)` to re-score active recent canonical clusters and return scanned/scored/fallback counts.
  - **Acceptance**: re-running the operation is idempotent and refreshes corroboration when a new independent report arrives.
- [x] **T020**: Implement `backfill_truth_scores(batch_size=200)` to process active null-score articles in independently committed batches, with rollback isolation and aggregate progress output.
- [x] **T021**: Add a Flask CLI command or controlled service invocation for invoking T020 outside an HTTP request; include optional `--all` re-score mode and a bounded batch-size option.
- [x] **T022**: Register the hourly `truth_score_maintenance` APScheduler job in `src/services/scheduler_service.py` using `max_instances=1` and a Flask app context.
- [x] **T023**: Add `_truth_score_maintenance_job()` with structured success/failure logging that calls T019 and does not interrupt existing scraper or Daily Brief jobs.
- [x] **T024**: Add integration tests proving scraper promotion creates a score/audit record, scoring fallback does not discard the Article, recent re-score updates a two-domain cluster, and backfill resumes after a batch failure.

---

## Phase 4: Daily Brief and Admin Operations

- [x] **T025**: Update `generate_daily_brief()` in `src/services/brief_service.py` to prefer eligible canonical articles (`primary_article_id IS NULL`) after existing user-preference and 24-hour filters.
- [x] **T026**: Add a candidate fallback query that includes scored non-canonical articles only if fewer than five canonical candidates are available; retain a maximum of five total candidates.
- [x] **T027**: Order Daily Brief candidates by `truth_score DESC`, `published_at DESC`, then `id DESC`, and log only selected article IDs and scores.
  - **Acceptance**: a brief with several reports of one event selects no more than one canonical report before using fallback candidates.
- [x] **T028**: Add `GET /api/admin/articles/<article_id>/truth-score` in `src/routes.py`, returning total, component scores, version, calculation time, and corroboration IDs/domains from the audit record.
- [x] **T029**: Add `POST /api/admin/articles/<article_id>/truth-score/recalculate`, delegating to T014 and returning 404 for an absent Article.
- [x] **T030**: Add `POST /api/admin/truth-scores/backfill`, starting a bounded background job/service invocation and returning a job ID without running all batches in the HTTP request.
- [X] **T031**: Apply existing admin authorization to T028–T030; add tests that unauthenticated/non-admin requests are rejected and admins receive the documented response shape.
- [X] **T032**: Add Daily Brief integration tests for score-first ordering, recency tie-breaking, canonical diversity, and the fewer-than-five-canonical fallback.

---

## Phase 5: Backfill Completion, Constraint, and Release Validation

- [X] **T033**: Run the backfill against a representative non-production database and verify all active articles have scores in the inclusive 0–100 range and exactly one audit record.
- [X] **T034**: Produce the follow-up Alembic migration: assign fallback 40 to any residual active null scores, change `articles.truth_score` to non-null, and add the 0–100 check constraint.
  - **Prerequisite**: T033 has reported zero unexpected active null scores.
- [X] **T035**: Verify upgrade and downgrade strategy for both migrations on a production-like database copy. Record expected lock time and row counts in deployment notes.
- [X] **T036**: Run the full automated suite (`pytest tests/ -v`) and resolve regressions in scraper, admin authorization, article retrieval, and Daily Brief tests.
- [X] **T037**: Perform manual operational verification: trigger one scrape, inspect score API as an admin, run a small backfill, confirm maintenance-job logs, then generate a Daily Brief and confirm its selected IDs/scores follow the ranking rules.
- [X] **T038**: Define and monitor rollout metrics: active null-score count (target 0), fallback rate (target <1%), score distribution, calculation latency, and Daily Brief cluster diversity.

---

## Dependency Order

```text
T001–T006
  -> T007–T016
  -> T017–T024
  -> T025–T032
  -> T033–T038
```

T025–T032 may begin after T014 is complete, but must not ship before scraper integration and a successful initial backfill path are available.
