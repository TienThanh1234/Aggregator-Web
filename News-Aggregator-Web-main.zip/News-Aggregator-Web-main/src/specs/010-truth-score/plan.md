# Implementation Plan: Truth Score for Articles

**Branch**: `010-truth-score` | **Date**: 2026-08-17 | **Spec**: [spec.md](spec.md)

## Summary

Implement a deterministic, auditable 0–100 evidence-confidence score for every active article. The score combines source reliability, independent cross-source corroboration, publication metadata, and content completeness. It replaces the current nullable value used by Daily Brief, while explicitly avoiding unsupported AI or engagement signals.

Delivery adds one audit model, extends `Article` and `ScraperConfig`, introduces a service responsible for grouping and scoring, runs a safe backfill/maintenance job, exposes three admin-only operations, and updates Daily Brief to select distinct canonical story clusters by score then recency.

## Technical Context

**Language/Version**: Python 3.11+, Flask, Flask-SQLAlchemy, Alembic, APScheduler

**Storage**: PostgreSQL via Supabase (production) / local PostgreSQL (development)

**Existing State**:

- `Article.truth_score` is nullable and `brief_service.py` currently orders it with `NULLS LAST` before `published_at`.
- `Article.content_hash`, `title_fingerprint`, `canonical_url`, and `primary_article_id` already exist and are populated by `ScraperService.process_raw_article()`.
- `ScraperConfig` identifies a source with `source_domain` but has no reliability rating.
- `scheduler_service.py` hosts hourly scraper work and the 07:00 Asia/Bangkok Daily Brief job.
- `routes.py` already has the admin authorization helpers and the Duplicate Console endpoints; the score management endpoints follow the same guard pattern.

**Project Type**: Server-rendered Flask MVC app with vanilla JavaScript. This feature is backend/admin API only; it adds no public UI in its first release.

## Constitution Check

- **MVC**: SQLAlchemy schema remains in `models.py`; score, cluster, and backfill logic lives in `services/truth_score_service.py`; routes only validate/authorize and return service results.
- **Data integrity**: score and audit record use a single database transaction. Scores are constrained to 0–100 and backfill is resumable in independent batches.
- **Error handling**: a scoring failure cannot discard a scraped article. A conservative score of 40 and an audit record are stored, then the failure is logged without raw article text.
- **Security**: reliability changes, score explanations, and recalculation are admin-only. No new secret or third-party API is introduced.
- **Code organization**: no LLM call is added. Deterministic helpers remain unit-testable without app or network access.

## Project Structure (Post-Implementation)

```text
src/
├── models.py                                  # [MODIFY] score timestamps/version, audit model, source reliability
├── routes.py                                  # [MODIFY] three admin-only truth-score endpoints
├── services/
│   ├── scraper_service.py                     # [MODIFY] invokes score persistence during promotion
│   ├── scheduler_service.py                   # [MODIFY] hourly maintenance re-score job
│   ├── brief_service.py                       # [MODIFY] canonical cluster-aware candidate query
│   └── truth_score_service.py                 # [NEW] deterministic scoring, clustering, backfill
├── migrations/versions/
│   └── <revision>_truth_score.py              # [NEW] schema, data migration, indexes
└── tests/
    ├── test_truth_score_service.py            # [NEW] formula, clustering, fallback, backfill tests
    └── test_truth_score_routes.py             # [NEW] authorization and API contract tests
```

## Implementation Phases

### Phase 1 — Schema and Migration

**Objective**: Make score data durable, auditable, queryable, and safe for existing records.

1. **Modify `models.py`**
   - Extend `Article` with `truth_score_updated_at` (`DateTime`, nullable) and `truth_score_version` (`String(20)`, default `v1`, non-null after migration).
   - Keep `truth_score` nullable in the application model until backfill has safely completed; the final migration makes it non-null with a check constraint `0 <= truth_score <= 100`.
   - Extend `ScraperConfig` with `reliability_score` (`Integer`, default 50, non-null, check constraint `0 <= reliability_score <= 100`).
   - Add `ArticleTruthScore` with a unique `article_id` foreign key, total/component columns, corroborating IDs/domains JSON text, `calculation_version`, and `calculated_at`. Define the one-to-one relationship with `Article`.

2. **Create Alembic migration**
   - Add fields and `article_truth_scores` without destructive schema changes.
   - Populate `reliability_score = 50` for existing sources.
   - Create indexes needed by scoring: `(primary_article_id)`, `(truth_score)`, and `(truth_score_updated_at)` as appropriate for PostgreSQL query plans.
   - Do not make `truth_score` non-null in this migration. This occurs in Phase 4 after the application backfill has reported zero remaining null active articles.

**Acceptance criteria**

- Migration preserves all articles, raw articles, sources, and Daily Brief records.
- Every source has a neutral reliability score of 50 after upgrade.
- `ArticleTruthScore.article_id` is unique and cascades on article deletion.

### Phase 2 — Deterministic Score and Clustering Service

**Objective**: Encapsulate all scoring logic in a testable service with no external calls.

1. **Add `services/truth_score_service.py`** with:

| Function | Responsibility |
|---|---|
| `normalize_source_domain(url)` | Return a normalized registrable/configured source domain, or `None`. |
| `find_story_cluster(article)` | Find exact content-hash candidates first, then same title fingerprint in the 72-hour window. Return accepted members only. |
| `assign_canonical_article(article, members)` | Preserve the oldest accepted article as canonical and set `primary_article_id` for remaining members. |
| `calculate_score(article, cluster_members, source_config)` | Return total and all four components using the v1 formula; validate all ranges. |
| `upsert_score(article, calculation)` | Persist the article columns and one current audit row in the caller’s transaction. |
| `score_article_and_cluster(article_id)` | Load article, cluster it, score every accepted member, and commit atomically. |
| `backfill_truth_scores(batch_size=200)` | Iterate active articles with `NULL` score, commit each batch, and return aggregate counts. |
| `rescore_recent_articles(hours=72)` | Re-score recent clusters to account for late independent coverage. |

2. **Formula implementation**
   - Use only the v1 components and exact thresholds defined in spec §3.
   - Use source reliability 50 if no matching source configuration exists.
   - Count distinct normalized domains, never article URLs, for corroboration.
   - Round to an integer and enforce total 0–100 before persistence.
   - `calculate_score` remains pure where possible; unit tests can build model instances without a database.

3. **Cluster safety**
   - Exact non-null `content_hash` can be automatically accepted.
   - `title_fingerprint` candidates must also meet the 72-hour window. Initially, retain them as standalone unless an existing duplicate-resolution decision marks the association accepted; this prevents title collisions from falsely increasing scores.
   - In this first implementation, record only accepted deterministic clusters. A `needs_review` state and UI workflow are deferred until a review model is specified.

4. **Failure path**
   - If the orchestration layer fails, persist score 40, formula version `v1-fallback`, a current audit record, and a structured warning containing article ID plus exception type.
   - Do not use the fallback merely because an optional field is absent; absent metadata naturally contributes zero points.

**Acceptance criteria**

- A complete neutral-source single article has score 48.
- A second accepted independent domain raises corroboration from 0 to 15.
- Three articles from one domain add no corroboration.
- Same inputs yield identical score breakdowns.

### Phase 3 — Scraper and Scheduler Integration

**Objective**: Score new data and maintain scores as coverage evolves, without slowing or failing the scrape pipeline.

1. **Modify `services/scraper_service.py`**
   - After article creation, category association, and `db.session.flush()`, call a transaction-aware `score_new_article(article)` helper.
   - Persist `RawArticle` status, `Article`, cluster links, and audit score in the same transaction.
   - On a scoring exception, invoke the fallback persistence routine and complete the article promotion; only a database commit failure rolls back the transaction.

2. **Modify `services/scheduler_service.py`**
   - Register `truth_score_maintenance` with `IntervalTrigger(hours=1)`, `max_instances=1`, and a Flask app context.
   - Add `_truth_score_maintenance_job()` that calls `rescore_recent_articles(hours=72)`, logs number scanned/scored/fallback, and isolates exceptions.
   - Do not couple this job to the 07:00 Daily Brief job. It must be able to run independently after scraper activity.

3. **Backfill operation**
   - Provide a service callable from a Flask CLI command or a controlled maintenance invocation; it processes 200 articles per transaction and emits progress log events.
   - It is idempotent: retrying processes only current null scores unless explicitly requested to re-score all active records.

**Acceptance criteria**

- Promoting a raw article results in a score/audit record in the same successful transaction.
- Scoring errors leave a valid article with score 40 and are visible in logs.
- Two accepted reports entering within 72 hours are re-scored within the next maintenance interval.

### Phase 4 — Daily Brief and Admin APIs

**Objective**: Consume the score safely in Daily Brief and make operations auditable.

1. **Modify `services/brief_service.py`**
   - Retain existing 24-hour and user preference filters.
   - Prefer `Article.primary_article_id IS NULL`, then add other scored articles only if fewer than five canonical candidates exist.
   - Order by `truth_score DESC`, `published_at DESC`, `id DESC`; return at most five articles.
   - Log selected article IDs and scores, without descriptions or content.

2. **Modify `routes.py`**
   - Add `GET /api/admin/articles/<int:article_id>/truth-score` that returns the stored audit breakdown and cluster IDs/domains.
   - Add `POST /api/admin/articles/<int:article_id>/truth-score/recalculate` that calls `score_article_and_cluster`.
   - Add `POST /api/admin/truth-scores/backfill` that queues/starts the safe background backfill and returns a job identifier; it must not run the entire batch within the request.
   - Use the existing admin helper for all three endpoints and return 404 for a missing article.

3. **Complete migration**
   - After the backfill succeeds in deployed environments, ship a follow-up migration to set remaining active null values to 40, change `truth_score` to non-null, and add its 0–100 check constraint.

**Acceptance criteria**

- Daily Brief no longer ranks an active candidate with a null score.
- A cluster contributes one canonical item before fallback candidates are chosen.
- Unauthenticated/non-admin API requests are denied; admin score response explains every component.

### Phase 5 — Verification and Rollout

**Objective**: Prove correctness, migration safety, and intended ranking behaviour before enabling production backfill.

1. **Service unit tests**
   - Formula boundary values, neutral default, missing metadata, formula version, and fallback score.
   - Domain deduplication, exact hash match, 72-hour title window, canonical selection, and re-score propagation.
   - Backfill batching/idempotency and rollback isolation.

2. **Integration tests**
   - Raw article promotion creates the audit row and a numeric score.
   - Daily Brief selects canonical candidates ordered score → recency.
   - Admin API contracts and authorization.

3. **Migration verification**
   - Upgrade a copy of representative data.
   - Run backfill, verify zero active null scores, then apply the non-null constraint migration.
   - Inspect scheduler logs over at least one scraper cycle and one Daily Brief generation.

4. **Operational metrics**
   - Track count of active null scores (target: 0), fallback calculation rate (target: <1%), score distribution, average score processing time, and Daily Brief source cluster diversity.

## Implementation Order

1. Models and additive migration.
2. Pure calculation tests and service implementation.
3. Scraper transaction integration and maintenance scheduler.
4. Backfill in non-production, then production.
5. Daily Brief query update and admin endpoints.
6. Final non-null migration after backfill verification.

## Risks and Decisions

| Risk | Mitigation |
|---|---|
| Similar headlines describe different events | Only exact content hashes auto-cluster in v1; title-only matches do not raise corroboration without a future review decision. |
| A source’s reputation is subjective | Default every source to neutral 50, record the admin value, and make it auditable. |
| Late reporting changes ranking | Hourly re-score of the last 72 hours updates corroboration predictably. |
| Scoring blocks scraping | Use deterministic queries, batch maintenance, and fallback score 40 rather than rejecting the article. |
| Historic null scores cause unstable brief results | Backfill before enforcing non-null; the Brief query remains defensive during rollout. |
