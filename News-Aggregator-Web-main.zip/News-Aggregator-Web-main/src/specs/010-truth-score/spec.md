# Feature Specification: Truth Score for Articles

**Feature Branch**: `010-truth-score`  
**Created**: 2026-08-17  
**Status**: Draft  
**Target Specification Location**: `src/specs/010-truth-score/spec.md`

---

## 1. Purpose and Scope

`truth_score` is a reproducible **evidence-confidence score** from 0 to 100. It ranks articles for the news feed and Daily Brief; it does **not** assert that every claim in an article is factually true.

The current value is nullable and is never calculated. Consequently, Daily Brief falls back to recency ordering. This feature supplies a deterministic scoring pipeline that:

- scores each newly promoted `Article`;
- re-scores related articles when independent coverage arrives;
- preserves the score and its inputs for auditing;
- supplies a non-null score for all eligible articles before they can be ranked by Daily Brief.

Out of scope: automatic verification against the open web, declaring a claim true or false, and changing article copy.

## 2. User Stories and Acceptance Scenarios

### User story 1 — Reliable ranking

**As a** reader, **I want** corroborated reporting from reliable sources to rank above single-source or incomplete reporting, **so that** the Daily Brief favours better-supported coverage.

- **AS-TS-01**: Given a newly promoted article, when the scoring job completes, then it has a numeric `truth_score` in the inclusive range 0–100.
- **AS-TS-02**: Given two otherwise comparable articles, when one has coverage from more independent source domains, then its score is higher.
- **AS-TS-03**: Given a score cannot be calculated because the source configuration or metadata is missing, when the job completes, then the article receives the conservative fallback score of 40 and a reason is logged; no `NULL` score is persisted.

### User story 2 — Explainable operations

**As an** administrator, **I want** to inspect why an article received its score, **so that** source ratings and grouping errors can be corrected.

- **AS-TS-04**: Given an administrator views an article’s score detail, when it is loaded, then the API returns the total score, each component, scoring version, calculation time, and IDs/domains of the corroborating articles.
- **AS-TS-05**: Given an administrator changes a source reliability rating, when they request a re-score, then all affected articles are recalculated without changing article content or deleting records.

### User story 3 — Daily Brief ranking

**As a** Daily Brief user, **I want** the candidate articles ordered by evidence confidence before recency, **so that** the five supplied articles are not merely the newest ones.

- **AS-TS-06**: Given eligible articles with calculated scores, when a Daily Brief is generated, then candidates are ordered by `truth_score DESC`, then `published_at DESC`.
- **AS-TS-07**: Given multiple articles report the same event, when Daily Brief selects candidates, then only the cluster’s canonical article is included unless fewer than five distinct clusters are available.

## 3. Score Definition

The score is an integer from 0 to 100. It is calculated only from stored, auditable signals.

| Component | Range | Rule |
|---|---:|---|
| Source reliability | 0–50 | `round(source_reliability / 100 * 50)`. Sources default to 100/100, therefore 50 points. |
| Independent corroboration | 0–20 | Count distinct source domains in the same story cluster: 1 domain = 0; 2 = 10; 3 = 15; 4 or more = 20. The article’s own domain counts once. |
| Publication metadata | 0–15 | 8 points when `published_at` is present; 4 points when `canonical_url` is a valid HTTP(S) URL; 3 points when `source_url` domain matches a configured source. |
| Content completeness | 0–15 | 5 points for a non-empty title; 5 for a description of at least 80 characters; 5 for raw content of at least 500 characters. |

`truth_score = min(100, sum(components))`. The pipeline MUST round the final value to an integer before persistence.

The score MUST NOT use engagement, user reactions, AI-generated `confidenceScore`, or an LLM’s claimed external verification. The existing AI fact-check only assesses support inside supplied text and is not suitable as a truth signal.

## 4. Story Clustering and Independence

Corroboration is measured per story cluster, not by counting URLs.

1. A new article first matches an existing cluster by equal non-null `content_hash`.
2. If no hash match exists, it may match by equal non-null `title_fingerprint` within a 72-hour publication window.
3. A candidate match with a different source domain is marked `needs_review` unless an approved deterministic similarity threshold is met. It MUST NOT increase corroboration until accepted.
4. The oldest article in an accepted cluster is the canonical article (`primary_article_id = NULL`). Other members point to its ID through `primary_article_id`.
5. Multiple URLs from the same registrable source domain contribute only one corroborating source.

The system MUST re-score every accepted member and its canonical article whenever cluster membership changes. A rejected duplicate remains a standalone article and is not deleted by scoring.

## 5. Data Model and API Contracts

### 5.1 `articles`

The existing `truth_score` column changes from nullable to `NOT NULL` after backfill. Add:

| Column | Type | Constraint | Description |
|---|---|---|---|
| `truth_score_updated_at` | timestamp | nullable | Last successful calculation time. |
| `truth_score_version` | string(20) | not null, default `v1` | Formula version used for the stored score. |

### 5.2 `article_truth_scores`

Store the current calculation record for auditability.

| Column | Type | Constraint |
|---|---|---|
| `id` | integer | primary key |
| `article_id` | integer | FK `articles.id`, unique, cascade delete |
| `total_score` | integer | not null, 0–100 |
| `source_reliability_score` | integer | not null, 0–50 |
| `corroboration_score` | integer | not null, 0–20 |
| `metadata_score` | integer | not null, 0–15 |
| `content_score` | integer | not null, 0–15 |
| `corroborating_article_ids` | text/JSON | not null, default `[]` |
| `corroborating_domains` | text/JSON | not null, default `[]` |
| `calculation_version` | string(20) | not null |
| `calculated_at` | timestamp | not null |

### 5.3 `scraper_configs`

Add `reliability_score` as an administrator-maintained integer from 0 to 100, default 100. This is an editorial input, not a claim that individual stories are true.

### 5.4 Endpoints

- `GET /api/admin/articles/<article_id>/truth-score` returns the article’s current score breakdown and cluster information.
- `POST /api/admin/articles/<article_id>/truth-score/recalculate` recalculates that article and its accepted cluster. Admin-only.
- `POST /api/admin/truth-scores/backfill` queues re-scoring for eligible articles. Admin-only; it returns a job identifier and must not run synchronously in an HTTP request.

All endpoints require the existing admin authorization guard. Score detail is not exposed on public article endpoints in this phase.

## 6. Processing Lifecycle

```text
RawArticle promoted to Article
  -> normalize URL/domain and calculate fingerprints
  -> assign or create a candidate story cluster
  -> calculate deterministic score and audit record
  -> persist Article + score atomically
  -> enqueue accepted cluster members for re-score
  -> Daily Brief selects canonical candidates by score, then recency
```

- Scoring MUST run after the promotion transaction has article data available and before the article becomes eligible for Daily Brief.
- Failures MUST not abort scraping. The transaction stores fallback score 40, creates an audit record with zero/available component values, and logs the exception without article text or secrets.
- A scheduled maintenance job re-scores articles in the last 72 hours every hour to capture late corroboration.
- A one-time backfill processes all existing active articles in batches of at most 200, commits each batch independently, and is safe to resume after failure.

## 7. Daily Brief Integration

Daily Brief retains its existing preference filtering and 24-hour window. Before applying `limit(5)`, it MUST:

1. exclude `is_deleted = true` articles;
2. prefer canonical cluster articles (`primary_article_id IS NULL`);
3. fall back to any scored article only if fewer than five canonical candidates exist;
4. order by non-null `truth_score DESC`, then `published_at DESC`, then `id DESC`.

The service MUST log the five selected IDs and their scores. It MUST not create a new Daily Brief when no candidate articles exist; instead it preserves the existing empty-state behaviour.

## 8. Non-functional Requirements

- **Determinism**: identical stored inputs and formula version produce the same score.
- **Performance**: calculation for one article and a cluster of up to 20 members completes within 500 ms excluding database contention; batch work runs off the request thread.
- **Integrity**: article score and its current audit record commit atomically. A score is always within 0–100.
- **Observability**: log calculation result, formula version, article ID, cluster size, and fallback reason. Do not log raw article content.
- **Security**: only admins may set source reliability, view score breakdowns, or trigger re-scoring.

## 9. Acceptance Tests

1. A fully populated article from a default source with no corroboration scores 50 + 15 + 15 = **80**.
2. Adding an accepted report from a second domain increases each clustered article’s corroboration component from 0 to 10.
3. Three links from the same domain count as one domain and leave corroboration at 0 when no other domain covers the story.
4. An article with missing source configuration receives a score of 40 on calculation failure and never persists `NULL`.
5. Re-running calculation with unchanged data gives the same total and component values.
6. Daily Brief with six eligible articles from three clusters selects no more than one canonical article per cluster before using fallback candidates.
7. An unprivileged request to any truth-score management endpoint returns 403.
8. Backfill of existing articles converts every active article from `NULL` to a value in 0–100 without modifying title, body, categories, or publication time.

## 10. Delivery Boundaries

This specification intentionally separates score calculation from a full misinformation-detection system. Future versions may add trusted external fact-check sources or human review decisions only after defining their provenance, expiry, dispute workflow, and legal/privacy requirements.
