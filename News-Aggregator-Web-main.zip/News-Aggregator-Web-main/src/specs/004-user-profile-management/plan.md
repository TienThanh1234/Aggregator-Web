# Implementation Plan: User Profile Management

**Branch**: `004-user-profile-management` | **Date**: 2026-07-23 | **Spec**: [spec.md](spec.md)

## Summary

This plan implements a secure self-service profile settings flow for authenticated users in the Tell Me More News Aggregator. The feature introduces three user-facing capabilities: personal info updates, password changes, and avatar uploads. The implementation will extend the existing `User` model and authentication foundation, add a dedicated profile service module, wire authenticated profile endpoints in the Flask controller layer, and render a settings experience that is visually aligned with the current premium neoclassical frontend shell.

---

## Technical Context

**Language/Version**: Python 3.11+, HTML5, CSS3, ES6+ JavaScript

**Primary Dependencies**: Flask 3.1.3, Flask-SQLAlchemy 3.1.1, Werkzeug 3.1.8, Flask-Migrate 4.1.0, python-dotenv 1.2.2

**Storage**: PostgreSQL via Supabase/cloud or localhost development database

**Existing State**: The `User` model already includes `email`, `password_hash`, `role`, `session_version`, and authentication helpers. The application already has authenticated UI state, role-based header navigation, and a premium editorial layout. The missing work is the user profile settings surface, backend update endpoints, avatar upload support, and the database column extensions for avatar metadata.

**Project Type**: Flask MVC application with Jinja2 templates and vanilla frontend assets

---

## Constitution Check

The implementation plan conforms to the constitution in the following ways:

- **Strict MVC Pattern (Principle II)**: Route handlers in `routes.py` remain thin and delegate profile logic to a service layer module such as `services/profile_service.py`. Database schema remains in `models.py`; presentation remains in `templates/` and `static/`.
- **Environment Configuration (Principle III — NON-NEGOTIABLE)**: No secrets, upload destinations, or credentials are hardcoded. All sensitive configuration remains in `.env`.
- **Data Integrity (Principle IV)**: A unique email constraint remains enforced at the database layer. Password updates hash securely and invalidate stale session state.
- **Code Organization (Principle V)**: `User` remains a PascalCase model class; service functions use snake_case; constants stay UPPER_SNAKE_CASE.
- **Error Handling (Principle VI)**: Profile validation failures are returned with clear messages; all caught exceptions are logged with context.
- **Security (Code Quality Standards)**: Passwords are only stored as Werkzeug PBKDF2 hashed strings; upload operations are validated by type, extension, and size; SQLAlchemy ORM is used for all query and persistence logic.
- **Frontend Stack**: Jinja2 + vanilla HTML/CSS/JS only; no framework sprawl is introduced.
- **Environment Governance (Principle VIII)**: All schema, test, and runtime commands should be executed within the activated `venv` context.

---

## Project Structure (Post-Implementation)

```text
src/
├── app.py                          # [MODIFY] — Ensure updated User model is imported cleanly
├── models.py                       # [MODIFY] — Extend `User` with avatar metadata & validation-friendly fields
├── routes.py                       # [MODIFY] — Add authenticated profile endpoints
├── services/
│   ├── __init__.py                 # [EXISTING]
│   ├── auth_service.py             # [EXISTING] — Reuse for current session and login helpers
│   ├── profile_service.py          # [NEW] — Profile read/update, password change, avatar upload orchestration
│   └── email_service.py            # [EXISTING]
├── templates/
│   └── index.html                  # [MODIFY] — Add settings menu entry and profile settings UI shell
├── static/
│   ├── css/
│   │   └── frontend.css            # [MODIFY] — Settings styles, avatar preview, responsive layout
│   └── js/
│       └── frontend.js             # [MODIFY] — Profile settings JS controller, form validation, toast + avatar update
├── migrations/
│   └── versions/
│       └── 20260723_add_user_avatar_profile_fields.py   # [NEW] — Alembic migration for profile fields
└── tests/
    └── test_profile_management.py  # [NEW] — API and business-logic tests for settings flows
```

---

## Implementation Phases

### Phase 1 — Database Model Evolution & Migration

**Objective**: Extend the `User` entity with data fields required for avatar handling and secure profile updates, then add a migration to persist the schema change.

#### Work Items

1. **Modify** `src/models.py`
   - Add `avatar_url`, `avatar_mime_type`, and `avatar_uploaded_at` to the `User` model.
   - Keep the existing password hashing helpers intact and re-use them for password updates.
   - Ensure `session_version` remains present for session invalidation support after password rotation.

2. **Generate Alembic migration**
   ```powershell
   cd src
   venv\Scripts\Activate.ps1
   flask db migrate -m "add_user_profile_avatar_fields"
   flask db upgrade
   ```

3. **Verify** the resulting PostgreSQL table contains the new profile columns and still preserves existing user rows.

#### Key Decisions

- The new avatar fields should be nullable initially to avoid breaking existing user data during rollout.
- Existing `email` and `password_hash` constraints remain unchanged, preserving backward compatibility.
- The `session_version` integer already exists and will be incremented after password changes to support token/session invalidation logic.

#### Acceptance Criteria

- The migration completes without errors.
- Existing user records remain intact.
- New `avatar_*` columns are available for profile upload persistence.

---

### Phase 2 — Profile Service Layer (Business Logic)

**Objective**: Build a dedicated profile service that contains all profile-management logic, keeping routes thin and business logic centralized.

#### [NEW] `src/services/profile_service.py`

This service module will expose the following functions:

1. **`get_profile_data(user_id: int) -> tuple[dict, int]`**
   - Reads the currently authenticated user from the database.
   - Returns safe, non-sensitive user profile metadata, excluding password hashes.

2. **`update_profile(user_id: int, full_name: str | None, email: str | None) -> tuple[dict, int]`**
   - Validates required fields and email format.
   - Prevents duplicate email conflicts at the database layer.
   - Updates only the intended fields and commits changes.

3. **`change_password(user_id: int, current_password: str, new_password: str, confirm_password: str) -> tuple[dict, int]`**
   - Verifies the current password against the stored hash.
   - Enforces password policy and confirmation matching.
   - Replaces the stored hash and increments `session_version` to harden active sessions.

4. **`upload_avatar(user_id: int, uploaded_file) -> tuple[dict, int]`**
   - Validates file extension, MIME type, and file size.
   - Persists the upload into an app-controlled upload directory.
   - Stores the avatar reference in `avatar_url`, `avatar_mime_type`, and `avatar_uploaded_at`.

#### Implementation Notes

- All update paths must perform validation before persistence.
- Use structured logging for all success/failure flows.
- Reuse existing `User.set_password()` and `User.check_password()` methods instead of introducing custom password logic.
- Return consistent JSON status payloads for frontend consumption.

#### Acceptance Criteria

- Profile retrieval returns the current user state safely.
- Personal info updates persist to the database when inputs are valid.
- Password changes require current-password verification and reject weak or mismatched submissions.
- Avatar uploads are rejected for invalid type/size and succeed for compliant files.

---

### Phase 3 — Authenticated Route Exposure (Controller Layer)

**Objective**: Add profile endpoints in `routes.py` while keeping the route layer thin and delegating to the profile service.

#### [MODIFY] `src/routes.py`

The following route handlers should be added:

```python
@main_bp.route("/api/profile", methods=["GET", "PATCH"])
def api_profile():
    """Return or update the authenticated user's profile."""
    ...

@main_bp.route("/api/profile/password", methods=["POST"])
def api_profile_password():
    """Change the authenticated user's password."""
    ...

@main_bp.route("/api/profile/avatar", methods=["POST"])
def api_profile_avatar():
    """Upload a profile image for the authenticated user."""
    ...
```

#### Implementation Rules

- Access must be restricted to authenticated users only.
- The `routes.py` layer should parse request data and delegate all business behavior to `services/profile_service.py`.
- Responses should be JSON-only and follow the same consistent status contract established in the auth feature.

#### Acceptance Criteria

- `GET /api/profile` returns serialized profile details for the current session user.
- `PATCH /api/profile` updates `full_name` and/or `email` fields.
- `POST /api/profile/password` changes the hash and returns a success or validation error.
- `POST /api/profile/avatar` stores the avatar reference and returns its URL.

---

### Phase 4 — Frontend Profile Settings Integration

**Objective**: Add a profile settings experience to the existing authenticated navigation that feels native to the current premium editorial dashboard UI.

#### 4A. [MODIFY] `src/templates/index.html`

1. Add a new authenticated dropdown link: **Profile Settings**.
2. Add a dedicated settings section or route within the existing app shell to host:
   - Personal Information form
   - Password Change form
   - Profile Picture upload form
3. Keep the same premium neoclassical layout, card rhythm, and typography theme used by current pages.

#### 4B. [MODIFY] `src/static/css/frontend.css`

Add a new CSS block for the profile settings view:

- `.settings-shell`
- `.settings-header`
- `.settings-grid`
- `.settings-card`
- `.settings-card-wide`
- `.avatar-preview`
- `.helper-text`
- `.settings-title`
- `.eyebrow-label`

Use the existing design tokens (`--primary`, `--secondary`, `--outline`, `--muted`, `--surface`, `--background`, `--ff-serif`, `--ff-sans`) so the UI remains visually consistent.

#### 4C. [MODIFY] `src/static/js/frontend.js`

Add a profile settings controller that:

1. Loads the current authenticated profile from `/api/profile`.
2. Submits personal info updates to `/api/profile`.
3. Submits password changes to `/api/profile/password`.
4. Uploads avatar images to `/api/profile/avatar`.
5. Updates the header avatar and user display name after successful profile changes.
6. Displays toast notifications for save/update success or validation errors.

#### Acceptance Criteria

- The profile settings UI is reachable from the authenticated header dropdown.
- The settings forms visually fit the existing layout and styling system.
- Successful profile edits update the visible account information without a page reload.
- Avatar upload results are shown in the UI immediately after success.

---

### Phase 5 — Verification & Regression Safety

**Objective**: Verify the feature works within the existing codebase and does not regress the authentication or homepage flows.

#### Automated Tests

Create or extend tests covering:

1. `GET /api/profile` returns the authenticated user’s current public profile.
2. `PATCH /api/profile` updates `full_name` and `email` correctly.
3. `POST /api/profile/password` rejects invalid current password and rejects weak password policy.
4. `POST /api/profile/avatar` rejects invalid files and saves valid uploads.
5. Existing auth login/logout behavior still works with the new schema changes.

#### Manual Verification

- Start the Flask app through the project’s standard development flow.
- Sign in as a registered user.
- Open the profile settings area.
- Update name and email, then confirm the new values persist.
- Change the password with a valid current password and verify the session state is hardened.
- Upload a valid avatar image and confirm the header renders the updated avatar.
- Attempt invalid inputs to confirm error messages and validation behavior.

---

## Verification Plan

### Automated Verification

Run the relevant test subset after implementation:

```powershell
cd src
venv\Scripts\Activate.ps1
pytest tests/test_auth.py tests/test_profile_management.py
```

### Manual Verification Checklist

- User can view and edit personal information.
- Password change requires current password verification.
- Profile picture upload is accepted only for valid formats/sizes.
- Header dropdown and authenticated shell reflect the updated profile state.
- No regression to existing login, logout, or article browsing experience.
