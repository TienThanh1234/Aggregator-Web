# Tasks: User Profile Management

**Input**: Design documents from [spec.md](spec.md) and [plan.md](plan.md)

**Prerequisites**: plan.md (required), spec.md (required for user stories), constitution.md (required for governance)

**Branch**: `004-user-profile-management`

**Scope**: This task breakdown covers the full User Profile Management feature — Personal Info Updates, Password Change Workflow, and Profile Picture Uploads — while preserving the existing Flask MVC architecture and premium neoclassical frontend theme.

---

## Phase 1: Database Model Evolution & Migration

**Purpose**: Extend the existing `User` ORM model with avatar metadata and profile-related persistence fields, then generate a migration for safe database rollout.

### Implementation Tasks

- [x] T001 [P] Extend the `User` model in [src/models.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py) with avatar-related columns.
  - Add `avatar_url = db.Column(db.String(1000), nullable=True)`.
  - Add `avatar_mime_type = db.Column(db.String(120), nullable=True)`.
  - Add `avatar_uploaded_at = db.Column(db.DateTime, nullable=True)`.
  - Keep existing `email`, `password_hash`, `role`, `session_version`, and auth helper methods intact.
  - **Acceptance Criteria**: The `User` model exposes all avatar fields and remains compatible with existing account records.

- [x] T002 [P] Confirm the `User` model already supports secure password hashing and keep the password lifecycle intact.
  - Reuse `set_password()` and `check_password()` currently defined on `User`.
  - Ensure password change operations update `password_hash` and do not expose it in API responses.
  - **Acceptance Criteria**: Password hashes remain stored via Werkzeug PBKDF2 and never leaked through profile responses.

- [x] T003 Generate and apply the Alembic migration for avatar/profile fields.
  - Activate venv: `venv\Scripts\Activate.ps1`.
  - Run `flask db migrate -m "add_user_profile_avatar_fields"`.
  - Run `flask db upgrade`.
  - **Acceptance Criteria**: The PostgreSQL `users` table contains the new avatar support columns, and existing rows remain intact.

---

## Phase 2: Profile Service Layer (Business Logic)

**Purpose**: Create the `profile_service.py` module containing all profile-management business logic and keeping routes thin per MVC.

### Implementation Tasks

- [x] T004 [P] Create [src/services/profile_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/profile_service.py) with `get_profile_data()`.
  - Accept `user_id` and return a safe profile payload containing only public account details.
  - Exclude `password_hash` from all outputs.
  - **Acceptance Criteria**: An authenticated user receives their current `id`, `username`, `email`, `full_name`, `role`, and avatar metadata without sensitive secrets.

- [x] T005 [P] Add `update_profile()` to [src/services/profile_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/profile_service.py).
  - Accept `user_id`, `full_name`, and `email` values.
  - Validate non-empty values and email format.
  - Reject duplicate email conflicts with a clear error response.
  - Persist the update via SQLAlchemy and commit atomically.
  - **Acceptance Criteria**: Valid updates return 200 with the updated profile. Duplicate email returns 400 with a user-friendly validation message.

- [x] T006 [P] Add `change_password()` to [src/services/profile_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/profile_service.py).
  - Accept `user_id`, `current_password`, `new_password`, `confirm_password`.
  - Verify the current password using `User.check_password()`.
  - Enforce password policy (minimum 8 chars, at least one letter and one number, and matching confirmation).
  - Replace the password hash using `User.set_password()`.
  - Increment `session_version` to harden session state after a password rotation.
  - **Acceptance Criteria**: Correct current password + valid new password produces 200 success. Wrong current password or weak password produces 400/401 with appropriate validation message.

- [x] T007 [P] Add `upload_avatar()` to [src/services/profile_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/profile_service.py).
  - Validate uploaded file size, extension, and MIME type.
  - Persist the image into a controlled upload directory under the app’s static assets or upload-safe storage path.
  - Save the resulting file reference into `avatar_url`, `avatar_mime_type`, and `avatar_uploaded_at`.
  - **Acceptance Criteria**: Valid image uploads succeed and produce a saved avatar reference; invalid file types or oversized files are rejected cleanly.

- [x] T008 Add structured logging and error-handling guards to [src/services/profile_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/profile_service.py).
  - Wrap database updates in `try/except` and call `db.session.rollback()` on failure.
  - Log successful updates and failure reasons with `logging.getLogger(__name__)`.
  - **Acceptance Criteria**: All relevant flows emit structured logs and no silent failures occur.

---

## Phase 3: API Route Registration (Controller Layer)

**Purpose**: Add thin authenticated routes in `routes.py` so the controller layer delegates profile operations to the service module.

### Implementation Tasks

- [x] T009 [P] Add `GET /api/profile` to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Import `get_profile_data` from `services.profile_service`.
  - Return JSON from the service with appropriate HTTP status.
  - **Acceptance Criteria**: The endpoint returns the active user profile for authenticated sessions.

- [x] T010 [P] Add `PATCH /api/profile` to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Read JSON body fields for `full_name` and `email`.
  - Delegate to `update_profile()`.
  - **Acceptance Criteria**: Name and email updates persist correctly and return success JSON.

- [x] T011 [P] Add `POST /api/profile/password` to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Read `current_password`, `new_password`, and `confirm_password` from the request JSON.
  - Delegate to `change_password()`.
  - **Acceptance Criteria**: Password rotation is only allowed when current password verification succeeds.

- [x] T012 Add `POST /api/profile/avatar` to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Handle multipart upload input.
  - Delegate to `upload_avatar()`.
  - Return the stored avatar URL in the response body.
  - **Acceptance Criteria**: Valid avatar uploads return a success payload with avatar URL. Invalid uploads return a validation error.

- [x] T013 Update imports in [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Import profile service functions from the new service module.
  - Keep route handlers thin and free of business logic.
  - **Acceptance Criteria**: All new endpoints import cleanly without runtime errors.

---

## Phase 4: Frontend Integration (HTML + CSS + JavaScript)

**Purpose**: Add a settings experience that blends into the existing premium editorial shell rather than creating a disconnected UI.

### 4A. HTML Template Updates

- [x] T014 [P] Update [src/templates/index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html) to expose a profile settings entry.
  - Add a new dropdown item or navigation action named **Profile Settings** in the authenticated user card.
  - Ensure the current authenticated user’s avatar and display name are visible in the shell.
  - **Acceptance Criteria**: Users can navigate into the profile settings UI from the authenticated header navigation.

- [x] T015 [P] Add the profile settings shell markup to [src/templates/index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html).
  - Include sections for: personal info, security/password update, and profile picture upload.
  - Keep markup consistent with current layout and semantic structure.
  - **Acceptance Criteria**: The settings screen matches the existing visual rhythm and card-based composition.

### 4B. CSS Styling

- [x] T016 [P] Add settings shell styles to [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).
  - Implement `.settings-shell`, `.settings-header`, `.settings-grid`, `.settings-card`, and `.settings-card-wide`.
  - Use existing CSS vars to maintain the same neoclassical theme.
  - **Acceptance Criteria**: The profile settings section visually aligns with the current homepage and article reader layout.

- [x] T017 [P] Add avatar preview and helper text styling in [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).
  - Style `.avatar-preview`, `.helper-text`, `.eyebrow-label`, and `.settings-title`.
  - Ensure components remain responsive on narrow screens.
  - **Acceptance Criteria**: The avatar preview and uploaded asset UI are aesthetically consistent and readable.

### 4C. JavaScript SPA Controller

- [x] T018 [P] Extend the front-end state container in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js) with profile settings state variables.
  - Add references for the settings forms and output nodes.
  - Track current profile data and current avatar URL.
  - **Acceptance Criteria**: The JS controller can read and update profile UI state.

- [x] T019 [P] Implement `loadProfileSettings()` in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Fetch `GET /api/profile` on page load or when navigating into the settings panel.
  - Fill the personal info form and avatar preview with the current user data.
  - **Acceptance Criteria**: The settings screen reflects the active account profile.

- [x] T020 [P] Implement `handleProfileUpdate()` in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Submit the profile info form to `PATCH /api/profile`.
  - Display toast success or validation error messages.
  - Update the visible header display name after successful changes.
  - **Acceptance Criteria**: Personal info updates apply immediately to the visible UI without page reload.

- [x] T021 [P] Implement `handlePasswordChange()` in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Submit the password form to `POST /api/profile/password`.
  - Show success or validation failure toasts.
  - **Acceptance Criteria**: Password update requires current-password verification and shows correct UX feedback.

- [x] T022 [P] Implement `handleAvatarUpload()` in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Send the selected image file to `POST /api/profile/avatar` via multipart form upload.
  - Refresh the avatar preview and header avatar after success.
  - **Acceptance Criteria**: Avatar uploads work end-to-end for valid file selections.

- [x] T023 Add event wiring in the `init()` function of [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Bind the profile settings forms to the new handlers.
  - Ensure the page continues to work with the existing article feed and auth flows.
  - **Acceptance Criteria**: No new console errors occur when the settings UI is opened.

---

## Phase 5: Verification and Test Coverage

**Purpose**: Validate the profile-management feature through automated tests and manual verification for regression safety.

### Implementation Tasks

- [x] T024 Create [src/tests/test_profile_management.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/tests/test_profile_management.py) with personal-info update tests.
  - Test successful `PATCH /api/profile` updates `full_name` and `email`.
  - Test duplicate-email rejection returns 400.
  - Test malformed email rejection returns 400.
  - **Acceptance Criteria**: Profile update validation is covered by automated tests.

- [x] T025 Add password-change tests to [src/tests/test_profile_management.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/tests/test_profile_management.py).
  - Test valid password change with correct current password returns 200.
  - Test wrong current password returns 401/400 with a generic validation failure message.
  - Test weak new password returns 400.
  - **Acceptance Criteria**: Password change rules are verified in tests.

- [x] T026 Add avatar upload tests to [src/tests/test_profile_management.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/tests/test_profile_management.py).
  - Test valid upload saves the model reference and returns the new avatar URL.
  - Test invalid file type and oversized file are rejected.
  - **Acceptance Criteria**: Upload validation behavior is covered.

- [x] T027 Run the relevant test subset and verify the new feature is stable.
  - Command: `cd src && venv\Scripts\Activate.ps1 && python -m pytest tests/test_profile_management.py -v`
  - **Acceptance Criteria**: All newly added tests pass without regressions to the existing auth flow.

---

## Phase 6: Regression and UX Review

**Purpose**: Verify the feature works cleanly within the existing app shell, with no breakage to the homepage, auth modal, or article reader navigation.

### Implementation Tasks

- [x] T028 Run manual browser verification after implementation.
  - Sign in, open the profile settings UI, update the display name, change the email, and verify saved state.
  - Change the password and confirm the session is hardened.
  - Upload a profile image and confirm header rendering updates accordingly.
  - **Acceptance Criteria**: The new experience is polished, secure, and visually integrated.

- [x] T029 Review for constitution compliance before merge.
  - Confirm routes remain thin, models remain schema-only, and no hardcoded secrets are introduced.
  - Confirm all uploads and password changes use validation and logging.
  - **Acceptance Criteria**: Implementation respects the governing constitution and code organization principles.
