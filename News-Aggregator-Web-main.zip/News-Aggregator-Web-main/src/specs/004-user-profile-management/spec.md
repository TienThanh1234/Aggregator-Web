# Feature Specification: User Profile Management

**Feature Branch**: `004-user-profile-management`  
**Created**: 2026-07-23  
**Status**: Draft  
**Target Specification Location**: `src/specs/004-user-profile-management/spec.md`  
**Constitution Authority**: Built strictly in compliance with [constitution.md](../../.specify/memory/constitution.md) (MVC Pattern, Flask-SQLAlchemy, Environment Configuration, Vanilla HTML5/CSS3/JS, Security Governance).

---

## 1. Executive Summary & Scope

The **User Profile Management** feature introduces a secure, self-service account settings experience for authenticated users of the Tell Me More News Aggregator.

This specification covers three user-facing capabilities:

1. **Personal Info Updates**: allows logged-in users to update their display name and email address.
2. **Password Changes**: allows secure replacement of the current password with a new password after re-authentication.
3. **Profile Picture Uploads**: allows the user to upload a custom avatar image that appears in the authenticated header and dashboard shell.

The feature is intentionally designed to fit the existing neoclassical editorial interface already used by the application homepage, article reading experience, and authenticated user navigation.

> [!NOTE]
> Per the project constitution, this specification defines backend contracts, database schema changes, security controls, and frontend GUI expectations. No implementation code is executed during this specification phase.

---

## 2. User Stories & Acceptance Criteria

### User Story 1 — Personal Information Updates (Priority: P1)
**As a** registered user,  
**I want to** update my personal information (full name and email) from a settings page,  
**So that** my account details remain current and account notifications continue to reach me reliably.

#### Acceptance Scenarios:
- **AS-UP-01 (Profile Load)**: Given an authenticated user visits the profile settings page, when the page loads, then the current `full_name`, `email`, and avatar state are displayed in a polished settings layout that matches the site visual language.
- **AS-UP-02 (Valid Update)**: Given the user enters a valid full name and a unique email address, when the save action is submitted, then the backend persists the updates in PostgreSQL and returns a success message without exposing sensitive account data.
- **AS-UP-03 (Duplicate Email Protection)**: Given an email already associated with another account, when the user submits the update, then the backend rejects the request with a clear validation error and preserves the previous account data.
- **AS-UP-04 (Client & Server Validation)**: Given invalid inputs such as malformed email syntax or empty required fields, then inline frontend validation and server-side validation both prevent invalid persistence.

---

### User Story 2 — Password Change Workflow (Priority: P1)
**As a** registered user,  
**I want to** change my password from the settings page using my current password and a new secure password,  
**So that** I can protect my account whenever my password is compromised or needs rotation.

#### Acceptance Scenarios:
- **AS-PW-01 (Verified Change)**: Given the user provides the current password, a new password, and a confirmation value, when the password change is submitted, then the backend verifies the existing hash and applies the new password only if all validations succeed.
- **AS-PW-02 (Policy Enforcement)**: Given the new password does not satisfy the project minimum password policy, when the user tries to submit it, then the system rejects the change with an explicit message and requires a stronger password.
- **AS-PW-03 (Session Hardening)**: Given the password is successfully changed, when the request completes, then existing sessions are invalidated or versioned to prevent reuse of old session state, and the user is prompted to sign in again for safety.
- **AS-PW-04 (No Disclosure)**: Given a failed password-change attempt, when the response is returned, then the service uses a generic error message and does not expose whether the current password was correct.

---

### User Story 3 — Profile Picture Uploads (Priority: P2)
**As a** registered user,  
**I want to** upload a profile photo from the settings area,  
**So that** my account is visually personalized instead of showing a blank or generic avatar.

#### Acceptance Scenarios:
- **AS-AV-01 (Valid Upload)**: Given the user selects a supported image file under the configured size limit, when the upload is processed, then the backend stores the image in an upload-safe location and saves its reference in the database.
- **AS-AV-02 (Invalid File Rejection)**: Given the selected file is not an image type or exceeds the allowed size threshold, when the upload is attempted, then the UI shows a clear error and the file is not persisted.
- **AS-AV-03 (Avatar Rendering)**: Given an uploaded profile picture exists, when the user returns to the app header or dashboard, then the avatar is visually rendered with the same premium theme styling used across the existing authenticated navigation.

---

## 3. Database Schema & Architecture (MVC Model Layer)

In compliance with section II of `constitution.md`, all persistent profile data stays in the SQLAlchemy data model layer inside `src/models.py`.

### 3.1 `User` Entity Extensions

The existing `User` entity will be extended with profile-management fields.

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `full_name` | `VARCHAR(100)` | Nullable | User-visible display name |
| `email` | `VARCHAR(255)` | Unique, Not Null, Index | Primary account email for notifications |
| `password_hash` | `VARCHAR(255)` | Not Null | Hashed password value |
| `avatar_url` | `VARCHAR(1000)` | Nullable | Publicly accessible avatar file URL or storage path reference |
| `avatar_mime_type` | `VARCHAR(120)` | Nullable | Uploaded Content-Type metadata |
| `avatar_uploaded_at` | `TIMESTAMP` | Nullable | Timestamp of last successful avatar upload |
| `session_version` | `INTEGER` | Default `0`, Not Null | Increments after password change to invalidate older sessions |

### 3.2 Data Integrity Requirements
- `email` remains unique at the database layer.
- `avatar_url` must be validated server-side before being stored.
- Password changes must update the stored hash and trigger session invalidation via the `session_version` field.
- Image references should be persisted as relative or signed URLs that comply with server-side upload policy.

```python
# Conceptual representation for src/models.py
from datetime import datetime
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash

class User(db.Model):
    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=True, index=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=True)
    role = db.Column(db.String(50), nullable=False, default="user")
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.utcnow())
    last_login = db.Column(db.DateTime, nullable=True)
    password_reset_token_hash = db.Column(db.String(255), nullable=True)
    password_reset_expires_at = db.Column(db.DateTime, nullable=True)
    session_version = db.Column(db.Integer, nullable=False, default=0)
    avatar_url = db.Column(db.String(1000), nullable=True)
    avatar_mime_type = db.Column(db.String(120), nullable=True)
    avatar_uploaded_at = db.Column(db.DateTime, nullable=True)
```

---

## 4. API & Controller Specification (MVC Controller & Service Layer)

The route layer in `src/routes.py` remains thin and delegates business logic to service modules such as `src/services/profile_service.py`.

### 4.1 Authenticated Profile API Endpoints

#### 1. `GET /api/profile`
- **Description**: Returns the authenticated user’s current public profile state.
- **Response (200 OK)**:
```json
{
  "status": "success",
  "user": {
    "id": 12,
    "username": "johndoe",
    "full_name": "John Doe",
    "email": "john@example.com",
    "avatar_url": "/static/uploads/avatars/12.png",
    "role": "user"
  }
}
```

#### 2. `PATCH /api/profile`
- **Description**: Updates `full_name` and/or `email` for the authenticated user.
- **Request Body**:
```json
{
  "full_name": "Johnathan Doe",
  "email": "johnathan@example.com"
}
```
- **Response (200 OK)**:
```json
{
  "status": "success",
  "message": "Profile updated successfully.",
  "user": {
    "id": 12,
    "full_name": "Johnathan Doe",
    "email": "johnathan@example.com"
  }
}
```

#### 3. `POST /api/profile/password`
- **Description**: Changes the currently authenticated user’s password.
- **Request Body**:
```json
{
  "current_password": "OldPassword123",
  "new_password": "NewPassword456!",
  "confirm_password": "NewPassword456!"
}
```
- **Response (200 OK)**:
```json
{
  "status": "success",
  "message": "Password updated successfully. Please sign in again.",
  "redirect_url": "/login"
}
```

#### 4. `POST /api/profile/avatar`
- **Description**: Uploads a profile image that will be used in the authenticated UI shell.
- **Request Body**: `multipart/form-data` with image file.
- **Response (200 OK)**:
```json
{
  "status": "success",
  "message": "Profile picture uploaded successfully.",
  "avatar_url": "/static/uploads/avatars/12.png"
}
```

### 4.2 Service Responsibilities
The implementation must keep route handlers thin and move logic into a dedicated service module such as `src/services/profile_service.py` with functions for:
- `get_profile_data(user_id)`
- `update_profile(user_id, full_name, email)`
- `change_password(user_id, current_password, new_password)`
- `upload_avatar(user_id, uploaded_file)`

All user-facing results must return consistent JSON response shapes and log security-relevant events.

---

## 5. Frontend GUI Design & Existing Theme Alignment

The User Profile Management screen must follow the same premium neoclassical visual system already established in `src/templates/index.html` and `src/static/css/frontend.css`.

### 5.1 Layout Objective
The settings experience should appear as a new authenticated section under the existing user navigation flow, not as a foreign modal or completely separate design system.

Suggested placement:
- Add a new menu item in the authenticated header dropdown: **Profile Settings**.
- Render a dedicated settings dashboard page or section in the existing container alignment with the current editorial shell.

### 5.2 Visual Design Constraints
Keep the same:
- dark obsidian banner surface (`#1A1A1A`)
- slate & indigo palette
- serif + sans typography pairing
- dot grid overlays and card grid rhythm
- rounded premium cards and measured spacing

### 5.3 UI Wireframe Specification

```html
<section class="settings-shell">
  <div class="settings-header">
    <div>
      <p class="eyebrow-label">Account Controls</p>
      <h2 class="settings-title">Profile Settings</h2>
    </div>
    <div class="avatar-preview-wrap">
      <img class="avatar-preview" src="/static/uploads/avatars/default.png" alt="Current avatar">
    </div>
  </div>

  <div class="settings-grid">
    <div class="settings-card">
      <h3>Personal Information</h3>
      <form id="form-profile-info">
        <label>Full Name</label>
        <input type="text" id="profile-full-name" />
        <label>Email Address</label>
        <input type="email" id="profile-email" />
        <button type="submit">Save Changes</button>
      </form>
    </div>

    <div class="settings-card">
      <h3>Security</h3>
      <form id="form-profile-password">
        <label>Current Password</label>
        <input type="password" id="current-password" />
        <label>New Password</label>
        <input type="password" id="new-password" />
        <label>Confirm Password</label>
        <input type="password" id="confirm-password" />
        <button type="submit">Change Password</button>
      </form>
    </div>

    <div class="settings-card settings-card-wide">
      <h3>Profile Picture</h3>
      <form id="form-profile-avatar" enctype="multipart/form-data">
        <input type="file" id="avatar-upload" accept="image/*" />
        <button type="submit">Upload Image</button>
      </form>
      <p class="helper-text">Supported formats: JPG, PNG, WEBP. Maximum size: 2MB.</p>
    </div>
  </div>
</section>
```

### 5.4 Frontend Interaction Requirements
- Display live validation messages for invalid email, empty name, weak password, or invalid image file.
- Show a success toast after save operations.
- Update the header avatar and displayed user name immediately on successful profile changes.
- Preserve the existing SPA-style navigation and do not break the article feed experience.

---

## 6. Security & Compliance Controls

This feature must follow the same protection posture as the current authentication system.

### Security Requirements
- Password update must require the user’s current password.
- Passwords must be stored only as salted hashes using the existing `set_password()` pattern.
- All file uploads must be validated by MIME type, extension, and size.
- Avatar file storage must use a dedicated upload directory that is not executable.
- Email update must use uniqueness constraints at the database layer.
- Failed profile operations must emit logs and not reveal sensitive details in the client response.
- Session versioning must be incremented after password changes to invalidate stale sessions if session token checks are used.

---

## 7. Files to be Created / Modified

### [NEW] `src/services/profile_service.py`
- Contains business logic for profile reads, password changes, and avatar upload orchestration.

### [MODIFY] `src/models.py`
- Extend the `User` entity with the avatar-related columns and any validation-related defaults.

### [MODIFY] `src/routes.py`
- Add authenticated endpoints for profile read/update, password change, and avatar upload.

### [MODIFY] `src/templates/index.html`
- Add a settings navigation entry and the profile settings panel/layout.

### [MODIFY] `src/static/css/frontend.css`
- Add styling for the settings shell, cards, forms, avatar preview, and responsive layout.

### [MODIFY] `src/static/js/frontend.js`
- Add client-side request handlers, form validation, avatar preview, and toast updates.

---

## 8. Success Criteria

- **SC-UP-001**: A logged-in user can open a settings area and update their full name and email without leaving the existing app shell.
- **SC-UP-002**: A user can securely change their password using current-password verification and new-password validation.
- **SC-UP-003**: A profile picture can be uploaded, persisted, and rendered in the authenticated header/dashboard UI.
- **SC-UP-004**: All profile changes remain aligned with the existing premium editorial style and responsive layout conventions.
- **SC-UP-005**: The backend and database enforce uniqueness, validation, and secure password storage rules.

---

## 9. Notes for Implementation Planning

This feature is a direct enhancement of existing authentication and user account foundations. It should be delivered as a user-account enhancement module rather than a separate product domain, because it naturally extends the current `User` model, session state, and authenticated header navigation already present in the codebase.
