# Feature Specification: Account Authentication (Auth) System

**Feature Branch**: `003-account-authentication`  
**Created**: 2026-07-23  
**Status**: Draft  
**Target Specification Location**: `src/specs/003-account-authentication/spec.md`  
**Constitution Authority**: Built strictly in compliance with [constitution.md](../../.specify/memory/constitution.md) (MVC Pattern, Flask-SQLAlchemy, Environment Configuration, Vanilla HTML5/CSS3/JS, Security Governance).

---

## 1. Executive Summary & Scope

The **Account Authentication (Auth) System** introduces user identity management, role-based access control (RBAC), and session security to the *Tell Me More* Neoclassical News Aggregator. 

This functional specification covers four core authentication features:
1. **Guest User Registration**: Enables new visitors to register a personal account, creating a unique profile to unlock protected system features (e.g., article bookmarking, AI custom context queries, personalized feeds).
2. **Role-Based Login**: Validates credentials securely and automatically routes users to their corresponding dashboard based on assigned roles (**Guest**, **User**, or **Admin**).
3. **Log Out & Session Invalidation**: Immediately terminates server-side session state and purges active browser memory/cookies to ensure account safety on shared devices.
4. **Forgot Password & Credential Reset**: Lets an account holder request a time-limited, single-use reset link without exposing whether an email address is registered.

> [!NOTE]
> Per the project constitution, this specification defines the design, database contracts, API interfaces, security controls, and frontend GUI layouts. **No implementation code is executed during this specification phase.**

---

## 2. User Stories & Acceptance Criteria

### User Story 1 — Guest User Registration (Priority: P1)
**As a** new guest visitor,  
**I want to** register for a personal account by filling in my registration details (username, email, password, full name),  
**So that** I can create a distinct user identity and access protected features of the application later.

#### Acceptance Scenarios:
- **AS-REG-01 (Valid Registration)**: Given a guest on the registration modal/page, when they provide a valid email, unique username, and strong password (min 8 chars, 1 number, 1 special char), then the backend hashes the password, stores the record in PostgreSQL, creates a standard `user` role account, and displays a success notification with direct login access.
- **AS-REG-02 (Duplicate Prevention)**: Given an existing email or username in the database, when a guest attempts to register with identical details, then the application rejects the request with an explicit error message ("Email or username already registered").
- **AS-REG-03 (Client & Server Validation)**: Given incomplete or improperly formatted inputs (e.g. invalid email format), then real-time inline validation flags the errors before submission, and server-side validation acts as a fallback.

---

### User Story 2 — Role-Based Secure Login & Automatic Redirection (Priority: P1)
**As a** registered account holder (Guest, Standard User, or Admin),  
**I want to** enter my credentials and log into the application,  
**So that** my identity is verified and I am automatically directed to the correct dashboard with the tools tailored to my role.

#### Acceptance Scenarios:
- **AS-LOG-01 (Credential Verification)**: Given valid login credentials (email/username + password), when submitted, the backend verifies the password hash via `check_password_hash` and initializes an encrypted session.
- **AS-LOG-02 (Role-Based Redirection)**:
  - **Guest Role**: Directs user to the main public dispatch feed with an unauthenticated banner inviting them to register/login.
  - **Standard User Role**: Directs user to the **Personalized Reader Dashboard** (`/dashboard/user`), displaying saved dispatches, custom category preferences, and AI chat history.
  - **Admin Role**: Directs user to the **System Admin Dashboard** (`/dashboard/admin`), displaying ETL scraper status, job execution controls, duplicate logs, and user role management.
- **AS-LOG-03 (Failed Login Protection)**: Given incorrect credentials, the system responds with a generic error message ("Invalid username/email or password") without revealing whether the user exists, and increments rate-limiting counters.

---

### User Story 3 — Log Out & Active Session Memory Clearance (Priority: P1)
**As an** authenticated user operating on a public or shared computer,  
**I want to** log out of my account,  
**So that** my active session memory is completely cleared from the web browser and my account remains protected from unauthorized access.

#### Acceptance Scenarios:
- **AS-OUT-01 (Server Invalidation)**: When the user clicks the "Log Out" button, a `POST /api/auth/logout` request is dispatched to invalidate the Flask server session (`session.clear()`) and revoke auth tokens/cookies.
- **AS-OUT-02 (Client Memory Purge)**: The frontend JavaScript clears all cached user session data stored in `localStorage`, `sessionStorage`, and memory objects.
- **AS-OUT-03 (Secure Redirect)**: The user is redirected to the public homepage (`/`) with a toast notification ("You have been successfully logged out"), and subsequent browser back-button navigations to protected dashboards trigger an authentication redirect to `/login`.

---

## 3. Database Schema & Architecture (MVC Model Layer)

Following section II of `constitution.md`, database models reside strictly in `src/models.py`.

### 3.1 `User` Entity Schema (`src/models.py`)

| Column Name | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | `INTEGER` | Primary Key, Auto Increment | Unique account identifier |
| `username` | `VARCHAR(50)` | Unique, Not Null, Index | Public handle / login name |
| `email` | `VARCHAR(120)` | Unique, Not Null, Index | User email address |
| `password_hash` | `VARCHAR(255)` | Not Null | Salted hash generated via Werkzeug / bcrypt |
| `full_name` | `VARCHAR(100)` | Nullable | User display name |
| `role` | `VARCHAR(20)` | Default `'user'`, Not Null | Account role: `'guest'`, `'user'`, `'admin'` |
| `is_active` | `BOOLEAN` | Default `TRUE`, Not Null | Account status flag |
| `created_at` | `TIMESTAMP` | Default `CURRENT_TIMESTAMP` | Account creation timestamp (UTC) |
| `last_login` | `TIMESTAMP` | Nullable | Timestamp of last successful login |
| `password_reset_token_hash` | `VARCHAR(255)` | Nullable | SHA-256 digest of the active reset token; plaintext token is never persisted |
| `password_reset_expires_at` | `TIMESTAMP` | Nullable | UTC expiry for the active reset token |
| `session_version` | `INTEGER` | Default `0`, Not Null | Incremented after password reset to invalidate existing sessions |

```python
# Conceptual representation for src/models.py
from datetime import datetime
from werkzeug.security import generate_password_hash, check_password_hash
from app import db

class User(db.Model):
    __tablename__ = 'users'

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=False, index=True)
    email = db.Column(db.String(120), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=True)
    role = db.Column(db.String(20), nullable=False, default='user') # 'guest', 'user', 'admin'
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    last_login = db.Column(db.DateTime, nullable=True)

    def set_password(self, password: str) -> None:
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        return check_password_hash(self.password_hash, password)
```

---

## 4. API & Controller Specification (MVC Controller & Service Layer)

In compliance with `constitution.md`, route handlers in `src/routes.py` remain thin and delegate business logic to `src/services/auth_service.py`.

### 4.1 REST API Endpoints

#### 1. `POST /api/auth/register`
- **Description**: Registers a new user account.
- **Request Body**:
  ```json
  {
    "username": "johndoe",
    "email": "john@example.com",
    "password": "SecurePassword123!",
    "full_name": "John Doe"
  }
  ```
- **Response (210 Created)**:
  ```json
  {
    "status": "success",
    "message": "Account created successfully.",
    "user": {
      "id": 12,
      "username": "johndoe",
      "email": "john@example.com",
      "role": "user"
    }
  }
  ```

#### 2. `POST /api/auth/login`
- **Description**: Authenticates user credentials and establishes session state.
- **Request Body**:
  ```json
  {
    "identity": "johndoe",  // Accepts username or email
    "password": "SecurePassword123!"
  }
  ```
- **Response (200 OK)**:
  ```json
  {
    "status": "success",
    "message": "Login successful.",
    "redirect_url": "/dashboard/user",
    "user": {
      "id": 12,
      "username": "johndoe",
      "email": "john@example.com",
      "role": "user"
    }
  }
  ```

#### 3. `POST /api/auth/logout`
- **Description**: Clears server-side session and invalidates active authentication tokens.
- **Headers**: Session Cookie / Bearer Auth
- **Response (200 OK)**:
  ```json
  {
    "status": "success",
    "message": "Session invalidated successfully.",
    "redirect_url": "/"
  }
  ```

#### 4. `GET /api/auth/me`
- **Description**: Retrieves current authenticated session details.
- **Response (200 OK)**:
  ```json
  {
    "authenticated": true,
    "user": {
      "id": 12,
      "username": "johndoe",
      "role": "user"
    }
  }
  ```

---

## 5. Frontend GUI Design & Neoclassical Layout

The authentication interface matches the exact neoclassical, high-end editorial aesthetics established in `src/templates/index.html` and `src/static/css/frontend.css` (*Plus Jakarta Sans*, *Inter*, Slate `#0F172A`, Indigo `#4F46E5`, Obsidian Banner `#1A1A1A`, Dot Grid Overlays).

### 5.1 Auth Modal & Standalone GUI Wireframe

Below is the structured HTML wireframe specification to be integrated into `src/templates/index.html` and styled via `src/static/css/frontend.css`.

```html
<!-- ===== AUTHENTICATION MODAL SYSTEM ===== -->
<div id="auth-modal-overlay" class="auth-modal-backdrop hide">
  <div class="auth-card">
    
    <!-- Modal Header -->
    <div class="auth-card-header">
      <div class="auth-brand-logo">
        <svg class="logo-bolt" viewBox="0 0 16 24" fill="currentColor">
          <path d="M10 2 L4.5 12.5 H8.5 L7 17.5 L12.5 8 H8.5 L10 2 Z"/>
          <circle cx="8" cy="21.5" r="1.75"/>
        </svg>
        <span class="auth-brand-text">TELL ME MORE</span>
      </div>
      <button class="auth-close-btn" id="auth-modal-close" aria-label="Close Modal">&times;</button>
    </div>

    <!-- Auth Mode Switcher Tabs -->
    <div class="auth-nav-tabs">
      <button class="auth-tab-btn active" id="tab-auth-login" data-target="form-login">Sign In</button>
      <button class="auth-tab-btn" id="tab-auth-register" data-target="form-register">Create Account</button>
    </div>

    <!-- Alert / Toast Banner Container -->
    <div id="auth-alert-box" class="auth-alert hide">
      <i data-lucide="alert-circle" class="alert-icon"></i>
      <span id="auth-alert-message">Invalid username or password.</span>
    </div>

    <!-- Form 1: Login Form -->
    <form id="form-login" class="auth-form">
      <div class="form-group">
        <label for="login-identity" class="form-label">Username or Email</label>
        <div class="input-wrapper">
          <i data-lucide="user" class="input-icon"></i>
          <input type="text" id="login-identity" class="form-input" placeholder="e.g. reader@tellmemore.com" required>
        </div>
      </div>

      <div class="form-group">
        <div class="label-row">
          <label for="login-password" class="form-label">Password</label>
          <a href="#" class="forgot-link" id="forgot-pass-trigger">Forgot?</a>
        </div>
        <div class="input-wrapper">
          <i data-lucide="lock" class="input-icon"></i>
          <input type="password" id="login-password" class="form-input" placeholder="••••••••••••" required>
          <button type="button" class="toggle-password" id="toggle-login-pass">
            <i data-lucide="eye" class="eye-icon"></i>
          </button>
        </div>
      </div>

      <div class="form-options">
        <label class="checkbox-container">
          <input type="checkbox" id="remember-me-check">
          <span class="checkmark"></span>
          Remember session on this device
        </label>
      </div>

      <button type="submit" class="auth-submit-btn" id="btn-submit-login">
        <span>Sign In to Dispatch Dashboard</span>
        <i data-lucide="arrow-right" class="btn-icon"></i>
      </button>
    </form>

    <!-- Form 2: Guest Registration Form -->
    <form id="form-register" class="auth-form hide">
      <div class="form-group">
        <label for="reg-fullname" class="form-label">Full Name</label>
        <div class="input-wrapper">
          <i data-lucide="smile" class="input-icon"></i>
          <input type="text" id="reg-fullname" class="form-input" placeholder="e.g. Jane Doe" required>
        </div>
      </div>

      <div class="form-group">
        <label for="reg-username" class="form-label">Desired Username</label>
        <div class="input-wrapper">
          <i data-lucide="at-sign" class="input-icon"></i>
          <input type="text" id="reg-username" class="form-input" placeholder="e.g. janedoe" required>
        </div>
      </div>

      <div class="form-group">
        <label for="reg-email" class="form-label">Email Address</label>
        <div class="input-wrapper">
          <i data-lucide="mail" class="input-icon"></i>
          <input type="email" id="reg-email" class="form-input" placeholder="janedoe@example.com" required>
        </div>
      </div>

      <div class="form-group">
        <label for="reg-password" class="form-label">Password</label>
        <div class="input-wrapper">
          <i data-lucide="shield-check" class="input-icon"></i>
          <input type="password" id="reg-password" class="form-input" placeholder="At least 8 characters..." required>
        </div>
        <p class="input-help-text">Must contain at least 8 characters, including a letter and a number.</p>
      </div>

      <button type="submit" class="auth-submit-btn" id="btn-submit-register">
        <span>Create Personal Account</span>
        <i data-lucide="user-plus" class="btn-icon"></i>
      </button>
    </form>

    <!-- Footer Security Note -->
    <div class="auth-card-footer">
      <i data-lucide="shield" class="footer-shield-icon"></i>
      <span>Protected under Digital Integrity Encryption Protocol.</span>
    </div>

  </div>
</div>
```

---

### 5.2 Header Navigation Integration (Authenticated User State)

When a user logs in, the header in `src/templates/index.html` updates dynamically to display role badges and user controls:

```html
<!-- Site Header Nav (Updated for Auth) -->
<header class="site-header">
  <div class="container header-inner">
    <a href="/" class="logo-link">
      <svg class="logo-bolt" viewBox="0 0 16 24" fill="currentColor">
        <path d="M10 2 L4.5 12.5 H8.5 L7 17.5 L12.5 8 H8.5 L10 2 Z"/>
        <circle cx="8" cy="21.5" r="1.75"/>
      </svg>
      <span class="logo-text">TELL ME MORE</span>
    </a>

    <div class="header-right-actions">
      <!-- Unauthenticated View: Sign In Button -->
      <div id="nav-guest-actions" class="nav-auth-group">
        <button class="auth-outline-btn" id="nav-login-btn">Sign In</button>
        <button class="dispatches-btn" id="nav-register-btn">Register</button>
      </div>

      <!-- Authenticated View: User Profile Dropdown -->
      <div id="nav-user-actions" class="nav-auth-group hide">
        <div class="user-pill-dropdown" id="user-profile-menu">
          <span class="role-badge badge-user" id="nav-user-role-badge">USER</span>
          <span class="user-display-name" id="nav-user-display-name">Jane Doe</span>
          <i data-lucide="chevron-down" class="dropdown-icon"></i>

          <!-- Dropdown Popup -->
          <div class="dropdown-menu-card hide" id="user-dropdown-card">
            <a href="/dashboard" class="dropdown-item" id="menu-item-dashboard">
              <i data-lucide="layout-dashboard"></i> Dashboard
            </a>
            <a href="/bookmarks" class="dropdown-item">
              <i data-lucide="bookmark"></i> Saved Dispatches
            </a>
            <div class="dropdown-divider"></div>
            <button class="dropdown-item logout-item" id="btn-action-logout">
              <i data-lucide="log-out"></i> Log Out
            </button>
          </div>
        </div>
      </div>
    </div>

  </div>
</header>
```

---

### 5.3 Role Dashboards Layout Specifications

Following the requirements for role-based redirection, the frontend provides distinct views according to user roles:

#### 1. Guest Dashboard View (`/` - Public Feed View)
- Displays "The Live Feed" dispatches.
- Header shows "Sign In" and "Register" CTAs.
- Features sticky banner at top: *"Reading as Guest — Register a personal account to save dispatches and customize Tememo AI context parameters."*

#### 2. User Dashboard View (`/dashboard/user` - Standard Reader View)
- **Header**: Shows `[USER]` badge and account name.
- **Widgets**:
  - **Saved Dispatches**: Bookmarked articles with custom reading status.
  - **Reading History & AI Context Logs**: Summary of articles processed with Tememo AI.
  - **Account Preferences**: Email update and password change controls.

#### 3. Admin Dashboard View (`/dashboard/admin` - System Administrator View)
- **Header**: Shows `[ADMIN]` badge in terracotta red.
- **Widgets**:
  - **Scraper Pipeline Operations**: Status indicators for automated cron scraping jobs (APScheduler), last run timestamps, and manual trigger buttons.
  - **Database Integrity & Duplicate Logs**: Live feed of skipped duplicate dispatches and DB row counts.
  - **User Role Manager**: Table listing registered users with ability to toggle roles (`guest` ↔ `user` ↔ `admin`).

---

## 6. CSS Styling System (`src/static/css/frontend.css`)

To maintain exact theme harmony with existing pages, the following CSS rules will be added to `frontend.css`:

```css
/* ===== AUTHENTICATION SYSTEM STYLES ===== */
.auth-modal-backdrop {
  position: fixed;
  top: 0;
  left: 0;
  width: 100vw;
  height: 100vh;
  background: rgba(15, 23, 42, 0.75);
  backdrop-filter: blur(8px);
  z-index: 9999;
  display: flex;
  align-items: center;
  justify-content: center;
}

.auth-card {
  width: 100%;
  max-width: 440px;
  background: #FFFFFF;
  border-radius: 12px;
  box-shadow: 0 20px 25px -5px rgba(0, 0, 0, 0.1), 0 10px 10px -5px rgba(0, 0, 0, 0.04);
  border: 1px solid #E2E8F0;
  overflow: hidden;
  animation: authModalSlideIn 0.25s cubic-bezier(0.16, 1, 0.3, 1);
}

@keyframes authModalSlideIn {
  from { opacity: 0; transform: translateY(12px) scale(0.98); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}

.auth-card-header {
  background: #0F172A;
  padding: 1.25rem 1.5rem;
  display: flex;
  align-items: center;
  justify-content: space-between;
  color: #FFFFFF;
}

.auth-brand-logo {
  display: flex;
  align-items: center;
  gap: 0.5rem;
  font-family: var(--font-serif);
  font-weight: 700;
  letter-spacing: 0.05em;
  font-size: 0.95rem;
}

.auth-nav-tabs {
  display: flex;
  border-bottom: 1px solid #E2E8F0;
  background: #F8FAFC;
}

.auth-tab-btn {
  flex: 1;
  padding: 0.85rem 1rem;
  font-family: var(--font-sans);
  font-size: 0.875rem;
  font-weight: 600;
  color: #64748B;
  background: transparent;
  border: none;
  border-bottom: 2px solid transparent;
  cursor: pointer;
  transition: all 0.2s ease;
}

.auth-tab-btn.active {
  color: #4F46E5;
  border-bottom-color: #4F46E5;
  background: #FFFFFF;
}

.auth-form {
  padding: 1.5rem;
  display: flex;
  flex-direction: column;
  gap: 1.1rem;
}

.form-label {
  display: block;
  font-size: 0.75rem;
  font-weight: 700;
  text-transform: uppercase;
  letter-spacing: 0.05em;
  color: #334155;
  margin-bottom: 0.4rem;
}

.input-wrapper {
  position: relative;
  display: flex;
  align-items: center;
}

.input-icon {
  position: absolute;
  left: 0.85rem;
  width: 1rem;
  height: 1rem;
  color: #94A3B8;
}

.form-input {
  width: 100%;
  padding: 0.65rem 0.85rem 0.65rem 2.4rem;
  font-size: 0.9rem;
  font-family: var(--font-sans);
  border: 1px solid #CBD5E1;
  border-radius: 6px;
  background: #FFFFFF;
  color: #0F172A;
  transition: border-color 0.2s ease, box-shadow 0.2s ease;
}

.form-input:focus {
  outline: none;
  border-color: #4F46E5;
  box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.15);
}

.auth-submit-btn {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 0.5rem;
  width: 100%;
  padding: 0.75rem;
  background: #4F46E5;
  color: #FFFFFF;
  font-family: var(--font-sans);
  font-size: 0.875rem;
  font-weight: 600;
  border: none;
  border-radius: 6px;
  cursor: pointer;
  transition: background-color 0.2s ease;
}

.auth-submit-btn:hover {
  background: #4338CA;
}

/* Role Badges */
.role-badge {
  padding: 0.15rem 0.5rem;
  font-size: 0.65rem;
  font-weight: 800;
  letter-spacing: 0.05em;
  border-radius: 4px;
  text-transform: uppercase;
}

.badge-guest { background: #E2E8F0; color: #475569; }
.badge-user { background: #E0E7FF; color: #3730A3; }
.badge-admin { background: #FEE2E2; color: #991B1B; }
```

---

## 7. Security Controls & Constitutional Governance

In accordance with `constitution.md`:
1. **Password Protection**: Passwords MUST NEVER be stored in plain text. Hashing is performed using Werkzeug salted SHA-256 / PBKDF2 or bcrypt (`generate_password_hash`).
2. **Environment Secret Management (Principle III)**: Session secret keys (`SECRET_KEY`) and JWT tokens MUST be configured in `.env` and loaded via `python-dotenv`.
3. **Session Invalidation**: Log Out MUST invoke `session.clear()` server-side and purge client-side local/session memory.
4. **CSRF & Rate Limiting (Principle Section IX)**: All auth forms must include Flask-WTF CSRF tokens. Failed login attempts are rate-limited (e.g. max 5 attempts per minute per IP).
5. **Password Reset Tokens**: Reset tokens MUST be generated with `secrets.token_urlsafe`, stored only as SHA-256 hashes, expire after 30 minutes, and be cleared after successful use. Raw tokens, passwords, and reset URLs containing tokens MUST NOT be logged.
6. **Reset Delivery Configuration**: SMTP credentials and the public reset URL MUST come exclusively from `.env` (`MAIL_SERVER`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM`, `PASSWORD_RESET_URL`). `.env.example` must contain placeholders only.
7. **Reset Abuse Protection**: The request endpoint returns the same `202` response for existing and non-existing accounts and is rate-limited to five attempts per email/IP per 15 minutes.

---

## 8. Password Recovery Amendment

### User Story: Forgot Password & Secure Reset (P1)

An account holder can request a reset link by email, then set a new password without disclosing whether that email belongs to an account.

- `POST /api/auth/password-reset/request` accepts `{ "email": "reader@example.com" }` and always returns `202` with: `"If an active account matches this email, a password-reset link has been sent."`
- For an active account, `auth_service` creates a cryptographically random token, stores only `sha256(token)`, assigns a 30-minute UTC expiry, and emails `${PASSWORD_RESET_URL}?token=<token>` through the configured SMTP sender.
- `POST /api/auth/password-reset/confirm` accepts `{ "token": "...", "password": "..." }`. It applies the existing password-strength validation and returns `200` only for a valid, unexpired token; otherwise it returns `400` with `"This password-reset link is invalid or has expired."`
- A successful reset hashes the new password, clears reset-token fields, increments `session_version`, and requires a fresh login. The reset endpoint never creates an authenticated session.

### Data Contract

The `users` table gains `password_reset_token_hash VARCHAR(255) NULL`, `password_reset_expires_at TIMESTAMP NULL`, and `session_version INTEGER NOT NULL DEFAULT 0`. The Flask session stores the user's `session_version` at login; `get_current_user()` rejects and clears a session whose version no longer matches the user record.

### Frontend Contract

The login modal provides a **Forgot password?** trigger. The request screen accepts an email address and always displays the generic success notice. The reset screen accepts a new password and confirmation, validates strength before submission, removes passwords from the form after every response, and returns the user to the Sign In tab after success. Neither screen includes reset tokens in client-side storage.

---

## 9. Planned File Modification Inventory

When this specification is approved and moved to the implementation phase, the following repository files will be affected:

| Action | File Path | Description |
|---|---|---|
| **[NEW]** | [spec.md](spec.md) | This specification document. |
| **[NEW]** | [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py) | Service module for password hashing, user registration, credential checking, and session handling. |
| **[MODIFY]** | [src/models.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py) | Adds user authentication and password-reset state. |
| **[MODIFY]** | [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py) | Registers `/api/auth/*`, including password-reset request and confirmation handlers. |
| **[MODIFY]** | [src/templates/index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html) | Integrates auth modal, login/register tabs, header dropdown, and dashboard view containers. |
| **[MODIFY]** | [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css) | Adds styling for auth modal, form fields, role badges, and dashboard widgets. |
| **[MODIFY]** | [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js) | Adds JS controller logic for modal toggles, API requests (`fetch`), local session clearing, and role redirection. |

---

## 10. Success Criteria & Verification Plan

- **SC-AUTH-01 (Registration Validation)**: Submitting valid registration details creates a database record in PostgreSQL with a salted password hash and returns HTTP 201.
- **SC-AUTH-02 (Duplicate Rejection)**: Submitting duplicate usernames/emails returns HTTP 400 with actionable feedback without crashing the application.
- **SC-AUTH-03 (Role-Based Redirection)**: Successful authentication routes users to `/` (Guest), `/dashboard/user` (User), or `/dashboard/admin` (Admin) based on the user's DB role.
- **SC-AUTH-04 (Session & Memory Clearing)**: Clicking "Log Out" invalidates server-side session, clears client-side memory, and redirects to `/` within < 200ms.
- **SC-AUTH-05 (GUI Theme Alignment)**: Auth modals, buttons, forms, and badges seamlessly match the Neoclassical Obsidian/Indigo theme of `index.html`.
- **SC-AUTH-06 (Enumeration-safe Recovery)**: Password-reset requests return the same `202` response for active, inactive, and unknown email addresses.
- **SC-AUTH-07 (Single-use Reset)**: A reset token works once within 30 minutes, is never persisted or logged in plaintext, and invalidates all previous sessions after use.
