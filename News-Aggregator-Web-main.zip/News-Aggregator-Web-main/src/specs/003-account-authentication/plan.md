# Implementation Plan: Account Authentication (Auth) System

**Branch**: `003-account-authentication` | **Date**: 2026-07-23 | **Spec**: [spec.md](spec.md)

## Summary

This plan implements the Account Authentication system for the *Tell Me More* News Aggregator, introducing user registration, role-based login with automatic dashboard redirection, secure logout with full session/memory invalidation, and enumeration-safe password recovery. The work modifies the existing `User` model, creates an `auth_service.py` service module, registers `/api/auth/*` endpoints, integrates a neoclassical auth modal into the existing SPA frontend, and adds authentication-aware header navigation with role badges and a profile dropdown.

## Technical Context

**Language/Version**: Python 3.11+, HTML5, CSS3, ES6+ JavaScript

**Primary Dependencies**: Flask 3.1.3, Flask-SQLAlchemy 3.1.1, Werkzeug 3.1.8 (already installed — provides `generate_password_hash` / `check_password_hash`), Flask-Migrate 4.1.0 (Alembic), python-dotenv 1.2.2

**New Dependencies**: None required. Werkzeug's security module (already a Flask dependency) provides all password hashing functionality. Flask's built-in `session` object handles server-side session state. No additional packages needed.

**Storage**: PostgreSQL via Supabase (cloud) and localhost fallback (development)

**Existing State**: The `User` model already exists in `models.py` with `id`, `email`, `password_hash`, `role`, and `created_at` columns. It lacks `username`, `full_name`, `is_active`, and `last_login` fields required by the spec. The `SECRET_KEY` is already configured in `.env` and loaded in `app.py`.

**Project Type**: Web service (Flask MVC with Jinja2 templates, Vanilla JS SPA controller)

---

## Constitution Check

The implementation plan conforms to the constitution in the following ways:

- **Strict MVC Pattern (Principle II)**: Route handlers in `routes.py` remain thin, delegating registration logic, credential verification, and session management to `services/auth_service.py`. No business logic in templates or models beyond schema definition.
- **Environment Configuration (Principle III — NON-NEGOTIABLE)**: `SECRET_KEY` is already loaded from `.env` via `python-dotenv`. No new secrets are hardcoded. The existing `SECRET_KEY=11db98bedfb7c8139156df548a38e0a0` in `.env` will be used for Flask session signing.
- **Data Integrity (Principle IV — NON-NEGOTIABLE)**: Duplicate prevention is enforced through database-level `UNIQUE` constraints on `username` and `email`, with pre-insert validation in the service layer. Duplicate-skipping events are logged.
- **Code Organization (Principle V)**: PascalCase for model classes (`User`), snake_case for functions/methods (`register_user`, `check_password`), UPPER_SNAKE_CASE for constants.
- **Error Handling (Principle VI)**: Authentication failures return generic error messages without revealing user existence. All caught exceptions are logged with structured context.
- **Security (Code Quality Standards)**: Passwords hashed via Werkzeug PBKDF2. SQL injection prevented by exclusive use of SQLAlchemy ORM. CSRF protection noted for post-MVP.
- **Frontend Stack**: Vanilla HTML5/CSS3/JS with Jinja2 templates — no external frameworks introduced.
- **Environment Governance (Principle VIII)**: All CLI operations (migrations, tests) must execute inside the activated `venv`.

---

## Project Structure (Post-Implementation)

```text
src/
├── app.py                          # [MODIFY] — Import updated User model
├── models.py                       # [MODIFY] — Extend User model with new columns + helper methods
├── routes.py                       # [MODIFY] — Register /api/auth/* endpoints + header auth state
├── services/
│   ├── __init__.py                 # [EXISTING]
│   ├── auth_service.py             # [NEW] — Business logic for registration, login, logout
│   ├── scraper_service.py          # [EXISTING]
│   └── scheduler_service.py        # [EXISTING]
├── templates/
│   └── index.html                  # [MODIFY] — Auth modal, header nav auth groups, toast system
├── static/
│   ├── css/
│   │   └── frontend.css            # [MODIFY] — Auth modal styles, role badges, dropdown, toasts
│   └── js/
│       └── frontend.js             # [MODIFY] — Auth controller logic, modal toggles, session state
├── migrations/
│   └── versions/
│       └── 20260723_add_user_auth_columns.py  # [NEW] — Alembic migration for User schema changes
└── tests/
    └── test_auth.py                # [NEW] — Unit tests for auth endpoints
```

---

## Implementation Phases

### Phase 1 — Database Model Evolution & Migration

**Objective**: Extend the existing `User` model with the columns required by the auth specification, and generate an Alembic migration to apply the schema changes to PostgreSQL.

#### Work Items

1. **Modify** `src/models.py` — Add the following columns to the existing `User` class:
   - `username`: `db.Column(db.String(50), unique=True, nullable=True, index=True)` — Made `nullable=True` initially to avoid breaking existing rows; a data migration step will backfill existing users.
   - `full_name`: `db.Column(db.String(100), nullable=True)`
   - `is_active`: `db.Column(db.Boolean, nullable=False, default=True)`
   - `last_login`: `db.Column(db.DateTime, nullable=True)`

2. **Add helper methods** to the `User` model:
   ```python
   from werkzeug.security import generate_password_hash, check_password_hash

   def set_password(self, password: str) -> None:
       """Hash and store the given plaintext password."""
       self.password_hash = generate_password_hash(password)

   def check_password(self, password: str) -> bool:
       """Verify a plaintext password against the stored hash."""
       return check_password_hash(self.password_hash, password)
   ```

3. **Generate Alembic migration**:
   ```powershell
   cd src
   venv\Scripts\Activate.ps1
   flask db migrate -m "add_user_auth_columns"
   flask db upgrade
   ```

4. **Verify**: Confirm the `users` table in PostgreSQL now has `username`, `full_name`, `is_active`, and `last_login` columns alongside the existing columns.

#### Key Decisions

- The existing `User.email` column already has `unique=True` and `index=True` — no change needed.
- The existing `User.password_hash` column (`VARCHAR(255)`) is already sized correctly for Werkzeug PBKDF2 hashes.
- The existing `User.role` column (`VARCHAR(50)`, default `"user"`) is compatible with the spec's `'guest'`/`'user'`/`'admin'` values.
- `username` is initially `nullable=True` to avoid `NOT NULL` violations on existing rows. After backfilling, a follow-up migration can tighten this to `nullable=False`.

#### Acceptance Criteria

- The Alembic migration runs without errors against the Supabase PostgreSQL instance.
- Existing user records remain intact with `username=NULL`, `is_active=True`, `last_login=NULL`.
- New user inserts with `username` work correctly and enforce uniqueness.

---

### Phase 2 — Auth Service Layer (Business Logic)

**Objective**: Create the `auth_service.py` module containing all authentication business logic, keeping route handlers thin per MVC.

#### [NEW] `src/services/auth_service.py`

This service module exposes the following functions:

1. **`register_user(username, email, password, full_name=None) -> tuple[dict, int]`**
   - Validates input: checks required fields, email format (regex), password strength (min 8 chars, at least 1 letter + 1 number).
   - Checks for duplicate `username` or `email` in the database.
   - Creates a new `User` instance, calls `set_password()`, sets `role='user'`, commits to DB.
   - Returns serialized user dict and HTTP status `201`.
   - On duplicate: returns `{"status": "error", "message": "Email or username already registered."}` with status `400`.

2. **`login_user(identity, password) -> tuple[dict, int]`**
   - Queries `User` by `username` OR `email` (case-insensitive `ilike` match).
   - If user not found or `check_password()` fails or `is_active=False`: returns generic error `"Invalid username/email or password"` with status `401`.
   - On success: updates `last_login` timestamp, commits, populates Flask `session` with `user_id` and `role`.
   - Returns user data with `redirect_url` based on role:
     - `'guest'` → `"/"`
     - `'user'` → `"/dashboard/user"`
     - `'admin'` → `"/dashboard/admin"`

3. **`logout_user() -> tuple[dict, int]`**
   - Calls `session.clear()` to invalidate server-side session.
   - Returns `{"status": "success", "redirect_url": "/"}` with status `200`.

4. **`get_current_user() -> tuple[dict, int]`**
   - Reads `session['user_id']`; if present, queries `User` and returns serialized profile.
   - If no session: returns `{"authenticated": false}` with status `200`.

5. **`serialize_user(user: User) -> dict`** (internal helper)
   - Returns `{"id", "username", "email", "full_name", "role", "is_active"}`.

#### Implementation Notes

- All database operations wrapped in `try/except` with `db.session.rollback()` on failure.
- Every error path logged via `logging.getLogger(__name__)` with structured context.
- Password validation regex: `r'^(?=.*[A-Za-z])(?=.*\d).{8,}$'`
- Email validation regex: `r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'`

#### Acceptance Criteria

- `register_user` creates a user with a hashed password and returns 201.
- `register_user` rejects duplicates with 400 and a clear message.
- `login_user` verifies correct passwords and rejects incorrect ones with a generic message.
- `logout_user` clears the Flask session completely.

---

### Phase 3 — API Route Registration (Controller Layer)

**Objective**: Register the four auth REST endpoints in `routes.py`, keeping handlers thin and delegating to `auth_service`.

#### [MODIFY] `src/routes.py`

Add the following routes to the existing `main_bp` Blueprint:

```python
from flask import session
from services.auth_service import register_user, login_user, logout_user, get_current_user

@main_bp.route("/api/auth/register", methods=["POST"])
def api_auth_register():
    """Register a new user account."""
    data = request.get_json() or {}
    result, status = register_user(
        username=data.get("username", "").strip(),
        email=data.get("email", "").strip(),
        password=data.get("password", ""),
        full_name=data.get("full_name", "").strip() or None,
    )
    return jsonify(result), status

@main_bp.route("/api/auth/login", methods=["POST"])
def api_auth_login():
    """Authenticate user and establish session."""
    data = request.get_json() or {}
    result, status = login_user(
        identity=data.get("identity", "").strip(),
        password=data.get("password", ""),
    )
    return jsonify(result), status

@main_bp.route("/api/auth/logout", methods=["POST"])
def api_auth_logout():
    """Invalidate current session."""
    result, status = logout_user()
    return jsonify(result), status

@main_bp.route("/api/auth/me", methods=["GET"])
def api_auth_me():
    """Return current authenticated user details."""
    result, status = get_current_user()
    return jsonify(result), status
```

#### Import Changes

- Add `session` to existing Flask imports on line 5.
- Add `from services.auth_service import register_user, login_user, logout_user, get_current_user` below existing imports.
- Add `User` to the existing `from models import db, Article, Category` import.

#### Acceptance Criteria

- `POST /api/auth/register` with valid JSON returns 201 with user data.
- `POST /api/auth/login` with valid credentials returns 200 with redirect URL.
- `POST /api/auth/logout` clears session and returns 200.
- `GET /api/auth/me` returns authenticated user profile or `{"authenticated": false}`.
- All endpoints handle malformed requests gracefully with appropriate error codes.

---

### Phase 4 — Frontend Integration (HTML + CSS + JavaScript)

**Objective**: Integrate the auth modal, header navigation auth states, and auth controller logic into the existing SPA frontend while matching the neoclassical theme perfectly.

#### 4A. [MODIFY] `src/templates/index.html`

1. **Update the header** (lines 28–40): Replace the current simple header with the auth-aware version containing:
   - `#nav-guest-actions` div with "Sign In" and "Register" buttons (visible by default).
   - `#nav-user-actions` div with role badge, display name, chevron dropdown, and logout button (hidden by default with `.hide` class).

2. **Add auth modal markup** before the closing `</body>` tag:
   - Full auth modal overlay (`#auth-modal-overlay`) with login form, registration form, tab switcher, alert box, and security footer — exactly as specified in Section 5.1 of the spec.

3. **Add toast notification container** below the header:
   ```html
   <div id="toast-container" class="toast-container"></div>
   ```

#### 4B. [MODIFY] `src/static/css/frontend.css`

Append the following CSS sections at the end of the file:

1. **Auth Modal Styles** (~120 lines): `.auth-modal-backdrop`, `.auth-card`, `.auth-card-header`, `.auth-nav-tabs`, `.auth-tab-btn`, `.auth-form`, `.form-group`, `.form-label`, `.input-wrapper`, `.input-icon`, `.form-input`, `.auth-submit-btn`, `.auth-close-btn`, `.auth-alert`, `.auth-card-footer`, `.toggle-password`, `.forgot-link`, `.label-row`, `.form-options`, `.checkbox-container`, `.input-help-text`.
2. **Header Auth Group Styles** (~40 lines): `.header-right-actions`, `.nav-auth-group`, `.auth-outline-btn`, `.user-pill-dropdown`, `.user-display-name`, `.dropdown-icon`, `.dropdown-menu-card`, `.dropdown-item`, `.dropdown-divider`, `.logout-item`.
3. **Role Badge Styles**: `.role-badge`, `.badge-guest`, `.badge-user`, `.badge-admin`.
4. **Toast Notification Styles**: `.toast-container`, `.toast-item`, `@keyframes toastSlideIn`, `@keyframes toastFadeOut`.
5. **`@keyframes authModalSlideIn`**: Entrance animation for the modal card.
6. **Responsive overrides** at existing breakpoints: Auth modal should go full-width on screens < 480px.

All colors MUST use the existing CSS custom properties (`--primary`, `--secondary`, `--outline`, `--muted`, `--surface`, `--background`, `--ff-serif`, `--ff-sans`) to ensure theme coherence.

#### 4C. [MODIFY] `src/static/js/frontend.js`

Add an auth controller module at the end of the file (or integrated into the existing SPA controller pattern):

1. **Auth State Extension** — Add to the existing `state` object:
   ```javascript
   state.currentUser = null;  // null = unauthenticated
   ```

2. **Auth Element Refs** — Add to the existing `el` object:
   ```javascript
   el.authModalOverlay = document.getElementById("auth-modal-overlay");
   el.authModalClose   = document.getElementById("auth-modal-close");
   el.navLoginBtn      = document.getElementById("nav-login-btn");
   el.navRegisterBtn   = document.getElementById("nav-register-btn");
   el.navGuestActions  = document.getElementById("nav-guest-actions");
   el.navUserActions   = document.getElementById("nav-user-actions");
   // ... (all form inputs, buttons, dropdown elements)
   ```

3. **Auth Functions**:
   - `openAuthModal(tab)`: Shows the modal, switches to login or register tab, calls `lucide.createIcons()`.
   - `closeAuthModal()`: Hides the modal, resets form fields and alert state.
   - `switchAuthTab(targetFormId)`: Toggles `.active` class on tab buttons, shows/hides forms.
   - `handleLogin(e)`: Prevents default, sends `POST /api/auth/login`, on success stores user in `state.currentUser`, updates header UI, shows success toast, closes modal.
   - `handleRegister(e)`: Prevents default, validates inputs client-side, sends `POST /api/auth/register`, on success auto-switches to login tab with success message.
   - `handleLogout()`: Sends `POST /api/auth/logout`, clears `state.currentUser`, clears `localStorage`/`sessionStorage`, resets header to guest state, shows logout toast.
   - `checkAuthState()`: Called on page load, sends `GET /api/auth/me`, if authenticated updates `state.currentUser` and header UI.
   - `updateHeaderAuthUI()`: Toggles between `#nav-guest-actions` and `#nav-user-actions`, updates role badge and display name.
   - `showToast(message, type)`: Creates a temporary toast notification element, auto-removes after 4 seconds.
   - `togglePasswordVisibility(inputId)`: Toggles `type="password"` ↔ `type="text"` on password inputs.

4. **Event Binding** — Wire up click handlers on `init()`:
   - `el.navLoginBtn.addEventListener("click", () => openAuthModal("login"))`
   - `el.navRegisterBtn.addEventListener("click", () => openAuthModal("register"))`
   - Login form `submit` → `handleLogin`
   - Register form `submit` → `handleRegister`
   - Logout button click → `handleLogout`
   - Modal close button + backdrop click → `closeAuthModal`
   - Dropdown toggle click → show/hide dropdown card
   - Password visibility toggle

5. **Init Integration** — Call `checkAuthState()` at the end of the existing `init()` function to restore session on page load.

#### Acceptance Criteria

- Clicking "Sign In" in the header opens the auth modal on the login tab.
- Clicking "Register" opens the auth modal on the registration tab.
- Submitting valid registration creates a user and shows a success toast.
- Submitting valid login credentials updates the header to show role badge + username.
- Clicking "Log Out" in the dropdown clears the session and returns header to guest state.
- Auth modal matches the neoclassical theme (Slate/Indigo palette, Plus Jakarta Sans, slide-in animation).
- On page refresh, `GET /api/auth/me` restores the authenticated header state if session is active.

---

### Phase 5 — Error Handling, Logging & Testing

**Objective**: Ensure the auth system is robust, observable, and tested.

#### Error Handling Plan

1. All service functions wrapped in `try/except` with `db.session.rollback()` on database errors.
2. Password validation failures return 400 with specific field-level feedback.
3. Login failures return 401 with generic message — never reveal if the email/username exists.
4. Rate limiting on login (deferred to post-MVP but noted in code comments).

#### Logging Plan

Structured log messages using Python's `logging` module:

- `[AUTH][SUCCESS] User registered: {username} ({email})`
- `[AUTH][SUCCESS] User logged in: {username} (role: {role})`
- `[AUTH][SUCCESS] User logged out: {username}`
- `[AUTH][FAIL] Registration rejected — duplicate: {field}={value}`
- `[AUTH][FAIL] Login failed for identity: {identity} (reason: {reason})`
- `[AUTH][ERROR] Database error during {operation}: {exception}`

#### Unit Testing Plan

**[NEW]** `src/tests/test_auth.py`

| Test Case | Description |
|---|---|
| `test_register_valid_user` | Valid registration creates user in DB and returns 201 |
| `test_register_duplicate_email` | Duplicate email returns 400 with error message |
| `test_register_duplicate_username` | Duplicate username returns 400 with error message |
| `test_register_weak_password` | Password < 8 chars or missing letter/number returns 400 |
| `test_register_invalid_email` | Malformed email returns 400 |
| `test_login_valid_credentials` | Correct login returns 200 with user data and redirect URL |
| `test_login_wrong_password` | Wrong password returns 401 with generic error |
| `test_login_nonexistent_user` | Non-existent identity returns 401 with same generic error |
| `test_login_by_email` | Login using email instead of username returns 200 |
| `test_logout_clears_session` | Logout returns 200 and session is empty |
| `test_auth_me_authenticated` | GET /api/auth/me with session returns user profile |
| `test_auth_me_unauthenticated` | GET /api/auth/me without session returns `authenticated: false` |

Run tests with:
```powershell
cd src
venv\Scripts\Activate.ps1
python -m pytest tests/test_auth.py -v
```

#### Acceptance Criteria

- All 12 test cases pass.
- No unhandled exceptions in auth endpoints under malformed input.
- Log output provides enough context to diagnose any registration or login issue.

---

## Phase 6 â€” Password Recovery & Session Revocation

**Objective**: Add an email-delivered reset workflow without user enumeration and invalidate all prior sessions after a successful reset.

1. **Model and migration**: Add nullable `password_reset_token_hash` and `password_reset_expires_at`, plus non-null `session_version` with default `0`. Store only the SHA-256 digest of each reset token.
2. **Service layer**: Add `request_password_reset(email)` and `confirm_password_reset(token, password)` to `auth_service.py`. Use `secrets.token_urlsafe`, `hmac.compare_digest`, UTC expiry (30 minutes), existing password validation, and clear reset state after use.
3. **Email delivery**: Add a small SMTP helper using stdlib `smtplib`. Read `MAIL_SERVER`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM`, and `PASSWORD_RESET_URL` only from `.env`; add placeholder values to `.env.example`.
4. **Routes and session validation**: Add thin request/confirm routes. The request route always returns the same `202` response for a well-formed email. Login persists `session_version`; `get_current_user()` clears sessions whose version differs from the database value.
5. **Frontend and tests**: Add Forgot Password request/reset views without token storage. Test generic responses for existing/unknown/inactive accounts, token expiry and single-use behavior, password updates, and session invalidation.

## Implementation Order

1. Extend `User` model in `models.py` and generate Alembic migration (Phase 1)
2. Create `services/auth_service.py` with registration, login, logout, and session functions (Phase 2)
3. Register `/api/auth/*` routes in `routes.py` (Phase 3)
4. Update `index.html` with auth modal and header nav auth groups (Phase 4A)
5. Append auth CSS to `frontend.css` (Phase 4B)
6. Add auth JS controller to `frontend.js` (Phase 4C)
7. Write and execute unit tests in `tests/test_auth.py` (Phase 5)
8. Implement and test the password-reset workflow, email configuration, and session-version revocation (Phase 6)

---

## Deliverables

| # | Deliverable | File |
|---|---|---|
| 1 | Extended User model with auth columns + helper methods | [models.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py) |
| 2 | Alembic migration for schema changes | `migrations/versions/20260723_add_user_auth_columns.py` |
| 3 | Auth service module with business logic | [auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py) |
| 4 | Auth API endpoints registered in routes | [routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py) |
| 5 | Auth modal + header nav integration | [index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html) |
| 6 | Auth CSS styling (neoclassical theme) | [frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css) |
| 7 | Auth JS SPA controller | [frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js) |
| 8 | Unit test suite for auth endpoints | [test_auth.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/tests/test_auth.py) |
| 9 | Password-reset migration, service functions, routes, UI, and test coverage | `models.py`, `migrations/`, `services/auth_service.py`, `routes.py`, `templates/`, `static/`, `tests/test_auth.py` |
