# Tasks: Account Authentication (Auth) System

**Input**: Design documents from [spec.md](spec.md) and [plan.md](plan.md)

**Prerequisites**: plan.md (required), spec.md (required for user stories), constitution.md (required for governance)

**Branch**: `003-account-authentication`

**Scope**: This task breakdown covers the full Account Authentication system — Guest User Registration, Role-Based Login with automatic dashboard redirection, and Secure Log Out with session/memory invalidation.

---

## Phase 1: Database Model Evolution & Migration

**Purpose**: Extend the existing `User` ORM model with the columns required by the auth specification, add password helper methods, and generate an Alembic migration for the schema changes.

### Implementation Tasks

- [x] T001 [P] Extend the existing `User` model in [src/models.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py) by adding the `username`, `full_name`, `is_active`, and `last_login` columns.
  - Add `username = db.Column(db.String(50), unique=True, nullable=True, index=True)` — nullable initially to preserve existing rows.
  - Add `full_name = db.Column(db.String(100), nullable=True)`.
  - Add `is_active = db.Column(db.Boolean, nullable=False, default=True)`.
  - Add `last_login = db.Column(db.DateTime, nullable=True)`.
  - **Acceptance Criteria**: The `User` class has all four new columns defined. Existing columns (`id`, `email`, `password_hash`, `role`, `created_at`, `bookmarks`) remain unchanged.

- [x] T002 [P] Add `set_password()` and `check_password()` helper methods to the `User` model in [src/models.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py).
  - Import `generate_password_hash`, `check_password_hash` from `werkzeug.security`.
  - `set_password(self, password: str) -> None`: Hashes the password and stores in `self.password_hash`.
  - `check_password(self, password: str) -> bool`: Verifies plaintext against stored hash.
  - **Acceptance Criteria**: Calling `user.set_password("test123")` stores a hashed value in `password_hash`. Calling `user.check_password("test123")` returns `True`. Calling `user.check_password("wrong")` returns `False`.

- [x] T003 Generate and apply the Alembic migration for the new `User` columns.
  - Activate venv: `venv\Scripts\Activate.ps1`.
  - Run `flask db migrate -m "add_user_auth_columns"` to auto-generate the migration script.
  - Run `flask db upgrade` to apply the migration to the PostgreSQL (Supabase) database.
  - **Acceptance Criteria**: The `users` table in PostgreSQL contains `username`, `full_name`, `is_active`, and `last_login` columns. Existing user records remain intact with `username=NULL`, `is_active=True`, `last_login=NULL`. The migration script is saved in `src/migrations/versions/`.

---

## Phase 2: Auth Service Layer (Business Logic)

**Purpose**: Create the `auth_service.py` module encapsulating all registration, login, logout, and session query business logic — keeping route handlers thin per constitution Principle II (MVC).

### Implementation Tasks

- [x] T004 [P] Create [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py) with the `register_user()` function.
  - Accept `username`, `email`, `password`, `full_name` parameters.
  - Validate required fields: `username`, `email`, `password` must be non-empty.
  - Validate email format using regex: `r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'`.
  - Validate password strength using regex: `r'^(?=.*[A-Za-z])(?=.*\d).{8,}$'` (min 8 chars, at least 1 letter + 1 number).
  - Check for duplicate `username` or `email` in the database via SQLAlchemy query.
  - On valid: create `User` instance, call `set_password()`, set `role='user'`, commit to DB.
  - Return `({"status": "success", "message": "Account created successfully.", "user": {...}}, 201)`.
  - On duplicate: return `({"status": "error", "message": "Email or username already registered."}, 400)`.
  - On validation failure: return `({"status": "error", "message": "<specific field error>"}, 400)`.
  - Wrap all DB operations in `try/except` with `db.session.rollback()` on failure.
  - Log `[AUTH][SUCCESS] User registered: {username} ({email})` or `[AUTH][FAIL] Registration rejected — duplicate: {field}={value}`.
  - **Acceptance Criteria**: Valid registration creates a hashed-password user in DB and returns 201. Duplicate email/username returns 400. Weak password returns 400 with specific message.

- [x] T005 [P] Add the `login_user()` function to [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py).
  - Accept `identity` (username or email) and `password` parameters.
  - Query `User` by `username` OR `email` using case-insensitive `ilike` match.
  - If user not found, `check_password()` fails, or `is_active=False`: return `({"status": "error", "message": "Invalid username/email or password."}, 401)`.
  - On success: update `last_login` to `datetime.utcnow()`, commit, populate Flask `session` with `user_id` and `role`.
  - Compute `redirect_url` based on role: `'guest'` → `"/"`, `'user'` → `"/dashboard/user"`, `'admin'` → `"/dashboard/admin"`.
  - Return `({"status": "success", "message": "Login successful.", "redirect_url": ..., "user": {...}}, 200)`.
  - Log `[AUTH][SUCCESS] User logged in: {username} (role: {role})` or `[AUTH][FAIL] Login failed for identity: {identity}`.
  - **Acceptance Criteria**: Correct credentials return 200 with user data and correct redirect URL. Wrong password returns 401 with generic message (does NOT reveal if user exists). Inactive user returns 401.

- [x] T006 [P] Add the `logout_user()` function to [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py).
  - Import `session` from `flask`.
  - Call `session.clear()` to invalidate server-side session state.
  - Log `[AUTH][SUCCESS] User logged out: {username}` (using session data before clearing).
  - Return `({"status": "success", "message": "Session invalidated successfully.", "redirect_url": "/"}, 200)`.
  - **Acceptance Criteria**: After calling `logout_user()`, Flask `session` is empty. Subsequent `GET /api/auth/me` returns `{"authenticated": false}`.

- [x] T007 [P] Add the `get_current_user()` function to [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py).
  - Read `session.get('user_id')`. If present, query `User` by `id` and return serialized profile.
  - If no session or user not found: return `({"authenticated": false}, 200)`.
  - If authenticated: return `({"authenticated": true, "user": {"id", "username", "email", "full_name", "role"}}, 200)`.
  - **Acceptance Criteria**: With active session returns user profile. Without session returns `authenticated: false`. If user_id in session points to deleted/inactive user, returns `authenticated: false`.

- [x] T008 Add the `serialize_user()` internal helper to [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py).
  - Accept `User` model instance.
  - Return dict with keys: `id`, `username`, `email`, `full_name`, `role`, `is_active`.
  - Used internally by `register_user`, `login_user`, and `get_current_user`.
  - **Acceptance Criteria**: Serialization produces correct JSON-compatible dict. No `password_hash` is ever included in the output.

---

## Phase 3: API Route Registration (Controller Layer)

**Purpose**: Register the four auth REST endpoints in `routes.py` as thin handlers that delegate to `auth_service`, per constitution Principle II.

### Implementation Tasks

- [x] T009 [P] Add `POST /api/auth/register` route handler to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Import `register_user` from `services.auth_service`.
  - Extract `username`, `email`, `password`, `full_name` from `request.get_json()`.
  - Strip whitespace from string inputs.
  - Delegate to `register_user()` and return `jsonify(result), status`.
  - **Acceptance Criteria**: `POST /api/auth/register` with valid JSON `{"username": "test", "email": "test@test.com", "password": "Test1234"}` returns 201 with user data. Malformed JSON returns 400.

- [x] T010 [P] Add `POST /api/auth/login` route handler to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Import `login_user` from `services.auth_service`.
  - Extract `identity` and `password` from `request.get_json()`.
  - Delegate to `login_user()` and return `jsonify(result), status`.
  - **Acceptance Criteria**: Valid credentials return 200 with redirect URL. Invalid credentials return 401 with generic error.

- [x] T011 [P] Add `POST /api/auth/logout` route handler to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Import `logout_user` from `services.auth_service`.
  - Delegate to `logout_user()` and return `jsonify(result), status`.
  - **Acceptance Criteria**: Returns 200 and session is cleared.

- [x] T012 Add `GET /api/auth/me` route handler to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Import `get_current_user` from `services.auth_service`.
  - Delegate to `get_current_user()` and return `jsonify(result), status`.
  - **Acceptance Criteria**: With active session returns authenticated user profile. Without session returns `{"authenticated": false}`.

- [x] T013 Update import statements in [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Add `session` to the existing `from flask import ...` line.
  - Add `User` to the existing `from models import db, Article, Category` line.
  - Add `from services.auth_service import register_user, login_user, logout_user, get_current_user` below existing imports.
  - **Acceptance Criteria**: All four auth routes are importable and respond without `ImportError`.

---

## Phase 4: Frontend Integration (HTML + CSS + JavaScript)

**Purpose**: Integrate the neoclassical auth modal, auth-aware header navigation, and auth controller logic into the existing SPA frontend — matching the established premium editorial theme.

### 4A. HTML Template Updates

- [x] T014 [P] Update the header navigation in [src/templates/index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html) with auth-aware controls.
  - Replace the existing simple header (lines 28–40) with a dual-state header containing:
    - `#nav-guest-actions` div: "Sign In" (`.auth-outline-btn`) and "Register" (`.dispatches-btn`) buttons — visible by default.
    - `#nav-user-actions` div: Role badge (`#nav-user-role-badge`), display name (`#nav-user-display-name`), chevron dropdown icon, and dropdown card with Dashboard, Saved Dispatches, and Log Out items — hidden by default with `.hide` class.
  - Keep existing logo link and Dispatches button intact.
  - **Acceptance Criteria**: Unauthenticated visitors see "Sign In" and "Register" buttons. Authenticated users see role badge + name + dropdown (controlled by JS).

- [x] T015 [P] Add the auth modal HTML markup to [src/templates/index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html).
  - Insert the full `#auth-modal-overlay` div before the closing `</body>` tag (after the footer, before the scripts).
  - Modal must include: `.auth-card-header` with logo, `.auth-nav-tabs` with Sign In / Create Account tab buttons, `#auth-alert-box` for error feedback, `#form-login` with identity + password fields + remember checkbox + submit button, `#form-register` with full_name + username + email + password fields + submit button, `.auth-card-footer` with security note.
  - All form inputs must have unique `id` attributes as specified in the spec (e.g. `login-identity`, `login-password`, `reg-fullname`, `reg-username`, `reg-email`, `reg-password`).
  - Lucide icons used for input decorations (`user`, `lock`, `eye`, `smile`, `at-sign`, `mail`, `shield-check`).
  - **Acceptance Criteria**: The auth modal HTML structure is valid, all interactive elements have unique IDs, and the modal starts hidden with `.hide` class.

- [x] T016 Add a toast notification container to [src/templates/index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html).
  - Insert `<div id="toast-container" class="toast-container"></div>` below the header.
  - **Acceptance Criteria**: Toast container exists in the DOM and is positioned fixed via CSS for floating notifications.

### 4B. CSS Styling

- [x] T017 [P] Add auth modal CSS styles to [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).
  - Implement styles for: `.auth-modal-backdrop` (fixed overlay, `rgba(15, 23, 42, 0.75)` background, `backdrop-filter: blur(8px)`), `.auth-card` (440px max-width, white surface, border-radius 12px, shadow, slide-in animation), `.auth-card-header` (Slate 900 background, white text, logo display), `.auth-nav-tabs` + `.auth-tab-btn` (Indigo active underline), `.auth-form` (flex column, 1.5rem padding), `.form-group` + `.form-label` + `.input-wrapper` + `.input-icon` + `.form-input` (left-padded for icon, Indigo focus ring), `.auth-submit-btn` (Indigo 600 background, white text, hover darken), `.auth-close-btn`, `.auth-alert` (error state banner), `.auth-card-footer`.
  - Add `@keyframes authModalSlideIn` animation.
  - All colors MUST reference existing CSS custom properties (`--primary`, `--secondary`, `--outline`, `--surface`, `--background`, `--ff-serif`, `--ff-sans`).
  - **Acceptance Criteria**: Auth modal visually matches the Neoclassical Obsidian/Indigo theme. Inputs have focus rings. Submit button has hover transition. Modal slides in with animation.

- [x] T018 [P] Add header auth group and dropdown CSS styles to [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).
  - Implement styles for: `.header-right-actions` (flex row, gap), `.nav-auth-group` (flex, align-center), `.auth-outline-btn` (border-only button, Indigo color), `.user-pill-dropdown` (flex row, gap, cursor pointer, relative positioning), `.user-display-name`, `.dropdown-icon`, `.dropdown-menu-card` (absolute dropdown, white surface, shadow, z-index 100), `.dropdown-item` (flex row with icon + text, hover highlight), `.dropdown-divider` (1px border), `.logout-item` (terracotta/red hover state).
  - **Acceptance Criteria**: Guest header shows outline Sign In + filled Register buttons. Authenticated header shows pill with badge + name + dropdown. Dropdown appears on click with smooth transition.

- [x] T019 Add role badge CSS styles to [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).
  - `.role-badge`: padding, tiny font, bold weight, border-radius, uppercase.
  - `.badge-guest`: Slate 200 background, Slate 600 text.
  - `.badge-user`: Indigo 100 background, Indigo 800 text.
  - `.badge-admin`: Red 100 background, Red 800 text.
  - **Acceptance Criteria**: Each role badge displays correct color pairing.

- [x] T020 Add toast notification CSS styles to [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).
  - `.toast-container`: fixed position, top-right, z-index 10000, flex column, gap.
  - `.toast-item`: padding, border-radius, shadow, font-family `--ff-sans`, slide-in animation.
  - `.toast-success`: Emerald left-border accent.
  - `.toast-error`: Terracotta left-border accent.
  - `@keyframes toastSlideIn` and `@keyframes toastFadeOut`.
  - **Acceptance Criteria**: Toast messages appear in top-right corner, auto-dismiss with fade-out after 4 seconds.

- [x] T021 Add responsive overrides for auth modal in [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).
  - At screens < 480px: `.auth-card` goes `max-width: 100%`, `border-radius: 0`, full-height modal.
  - At screens < 640px: Header auth buttons stack vertically or shrink font.
  - **Acceptance Criteria**: Auth modal is fully usable on mobile viewports without horizontal overflow.

### 4C. JavaScript SPA Controller

- [x] T022 [P] Extend the `state` and `el` objects in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js) with auth properties.
  - Add `state.currentUser = null` to the state object.
  - Add element refs to the `el` object: `authModalOverlay`, `authModalClose`, `navLoginBtn`, `navRegisterBtn`, `navGuestActions`, `navUserActions`, `navUserRoleBadge`, `navUserDisplayName`, `userDropdownCard`, `userProfileMenu`, `btnActionLogout`, `tabAuthLogin`, `tabAuthRegister`, `formLogin`, `formRegister`, `authAlertBox`, `authAlertMessage`, `loginIdentity`, `loginPassword`, `toggleLoginPass`, `regFullname`, `regUsername`, `regEmail`, `regPassword`, `btnSubmitLogin`, `btnSubmitRegister`, `toastContainer`.
  - **Acceptance Criteria**: All auth DOM elements are cached in the `el` object. `state.currentUser` is initialized as `null`.

- [x] T023 [P] Implement auth modal control functions in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - `openAuthModal(tab)`: Removes `.hide` from `#auth-modal-overlay`, switches to specified tab (`"login"` or `"register"`), calls `lucide.createIcons()` for modal icons.
  - `closeAuthModal()`: Adds `.hide` to `#auth-modal-overlay`, resets all form inputs (`.reset()`), hides alert box.
  - `switchAuthTab(targetFormId)`: Toggles `.active` class between tab buttons, shows target form, hides other form.
  - `showAuthAlert(message, type)`: Shows `#auth-alert-box` with message text. Sets color based on `type` (`"error"` = terracotta, `"success"` = emerald).
  - **Acceptance Criteria**: Modal opens/closes smoothly. Tab switching shows correct form. Alert messages display with appropriate styling.

- [x] T024 [P] Implement `handleRegister(e)` function in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Prevent default form submission.
  - Client-side validation: check non-empty fields, email format, password strength (min 8 chars, letter + number).
  - On validation failure: call `showAuthAlert()` with specific message.
  - On valid: send `POST /api/auth/register` with `fetch()`, body = `{username, email, password, full_name}`.
  - On 201 success: auto-switch to login tab, show success alert "Account created! Please sign in."
  - On 400 error: show error alert with server message.
  - **Acceptance Criteria**: Valid registration shows success and switches to login tab. Invalid inputs show inline error. Duplicate rejection shows server error message.

- [x] T025 [P] Implement `handleLogin(e)` function in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Prevent default form submission.
  - Send `POST /api/auth/login` with `fetch()`, body = `{identity, password}`.
  - On 200 success: store returned user in `state.currentUser`, call `updateHeaderAuthUI()`, show success toast "Welcome back, {username}!", close modal.
  - On 401 error: show auth alert with server error message.
  - **Acceptance Criteria**: Successful login updates header to authenticated state and shows welcome toast. Failed login shows error alert in modal.

- [x] T026 [P] Implement `handleLogout()` function in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Send `POST /api/auth/logout` with `fetch()`.
  - Clear `state.currentUser = null`.
  - Clear `localStorage.clear()` and `sessionStorage.clear()`.
  - Call `updateHeaderAuthUI()` to reset header to guest state.
  - Hide dropdown card.
  - Show success toast "You have been successfully logged out."
  - **Acceptance Criteria**: Logout clears all client-side state, resets header, and shows confirmation toast.

- [x] T027 [P] Implement `checkAuthState()` function in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Send `GET /api/auth/me` with `fetch()`.
  - If response has `authenticated: true`: store user in `state.currentUser`, call `updateHeaderAuthUI()`.
  - If `authenticated: false`: ensure header stays in guest state.
  - Call this function at the end of the existing `init()` function.
  - **Acceptance Criteria**: On page refresh with active session, header restores to authenticated state. Without session, header stays as guest.

- [x] T028 Implement `updateHeaderAuthUI()` function in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - If `state.currentUser` is not null:
    - Hide `#nav-guest-actions` (add `.hide`), show `#nav-user-actions` (remove `.hide`).
    - Set `#nav-user-display-name` text to `currentUser.full_name || currentUser.username`.
    - Set `#nav-user-role-badge` text to `currentUser.role.toUpperCase()`.
    - Update badge class: remove all `badge-*` classes, add `badge-{role}`.
  - If `state.currentUser` is null:
    - Show `#nav-guest-actions`, hide `#nav-user-actions`.
  - **Acceptance Criteria**: Header correctly reflects current auth state with proper role badge color.

- [x] T029 Implement `showToast(message, type)` function in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Create a `div.toast-item.toast-{type}` element with the message text.
  - Append to `#toast-container`.
  - Auto-remove after 4 seconds with fade-out animation.
  - **Acceptance Criteria**: Toast appears in top-right, displays message, auto-dismisses.

- [x] T030 Implement `togglePasswordVisibility()` function and dropdown toggle in [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Toggle `type="password"` ↔ `type="text"` on password input.
  - Update Lucide eye icon between `eye` and `eye-off`.
  - Dropdown toggle: click on `#user-profile-menu` toggles `.hide` on `#user-dropdown-card`. Click outside closes dropdown.
  - **Acceptance Criteria**: Password visibility toggles correctly. Dropdown opens on click, closes on outside click.

- [x] T031 Wire up all auth event listeners in the `init()` function of [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - `el.navLoginBtn.addEventListener("click", () => openAuthModal("login"))`.
  - `el.navRegisterBtn.addEventListener("click", () => openAuthModal("register"))`.
  - `el.authModalClose.addEventListener("click", closeAuthModal)`.
  - `el.authModalOverlay.addEventListener("click", (e) => { if (e.target === el.authModalOverlay) closeAuthModal(); })`.
  - `el.tabAuthLogin.addEventListener("click", () => switchAuthTab("form-login"))`.
  - `el.tabAuthRegister.addEventListener("click", () => switchAuthTab("form-register"))`.
  - `el.formLogin.addEventListener("submit", handleLogin)`.
  - `el.formRegister.addEventListener("submit", handleRegister)`.
  - `el.btnActionLogout.addEventListener("click", handleLogout)`.
  - `el.toggleLoginPass.addEventListener("click", togglePasswordVisibility)`.
  - `el.userProfileMenu.addEventListener("click", ...)` — dropdown toggle.
  - Call `checkAuthState()` at end of `init()`.
  - **Acceptance Criteria**: All interactive auth elements respond correctly to user actions. No JavaScript errors in console on page load.

---

## Phase 5: Verification and Test Coverage

**Purpose**: Validate the auth system through automated unit tests and cross-check review to ensure quality, security, and theme compliance.

### Implementation Tasks

- [x] T032 Create [src/tests/test_auth.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/tests/test_auth.py) with registration test cases.
  - `test_register_valid_user`: Valid registration creates user in DB, returns 201, password is hashed (not plaintext).
  - `test_register_duplicate_email`: Second registration with same email returns 400 with "already registered" message.
  - `test_register_duplicate_username`: Second registration with same username returns 400.
  - `test_register_weak_password`: Password "abc" (too short / no number) returns 400 with password requirement message.
  - `test_register_invalid_email`: Email "not-an-email" returns 400 with email format message.
  - `test_register_missing_fields`: Empty username or email returns 400.
  - **Acceptance Criteria**: All 6 registration tests pass. Use Flask test client with test database configuration.

- [x] T033 Add login test cases to [src/tests/test_auth.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/tests/test_auth.py).
  - `test_login_valid_credentials`: Login with correct username + password returns 200 with user data and `redirect_url`.
  - `test_login_by_email`: Login using email instead of username returns 200.
  - `test_login_wrong_password`: Wrong password returns 401 with generic error message.
  - `test_login_nonexistent_user`: Non-existent identity returns 401 with same generic error (no user enumeration).
  - **Acceptance Criteria**: All 4 login tests pass. Error messages are identical for wrong password and nonexistent user.

- [x] T034 Add logout and session test cases to [src/tests/test_auth.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/tests/test_auth.py).
  - `test_logout_clears_session`: After login + logout, `GET /api/auth/me` returns `{"authenticated": false}`.
  - `test_auth_me_authenticated`: After login, `GET /api/auth/me` returns user profile with `{"authenticated": true}`.
  - `test_auth_me_unauthenticated`: Without login, `GET /api/auth/me` returns `{"authenticated": false}`.
  - **Acceptance Criteria**: All 3 session tests pass. Session state is correctly managed across requests.

- [x] T035 Run the full test suite and verify all tests pass.
  - Command: `cd src && venv\Scripts\Activate.ps1 && python -m pytest tests/test_auth.py -v`
  - **Acceptance Criteria**: All 13 test cases pass. No unhandled exceptions. Test output shows structured pass/fail for each case.

---

## Phase 6: Forgot Password & Session Revocation

**Purpose**: Provide an enumeration-safe, time-limited password recovery flow that never stores or logs a plaintext reset token and invalidates all prior sessions after a reset.

### Implementation Tasks

- [x] T036 [P] Extend `User` in [src/models.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py) with reset state.
  - Add nullable `password_reset_token_hash` (`String(255)`) and `password_reset_expires_at` (`DateTime`), plus `session_version = db.Column(db.Integer, nullable=False, default=0)`.
  - Generate an Alembic migration. Raw reset tokens MUST NOT be persisted.

- [x] T037 [P] Add `request_password_reset(email)` to [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py).
  - Generate with `secrets.token_urlsafe`, store only `hashlib.sha256(token.encode()).hexdigest()`, and set a 30-minute UTC expiry.
  - For every valid request shape, return `202` with `"If an active account matches this email, a password-reset link has been sent."` whether the account is active, inactive, or absent.

- [x] T038 [P] Add `confirm_password_reset(token, password)` to [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py).
  - Use `hmac.compare_digest`, validate expiry and existing password-strength rules, then set the password, clear reset fields, increment `session_version`, and commit atomically.
  - Invalid, expired, and used tokens all return `400`: `"This password-reset link is invalid or has expired."`

- [x] T039 Add SMTP reset-email delivery under [src/services/](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/).
  - Use stdlib `smtplib` with TLS and `.env` keys `MAIL_SERVER`, `MAIL_PORT`, `MAIL_USERNAME`, `MAIL_PASSWORD`, `MAIL_FROM`, and `PASSWORD_RESET_URL`.
  - Add placeholder-only values to `src/.env.example`; never log tokens, reset URLs, passwords, or SMTP credentials.

- [x] T040 Add thin `POST /api/auth/password-reset/request` and `POST /api/auth/password-reset/confirm` handlers to [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py).
  - Parse JSON then delegate only; malformed JSON returns `400`.

- [x] T041 Update session validation in [src/services/auth_service.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py).
  - Login sets `session["session_version"]`; `get_current_user()` clears sessions whose version differs from the database value.

- [x] T042 Add Forgot Password and Reset Password UI/controller support in [src/templates/index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html), [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css), and [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - Never persist the URL token to browser storage or app state; clear password inputs after every submission attempt.

- [x] T043 Add reset tests to [src/tests/test_auth.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/tests/test_auth.py).
  - Cover generic request responses, hashed token storage, expiry, single use, password update, old/new credential behavior, and session-version invalidation.

---

## Cross-Check Review Checklist

- [X] Reviewer confirms that `POST /api/auth/register` creates a user with a hashed password (never plaintext) in PostgreSQL.
- [X] Reviewer confirms that `POST /api/auth/login` returns correct `redirect_url` per role (`"/"` for guest, `"/dashboard/user"` for user, `"/dashboard/admin"` for admin).
- [X] Reviewer confirms that `POST /api/auth/logout` invalidates the Flask server session and subsequent `/api/auth/me` returns `authenticated: false`.
- [X] Reviewer confirms that password-reset requests never reveal whether an email is registered and always return the generic `202` response.
- [X] Reviewer confirms that reset tokens are random, hashed at rest, single-use, expire after 30 minutes, and are never logged.
- [X] Reviewer confirms that successful password resets invalidate all existing sessions and require fresh login.
- [X] Reviewer confirms that login failure responses are generic and do NOT reveal whether the username/email exists.
- [X] Reviewer confirms that the auth modal UI matches the neoclassical theme (Slate/Indigo palette, Plus Jakarta Sans typography, slide-in animation, blurred backdrop).
- [X] Reviewer confirms that the header switches between guest state (Sign In + Register) and authenticated state (role badge + name + dropdown) correctly.
- [X] Reviewer confirms that the toast notification system displays success/error messages and auto-dismisses.
- [X] Reviewer confirms that all auth forms work on mobile viewports (< 480px) without layout breaks.
- [X] Reviewer confirms that no secrets are hardcoded — all sensitive values loaded from `.env` per constitution Principle III.
- [X] Reviewer confirms that all new code follows naming conventions per constitution Principle V (PascalCase classes, snake_case functions, UPPER_SNAKE_CASE constants).
