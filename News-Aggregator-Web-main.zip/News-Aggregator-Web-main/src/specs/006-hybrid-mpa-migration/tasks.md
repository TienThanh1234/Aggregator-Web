# Tasks: Hybrid MPA Migration

**Input**: Design documents from `/specs/006-hybrid-mpa-migration/`

**Prerequisites**: plan.md (required), spec.md (required for user stories)

## Format: `[ID] [P?] [Story] Description`

- **[P]**: Can run in parallel (different files, no dependencies)
- **[Story]**: Which user story this task belongs to (US1, US2, US3, US4)

---

## Phase 1: Foundational — Presentation Service (Plan Phase A)

**Purpose**: Extract article serialization logic from `routes.py` into a dedicated service so both page routes and the compatibility JSON endpoint share identical transformation rules. This is a blocking prerequisite for all user stories.

**CRITICAL**: No user story work can begin until this phase is complete.

- [x] T001 [US1,US2] Create `services/article_service.py` with internal helpers `_map_category()`, `_proxy_image_url()`, `_parse_ai_metadata()`, `_split_paragraphs()` — extracted from current `routes.py` lines 270–311
- [x] T002 [US2] Implement `get_feed_articles(category, page, per_page)` in `services/article_service.py` — paginated query returning feed-card dicts (no paragraphs/body), total_pages, current_page
- [x] T003 [US1] Implement `get_article_detail(article_id)` in `services/article_service.py` — full article presentation dict including paragraphs, key_takeaways, unverified_claim fields; returns `None` for missing articles
- [x] T004 [P] [US2] Implement `get_categories()` in `services/article_service.py` — ordered list of categories with icons, using Vietnamese→English mapping
- [x] T005 [P] [US2] Implement `get_trending_articles(limit)` in `services/article_service.py` — top articles sorted by confidence_score
- [x] T006 [US1,US2] Implement `get_all_articles_legacy()` in `services/article_service.py` — backward-compatible function returning the same JSON shape as the current `/api/articles` endpoint
- [x] T007 [US1,US2] Refactor `routes.py` `/api/articles` route handler (lines 256–337) to delegate to `article_service.get_all_articles_legacy()` — verify existing `test_routes.py` still passes

**Checkpoint**: `article_service.py` is the single source of truth for article presentation. `/api/articles` returns identical output. All existing tests pass.

---

## Phase 2: Shared Page Shell (Plan Phase B)

**Purpose**: Convert the empty `base.html` into a master layout with Jinja2 template inheritance. Extract shared markup from the monolithic `index.html` into reusable partials.

- [x] T008 [P] [US1,US2] Create `templates/partials/_auth_modal.html` — extract auth modal overlay (login, register, password-reset forms) from `templates/index.html` lines 377–416
- [x] T009 [P] [US2] Create `templates/partials/_article_card.html` — reusable Jinja2 partial for a single feed card with `<a href>` link to article page (replaces JS `buildCard()` function)
- [x] T010 [P] [US3] Create `templates/partials/_tememo_panel.html` — extract Tememo AI sidebar (Summary, Fact-Check, Chat tabs) from `templates/index.html` lines 263–351, with `data-article-id` attribute for JS initialization
- [x] T011 [US1,US2,US3,US4] Build `templates/base.html` — shared document shell with `<!DOCTYPE>`, `<head>` (fonts, CSS, Lucide CDN), header navigation, toast container, `{% include "partials/_auth_modal.html" %}`, footer, Lucide init, `core.js` script tag, and overridable blocks: `{% block title %}`, `{% block meta %}`, `{% block hero %}`, `{% block content %}`, `{% block page_scripts %}`
- [x] T012 [US2] Add pagination CSS rules to `static/css/frontend.css` — `.pagination`, `.page-link`, `.page-info` styles matching the neoclassical design system
- [x] T013 [US2] Add `.card-link` CSS rule to `static/css/frontend.css` — unstyled `<a>` wrapper for article cards (replaces JS click handler with regular link)

**Checkpoint**: `base.html` renders a complete page shell. Partials are extracted and can be included. No page routes exist yet.

---

## Phase 3: User Story 1 — Open and Share an Article Page (Priority: P1) MVP

**Goal**: Every article has a stable, directly accessible address (`/articles/<id>`) that works with refresh, sharing, bookmarking, and browser Back/Forward.

**Independent Test**: Copy an article address into a new browser session and verify the same article is displayed with title, metadata, body, image, and available analysis features.

### Implementation for User Story 1

- [x] T014 [US1] Create `templates/article.html` — extends `base.html`; overrides `{% block title %}` with article title; overrides `{% block meta %}` with `og:title`, `og:description`, `og:type`; renders article body (category badge, headline, byline, cover image, paragraphs) server-side; includes `partials/_tememo_panel.html`; loads `article.js` in `{% block page_scripts %}`
- [x] T015 [US1] Create `templates/404.html` — extends `base.html`; displays "Dispatch Not Found" with alert icon, message, and "Return to Feed" link
- [x] T016 [US1] Add `article_page(article_id)` route to `routes.py` — `@main_bp.route("/articles/<int:article_id>")`, calls `get_article_detail()`, renders `article.html` or returns `404.html` with status 404
- [x] T017 [US1] Register Flask `@main_bp.app_errorhandler(404)` in `routes.py` — catch-all 404 handler rendering `404.html` for any unmatched URL

### Tests for User Story 1

- [x] T018 [P] [US1] Write `TestArticlePage.test_article_page_returns_article_content` in `tests/test_mpa_routes.py` — create test article, GET `/articles/<id>`, assert 200 and article title in response HTML
- [x] T019 [P] [US1] Write `TestArticlePage.test_article_page_has_og_meta_tags` in `tests/test_mpa_routes.py` — assert `og:title` and `og:description` meta tags present in response
- [x] T020 [P] [US1] Write `TestArticlePage.test_article_page_404_for_missing_id` in `tests/test_mpa_routes.py` — GET `/articles/99999`, assert 404 status
- [x] T021 [P] [US1] Write `TestArticlePage.test_article_page_404_for_invalid_id` in `tests/test_mpa_routes.py` — GET `/articles/abc`, assert 404 status
- [x] T022 [P] [US1] Write `TestArticlePage.test_article_page_has_back_link_to_feed` in `tests/test_mpa_routes.py` — assert response HTML contains `href="/"` or `url_for('main.index')`
- [x] T023 [P] [US1] Write `TestCompatibilityEndpoint.test_api_articles_backward_compatible` in `tests/test_mpa_routes.py` — GET `/api/articles`, assert JSON array with expected field names (`id`, `title`, `category`, `paragraphs`, etc.)

**Checkpoint**: Article pages are directly addressable. Sharing a URL works. Refresh preserves the article. Browser navigation works. 404 is handled. Existing API endpoint is unchanged.

---

## Phase 4: User Story 2 — Browse the Server-Delivered News Feed (Priority: P2)

**Goal**: The initial news feed is fully browsable with server-rendered content. Categories, pagination, trending, and empty states work without JavaScript.

**Independent Test**: Load the news feed with client-side scripting disabled and verify that article summaries, categories, metadata, and links to article pages remain usable.

### Implementation for User Story 2

- [x] T024 [US2] Rewrite `templates/index.html` — extends `base.html`; overrides `{% block hero %}` with hero banner; overrides `{% block content %}` with server-rendered homepage grid: sidebar (categories as `<a>` links, trending as `<a>` links, mission widget) + feed column (feed header, articles grid using `{% include "partials/_article_card.html" %}` loop, pagination nav, empty state)
- [x] T025 [US2] Rewrite the `index()` route handler in `routes.py` — read `category` and `page` from `request.args`; call `get_feed_articles()`, `get_categories()`, `get_trending_articles()`; pass all to `render_template("index.html", ...)`

### Tests for User Story 2

- [x] T026 [P] [US2] Write `TestFeedPage.test_index_returns_html_with_articles` in `tests/test_mpa_routes.py` — create test articles, GET `/`, assert 200 and article titles in response HTML
- [x] T027 [P] [US2] Write `TestFeedPage.test_index_category_filter` in `tests/test_mpa_routes.py` — GET `/?category=Technology`, assert only matching articles in response
- [x] T028 [P] [US2] Write `TestFeedPage.test_index_pagination` in `tests/test_mpa_routes.py` — create 25+ articles, GET `/?page=2`, assert page 2 articles and pagination nav present
- [x] T029 [P] [US2] Write `TestFeedPage.test_index_empty_state` in `tests/test_mpa_routes.py` — GET `/?category=Nonexistent`, assert empty state message in response

**Checkpoint**: Feed page renders server-side with categories, trending, pagination. All content accessible without JavaScript. Category filter links navigate correctly.

---

## Phase 5: User Story 3 — Retain Interactive Article Enhancements (Priority: P3)

**Goal**: Summary, Fact-Check, and Chat AI features remain functional on article pages as progressive JavaScript enhancements. Stale responses are rejected.

**Independent Test**: Open a dedicated article page and exercise each supported analysis interaction without navigating away from the article.

### Implementation for User Story 3

- [x] T030 [US3] Create `static/js/core.js` — extract from `frontend.js`: `openAuthModal()`, `closeAuthModal()`, `switchAuthTab()`, `showAuthForm()`, `showAuthAlert()` (lines 606–641); `handleLogin()`, `handleRegister()` (lines 652–695); `handlePasswordResetRequest()`, `handlePasswordResetConfirm()` (lines 697–748); `handleLogout()` (lines 750–767); `checkAuthState()`, `updateHeaderAuthUI()`, `renderAvatar()`, `getInitials()` (lines 769–820); `showToast()` (lines 931–937); `togglePasswordVisibility()` (lines 939–945); user dropdown toggle (lines 968–974); `wireAuthEvents()` (lines 947–979); `setSubmitting()`, `readApiResponse()`, `getResetToken()` utilities; DOMContentLoaded init calling `wireAuthEvents()` and `checkAuthState()`
- [x] T031 [US3] Create `static/js/article.js` — extract from `frontend.js`: `switchTab()` (lines 426–443); `fetchSummary()` (lines 446–486); `fetchFactCheck()` (lines 489–533); `renderChat()` and chat form submit handler (lines 536–602); gauge animation from `loadTememo()` (lines 397–423); read `data-article-id` from `.reader-view` element; use `AbortController` per analysis surface to cancel stale requests (FR-011); DOMContentLoaded init calling `initTememo(articleId)` only when `data-article-id` is present
- [x] T032 [US3] Wire `article.js` script tag into `templates/article.html` `{% block page_scripts %}` — ensure Tememo panel initializes on article page load
- [x] T033 [US3] Verify Tememo panel graceful degradation — when JS is disabled, article body remains readable; Tememo panel shows static placeholder or is hidden via `<noscript>` fallback

### Tests for User Story 3

- [x] T034 [P] [US3] Write `TestArticlePage.test_article_page_has_tememo_panel` in `tests/test_mpa_routes.py` — assert Tememo panel container and tab buttons present in article page HTML
- [x] T035 [P] [US3] Write `TestArticlePage.test_article_page_loads_article_js` in `tests/test_mpa_routes.py` — assert `article.js` script tag present in article page response

**Checkpoint**: Summary, Fact-Check, and Chat AI features work on article pages. Stale response guard in place. Article remains readable without JS. Existing API endpoints (`/api/gemini/summarize`, `/api/gemini/factcheck`, `/api/gemini/chat`) unchanged.

---

## Phase 6: User Story 4 — Access Account and Profile Journeys (Priority: P4)

**Goal**: Authentication, profile settings, password change, and avatar upload remain fully functional across the multi-page architecture. Session persists across navigations.

**Independent Test**: Complete sign-in, sign-out, password-reset entry, profile viewing, profile editing, password change, and avatar upload from the migrated application.

### Implementation for User Story 4

- [x] T036 [US4] Create `static/js/profile.js` — extract from `frontend.js`: `handleProfileUpdate()` (lines 853–876); `handlePasswordChange()` (lines 878–905); `handleAvatarUpload()` (lines 907–929); DOMContentLoaded init wiring form submit handlers; on password change success, redirect to `/` and clear session state
- [x] T037 [US4] Create `templates/profile.html` — extends `base.html`; server-renders profile settings form (personal info, avatar preview, password change) with pre-filled values from server; loads `profile.js` in `{% block page_scripts %}`; content extracted from `templates/index.html` lines 162–213
- [x] T038 [US4] Add `profile_page()` route to `routes.py` — `@main_bp.route("/profile")`, check `get_current_user()`, redirect unauthenticated to `/?auth_intent=login&next=/profile`, render `profile.html` with user and profile data for authenticated users
- [x] T039 [US4] Add auth intent handling in `templates/base.html` — inline `<script>` after `core.js` that checks `URLSearchParams` for `auth_intent=login` and calls `window.TMM.openAuthModal("login")`; expose `openAuthModal` on `window.TMM` namespace in `core.js`
- [x] T040 [US4] Verify session continuity across page navigations — `core.js` calls `checkAuthState()` on every page load; Flask session cookie persists across `/`, `/articles/<id>`, `/profile`

### Tests for User Story 4

- [x] T041 [P] [US4] Write `TestProfilePage.test_profile_page_redirects_unauthenticated` in `tests/test_mpa_routes.py` — GET `/profile` without session, assert 302 redirect to `/?auth_intent=login`
- [x] T042 [P] [US4] Write `TestProfilePage.test_profile_page_renders_for_authenticated` in `tests/test_mpa_routes.py` — sign in, GET `/profile`, assert 200 and profile form fields in response
- [x] T043 [P] [US4] Write `TestProfilePage.test_profile_page_prefills_user_data` in `tests/test_mpa_routes.py` — sign in, GET `/profile`, assert user's full_name and email values present in response HTML
- [x] T044 [P] [US4] Write `TestSessionContinuity.test_session_persists_from_feed_to_article` in `tests/test_mpa_routes.py` — sign in, GET `/`, GET `/articles/<id>`, assert authenticated state in both responses
- [x] T045 [P] [US4] Write `TestSessionContinuity.test_session_persists_from_article_to_profile` in `tests/test_mpa_routes.py` — sign in, GET `/articles/<id>`, GET `/profile`, assert authenticated state and profile data

**Checkpoint**: Auth modal works from any page. Profile settings page is protected. Session persists across all pages. Password change invalidates session and redirects. All existing auth and profile tests pass.

---

## Phase 7: Polish & Cutover (Plan Phase F)

**Purpose**: Remove deprecated SPA code, run full regression, verify manual checklist.

- [x] T046 Remove `<script src="frontend.js">` from `templates/base.html` (if it was included for transitional testing)
- [x] T047 Delete `static/js/frontend.js` — the monolithic SPA controller is fully replaced by `core.js`, `article.js`, and `profile.js`
- [x] T048 Remove SPA view-switching DOM containers from old template markup — delete `#homepage-view`, `#article-reader-view`, `#profile-settings-view` wrapper divs with `.hide` class toggling (now each view is a separate template/page)
- [x] T049 Run existing regression suites: `python -m pytest tests/test_routes.py tests/test_auth.py tests/test_profile_management.py` — all must pass
- [x] T050 Run new MPA route tests: `python -m pytest tests/test_mpa_routes.py` — all must pass
- [x] T051 Manual verification checklist:
- [x] Open `/articles/<id>` in a new browser session → article displays with full content
- [x] Refresh an article page → same article remains
- [x] Share an article URL → recipient sees the correct article
- [x] Browser Back/Forward between feed and article → works correctly
- [x] Feed page loads with JS disabled → articles and categories visible
- [x] Article page loads with JS disabled → article content readable
- [x] Sign in → navigate feed → article → profile → session maintained
- [x] Password change → redirected to feed → must sign in again
- [x] Invalid article ID `/articles/99999` → 404 page displayed
- [x] Category filter links on feed → correct articles shown
- [x] Trending sidebar links → navigate to correct article pages

**Checkpoint**: All SPA code removed. All automated tests green. Manual checklist verified. Migration complete.

---

## Dependencies & Execution Order

### Phase Dependencies

```text
Phase 1 (Foundational)         ← No dependencies, start immediately
  ↓
Phase 2 (Page Shell)            ← Depends on Phase 1 (service must exist)
  ↓
Phase 3 (US1: Article Page)  ← Depends on Phase 2 (base.html + partials)
Phase 4 (US2: Feed Page)     ← Depends on Phase 2 (base.html + partials)
  ↓                              ↑ Phases 3 & 4 can run in PARALLEL
Phase 5 (US3: JS Enhancements)  ← Depends on Phase 3 (article page must exist)
Phase 6 (US4: Profile/Session)  ← Depends on Phase 2 (base.html)
  ↓                              ↑ Phases 5 & 6 can run in PARALLEL
Phase 7 (Cutover)               ← Depends on ALL previous phases
```

### Within Each Phase

- Tests marked [P] can run in parallel
- Implementation tasks follow: helpers → service functions → routes → templates
- Tasks touching the same file must be sequential

### Parallel Opportunities

| Parallel Group | Tasks |
|---|---|
| Phase 1 helpers | T004 + T005 (different functions, same file but independent) |
| Phase 2 partials | T008 + T009 + T010 (different files) |
| Phase 3 + Phase 4 | US1 and US2 can run in parallel after Phase 2 |
| Phase 5 + Phase 6 | US3 and US4 can run in parallel after their prerequisites |
| All test tasks within a phase | All [P] tests can run in parallel |

---

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 1: Foundational service
2. Complete Phase 2: Page shell + partials
3. Complete Phase 3: Article page (US1)
4. **STOP and VALIDATE**: Article pages directly addressable, shareable, refreshable
5. Deploy/demo if ready

### Incremental Delivery

1. Phase 1 + 2 → Foundation ready (zero visible user change)
2. + Phase 3 → Article pages live → Test independently → Demo (MVP!)
3. + Phase 4 → Server-rendered feed → Test independently → Demo
4. + Phase 5 → AI enhancements on article pages → Test independently → Demo
5. + Phase 6 → Profile page + sessions → Test independently → Demo
6. + Phase 7 → Cleanup and cutover → Final validation

---

## Notes

- [P] tasks = different files, no dependencies
- [Story] label maps task to specific user story for traceability
- Each user story should be independently completable and testable
- Commit after each task or logical group
- Stop at any checkpoint to validate story independently
- Total: **51 tasks** across 7 phases covering 4 user stories
