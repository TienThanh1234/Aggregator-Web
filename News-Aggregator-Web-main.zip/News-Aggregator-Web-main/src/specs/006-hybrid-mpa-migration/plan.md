# Implementation Plan: Hybrid MPA Migration

**Branch**: `006-hybrid-mpa-migration` | **Date**: 2026-07-30 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `specs/006-hybrid-mpa-migration/spec.md`

## Summary

Migrate the public feed, article reader, and profile settings from a client-side SPA (single `index.html` + monolithic `frontend.js` that toggles `#homepage-view`, `#article-reader-view`, `#profile-settings-view` via CSS class `.hide`) to independently addressable server-rendered pages. Preserve Summary, Fact-check, Chat, authentication, password reset, and profile updates as targeted JavaScript enhancements. Introduce an article presentation service so page routes and the compatibility JSON endpoint share serialization rules, retain the existing database schema, and cut over incrementally with route and regression tests.

## Technical Context

**Language/Version**: Python 3.11+, HTML5, CSS3, ES6+ JavaScript

**Primary Dependencies**: Flask 3.1.3, Jinja2 3.1.6, Flask-SQLAlchemy 3.1.1, Werkzeug 3.1.8, existing Lucide CDN and Google Fonts assets

**Storage**: Existing PostgreSQL database in deployed environments; SQLite in-memory database for isolated route tests. No schema migration is planned.

**Testing**: Python `unittest`, Flask test client, existing authentication/profile/route suites, and browser-level manual validation with and without JavaScript

**Target Platform**: WSGI web application served by Gunicorn; current supported desktop and mobile browsers

**Project Type**: Server-rendered web application with progressive client-side enhancement

**Performance Goals**: Primary feed and article content visible within 2 seconds for at least 95% of normal test visits; article-list route retains the constitution target of under 500 ms p95 for server processing

**Constraints**: Preserve existing visual design, session behavior, public interaction endpoints, stored data, and responsive behavior; do not introduce a frontend framework or build pipeline; do not implement full-text search in this feature

**Scale/Scope**: Three primary page contexts (`/`, `/articles/<id>`, `/profile`), shared layout/partials, approximately 20 articles per feed page, existing AI/auth/profile endpoints retained

---

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

### Pre-Design Gate

| Principle | Evaluation | Plan Response |
|---|---|---|
| Modular Scraping via OO Design (§I) | N/A | No scraper code is modified. |
| Strict MVC (§II) | PASS | Article lookup, pagination, category derivation, AI metadata parsing, and presentation mapping move to `services/article_service.py`; routes orchestrate; templates only display prepared values. |
| Environment Configuration (§III) | PASS | No new secrets or required environment variables are introduced. |
| Data Integrity & Duplicate Prevention (§IV) | PASS | Existing article, user, bookmark, and profile records remain unchanged; no schema migration is required. |
| Code Organization & Naming (§V) | PASS | New files follow snake_case naming; classes use PascalCase; all under existing `src/` tree. |
| Error Handling & Resilience (§VI) | PASS | Missing articles return a dedicated 404 page; query/render failures are logged and produce controlled error states. |
| Testing & Quality (§VII) | PASS | Route, session, direct-navigation, degraded-JavaScript, and regression coverage are part of the design and quickstart. |
| Environment Governance (§VIII) | PASS | All commands run inside activated venv per constitution policy. |
| Documentation Location (§IX) | PASS | All feature artifacts are contained in `src/specs/006-hybrid-mpa-migration/` with canonical names. |
| Security (§Code Quality) | PASS | Server templates rely on Jinja2 automatic escaping; external text is never marked safe; interactive rendering uses text nodes rather than untrusted HTML. |
| Performance & Pagination (§Performance) | PASS | Feed retrieval is paginated and avoids sending full article bodies for every feed card. |

No constitution violations require justification.

### Post-Design Gate

Phase 1 design retains the same outcomes:

- No persistent entity or database migration is introduced.
- `article_service.py` owns reusable article presentation logic; routes remain thin.
- Page contracts define safe failures, canonical article URLs, and compatibility behavior.
- The quickstart validates server-rendered content, JavaScript degradation, authentication persistence, accessibility basics, and regression tests.
- All generated artifacts remain inside the canonical feature directory.

**Post-design result**: PASS.

---

## Project Structure

### Documentation (this feature)

```text
specs/006-hybrid-mpa-migration/
├── spec.md
├── plan.md              # This file
└── tasks.md             # Generated later by $speckit-tasks
```

### Source Code (repository root)

```text
src/
├── app.py                                # Unchanged
├── models.py                             # Unchanged
├── routes.py                             # MODIFY: add page routes, keep API routes
├── services/
│   ├── article_service.py                # NEW: query and presentation mapping
│   ├── auth_service.py                   # Unchanged
│   ├── profile_service.py                # Unchanged
│   └── ...
├── templates/
│   ├── base.html                         # MODIFY: shared document shell (currently empty)
│   ├── index.html                        # MODIFY: server-rendered paginated feed (extends base)
│   ├── article.html                      # NEW: canonical article reader page
│   ├── profile.html                      # NEW: protected profile settings page
│   ├── 404.html                          # NEW: dedicated not-found page
│   └── partials/
│       ├── _article_card.html            # NEW: reusable feed card partial
│       ├── _auth_modal.html              # NEW: extracted auth modal markup
│       └── _tememo_panel.html            # NEW: extracted Tememo AI sidebar
├── static/
│   ├── css/frontend.css                  # MODIFY: minor additions for page-specific states
│   └── js/
│       ├── core.js                       # NEW: shared auth, modal, toast, navigation UI
│       ├── article.js                    # NEW: summary, fact-check, and contextual chat
│       ├── profile.js                    # NEW: profile update, password, avatar actions
│       └── frontend.js                   # DEPRECATED: retained temporarily, then deleted
└── tests/
    ├── test_routes.py                    # Unchanged (existing regression)
    ├── test_auth.py                      # Unchanged (existing regression)
    ├── test_profile_management.py        # Unchanged (existing regression)
    └── test_mpa_routes.py               # NEW: page contract/regression coverage
```

**Structure Decision**: Keep the existing single Flask application and MVC boundaries. Consolidate duplicated document markup into template inheritance, introduce one presentation-focused service, and split the monolithic browser controller by page responsibility without adding a build system.

---

## Design and Migration Strategy

### Phase A — Presentation Boundary (`article_service.py`)

> **Goal**: Extract all article serialization/presentation logic from `routes.py` into a service, so both the existing `/api/articles` JSON endpoint and future server-rendered pages share the same transformation rules.

#### [NEW] `services/article_service.py`

Create a presentation service with the following responsibilities:

```python
# Key functions to implement:

def get_feed_articles(
    category: str | None = None,
    page: int = 1,
    per_page: int = 20
) -> tuple[list[dict], int, int]:
    """Return (feed_cards, total_pages, current_page).
    
    Feed cards include: id, title, category (mapped), author, date,
    image (proxied), summary, confidence_score, read_time.
    Does NOT include paragraphs or full body to keep feed payloads light.
    """

def get_article_detail(article_id: int) -> dict | None:
    """Return a full article presentation dict or None if not found.
    
    Includes: id, title, category, author, date, image, summary,
    confidence_score, read_time, paragraphs, key_takeaways,
    unverified_claim, unverified_claim_analysis.
    """

def get_categories() -> list[dict]:
    """Return ordered categories with counts, using the Vietnamese→English
    mapping currently in get_articles() route."""

def get_trending_articles(limit: int = 5) -> list[dict]:
    """Return top articles by confidence_score for sidebar."""

# Internal helpers (extracted from current routes.py lines 262-337):
def _map_category(raw_cat: str) -> str: ...
def _proxy_image_url(cover_image_url: str | None) -> str: ...
def _parse_ai_metadata(ai_summary: str | None) -> dict: ...
def _split_paragraphs(raw_content: str | None, description: str | None) -> list[str]: ...
```

**Constitution compliance**: 
- MVC §II: Business logic moves to service; route handlers remain thin orchestrators.
- Code Organization §V: snake_case functions, PascalCase for any type hints.

#### [MODIFY] `routes.py` — Refactor `/api/articles`

Replace the inline serialization logic (lines 262–337) with a call to `article_service.get_feed_articles()`. Keep the endpoint returning the same JSON shape for backward compatibility.

```python
@main_bp.route("/api/articles", methods=["GET"])
def get_articles():
    """Compatibility endpoint — delegates to article_service."""
    try:
        from services.article_service import get_all_articles_legacy
        return jsonify(get_all_articles_legacy())
    except Exception as exc:
        logger.error("[ERROR] Failed to fetch articles: %s", exc)
        return jsonify({"error": str(exc)}), 500
```

---

### Phase B — Shared Page Shell (`base.html` + partials)

> **Goal**: Convert the empty `base.html` into the single document shell with overridable blocks. Extract shared markup (header, footer, auth modal, toast region) from the monolithic `index.html`.

#### [MODIFY] `templates/base.html` — Master Layout

The base template provides:
- `<!DOCTYPE html>`, `<html lang="en">`, `<head>` with fonts, CSS, Lucide CDN
- Overridable blocks: `{% block title %}`, `{% block meta %}`, `{% block content %}`, `{% block page_scripts %}`
- Shared header with logo, nav, auth/profile dropdown
- Toast container `#toast-container`
- Auth modal (via `{% include "partials/_auth_modal.html" %}`)
- Footer
- Lucide init script
- Shared `core.js` script

```html
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>{% block title %}Tell Me More — Premium Neoclassical News Aggregator{% endblock %}</title>
  {% block meta %}
  <meta name="description" content="...">
  <meta property="og:title" content="Tell Me More">
  <meta property="og:type" content="website">
  {% endblock %}
  <!-- Fonts, CSS, Lucide (same as current index.html lines 14-23) -->
  <link rel="stylesheet" href="{{ url_for('static', filename='css/frontend.css') }}">
  <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body>
  <!-- Header (lines 28-64 from current index.html) -->
  <header class="site-header">...</header>
  <div id="toast-container" class="toast-container" aria-live="polite"></div>

  {% block hero %}{% endblock %}

  <main class="container main-content" style="flex:1;">
    {% block content %}{% endblock %}
  </main>

  <!-- Footer (lines 358-375 from current index.html) -->
  <footer class="site-footer">...</footer>

  {% include "partials/_auth_modal.html" %}

  <script>lucide.createIcons();</script>
  <script src="{{ url_for('static', filename='js/core.js') }}"></script>
  {% block page_scripts %}{% endblock %}
</body>
</html>
```

#### [NEW] `templates/partials/_auth_modal.html`

Extract lines 377–416 from `index.html` (the auth modal overlay, login form, register form, password reset forms) into a standalone partial.

#### [NEW] `templates/partials/_article_card.html`

Reusable Jinja2 partial for a single feed card (replaces `buildCard()` in `frontend.js`):

```html
<article class="article-card {{ 'lead-card' if is_lead else '' }}">
  <a href="{{ url_for('main.article_page', article_id=article.id) }}" class="card-link">
    <div class="card-img-wrap">
      <img class="card-img" src="{{ article.image }}" alt="{{ article.title }}" referrerpolicy="no-referrer"
        onerror="this.parentElement.style.background='var(--primary-cnt)'; this.style.display='none';">
      <span class="card-cat-badge">{{ article.category }}</span>
    </div>
    <div class="card-body">
      <div><div class="card-meta">
        <span>{{ article.author }}</span><span>&bull;</span><span>{{ article.date }}</span>
      </div>
      <h3 class="card-title">{{ article.title }}</h3>
      <p class="card-summary">{{ article.summary }}</p></div>
      <div class="card-footer">
        <span class="card-action"><i data-lucide="feather" class="card-action-icon"></i>Tell Me More</span>
        <span class="card-read-time">{{ article.read_time }}</span>
      </div>
    </div>
  </a>
</article>
```

#### [NEW] `templates/partials/_tememo_panel.html`

Extract lines 263–351 from `index.html` (the Tememo AI sidebar with Summary/Fact-Check/Chat tabs) into a reusable partial, included by `article.html`. Article-specific data attributes are set via `data-article-id="{{ article.id }}"` for JS initialization.

---

### Phase C — Addressable Feed and Article Pages

> **Goal**: Create the three primary server-rendered pages: `/` (feed), `/articles/<id>` (article detail), and a 404 page.

#### [MODIFY] `templates/index.html` — Server-Rendered Feed

Rewrite to extend `base.html`. Server-side rendering replaces client-side `fetch("/api/articles")` + JS DOM injection.

```html
{% extends "base.html" %}

{% block title %}Tell Me More — {{ active_category }}{% endblock %}

{% block hero %}
<!-- Hero banner (lines 69-83 from current index.html) -->
<div class="hero-banner" id="hero-banner-widget">...</div>
{% endblock %}

{% block content %}
<div class="homepage-grid">
  <!-- LEFT: Sidebar with server-rendered categories and trending -->
  <aside class="sidebar">
    <div class="widget">
      <h3 class="widget-heading">Insight Streams</h3>
      <nav class="category-nav">
        {% for cat in categories %}
        <a href="{{ url_for('main.index', category=cat.name) if cat.name != 'All Dispatches' else url_for('main.index') }}"
           class="cat-btn {{ 'active' if cat.name == active_category else '' }}">
          <div class="cat-btn-left">
            <i data-lucide="{{ cat.icon }}" class="cat-icon"></i>
            <span>{{ cat.name }}</span>
          </div>
          {% if cat.name == active_category %}<span class="cat-dot"></span>{% endif %}
        </a>
        {% endfor %}
      </nav>
    </div>

    <div class="widget">
      <div class="widget-heading-row">
        <i data-lucide="trending-up" class="widget-icon"></i>
        <h3 class="widget-heading">Trending Now</h3>
      </div>
      <ul class="trending-list">
        {% for t in trending %}
        <li class="trending-item">
          <span class="trending-num">{{ "%02d" | format(loop.index) }}.</span>
          <a href="{{ url_for('main.article_page', article_id=t.id) }}" class="trending-title">{{ t.title }}</a>
        </li>
        {% endfor %}
      </ul>
    </div>

    <!-- Our Mission widget (static, lines 113-131) -->
    <div class="mission-widget">...</div>
  </aside>

  <!-- RIGHT: Feed -->
  <div class="feed-col">
    <div class="feed-header">
      <div class="feed-header-left">
        <i data-lucide="globe" class="feed-globe-icon"></i>
        <h2 class="feed-title">The Live Feed</h2>
        <span class="feed-category-badge">{{ active_category }}</span>
      </div>
    </div>

    <div class="articles-grid">
      {% if articles %}
        {% for article in articles %}
          {% include "partials/_article_card.html" %}
        {% endfor %}
      {% else %}
        <div class="empty-state">
          <i data-lucide="feather" style="height:2rem;width:2rem;opacity:.3;"></i>
          <h3 class="empty-title">No dispatches found</h3>
          <p class="empty-desc">No articles match the selected category.</p>
        </div>
      {% endif %}
    </div>

    <!-- Pagination -->
    {% if total_pages > 1 %}
    <nav class="pagination" aria-label="Feed pagination">
      {% if current_page > 1 %}
      <a href="?page={{ current_page - 1 }}{{ '&category=' + active_category if active_category != 'All Dispatches' else '' }}" class="page-link">&laquo; Previous</a>
      {% endif %}
      <span class="page-info">Page {{ current_page }} of {{ total_pages }}</span>
      {% if current_page < total_pages %}
      <a href="?page={{ current_page + 1 }}{{ '&category=' + active_category if active_category != 'All Dispatches' else '' }}" class="page-link">Next &raquo;</a>
      {% endif %}
    </nav>
    {% endif %}
  </div>
</div>
{% endblock %}
```

#### [MODIFY] `routes.py` — Add Page Routes

```python
from services.article_service import (
    get_feed_articles,
    get_article_detail,
    get_categories,
    get_trending_articles,
)

@main_bp.route("/")
def index():
    """Server-render the paginated news feed."""
    category = request.args.get("category")
    page = request.args.get("page", 1, type=int)
    articles, total_pages, current_page = get_feed_articles(
        category=category, page=page, per_page=20
    )
    return render_template(
        "index.html",
        articles=articles,
        categories=get_categories(),
        trending=get_trending_articles(),
        active_category=category or "All Dispatches",
        current_page=current_page,
        total_pages=total_pages,
    )

@main_bp.route("/articles/<int:article_id>")
def article_page(article_id: int):
    """Server-render the canonical article reader page."""
    article = get_article_detail(article_id)
    if article is None:
        return render_template("404.html", message="Dispatch not found."), 404
    return render_template("article.html", article=article)

@main_bp.route("/profile")
def profile_page():
    """Server-render the protected profile settings page."""
    auth_data, _ = get_current_user()
    if not auth_data.get("authenticated"):
        return redirect(url_for("main.index", auth_intent="login", next="/profile"))
    user_id = auth_data["user"]["id"]
    profile_result, _ = get_profile_data(user_id)
    return render_template(
        "profile.html",
        user=auth_data["user"],
        profile=profile_result.get("profile", {}),
    )
```

#### [NEW] `templates/article.html`

```html
{% extends "base.html" %}

{% block title %}{{ article.title }} — Tell Me More{% endblock %}

{% block meta %}
<meta name="description" content="{{ article.summary[:160] }}">
<meta property="og:title" content="{{ article.title }}">
<meta property="og:description" content="{{ article.summary[:200] }}">
<meta property="og:type" content="article">
{% endblock %}

{% block content %}
<div class="reader-view" data-article-id="{{ article.id }}">
  <div class="reader-top-nav">
    <a href="{{ url_for('main.index') }}" class="back-btn">
      <i data-lucide="arrow-left" class="back-icon"></i>
      BACK TO DISPATCH FEED
    </a>
    <span class="dispatch-id-label">Dispatch ID: {{ article.id }}</span>
  </div>

  <div class="reader-grid">
    <!-- LEFT: Article Body (server-rendered) -->
    <article class="article-body">
      <div class="article-meta-top">
        <span class="article-cat-tag">{{ article.category }}</span>
        <span class="meta-dot"></span>
        <span class="article-read-time">{{ article.read_time }}</span>
      </div>
      <h1 class="article-headline">{{ article.title }}</h1>
      <div class="article-byline">
        <span>By <strong>{{ article.author }}</strong></span>
        <span>{{ article.date }}</span>
      </div>
      {% if article.image %}
      <div class="article-cover">
        <img class="article-cover-img" src="{{ article.image }}" alt="{{ article.title }}">
      </div>
      {% endif %}
      <div class="article-body-text">
        {% for paragraph in article.paragraphs %}
        <p>{{ paragraph }}</p>
        {% endfor %}
      </div>
      <div class="meander-separator" style="opacity:0.4; margin-top:2rem;"></div>
    </article>

    <!-- RIGHT: Tememo AI Panel -->
    {% include "partials/_tememo_panel.html" %}
  </div>
</div>
{% endblock %}

{% block page_scripts %}
<script src="{{ url_for('static', filename='js/article.js') }}"></script>
{% endblock %}
```

#### [NEW] `templates/404.html`

```html
{% extends "base.html" %}
{% block title %}Not Found — Tell Me More{% endblock %}
{% block content %}
<div class="empty-state" style="padding:4rem 0;">
  <i data-lucide="alert-triangle" style="height:2rem;width:2rem;color:var(--terracotta);"></i>
  <h1 class="empty-title">Dispatch Not Found</h1>
  <p class="empty-desc">{{ message or "The requested dispatch could not be located." }}</p>
  <a href="{{ url_for('main.index') }}" class="back-btn" style="margin-top:1rem;">
    <i data-lucide="arrow-left" class="back-icon"></i>Return to Feed
  </a>
</div>
{% endblock %}
```

#### [NEW] `templates/profile.html`

Server-render the profile settings page (currently lines 162–213 of `index.html`). Extends `base.html`, fills form fields with server-delivered values, delegates form submissions to `profile.js`.

---

### Phase D — Progressive JavaScript Enhancements

> **Goal**: Split the monolithic `frontend.js` (~980 lines) into focused, page-specific scripts. Each page loads only the JS it needs.

#### [NEW] `static/js/core.js` (~250 lines)

Shared across all pages via `base.html`. Contains:

| Responsibility | Extracted From |
|---|---|
| Auth modal open/close/tab switching | `openAuthModal()`, `closeAuthModal()`, `switchAuthTab()`, `showAuthForm()`, `showAuthAlert()` (lines 606–641) |
| Login/Register/Password-reset handlers | `handleLogin()`, `handleRegister()`, `handlePasswordResetRequest()`, `handlePasswordResetConfirm()` (lines 652–748) |
| Logout handler | `handleLogout()` (lines 750–767) |
| Auth state check on page load | `checkAuthState()`, `updateHeaderAuthUI()`, `renderAvatar()` (lines 769–820) |
| User dropdown toggle | Lines 968–974 |
| Toast notifications | `showToast()` (lines 931–937) |
| Password visibility toggle | `togglePasswordVisibility()` (lines 939–945) |
| Utility helpers | `setSubmitting()`, `readApiResponse()`, `getInitials()`, `getResetToken()` |

Initialization: `document.addEventListener("DOMContentLoaded", () => { wireAuthEvents(); checkAuthState(); });`

#### [NEW] `static/js/article.js` (~350 lines)

Loaded only on `/articles/<id>` via `article.html {% block page_scripts %}`. Contains:

| Responsibility | Extracted From |
|---|---|
| Tememo tab switching | `switchTab()` (lines 426–443) |
| Summary fetch and render | `fetchSummary()` (lines 446–486) |
| Fact-check fetch and render | `fetchFactCheck()` (lines 489–533) |
| Chat conversation | `renderChat()`, chat form submit handler (lines 536–602) |
| Gauge animation | Part of `loadTememo()` (lines 397–423) |

Reads `data-article-id` from the `.reader-view` element. Uses one `AbortController` per analysis surface to cancel stale requests (spec FR-011: results must match current article context).

```javascript
// article.js initialization
document.addEventListener("DOMContentLoaded", () => {
  const readerEl = document.querySelector("[data-article-id]");
  if (!readerEl) return;
  const articleId = readerEl.dataset.articleId;
  initTememo(articleId);
});
```

#### [NEW] `static/js/profile.js` (~120 lines)

Loaded only on `/profile` via `profile.html {% block page_scripts %}`. Contains:

| Responsibility | Extracted From |
|---|---|
| Profile update (PATCH) | `handleProfileUpdate()` (lines 853–876) |
| Password change (POST) | `handlePasswordChange()` (lines 878–905) |
| Avatar upload (POST) | `handleAvatarUpload()` (lines 907–929) |

On password change success, redirects to `"/"` and clears session state (matching existing behavior line 899).

#### [DEPRECATE → DELETE] `static/js/frontend.js`

After all three page-specific scripts are verified:
1. Keep `frontend.js` temporarily for regression comparison.
2. Remove it once `test_mpa_routes.py` and manual tests pass.

---

### Phase E — Profile and Session Continuity

> **Goal**: Make `/profile` a protected server-rendered page. Ensure session persists across page navigations.

#### [MODIFY] `routes.py` — `/profile` Route

- Check `get_current_user()` on the server side.
- If unauthenticated → `redirect(url_for("main.index", auth_intent="login", next="/profile"))`.
- If authenticated → render `profile.html` with pre-filled profile data.

#### [MODIFY] `templates/base.html` — Auth Intent Handling

Add a `<script>` block that checks for `auth_intent` query parameter and auto-opens the auth modal:

```javascript
// In base.html, after core.js loads:
const params = new URLSearchParams(window.location.search);
if (params.get("auth_intent") === "login") {
  window.TMM.openAuthModal("login");
}
```

#### Session Continuity

- Flask session cookie already persists across page navigations (existing `SESSION_COOKIE_HTTPONLY`, `SESSION_COOKIE_SAMESITE` settings in auth_service.py).
- `core.js` calls `checkAuthState()` on every page load, ensuring the header UI reflects the current session.
- After password rotation (in `profile.js`), redirect to `/` — the server will see the invalidated session and show the guest UI.

---

### Phase F — Verification and Cutover

> **Goal**: Add page-contract tests before removing SPA-only rendering paths. Run existing suites after each migration slice. Clean up obsolete code.

#### [NEW] `tests/test_mpa_routes.py`

```python
class TestFeedPage(unittest.TestCase):
    """Verify the server-rendered feed page contract."""
    
    def test_index_returns_html_with_articles(self): ...
    def test_index_category_filter(self): ...
    def test_index_pagination(self): ...
    def test_index_empty_state(self): ...
    def test_index_no_js_required_for_content(self): ...

class TestArticlePage(unittest.TestCase):
    """Verify the server-rendered article page contract."""
    
    def test_article_page_returns_article_content(self): ...
    def test_article_page_has_og_meta_tags(self): ...
    def test_article_page_404_for_missing_id(self): ...
    def test_article_page_404_for_invalid_id(self): ...
    def test_article_page_refresh_preserves_content(self): ...
    def test_article_page_has_back_link_to_feed(self): ...

class TestProfilePage(unittest.TestCase):
    """Verify the protected profile page contract."""
    
    def test_profile_page_redirects_unauthenticated(self): ...
    def test_profile_page_renders_for_authenticated(self): ...
    def test_profile_page_prefills_user_data(self): ...

class TestCompatibilityEndpoint(unittest.TestCase):
    """Verify /api/articles still returns the same JSON shape."""
    
    def test_api_articles_backward_compatible(self): ...

class TestSessionContinuity(unittest.TestCase):
    """Verify session persists across page navigations."""
    
    def test_session_persists_from_feed_to_article(self): ...
    def test_session_persists_from_article_to_profile(self): ...
```

#### Existing Test Regression

- `test_routes.py` — Must continue passing (API endpoints unchanged).
- `test_auth.py` — Must continue passing (auth endpoints unchanged).
- `test_profile_management.py` — Must continue passing (profile API endpoints unchanged).

#### Manual Verification Checklist

- [ ] Open `/articles/<id>` in a new browser session → article displays with full content
- [ ] Refresh an article page → same article remains
- [ ] Share an article URL → recipient sees the correct article
- [ ] Browser Back/Forward between feed and article → works correctly
- [ ] Feed page loads with JS disabled → articles and categories visible
- [ ] Article page loads with JS disabled → article content readable, AI panel gracefully hidden
- [ ] Sign in → navigate feed → article → profile → session maintained
- [ ] Password change → redirected to feed → must sign in again
- [ ] Invalid article ID `/articles/99999` → 404 page displayed
- [ ] Category filter links on feed → correct articles shown
- [ ] Trending sidebar links → navigate to correct article pages

#### Cutover Sequence

1. Deploy Phase A (article_service) — Zero visible change; `/api/articles` still works.
2. Deploy Phase B+C (templates + page routes) — New pages live; old SPA controller still loaded but unused for primary navigation.
3. Deploy Phase D (JS split) — Remove `frontend.js` from `base.html`; load `core.js` + page-specific scripts.
4. Deploy Phase E (profile page) — Protected route live.
5. Deploy Phase F (cleanup) — Delete `frontend.js`, remove SPA view-switching DOM containers from old `index.html`, confirm all tests green.

---

## Complexity Tracking

No constitution violations or exceptional complexity are introduced.

---

## File Change Summary

| File | Action | Phase | Description |
|---|---|---|---|
| `services/article_service.py` | NEW | A | Article query, mapping, and presentation service |
| `routes.py` | MODIFY | A, C, E | Refactor `/api/articles`; add `/`, `/articles/<id>`, `/profile` page routes |
| `templates/base.html` | MODIFY | B | Shared document shell with Jinja2 blocks |
| `templates/partials/_auth_modal.html` | NEW | B | Extracted auth modal markup |
| `templates/partials/_article_card.html` | NEW | B | Reusable feed card partial |
| `templates/partials/_tememo_panel.html` | NEW | B | Extracted Tememo AI sidebar |
| `templates/index.html` | MODIFY | C | Server-rendered paginated feed extending base |
| `templates/article.html` | NEW | C | Canonical article reader page |
| `templates/404.html` | NEW | C | Dedicated not-found page |
| `templates/profile.html` | NEW | E | Protected profile settings page |
| `static/js/core.js` | NEW | D | Shared auth, modal, toast, navigation JS |
| `static/js/article.js` | NEW | D | Article-specific Tememo enhancements |
| `static/js/profile.js` | NEW | D | Profile update/password/avatar JS |
| `static/css/frontend.css` | MODIFY | B, C | Minor additions for pagination, page-specific states |
| `static/js/frontend.js` | DELETE | F | Removed after all page scripts verified |
| `tests/test_mpa_routes.py` | NEW | F | Page contract and regression tests |
