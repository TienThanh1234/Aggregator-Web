# Feature Specification: Premium Neoclassical News Aggregator Frontend (Tell Me More)

**Feature Branch**: `002-frontend-design`

**Created**: 2026-06-27

**Status**: Draft

**Scope**: This document specifies the design and functionality dedicated to the **Homepage (The Live Feed)** and the **Article Detailed Reading page** of the News Aggregator Web Application.

**Input**: User reference codebase in [src/ref](file:///c:/Users/user/Documents/repos/news-aggregator/src/ref) containing a premium Vite/React/TS news dashboard layout.

---

## User Scenarios & Testing

### User Story 1 — Elegant News Portal Index (Priority: P1)
As a premium reader, I want to browse news articles through a beautifully formatted neoclassical grid layout on the **Homepage** so that I can consume news in a focused, high-end editorial environment.
- **Acceptance Scenario**: 
  - Given the database contains articles, when a user visits the homepage, they see a "Lead Article" (promoted index 0) occupying a wider card, and other articles in a clean 2-column grid.
  - Clicking on the search bar and typing a keyword filters the list instantly by title or description.

### User Story 2 — Categorized Feeds (Priority: P2)
As a focused reader, I want to view articles filtered by specific categories (e.g. Science, Tech, World) on the **Homepage** so that I can bypass topics I am not interested in.
- **Acceptance Scenario**: 
  - Given the categories in the database, when the user clicks a category link in the "Category Bar" (e.g., "Số hóa"), the The Live Feed feed instantly filters to display only articles associated with that category.

### User Story 3 — AI-Assisted Reading Room (Priority: P1)
As a critical reader, I want an interactive sidebar on the **Article Detailed Reading page** that displays AI summaries, conducts fact-checks of unverified assertions, and lets me chat with an AI partner about the article so that I can gain deep context.
- **Acceptance Scenario**: 
  - When viewing an article, the right sidebar renders a "Truth Index Gauge" (using the article's `truth_score`).
  - Clicking the "Summary" tab displays key takeaways.
  - Clicking the "Fact-Check" tab highlights "Verified Solid Claims" and "Unverified Assertions" with their specific analysis.
  - In the article text, any unverified assertion is highlighted in red/terracotta with a dotted border; hovering shows a tooltip, and clicking it takes the reader directly to the Fact-Check tab.

---

## Database & API Integration

To remain compatible with our existing Flask backend and PostgreSQL database, the frontend will connect to the following REST API endpoints served by Flask:

### 1. Database Model Mapping to Frontend
The database columns in `models.py` will map to the frontend JSON structure:

| Database Column (`models.py`) | Frontend Field | Format / Type | Description |
|---|---|---|---|
| `Article.id` | `id` | integer | Unique article identifier |
| `Article.title` | `title` | string | Headline of the dispatch |
| `Article.description` | `summary` | text | Short preview summary |
| `Article.raw_content` | `paragraphs` | list of strings | Extracted text content split by double newlines (`\n\n`) |
| `Article.cover_image_url` | `image` | string | URL of the cover photo |
| `Category.name` (linked) | `category` | string | Category name (e.g. "Khoa học") |
| `Article.published_at` | `date` | string (formatted) | E.g. "27/06/2026" or "14:15" |
| `Article.truth_score` | `confidenceScore` | integer (0-100) | Extracted from `truth_score` (e.g., `0.85` -> `85%`) |
| `Article.ai_summary` | `ai_metadata` | JSON string / object | JSON-serialized dictionary containing takeaways and claims. |

**Structure of `Article.ai_summary` JSON field:**
```json
{
  "readTime": "3 min read",
  "author": "VnExpress Reporter",
  "keyTakeaways": [
    "Key finding 1",
    "Key finding 2"
  ],
  "unverifiedClaim": "The specific assertion extracted from paragraphs",
  "unverifiedClaimAnalysis": "Detailed fact check analysis of the unverified claim"
}
```

### 2. Backend Endpoints (to be implemented in `routes.py`)
- **`GET /api/articles`**: Returns a list of all processed articles with their categories.
- **`POST /api/gemini/summarize`**: Accepts article content and returns an AI-generated summary, key takeaways, and a truth index score using the Gemini API.
- **`POST /api/gemini/factcheck`**: Accepts article content, cross-checks claims, and returns verified vs. unverified statements.
- **`POST /api/gemini/chat`**: Handles conversation messages between the user and the AI assistant regarding the specific article context.

---

## Page Layout & Component Design

The frontend will use a semantic HTML5, Vanilla JavaScript, and Vanilla CSS architecture (residing in `templates/` and `static/`) served directly by the Flask server.

### 1. Color System (Premium Slate & Indigo Theme)
```css
:root {
  --color-primary: #0F172A;              /* Slate 900 */
  --color-on-primary: #FFFFFF;
  --color-primary-container: #F1F5F9;    /* Slate 100 */
  --color-secondary: #4F46E5;            /* Indigo 600 */
  --color-background: #F8FAFC;           /* Slate 50 */
  --color-surface: #FFFFFF;
  --color-terracotta: #EF4444;           /* Red 500 (Warnings/Claims) */
  --font-serif: "Plus Jakarta Sans", "Inter", sans-serif;
  --font-sans: "Inter", sans-serif;
}
```

### 2. Layout Structure

#### A. Global Navigation Header
- Minimalist navigation bar containing the title **TELL ME MORE** in a bold, tracked serif font.
- A home button and category shortcut links.

#### B. Hero Status Banner (Only visible on the Homepage)
- Dark obsidian ribbon (`#1A1A1A`) indicating "Dispatch Network Synchronized" with a subtle geometric dot pattern background.
- Dynamic quote ticker: *"Ask questions, seek context, uncover deeper insights."*

#### C. Two-Column Dashboard (Homepage Feed Mode)
- **Left Column (25% width - Category Bar):**
  - Category list filter (All Dispatches, Số hóa, Khoa học, Thể thao, v.v.).
  - "Trending Dispatches" widget showing titles of top-scoring articles.
- **Right Column (75% width - The Live Feed):**
  - Search box with dynamic filtering of article listings.
  - Interactive grid:
    - First article is the **Lead Article** (spans 2 columns, side-by-side thumbnail and summary layout).
    - Sub-articles rendered as a responsive 2-column grid.

#### D. Interactive Reading Room (Article Detailed Reading Mode)
- **Left Column (65% width - Article Body):**
  - Category tag and read time metadata.
  - Large serif title, author metadata, and a divider line.
  - Featured cover image.
  - Article text split into paragraphs.
  - If the paragraph contains the `unverifiedClaim` string, it is automatically rendered as a warning span with a red dotted bottom border. Hovering displays a popover card; clicking it triggers the **Fact-Check** tab on the right sidebar.
- **Right Column (35% width - Tememo AI Assistant Panel):**
  - **Reliability Circle Gauge**: A SVG radial progress bar mapping the `confidenceScore`.
  - **Segmented Tab Control**: Button group to switch between **Summary**, **Fact-Check**, and **Chat AI**.
  - **Dynamic Tab Panels**:
    - *Summary*: Key bullet points and an outline of "Key Takeaways".
    - *Fact-Check*: Checklist of verified claims vs. red box showing unverified claims and their academic/contextual analysis.
    - *Chat AI*: Simple chat feed allowing users to type questions and receive contextual responses about the article.

---

## Technical Specifications

### Files to be Created/Modified

#### [NEW] [frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css)
- Contains color variables, typography rules, layout configurations (CSS Grid & Flexbox), dot grid backgrounds, meander patterns, animations, and the circular gauge styles.

#### [NEW] [index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html)
- Main Jinja2 index page containing both **Homepage** and **Article Detailed Reading Page** layouts.
- Handles toggling of view visibility via JavaScript to provide a fast SPA feel.
- Includes semantic SEO tags (open graph meta tags, viewport settings, title).

#### [NEW] [frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js)
- Vanilla JS controller:
  - Fetches articles from `/api/articles` on load.
  - Handles client-side search, filtering by category on the **Homepage**, and selecting an article to read.
  - Manages view transitions to show the **Article Detailed Reading Page**.
  - Manages tab state changes and updates SVG circle gauge offsets.
  - Handles AI chat submission, displaying simulated loading bubbles and updating the chat message DOM.

#### [MODIFY] [routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py)
- Setup endpoints:
  - `GET /` -> Render `index.html`.
  - `GET /api/articles` -> Serialize Article DB model instances to JSON.
  - `POST /api/gemini/summarize` -> Return mocked or generated summaries.
  - `POST /api/gemini/factcheck` -> Return mocked or generated fact checks.
  - `POST /api/gemini/chat` -> Handle dialogue prompts.

---

## Success Criteria

- **SC-001**: The homepage loads and renders the grid feed under 300ms.
- **SC-002**: Selecting any article hides the index list and opens the reading page (Article Detailed Reading Page) smoothly with micro-animations.
- **SC-003**: The chat AI interface allows typing questions, displays loading indicators, and pushes clean messages into the dialogue history.
- **SC-004**: Fully responsive layout from mobile screen widths (320px) up to large desktops.
