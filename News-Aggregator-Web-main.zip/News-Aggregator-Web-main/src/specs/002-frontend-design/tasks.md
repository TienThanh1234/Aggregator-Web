# Tasks: Premium Neoclassical News Aggregator Frontend (Tell Me More)

**Input**: Design documents from [spec.md](spec.md) and [plan.md](plan.md)

**Prerequisites**: plan.md (required), spec.md (required)

**Branch**: `002-frontend-design`

**Scope**: This plans focuses on **Homepage** and **Article Detailed Reading page** for News Aggregator Web.

---

## Phase 1: Backend Integration & Route Setup

**Purpose**: Implement the server routes in Flask to serve the static frontend and provide REST API data.

### Implementation Tasks

- [X] T001 Define core view routing in [src/routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py) to serve the main HTML index template.
  - **Acceptance Criteria**: Visiting `GET /` successfully renders the `index.html` template.
- [X] T002 Implement `/api/articles` JSON endpoint in `routes.py`.
  - **Acceptance Criteria**: Returns list of all articles from DB in JSON format, sorted by `published_at` descending, including nested category names.
- [X] T003 Implement `/api/gemini/summarize` JSON endpoint in `routes.py`.
  - **Acceptance Criteria**: Receives post request, extracts/returns JSON metadata payload from `ai_summary` field in database, or generates a placeholder summary if empty.
- [X] T004 Implement `/api/gemini/factcheck` JSON endpoint in `routes.py`.
  - **Acceptance Criteria**: Receives post request, returns lists of verified claims and unverified claims with analysis from `ai_summary`.
- [X] T005 Implement `/api/gemini/chat` JSON endpoint in `routes.py`.
  - **Acceptance Criteria**: Accepts a conversation question message, references the article's body text context, and returns a simulated or actual LLM response.

---

## Phase 2: HTML & CSS Foundation (Trang chủ & Trang đọc chi tiết)

**Purpose**: Establish the semantic HTML structures and CSS layout systems matching the neoclassical premium editorial design guidelines.

### Implementation Tasks

- [X] T006 Create the Jinja2 index page template [src/templates/index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html).
  - **Acceptance Criteria**: Implements clean HTML5 tags (header, nav, main, aside, footer), links custom CSS/JS assets, and includes SEO meta tags.
- [X] T007 Create styling stylesheet [src/static/css/frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).
  - **Acceptance Criteria**: Defines CSS variables (colors, fonts, sizes), meander line ornaments, dot background matrix, and structural grid rules.
- [X] T008 Implement grid layout rules in `frontend.css` for **The Live Feed** (Homepage) and **Category Bar** filters.
  - **Acceptance Criteria**: Homepage dashboard displays correctly on all screen resolutions; layouts wrap cleanly on narrow viewports.
- [X] T009 Implement CSS rules for **Tememo** (AI sidebar panel on the Article page) and the circular truth-index gauge.
  - **Acceptance Criteria**: Truth Index SVG circle path uses stroke-dashoffset transition effects; tab buttons display selected states.

---

## Phase 3: Client-Side Logic & SPA Controller

**Purpose**: Write JavaScript logic to manage views, load article content, handle search/filtering, and orchestrate AI interactions.

### Implementation Tasks

- [x] T010 Create Vanilla JS controller script [src/static/js/frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js).
  - **Acceptance Criteria**: Manages client states: `currentView` (feed vs reader), `selectedArticle`, `selectedCategory`, `searchQuery`, and `dialogHistory`.
- [x] T011 Implement fetch-based data initialization on window load in `frontend.js`.
  - **Acceptance Criteria**: Fetches articles from `/api/articles` and renders cards dynamically into the HTML.
- [x] T012 Implement instant search and category filter event handlers in `frontend.js`.
  - **Acceptance Criteria**: Typing in search box or clicking Category Bar updates visible articles dynamically on the **Homepage**.
- [x] T013 Implement detailed Article Reader view toggle logic in `frontend.js`.
  - **Acceptance Criteria**: Clicking an article card transitions view to **Article Detailed Reading Page**, splits content into paragraphs, and highlights `unverifiedClaim` text in red.
- [x] T014 Implement Tememo tab switching (Summary, Fact-Check, Dialogue) and SVG circle gauge offset update.
  - **Acceptance Criteria**: Clicking tabs reveals matching panels. SVG circle fills to map the article's truth score.
- [x] T015 Implement interactive dialogue submit handling in `frontend.js`.
  - **Acceptance Criteria**: Sends typed chat questions to `/api/gemini/chat`, shows typing indicators, and appends response bubbles into dialogue history.

---

## Phase 4: Verification and Test Coverage

**Purpose**: Test routes, API communication, and responsive layouts to ensure quality and compatibility.

### Implementation Tasks

- [x] T016 Implement automated tests for Flask routes in `routes.py`.
  - **Acceptance Criteria**: Tests prove route endpoints respond with correct HTTP codes and payload schemas.
- [x] T017 Verify responsive layout sizing.
  - **Acceptance Criteria**: Manual developer tools emulation confirms columns wrap correctly on tablet and phone widths for both the **Homepage** and **Article Detailed Reading Page**.
- [x] T018 Confirm search, category filtering, tab toggles, and chat responses function.

---

## Cross-Check Review Checklist

- [x] Reviewer confirms that visiting `GET /` loads the **Homepage** successfully without console errors.
- [x] Reviewer confirms that the Category Bar correctly filters the feed.
- [x] Reviewer confirms that Tememo renders summaries, key takeaways, and conducts fact-checks on the **Article Detailed Reading Page**.
- [x] Reviewer confirms that the truth index gauge SVG transitions to the correct percentage.
- [x] Reviewer confirms that the UI adapts to mobile screen sizes without layout breaks for both target pages.
