# Implementation Plan: Premium Neoclassical News Aggregator Frontend (Tell Me More)

**Branch**: `002-frontend-design` | **Date**: 2026-06-27 | **Spec**: [spec.md](spec.md)

## Summary

This plan outlines the design, creation, and integration of the premium neoclassical editorial user interface for the News Aggregator Web Application. We will build a responsive, single-page-like experience featuring a dynamic newsfeed (**The Live Feed** on the **Trang chủ / Homepage**), category navigation (**Category Bar**), and an interactive AI Assistant panel (**Tememo** on the **Trang đọc chi tiết bài viết / Article Detailed Reading page**) with live truth-index indicators and context dialogue. The frontend will be served directly by Flask using Jinja2 templates, custom Vanilla CSS, and native JavaScript.

---

## Scope & Target Pages
Tài liệu kế hoạch này dành riêng cho việc triển khai hai chế độ xem chính của ứng dụng frontend:
1. **Trang chủ (Homepage - The Live Feed & Category Bar):** Hiển thị luồng tin tức dạng lưới, thanh phân loại danh mục bài báo, bộ tìm kiếm bài viết và danh sách tin nổi bật.
2. **Trang đọc chi tiết bài viết (Article Detailed Reading page & Tememo):** Đọc nội dung bài báo, hiển thị đánh dấu các tuyên bố chưa xác thực trực quan trong văn bản và panel trợ lý AI Tememo (Summary, Fact-Check, Chatbot).

---

## Technical Context

**Language/Version**: Python 3.11+, HTML5, CSS3, ES6+ JavaScript

**Primary Integration Point**: Flask Routing (`routes.py`), SQLAlchemy Models (`models.py`), Static Asset Folder (`static/`), and Templates Folder (`templates/`).

**Dependencies**: Standard Flask, Lucide Icons (CDN), Google Fonts (Inter, Plus Jakarta Sans, Fira Code), and Gemini API integration (optional/mocked for MVP).

---

## Constitution Check

The implementation plan conforms to the constitution in the following ways:
- **Strict MVC Pattern**: Keep routing logic thin in `routes.py`, UI representation in HTML/CSS in `templates/` and `static/`, and business logic (like JSON serialization or prompt compiling) in the services layer.
- **Environment Configuration**: API keys or endpoint routes used for Gemini interaction are fetched from `.env`.
- **No Heavy Frameworks**: Handled via semantic HTML, Vanilla CSS, and Vanilla JS, avoiding heavy frameworks or build setup for maximum lightness.
- **Responsive Layout**: Designed for mobile up to wide desktop viewport support using CSS flexbox and grid layouts.

---

## Proposed Changes

### Component 1 — Routes & API Endpoints

#### [MODIFY] [routes.py](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py)
- Create route `GET /` to render `index.html`.
- Create API route `GET /api/articles` to fetch processed articles from the database, sort by `published_at` descending, and return as JSON.
- Create API route `POST /api/gemini/summarize` to return summary data. If `ai_summary` is populated in the database, return it; otherwise, trigger a lightweight Gemini model query to generate takeaways and summary bullets.
- Create API route `POST /api/gemini/factcheck` to return verified/unverified assertions.
- Create API route `POST /api/gemini/chat` to handle conversations based on article context.

---

### Component 2 — HTML Templates

#### [NEW] [index.html](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html)
- Main template structure served by Jinja2.
- Contains the header section, hero digital banner, main two-column grid wrapper for the **Trang chủ** (Side Category Bar and Main Live Feed), article details reading section for the **Trang đọc chi tiết bài viết**, right Tememo AI sidebar panel, and the meander-patterned footer.
- Imports `frontend.css` and `frontend.js`.
- Automatically implements basic SEO best practices (title, viewport, description meta, favicon).

---

### Component 3 — Static Assets

#### [NEW] [frontend.css](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css)
- Implement custom design tokens (colors, typography, spacing).
- Create meander CSS ornaments and dot matrix grids.
- Implement layout grids for **The Live Feed** (Homepage) and Article Reader.
- Implement SVG circle stroke-dashoffset transition styles for the Truth Index circle gauge.
- Add CSS transitions for smooth hover states, sidebar slide-ins, and loading spinner keyframes.

#### [NEW] [frontend.js](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/frontend.js)
- Build the core JS client:
  - State management for current active view (Homepage vs Reading Page), selected article model, search filter, selected category, and chat dialog history.
  - DOM rendering handlers to populate article cards (dynamic lead card size vs standard cards) on the **Trang chủ**.
  - Search and filter logic that reacts to input events on the **Trang chủ**.
  - Tab selection switching logic in Tememo (Summary, Fact-Check, Dialogue) to swap visible sub-panels on the **Trang đọc chi tiết**.
  - SVG circle path dashboard gauge update logic.
  - Fetch-based communication with `/api/gemini/*` endpoints, updating dialog bubbles with loading states and user input.

---

## Verification Plan

### Automated Tests
- Write Flask testing unit tests to verify that:
  - `GET /` returns `200 OK` and renders HTML.
  - `GET /api/articles` returns valid JSON matching the list structure.
  - API endpoints handle missing IDs gracefully with `404` or proper error codes.

### Manual Verification
- Start the Flask app using:
  ```powershell
  python app.py
  ```
- Visit `http://127.0.0.1:5000` in the browser.
- Verify listing view (the lead card, standard cards, Category Bar, search filtering) on the **Trang chủ**.
- Click an article to enter the Reading Room (**Trang đọc chi tiết**):
  - Verify layout looks premium and matches HSL colors.
  - Verify SVG circle gauge updates to correct truth index score.
  - Click through the tabs: Summary, Fact-Check, and Chat AI.
  - Type a message in the chat box, press Enter, verify the typing indicator is shown, and then a response bubble appears.
- Test mobile view responsiveness in Developer Tools.
