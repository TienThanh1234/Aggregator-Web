# Tasks: Search Functional Group

**Input**: `spec.md`, `plan.md`, and the constitution
**Architecture**: Hybrid MPA

`[P]` marks parallelizable work once dependencies complete.

## Phase 1 — FTS foundation

- [X] T001 [P] Add `Article.search_vector` and documented `SearchLog` to `src/models.py`.
- [X] T002 Create a reversible Alembic migration with `simple` weighted vectors, trigger, GIN index, log indexes, and backfill.

## Phase 2 — Service and contracts

- [X] T004 Create typed/documented validation helpers in `src/services/search_service.py`; normalize whitespace, require a 1–200 character query, and safely handle tsquery operators.
- [X] T005 [P] Implement search-result serialization by reusing Hybrid MPA article-presentation rules: `canonical_path`, `image_alt`, `read_time`, and `confidence_score`.
- [X] T006 Implement FTS, filters, deterministic ordering, bounded pagination, and search-event logging in `search_articles()`.
- [X] T007 [P] Implement 24-hour trends and authenticated recent-search retrieval.
- [X] T008 Add thin `GET /api/search` and `GET /api/search/trending` routes; map validation errors to 400 and keep SQL out of routes.

## Phase 3 — Server-rendered search journey

- [X] T009 Add `GET /search` (`search_page`) and render a stable, shareable result URL.
- [X] T010 Add global GET form in `src/templates/base.html` with `action=url_for('main.search_page')`, input `q`, accessible label, and `maxlength="200"`.
- [X] T011 Create `src/templates/search.html` with filters, result count, cards, empty/error states, and state-preserving pagination.
- [X] T012 Reuse or safely extend `_article_card.html` so every search result links to the canonical article page.
- [X] T013 Add token-based search styles and mobile/focus/error states.

**Checkpoint**: `/search?q=<term>` works after direct load, refresh, copied URL, and with JavaScript disabled.

## Phase 4 — Progressive enhancement and verification

- [X] T014 Add `src/static/js/search.js` for Cmd/Ctrl+K focus and trend/recent dropdowns; selecting a term uses the normal GET search URL.
- [X] T015 [P] Add HTML route tests for direct `/search`, escaped output, filter-state preservation, pagination, and canonical article links.

## Dependencies

```text
T001 + T002 -> T004 + T005 -> T006 + T007 -> T008
                                        -> T009 -> T010 + T011 + T012 + T013
                                        -> T014
T008 + T009..T014 -> T015
```
