# Feature Specification: Search Functional Group

**Feature Branch**: `005-search-functionality`
**Created**: 2026-07-29
**Updated**: 2026-07-31
**Status**: Ready for implementation
**Spec ID**: `SEARCH-001`

## 1. Scope

Search is a Hybrid MPA feature. A submitted query renders a shareable, server-delivered Search Engine Results Page (SERP); JavaScript may enhance that page but is not required to read results, change filters, or paginate.

The feature provides a global search form in the shared header, `GET /search` HTML results, optional `GET /api/search` and `GET /api/search/trending` APIs, PostgreSQL full-text search, search-history logging, and 24-hour trending keywords.

### Goals

- A reader can open, refresh, bookmark, or share `/search?q=<query>` without previous navigation.
- The delivered SERP remains usable with JavaScript disabled.
- Result cards link to canonical `GET /articles/<article_id>` pages.
- Search reuses Hybrid MPA presentation conventions and Neoclassical design tokens.

### Non-goals

- A client-side SPA view or history-state routing.
- Type-ahead/autocomplete, saved-search alerts, semantic search, or an external search engine.
- Bookmark toggling until a supported bookmark service and endpoint exist; `is_bookmarked` may be exposed when that dependency is available.

## 2. Hybrid MPA Architecture

| Concern | Required implementation |
| --- | --- |
| Global header | Add a `method="get"` form targeting `url_for('main.search_page')` in `templates/base.html`. The input name is `q`, has `maxlength="200"`, and keeps its value only on the SERP. |
| SERP route | `GET /search` reads query parameters, delegates to `services/search_service.py`, and renders `templates/search.html`. |
| Filters and pagination | Standard GET form controls and anchors. Every navigation preserves `q`, `category`, `source`, `time`, `sort`, and `page` as applicable. |
| Results | Reuse or extend `templates/partials/_article_card.html`; every card links to `main.article_page`. |
| Optional JavaScript | `static/js/search.js` may load trends and enhance UI feedback. It must never be the only rendering or navigation path. |
| Shared behavior | `static/js/core.js` remains responsible for authentication UI, toasts, and shared header behavior. |

The legacy SPA containers, `static/js/frontend.js`, `showSearchView()`, and `history.pushState()` are not part of this feature.

## 3. Data Model

### 3.1 `articles.search_vector`

Add a nullable PostgreSQL `TSVECTOR` column. A migration creates a trigger that assigns weighted vectors from `title` (A), `description` (B), and `raw_content` (C), backfills existing rows, and creates `idx_articles_search_vector` as a GIN index.

Use `to_tsvector('simple', ...)` and `plainto_tsquery('simple', ...)` consistently. This supports Unicode Vietnamese tokens but does **not** provide accent-insensitive search. Accent-insensitive matching requires a separately approved `unaccent` extension and index design.

### 3.2 `search_logs`

| Column | Requirements |
| --- | --- |
| `id` | Integer primary key |
| `keyword` | Lowercased normalized query, `VARCHAR(255)`, non-null |
| `user_id` | Nullable foreign key to `users.id` |
| `results_count` | Non-null integer, default `0` |
| `searched_at` | UTC timestamp, non-null |

Create indexes on `searched_at DESC`, `keyword`, and `(user_id, searched_at DESC)`.

## 4. Contracts

### 4.1 `GET /search`

| Parameter | Default | Validation |
| --- | --- | --- |
| `q` | — | Required after trimming; 1–200 characters |
| `category` | `all` | `all` or an available public category |
| `source` | `all` | `all` or a bounded source value |
| `time` | `all` | `24h`, `7d`, `30d`, `all` |
| `sort` | `relevant` | `relevant`, `newest`, `oldest` |
| `page` | `1` | positive integer |
| `per_page` | `10` | integer from 1 to 50 |

A valid request returns `200` and renders `search.html`. Missing/invalid query renders a clear inline validation state without results. Invalid filter values return `400`. Routes remain thin and contain no SQL.

### 4.2 `GET /api/search`

The endpoint accepts the same parameters and returns a `status`, `data.articles`, `data.pagination`, `data.query`, and `data.filters_applied` envelope for progressive enhancement or future clients.

Each result uses Hybrid MPA presentation fields: `id`, `title`, `summary`, `image`, `image_alt`, `category`, `author`, `date`, `read_time`, `confidence_score`, and `canonical_path`, plus `relevance_score`. Images follow existing proxy behavior. `is_bookmarked` is optional until bookmark support exists.

### 4.3 `GET /api/search/trending`

Returns up to ten keywords ordered by the prior 24 hours of `search_logs`, plus up to five deduplicated recent terms for an authenticated user. Guests receive an empty `recent_searches` list. Trend failure must not stop ordinary HTML search.

## 5. Responsibilities

- `services/search_service.py`: validation, query construction, filters, ordering, pagination, serialization, logging, and trends.
- `services/article_service.py`: source of existing public article/card presentation rules; do not duplicate that mapping.
- `routes.py`: `search_page`, `api_search`, and `api_search_trending`; reads HTTP input and maps validation errors to 400.
- Templates render supplied data only. Query output uses Jinja autoescaping; optional JavaScript uses `textContent`.

## 6. User Journeys

### Execute and share a search

Submitting the header form opens `/search?q=<encoded-term>`. The server renders matching cards and state-preserving pagination; refresh, copied URLs, browser navigation, and JavaScript-disabled browsing retain context.

### Filter and paginate

Changing a filter issues a GET request with active values and resets `page=1`. Previous/Next links preserve complete state.

### Trends and recent history

Optional client code requests trends only when an empty header input gains focus. Selecting a term navigates through the same GET search URL. A trend failure leaves ordinary search usable.

## 7. Security, Performance, and Testing

- Normalize whitespace, enforce a 200-character limit, and use parameterized SQLAlchemy expressions; never interpolate query input into raw SQL or HTML.
- Highlighting, if added, must operate on safe DOM text rather than injected HTML.
- Migration, backfill, trigger, and GIN index are release blockers. Verify a representative FTS query uses the GIN index and p95 is below 500 ms.
- Tests cover FTS ranking, validation, filters, pagination, logging, trends, direct `/search` access, refreshable URLs, filter-state preservation, canonical links, and JavaScript-disabled HTML behavior. PostgreSQL-specific FTS tests run against PostgreSQL.
