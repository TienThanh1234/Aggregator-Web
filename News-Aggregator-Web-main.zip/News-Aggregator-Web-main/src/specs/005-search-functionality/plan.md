# Implementation Plan: Search Functional Group

**Architecture**: Hybrid MPA
**Updated**: 2026-07-31

## Summary

Implement PostgreSQL full-text article search as a server-rendered, addressable experience. The primary reader journey is `GET /search?q=...`; JSON endpoints and `static/js/search.js` are optional enhancements, never a replacement for HTML delivery.

## Technical Context

- **Backend**: Flask, Flask-SQLAlchemy, PostgreSQL, Alembic.
- **Presentation**: Jinja templates with `base.html`, `index.html`, `article.html`, and reusable article-card partials.
- **Client code**: Vanilla JavaScript. `core.js` owns shared auth/toast behavior; search-specific enhancement is isolated in `search.js`.
- **Tests**: pytest against PostgreSQL, plus route/template tests and manual no-JS verification.

## Constitution Check

- Controllers delegate query and serialization work to `services/search_service.py`.
- Templates receive display-ready data and do not build queries.
- Existing article presentation mapping in `services/article_service.py` is reused for consistent cards and canonical links.
- No JavaScript feature is required to submit, filter, paginate, or open a result.

## Project Structure

```text
src/
├── models.py
├── routes.py
├── services/search_service.py
├── migrations/versions/<revision>_add_search_fts.py
├── templates/base.html
├── templates/search.html
├── templates/partials/_article_card.html
├── static/css/frontend.css
├── static/js/search.js
└── tests/test_search.py
```

## Implementation Phases

### 1. Schema and shared service

Add the FTS model/schema, reversible PostgreSQL migration using `simple`, typed validation, safe queries, filters, sorting, pagination, logging, and trend aggregation. Reuse/centralize Hybrid MPA presentation fields rather than `/api/articles` legacy serialization.

### 2. HTML-first routes and templates

Add `GET /search`, a global GET form in `base.html`, and `search.html` with accessible filters, reusable cards, empty/error states, and query-preserving pagination. Each card uses `url_for('main.article_page', article_id=...)`.

### 3. Optional APIs and enhancement

Add thin JSON routes and `search.js` only for trends, recent terms, Cmd/Ctrl+K, and safe visual enhancement. Do not reintroduce SPA containers or `frontend.js`.

### 4. Test and release

Verify migration upgrade/downgrade and indexes, write PostgreSQL service/API/HTML route tests, exercise direct load and no-JS paths, then inspect GIN query plans and representative response times.

## Dependency Decision

Bookmark toggling is excluded until a supported MPA bookmark service/route contract exists. `is_bookmarked` may be introduced only with that explicitly scoped dependency.
