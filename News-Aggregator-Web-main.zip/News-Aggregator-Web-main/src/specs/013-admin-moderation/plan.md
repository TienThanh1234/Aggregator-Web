# Implementation Plan: Community Moderation

**Branch**: `013-admin-moderation` | **Date**: 2026-08-22 | **Spec**: [spec.md](spec.md)

**Implementation status**: Completed in code and migrated to the configured Supabase database on 2026-08-22. Manual responsive UI smoke verification remains a release checklist item.

## Summary

Implement an admin-only Community Moderation workspace for comments and report handling. Readers will be able to report visible comments. Before persistence, every new comment is checked against an admin-managed prohibited-word/phrase list. Administrators will be able to search/filter a bounded moderation queue, manage prohibited terms, inspect safe filter activity and author/article/reaction context, hide or restore comments, permanently delete only after confirmation, dismiss reports, and navigate to existing user-ban controls.

The implementation reuses Flask, SQLAlchemy, `AdminAuditLog`, the existing authentication/admin guards, and the Admin Dashboard's vanilla-JavaScript tab pattern. Public comment serialization will be updated so a hidden comment is excluded before counts and pagination are calculated.

## Technical Context

**Language/Version**: Python 3.11+, JavaScript ES6+, HTML5/CSS3  
**Primary Dependencies**: Flask, Flask-SQLAlchemy, Alembic/Flask-Migrate, Jinja2, vanilla JavaScript  
**Storage**: PostgreSQL/Supabase in production; SQLite-compatible test schema  
**Testing**: Python `unittest` suite executed through `venv\Scripts\python -m unittest`  
**Target Platform**: Responsive Flask web application on desktop and mobile browsers  
**Project Type**: Existing single-project server-rendered web application  
**Performance Goals**: First 50-row moderation queue page under 500 ms p95 excluding database contention; public comment suppression on the next request  
**Constraints**: Existing MVC boundaries; deterministic prohibited-term matching only (no LLM/toxicity classifier); all mutating admin actions must be atomic and auditable; no reporter identity in public responses; rejected comment text must never be persisted  
**Scale/Scope**: One new admin dashboard tab, public report/filter control, four new persistent moderation entities, extended `Comment`, and protected API endpoints

## Constitution Check

| Gate | Status | Plan response |
|---|---|---|
| Strict MVC | Pass | Models remain in `models.py`; queries/mutations live in a dedicated `services/moderation_service.py`; `routes.py` only authenticates, validates request shape, and returns responses. |
| Database migrations | Pass | One Alembic migration adds comment moderation columns, report/action tables, constraints, and indexes. |
| Data integrity | Pass | Use foreign keys, server-side state transitions, one-report-per-user/comment constraint, and one transaction for comment/report/action/audit mutations. |
| Security/no secrets | Pass | Reuse existing session guards; no new environment variables or external services. |
| Testing | Pass | Add service and route tests using existing Flask/SQLite test patterns; do not depend on live services. |
| UI isolation | Pass | Extend existing `admin.html` and `admin.js`; use escaped text rendering and existing confirmation/toast behavior. |

No constitution exception or additional project structure is required.

## Existing Code Integration Points

| Area | Existing responsibility | Change |
|---|---|---|
| `models.py` | `Comment`, `Reaction`, `AdminAuditLog` | Extend comment visibility/moderation metadata; add report and moderation-action models/relations. |
| `services/comment_service.py` | Public comment creation/listing and reactions | Enforce public visibility and call prohibited-term validation before creating a comment; add report submission wrapper or delegate it to moderation service. |
| `services/dashboard_service.py` | User activity lists and self-delete | Exclude hidden comments; close related reports safely on self-delete. |
| `services/admin_service.py` | Existing admin content/user actions | Keep user-ban logic here; share only its audit helper if it can be safely extracted. |
| `services/moderation_service.py` | New | Own prohibited-term matching, validation, queue querying, report state changes, comment actions, reaction context, filter events, and audit writes. |
| `routes.py` | Thin controllers | Add public report endpoint and admin moderation endpoints behind `_get_admin_user()`. |
| `templates/article.html` / `static/js/article.js` | Article discussion UI | Add report control per comment for authenticated readers and refresh the list after successful submission. |
| `templates/admin.html` / `static/js/admin.js` | Admin Dashboard | Add Community Moderation tab, badge, filters, queue, context dialog, action confirmations, and state refresh. |
| `migrations/versions/` | Schema history | Add a single forward/reversible migration. |
| `tests/` | Unit and route coverage | Add moderation service/route tests and extend comment/dashboard behavior tests. |

## Data Model and Migration Design

### `comments` extension

Keep existing `is_deleted` semantics for user self-deletion/permanent removal. Add:

| Column | Type | Default | Purpose |
|---|---|---:|---|
| `is_hidden` | Boolean, indexed | `false` | Reversible administrative public suppression. |
| `moderation_reason` | String(50), nullable | — | Standardized hide/delete reason. |
| `moderation_note` | Text, nullable | — | Optional internal note; never serialized publicly. |
| `moderated_by_id` | FK `users.id`, nullable | — | Most recent acting moderator. |
| `moderated_at` | DateTime, nullable/indexed | — | Most recent visibility-state change. |

Public visibility predicate: `Comment.is_deleted IS false AND Comment.is_hidden IS false`.

### `comment_reports`

| Column | Type | Constraint / purpose |
|---|---|---|
| `id` | Integer PK | — |
| `comment_id` | FK `comments.id` | indexed; delete with comment |
| `reporter_id` | FK `users.id` | indexed; private to moderation flow |
| `reason` | String(50) | one of defined report reasons |
| `explanation` | Text, nullable | required only for `other`, length-limited |
| `status` | String(20) | `open`, `resolved`, or `dismissed`; indexed |
| `resolution_action_id` | FK `comment_moderation_actions.id`, nullable | connects report outcome to decision |
| `created_at`, `resolved_at` | DateTime | timing/audit fields |

Use a database unique constraint on `(comment_id, reporter_id)`. Reports are never recreated after a dismissed/resolved one in v1; re-reporting returns the existing report idempotently. This is stricter than “one active report” but prevents repeated-report inflation and is simpler/auditable.

### `comment_moderation_actions`

| Column | Type | Purpose |
|---|---|---|
| `id` | Integer PK | Decision identifier |
| `comment_id` | FK `comments.id` | Moderated target |
| `admin_id` | FK `users.id` | Acting admin |
| `action` | String(30), indexed | `hide`, `restore`, `delete`, `dismiss_report` |
| `reason` | String(100) | Required decision reason |
| `note` | Text, nullable | Internal context |
| `created_at` | DateTime, indexed | Audit timeline |

Add query-supporting indexes for comment public/moderation state and report status/reason/created time. The migration's downgrade drops the new relations/indexes before comment fields.

### `comment_prohibited_terms` and `comment_filter_events`

`comment_prohibited_terms` stores an admin-managed `display_term`, unique normalized `normalized_term`, optional safe category label, `is_active`, creator/updater IDs, and timestamps. Normalization is implemented once in `moderation_service.py`: Unicode normalization, case folding, whitespace collapse, and punctuation-to-boundary treatment. The service distinguishes a single-token rule (word-boundary match) from a multi-token phrase (contiguous normalized phrase match).

`comment_filter_events` stores only the actor user ID, article ID, matched rule ID, outcome, and timestamp. It deliberately has **no comment-body, hash, or explanation field**. It supports limited admin investigation without retaining rejected user text.

## API Plan

### Public API

`POST /api/comments/<comment_id>/reports`

- Requires the current active authenticated user.
- Request JSON: `{ "reason": "spam", "explanation": "optional except for other" }`.
- Validate visible/non-deleted target and allowed reason. Reject self-reporting with `400`.
- Return `201` with a minimal acknowledgement for a new report; return `200` with the same acknowledgement when already reported.
- Never return reporter IDs, internal notes, or report lists.
- `create_comment()` calls `evaluate_prohibited_terms(content)` before making a `Comment`. A match writes one `CommentFilterEvent`, commits the event, and returns a generic `400`; no comment is created. The response never identifies the matching term.

### Admin APIs

All endpoints call `_get_admin_user()` first.

| Endpoint | Service operation | Validation and result |
|---|---|---|
| `GET /api/admin/moderation/summary` | `get_moderation_summary` | Open-report count for the tab badge. |
| `GET /api/admin/moderation/comments` | `get_moderation_comments` | Bounded `q`, filters, page/per-page; redacted reporter detail by default. |
| `GET /api/admin/moderation/comments/<id>` | `get_moderation_comment_detail` | Full admin context, action timeline, aggregated report/reaction context. |
| `POST /api/admin/moderation/comments/<id>/hide` | `hide_comment` | Required reason, optional note; idempotent. |
| `POST /api/admin/moderation/comments/<id>/restore` | `restore_comment` | Required reason, optional note; `409` for permanently deleted targets. |
| `DELETE /api/admin/moderation/comments/<id>` | `delete_comment_permanently` | Body must include `confirmed: true` and a reason. |
| `POST /api/admin/moderation/reports/<id>/dismiss` | `dismiss_report` | Required reason; returns `409` unless report is open. |
| `GET/POST /api/admin/moderation/prohibited-terms` | `list_prohibited_terms` / `create_prohibited_term` | Bounded admin list and validated rule creation. |
| `PATCH/DELETE /api/admin/moderation/prohibited-terms/<id>` | `update_prohibited_term` / `delete_prohibited_term` | Active-state change or deletion, both auditable. |
| `GET /api/admin/moderation/filter-events` | `get_filter_events` | Admin-only bounded activity metadata; never returns blocked text. |

Admin list/detail serializers can include author identity and report aggregate/reason data, but only the minimal reporter data needed for operational abuse review. All public serializers remain unchanged except visibility filtering.

## Implementation Phases

### Phase 1 — Schema and shared moderation primitives

1. Add comment moderation fields and new `CommentReport`, `CommentModerationAction`, `CommentProhibitedTerm`, and `CommentFilterEvent` models, relationships, constraints, and model docstrings.
2. Generate the Alembic migration; inspect its upgrade/downgrade against PostgreSQL and SQLite compatibility.
3. Create `services/moderation_service.py` with constants for report reasons/status/actions, prohibited-term normalization/matching, pagination validation, safe serializers, an audit helper, and transaction/error handling.
4. Add public visibility predicate/helper used by all comment read paths.
5. Unit-test model constraints, prohibited-term normalization/boundaries, and core validation helpers.

**Exit condition**: migration applies cleanly, no existing comment API exposes an `is_hidden` comment, and a prohibited-term match can be detected without persisting submitted text.

### Phase 2 — Reader reporting and public suppression

1. Implement idempotent report creation with reason/explanation validation, target visibility checks, self-report prevention, and a minimal response.
2. Integrate `evaluate_prohibited_terms()` into `create_comment()` before `Comment` instantiation. Persist only a safe `CommentFilterEvent` on match and fail closed if the filter cannot evaluate safely.
3. Add the report route in `routes.py` using the existing authentication/JSON helpers.
4. Update `get_article_comments()` to filter visible comments before totals/pagination.
5. Update `get_user_comments()` and `delete_user_comment()` so dashboard results suppress hidden comments and self-deletion closes open reports transactionally without deleting audit history.
6. Add Report control, report-reason dialog/form, confirmation state, and error feedback in the article discussion UI; guests receive the existing login prompt rather than a report request.
7. Cover public report route authorization, idempotency, invalid reason, hidden/missing target, filter match/non-match/inactive rule, no-comment persistence, counts, and self-delete interactions in tests.

**Exit condition**: a report can be submitted once, prohibited comment content is rejected before persistence, and a hidden comment is absent from article and dashboard lists/counts.

### Phase 3 — Admin moderation service and protected routes

1. Implement the moderation queue query with joins/eager loading, escaped excerpts, combined filters, pagination, report aggregation, and author’s recent-hidden count.
2. Implement detail/context query with comment history, article summary/link, report totals/reasons, and reaction aggregates plus a bounded recent reaction list.
3. Implement atomic `hide_comment`, `restore_comment`, `delete_comment_permanently`, and `dismiss_report` mutations. Each writes `CommentModerationAction` and `AdminAuditLog`; hide/delete resolve all open reports.
4. Add admin routes with response/status contracts and no raw ORM serialization.
5. Implement prohibited-term CRUD and filter-event query service operations, including configuration audit actions.
6. Add their protected routes and test authorization, normalization uniqueness, active/inactive behavior, safe event serialization, and deleted-rule handling.
7. Test authorization, valid transitions, idempotent hide/restore behavior, deletion confirmation, report resolution/dismissal, audit rows, and rollback on forced failure.

**Exit condition**: every specified moderation mutation is admin-only, consistent, and auditable.

### Phase 4 — Admin Dashboard workspace

1. Add a **Community Moderation** navigation item and dynamic open-report badge to `admin.html`.
2. Add queue filter controls, paginated result table/cards, safe text rendering, empty/loading/error states, and report status badges to `admin.js`.
3. Add an accessible detail dialog/drawer with article/author context, report breakdown, reaction aggregate, action history, and action buttons.
4. Add a **Prohibited Terms** sub-panel with validated create form, activate/deactivate/delete actions, plus a bounded filter-event activity list that never displays rejected text.
5. Reuse the existing confirmation modal pattern for hide, restore, delete, dismiss, and prohibited-rule deletion; require reason and show irreversible-delete wording.
6. On successful mutation, refresh summary, queue, terms, filter events, and open detail without reloading the page; link author context to existing User Management.
7. Add responsive CSS only where current admin styles cannot support the new content safely.

**Exit condition**: an admin can complete report review, hide/restore, and report dismissal entirely through the dashboard.

### Phase 5 — Verification and rollout safeguards

1. Run focused tests plus the full existing unit suite in the project virtual environment.
2. Run `compileall` on changed Python modules and `git diff --check`.
3. Apply the migration to a non-production/test database first; inspect backward compatibility for existing comments.
4. Perform manual role-based smoke tests: guest, normal user, banned user, and admin; verify public APIs never reveal hidden comments, private report data, prohibited terms, or rejected comment text.
5. Verify prohibited word/phrase matching with case, Vietnamese accents, punctuation, whitespace, false-positive boundaries, and inactive rules.
6. Verify pagination, combined filters, destructive-action confirmation, error states, and mobile dashboard layout.
7. Document migration name, endpoint contracts, filter behavior, and moderator workflow in the feature quickstart/release notes if the team elects to create them during implementation.

## Test Strategy

| Layer | Tests |
|---|---|
| Service unit | Reason/length validation, report idempotency, term normalization/boundaries, inactive-rule behavior, no-comment persistence, safe filter events, visibility predicate, queue filters, aggregation, transitions, audit helper, transaction rollback. |
| Route | Authentication/authorization, response schema/status codes, malformed JSON, pagination caps, permanent-delete confirmation, prohibited-term CRUD. |
| Regression | Existing comments/reactions, dashboard comment activity, user self-delete, admin dashboard routes, user ban flow. |
| Manual | Public report/filter UX, suppression in article UI, admin queue/detail actions, prohibited-term configuration, restore, reaction context, responsive layout. |

Suggested focused commands:

```powershell
venv\Scripts\python -m unittest tests.test_moderation_service tests.test_moderation_routes tests.test_routes tests.test_dashboard
venv\Scripts\python -m compileall -q models.py routes.py services\comment_service.py services\dashboard_service.py services\moderation_service.py
git diff --check
```

## Project Structure

```text
src/
├── models.py
├── routes.py
├── migrations/versions/
│   └── <revision>_admin_moderation.py
├── services/
│   ├── comment_service.py
│   ├── dashboard_service.py
│   ├── admin_service.py
│   └── moderation_service.py
├── templates/
│   ├── admin.html
│   └── article.html
├── static/
│   ├── js/admin.js
│   ├── js/article.js
│   └── css/frontend.css
├── tests/
│   ├── test_moderation_service.py
│   └── test_moderation_routes.py
└── specs/013-admin-moderation/
    ├── spec.md
    ├── plan.md
    └── tasks.md                 # Created by /speckit.tasks
```

**Structure Decision**: Extend the current Flask monolith; no new application, frontend framework, background worker, external service, or environment configuration is needed.
