# Feature Specification: Admin Moderation for Community Interaction

**Feature Branch**: `013-admin-moderation`  
**Created**: 2026-08-22  
**Status**: Implemented  
**Target Specification Location**: `src/specs/013-admin-moderation/spec.md`  
**Constitution Authority**: [constitution.md](../../.specify/memory/constitution.md)

---

## 1. Purpose and Scope

This feature gives administrators a dedicated **Community Moderation** workspace for keeping article discussions constructive and safe. Administrators can configure automatic prohibited-term filtering, find comments and reactions, review reports, hide or restore inappropriate comments, remove abusive comments when necessary, and apply an account sanction through the existing user-management flow.

The feature extends the existing Admin Dashboard. It does not change public article content, alter another user's profile, or make an automated decision about whether a comment is abusive.

### Goals

- Give admins one searchable queue for public comments, reports, and reaction activity.
- Suppress a moderated comment immediately from public article pages while preserving an auditable record.
- Let an admin restore a hidden comment when the decision is reversed.
- Let readers report a comment without exposing reporter identity to the author or public.
- Prevent a new comment containing an administrator-configured prohibited word or phrase from being published.
- Let admins manage prohibited terms without a deployment and audit each configuration change.
- Record every moderation decision with the acting admin, target, reason, timestamp, and optional note.
- Provide context and a safe hand-off to the existing ban/unban controls when an author repeatedly violates rules.

### Non-goals

- Automated toxicity classification, LLM moderation, automatic deletion of already published comments, or automatic bans.
- Editing a user's comment on their behalf.
- Private messages, threaded replies, user blocking, or social-network sharing.
- Removing an article reaction solely because it is a Like or Dislike; reaction moderation is for inspection and abuse investigation only in v1.
- Replacing the existing Article Content Cleanup or User Ban dashboard.

## 2. Definitions

| Term | Meaning |
|---|---|
| Public comment | A comment that is visible beneath an article to a normal visitor. |
| Hidden comment | A comment retained for moderation/audit purposes but excluded from public article and dashboard views. |
| Report | A reader-submitted flag identifying a comment and a standardized reason. |
| Open report | A report not yet resolved, dismissed, or made obsolete by a moderation action. |
| Moderation action | `hide`, `restore`, `delete`, `dismiss_report`, or a linked account sanction. |
| Reaction activity | Existing Like/Dislike records shown to admins for context; it remains publicly aggregated rather than individually exposed to readers. |
| Prohibited term | A normalized word or phrase maintained by an administrator. A new comment containing it is rejected before persistence and public display. |
| Filter event | An audit-safe record that a comment submission was blocked, without retaining the rejected comment body. |

## 3. User Stories and Acceptance Scenarios

### User Story 1 — Review and act on reported comments (P1)

**As an** administrator,  
**I want** to open a queue of reported comments with article and author context,  
**so that** I can remove harmful discussion promptly and consistently.

**Why this priority**: A report queue and a reversible public-hide action are the minimum useful moderation workflow.

**Independent Test**: Create a comment, submit a report as another authenticated user, then sign in as admin. The admin can filter the open report, review the comment in context, hide it, and verify that it disappears from the public article page.

**Acceptance Scenarios**:

1. **Given** an authenticated reader views a public comment, **When** they submit one allowed report reason, **Then** the system creates one report for that reader/comment pair and confirms receipt without exposing the reporter to the comment author.
2. **Given** an admin opens Community Moderation, **When** open reports exist, **Then** each row shows the report reason, reported comment excerpt, article title/link, author identity, report count, and oldest open-report time.
3. **Given** an admin reviews an inappropriate comment, **When** they choose **Hide comment** and enter a reason, **Then** the comment becomes hidden, all unresolved reports for it become resolved, the comment disappears from public discussion results immediately, and an audit record is written.
4. **Given** a comment has already been hidden, **When** a normal user requests the article comments endpoint or reloads the article page, **Then** the hidden comment is not returned or counted.
5. **Given** the same reader has already reported a comment, **When** they report it again, **Then** the system returns a safe idempotent result and does not create a duplicate report.

---

### User Story 2 — Search, filter, and restore community content (P1)

**As an** administrator,  
**I want** to search and filter all community comments by status, reason, author, and article,  
**so that** I can proactively moderate content and correct mistaken decisions.

**Why this priority**: Reports alone miss abusive content that has not been reported and a hide action must be reversible.

**Independent Test**: An admin searches for an author or article, filters to hidden comments, restores one, and confirms it reappears publicly with its original text and timestamp.

**Acceptance Scenarios**:

1. **Given** an admin enters a text query, **When** it matches a comment, author name, email, or article title, **Then** the moderation list returns matching records only and paginates the results.
2. **Given** an admin applies status filters (`visible`, `hidden`, `reported`, `resolved`) or a report-reason filter, **When** the list reloads, **Then** all filters are applied together without exposing private report data to non-admin users.
3. **Given** a hidden comment was moderated in error, **When** an admin chooses **Restore comment** and provides a reason, **Then** the comment returns to public discussion, prior reports remain historically resolved, and a restore audit record is written.
4. **Given** an admin determines a comment must not be retained, **When** they choose **Delete permanently** and confirm the irreversible action, **Then** the comment and its reports are removed according to the retention policy and the audit record retains only non-sensitive target metadata.
5. **Given** a comment author has several recent hidden comments, **When** an admin opens that author from the moderation row, **Then** the UI presents the count and a link to the existing user ban/unban control; no automatic ban is performed.

---

### User Story 3 — Inspect reaction activity without breaking privacy (P2)

**As an** administrator,  
**I want** to inspect reaction totals and unusual concentrated activity alongside comments,  
**so that** I can investigate potential manipulation without publishing individual reactions.

**Why this priority**: Reactions provide useful context, but removing a reaction is less urgent than handling harmful public text.

**Independent Test**: Seed likes/dislikes for an article, open its moderation context, and verify that admins see aggregate totals and a bounded recent-activity view while ordinary readers continue to see only existing public aggregate counts.

**Acceptance Scenarios**:

1. **Given** an admin opens an article's moderation context, **When** reactions exist, **Then** the dashboard displays Like/Dislike totals and a bounded recent activity summary.
2. **Given** an admin filters reaction activity by article or author, **When** results are displayed, **Then** the dashboard requires admin authorization and does not make individual reaction history available through public APIs.
3. **Given** an admin finds no policy violation, **When** they close the activity view, **Then** no reaction or comment is changed and no moderation action is recorded.

---

### User Story 4 — Automatically block prohibited terms (P1)

**As an** administrator,  
**I want** to maintain a prohibited-word list that is applied before a comment is published,  
**so that** obvious abusive or spam comments never become visible while human moderators retain control of borderline cases.

**Why this priority**: Pre-publication filtering reduces exposure to clearly prohibited language and reduces the volume that requires manual review.

**Independent Test**: An admin adds a prohibited word, then a normal user attempts to post a comment containing that word with different capitalization and surrounding punctuation. The request is rejected, no `Comment` record is created, and the attempt is visible only as a safe filter event to admins.

**Acceptance Scenarios**:

1. **Given** an admin adds an active prohibited term, **When** a user submits a comment whose normalized text contains that whole word or phrase, **Then** the API rejects the submission with `400`, no public comment is persisted, and the user receives a generic policy message without being told which term matched.
2. **Given** a prohibited term contains uppercase/lowercase differences, Unicode accents, repeated whitespace, or punctuation around it, **When** a user submits an equivalent normalized match, **Then** the filter blocks it consistently.
3. **Given** an admin deactivates or deletes a prohibited term, **When** a later comment contains only that term, **Then** the filter no longer blocks the comment and the earlier configuration change is retained in the audit trail.
4. **Given** a term appears only as part of a longer unrelated word, **When** word-boundary matching is applicable, **Then** the filter does not block the comment; phrases continue to match as normalized contiguous phrases.
5. **Given** the automatic filter blocks a submission, **When** an admin views filter activity, **Then** they can see time, submitting account, matched rule ID/category, and article context, but not the rejected comment body.

## 4. Edge Cases

- A deleted or hidden article must not expose its comments through public APIs, regardless of comment status.
- A report submitted while its comment is being hidden must resolve atomically or fail safely without a dangling open report.
- A comment deleted by its author or permanently deleted by an admin must not be restorable and must return `404` to later moderation actions.
- A banned, inactive, or deleted user cannot submit a new comment or report, but their existing comments remain available to authorized moderators as permitted by retention rules.
- If an admin tries to hide/restore the same comment twice, the second request is idempotent and does not create a duplicate audit entry.
- Lists and exports must escape user-provided comment text; no moderation UI may render it as HTML.
- If an admin's session expires during an action, no moderation change is committed and the API returns `401`/`403`.
- A filter configuration term must be normalized, non-empty, and limited in length; duplicate normalized terms cannot be created.
- The prohibited-term filter is evaluated before creating a `Comment`; a filter outage or configuration error must fail closed for comment submission and be logged without the submitted text.

## 5. Requirements

### Functional Requirements

- **FR-001**: All Community Moderation pages and `/api/admin/moderation/*` endpoints MUST require the existing admin authorization guard and return `403` for non-admin authenticated accounts.
- **FR-002**: Authenticated active users MUST be able to report a visible public comment with exactly one reason from: `spam`, `harassment`, `hate_or_abuse`, `misinformation`, `off_topic`, or `other`; `other` requires a short explanation.
- **FR-003**: The system MUST allow at most one active report per reporter and comment. Re-reporting the same comment MUST be idempotent.
- **FR-004**: The system MUST provide an admin moderation list with pagination, full-text-style query matching, and combined filters for comment visibility, report state, report reason, author, and article.
- **FR-005**: The system MUST display sufficient context for an admin to decide: comment text, creation time, article title/link, author identity/status, report count/reasons, and current moderation state.
- **FR-006**: An admin MUST be able to hide a visible comment with a required moderation reason. Hidden comments MUST be excluded from every public comment list, public comment count, and user dashboard activity list.
- **FR-007**: An admin MUST be able to restore a hidden, non-deleted comment with a required reason. Restoration MUST not reopen earlier reports automatically.
- **FR-008**: Permanent deletion MUST require an explicit confirmation and a required reason. It MUST remove the comment from all user-visible and admin active lists while retaining a minimal immutable audit entry.
- **FR-009**: Hiding, restoring, deleting, resolving a report, or dismissing a report MUST create an `AdminAuditLog` record with admin ID, action, target type/ID, timestamp, reason, and optional note. Audit records MUST NOT contain raw reporter identity in public-facing responses.
- **FR-010**: When a comment is hidden or deleted, all open reports for that comment MUST transition to `resolved` with the linked moderation action; dismissed reports MUST retain their dismissal reason.
- **FR-011**: The moderation workspace MUST show existing article reaction aggregates and may show bounded, admin-only reaction activity for investigation. It MUST NOT add a public endpoint that reveals another user's individual reactions.
- **FR-012**: The moderation UI MUST offer a contextual link to the existing user-management screen for an author, including the count of their recent hidden comments. Account bans remain a deliberate, separately confirmed action.
- **FR-013**: All admin mutations MUST validate target state server-side, use the existing service layer rather than business logic in routes/templates, and return clear `400`, `404`, `409`, or `500` failures without leaking internal data.
- **FR-014**: Existing user self-service deletion of their own comments MUST continue to work. It must not delete `AdminAuditLog` entries and must safely close any related open reports.
- **FR-015**: The system MUST evaluate every new comment against active administrator-configured prohibited terms before creating a `Comment` record or returning it to any public client.
- **FR-016**: Prohibited-term matching MUST be case-insensitive and normalize Unicode, whitespace, and punctuation consistently. Single-word rules MUST use word boundaries where supported; multi-word rules MUST match normalized contiguous phrases.
- **FR-017**: A blocked comment submission MUST return a generic `400` policy message, create no `Comment` record, disclose no matched term to the author, and record a filter event without storing the rejected comment body.
- **FR-018**: Admins MUST be able to create, activate/deactivate, list, and delete prohibited terms through protected moderation endpoints. Creating/updating/deleting a rule MUST write an `AdminAuditLog` event.
- **FR-019**: Prohibited-term configuration MUST validate normalization, uniqueness, maximum length, and an optional safe category/label. Only active rules participate in filtering.

### Key Entities

| Entity | Purpose and key attributes |
|---|---|
| `Comment` (extended) | Existing public comment. Add a visibility/moderation state, moderation reason, moderator ID, and moderated timestamp; preserve original author, article, content, and creation time. |
| `CommentReport` | One reader's report of one comment: reporter, comment, standardized reason, optional explanation, state (`open`, `resolved`, `dismissed`), timestamps, and resolving action reference. Unique on `(reporter_id, comment_id)` while active. |
| `CommentModerationAction` | Optional detailed decision record containing action, reason, note, acting admin, target comment, and timestamp. It supplies a concise history in the moderation UI. |
| `CommentProhibitedTerm` | An administrator-managed normalized word/phrase, optional category/label, active flag, creator/updater, and timestamps. The original display value is retained for the admin UI only. |
| `CommentFilterEvent` | A non-public audit-safe record of a blocked submission: submitting user, article, matched prohibited-term ID, timestamp, and outcome. It never stores the rejected comment body. |
| `Reaction` (existing) | Existing Like/Dislike record; reused for admin-only aggregate/context inspection, without changing normal public behavior. |
| `AdminAuditLog` (existing) | Immutable cross-system log for every moderation mutation and linked sanction hand-off. |

### API and UI Contract

| Surface | Contract |
|---|---|
| `POST /api/comments/<comment_id>/reports` | Authenticated reporting endpoint. Returns `201` for a new report and idempotent success for an existing report. |
| `GET /api/admin/moderation/comments` | Admin-only, paginated comment/report queue. Supports `q`, `status`, `report_state`, `reason`, `author_id`, `article_id`, `page`, and `per_page`. |
| `GET /api/admin/moderation/comments/<comment_id>` | Admin-only full context and action history for one comment. |
| `POST /api/admin/moderation/comments/<comment_id>/hide` | Admin-only hide action with a required reason and optional note. |
| `POST /api/admin/moderation/comments/<comment_id>/restore` | Admin-only restore action with a required reason and optional note. |
| `DELETE /api/admin/moderation/comments/<comment_id>` | Admin-only permanent deletion with confirmation, required reason, and optional note. |
| `POST /api/admin/moderation/reports/<report_id>/dismiss` | Admin-only dismissal with a required reason. |
| `GET/POST /api/admin/moderation/prohibited-terms` | Admin-only list/create prohibited terms. |
| `PATCH/DELETE /api/admin/moderation/prohibited-terms/<term_id>` | Admin-only activate/deactivate or remove a prohibited term. |
| `GET /api/admin/moderation/filter-events` | Admin-only bounded, paginated filter activity for operational review; rejected text is never returned. |
| Admin Dashboard | New **Community Moderation** navigation item with report count badge, searchable queue, context drawer/dialog, confirmation for destructive actions, and a link to User Management. |

## 6. Security, Privacy, and Integrity

- Reporter identity is visible only to authorized admins when necessary for abuse prevention; it is never returned by public article/comment APIs or displayed to the comment author.
- Public serializers must omit hidden and deleted comments before pagination/counting so totals do not disclose suppressed content.
- Mutating endpoints use the existing authenticated session and server-side authorization; client-side buttons are never the security boundary.
- Reasons, notes, and comment excerpts are treated as untrusted text and escaped in HTML/JavaScript output.
- Moderation actions are transactional: comment state, report state, action history, and audit log either commit together or roll back together.
- Prohibited-term changes must commit before they affect new submissions. A blocked submission records only metadata needed for an admin to investigate; it must never persist raw rejected text, a text hash, or a recoverable representation of the body.
- Do not log article bodies, raw comments, credentials, session tokens, or report explanations in application logs.

## 7. Non-functional Requirements

- The initial moderation queue should load in under 500 ms p95 for a 50-row page, excluding database contention.
- The system should reflect hide/restore results in public comment APIs on the next request; no page reload should be required in the admin dashboard after a successful action.
- The default queue must be bounded and paginated; it must not fetch the entire comment table into the browser.
- Add indexes for moderation status, comment article/author timestamps, and report state/reason to preserve filtering performance.
- Add unit/service tests for report idempotency, visibility suppression, restore, audit creation, authorization, filters, and transaction rollback; add route tests for public and admin API contracts.
- Add unit/service tests for normalization, word/phrase boundaries, case/diacritic/punctuation variants, inactive-rule behavior, safe filter-event serialization, and no-comment persistence after a blocked submission.

## 8. Success Criteria

- **SC-001**: An admin can locate an open report, review its context, and hide its comment in no more than three interactions after opening the queue.
- **SC-002**: A hidden comment has a 100% suppression rate from public article comments, public counts, search/presentation paths, and the author's dashboard activity.
- **SC-003**: 100% of hide, restore, delete, report-dismissal, and report-resolution decisions create an attributable audit record.
- **SC-004**: Duplicate reporting by the same account does not increase report count or create duplicate records.
- **SC-005**: An admin can restore a mistakenly hidden comment and it becomes publicly visible without data loss on the next article-comment request.
- **SC-006**: Non-admin users receive no moderation queue or individual reaction-history data from protected endpoints.
- **SC-007**: 100% of submissions matching an active prohibited term are rejected before a public comment record is created; no blocked comment body is persisted or exposed in the moderation workspace.

## 9. Assumptions

- The existing authentication, admin authorization guard, `Comment`, `Reaction`, `User`, and `AdminAuditLog` infrastructure will be reused.
- “Remove rude comments” in PA1 is implemented as reversible hide by default; permanent deletion is reserved for explicit confirmed cases.
- v1 uses deterministic administrator-configured prohibited terms, reader reports, and human judgment. There is no LLM/toxicity classifier or public appeal workflow.
- The automatic filter blocks only newly submitted comments. Existing comments are not retroactively hidden when a term is added; admins can review historical content through the normal moderation queue.
- Existing ban/unban behavior remains the source of truth for account sanctions; this feature only supplies context and navigation to that flow.
- Moderation reasons are initially stored/displayed in English identifiers and can be localized in the UI without changing persisted values.
