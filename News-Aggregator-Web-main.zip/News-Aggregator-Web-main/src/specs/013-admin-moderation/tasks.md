# Tasks: Community Moderation

**Branch**: `013-admin-moderation` | **Spec**: [spec.md](spec.md) | **Plan**: [plan.md](plan.md)

**Implementation status**: Code, migration, protected APIs, and automated tests are complete. Keep the explicit manual UI/release verification tasks as the final hand-off checklist.

---

## Phase 1: Schema and Shared Foundation

**Purpose**: Establish auditable moderation data, a single visibility rule, and safe prohibited-term matching before exposing any new UI or endpoint.

- [ ] **T001**: Review existing `Comment`, `Reaction`, `AdminAuditLog`, authentication helpers, comment/dashboard services, and Alembic revision length conventions in `src/models.py`, `src/routes.py`, `src/services/comment_service.py`, `src/services/dashboard_service.py`, `src/services/admin_service.py`, and `src/migrations/versions/`.
  - **Acceptance**: document the compatible forward migration revision and preserve existing `Comment.is_deleted` behavior.
- [ ] **T002**: Extend `Comment` in `src/models.py` with indexed reversible moderation visibility and metadata fields: `is_hidden`, `moderation_reason`, `moderation_note`, `moderated_by_id`, and `moderated_at`; add safe relationships to the moderator and moderation entities.
- [ ] **T003**: Add `CommentReport` to `src/models.py` with comment/reporter FKs, normalized reason, bounded optional explanation, status, resolution-action relation, timestamps, and unique `(comment_id, reporter_id)` constraint.
- [ ] **T004**: Add `CommentModerationAction` to `src/models.py` with comment/admin FKs, action, reason, optional internal note, timestamp, and query indexes.
- [ ] **T005**: Add `CommentProhibitedTerm` and `CommentFilterEvent` to `src/models.py`. Ensure `CommentFilterEvent` has only user/article/rule/outcome/timestamp metadata and no rejected-body, hash, or recoverable content field.
- [ ] **T006**: Create an additive, reversible Alembic migration in `src/migrations/versions/` for T002–T005, including foreign keys, unique constraints, and indexes for moderation queue/filter-event queries.
- [ ] **T007**: Create `src/services/moderation_service.py` with module documentation, type hints, logger, named constants for report reasons/statuses/actions, pagination caps, and a single public-comment visibility predicate.
- [ ] **T008**: Implement pure normalization/matching helpers in `src/services/moderation_service.py`: Unicode normalization, case folding, whitespace collapse, punctuation-to-boundary treatment, whole-word matching for one-token rules, and contiguous normalized phrase matching for multi-token rules.
- [ ] **T009**: Implement shared validation helpers in `src/services/moderation_service.py` for report reason/explanation, moderation reason/note, term display/category, page/per-page, and safe plain-text serialization.
- [ ] **T010**: Implement a transaction-safe audit helper in `src/services/moderation_service.py` that writes minimal action metadata to existing `AdminAuditLog` without logging raw comment/rejected text.
- [ ] **T011**: Create `src/tests/test_moderation_service.py` with test fixtures for active users, admin, articles, comments, reactions, and database cleanup matching the existing Flask/SQLite test setup.
- [ ] **T012**: Add foundation tests in `src/tests/test_moderation_service.py` for normalized-term uniqueness, word/phrase boundaries, case/diacritic/punctuation/whitespace variants, input lengths, and safe filter-event model fields.

**Checkpoint**: The schema migration applies/downgrades cleanly in the test database; filter matching is deterministic and stores no rejected content.

---

## Phase 2: User Story 4 — Automatically Block Prohibited Terms (Priority: P1)

**Goal**: Prevent a comment containing an active prohibited word/phrase from being persisted or displayed, while allowing admins to control the rules and inspect safe activity metadata.

**Independent Test**: Add an active prohibited term, attempt to post a comment containing a normalized equivalent, confirm `400`, no new `Comment`, and one safe `CommentFilterEvent`; deactivate the rule and confirm the same text can be posted.

- [ ] **T013 [US4]**: Implement `evaluate_prohibited_terms(content)` in `src/services/moderation_service.py`, loading only active rules and returning a private match result containing the rule ID, never a user-facing matched term.
- [ ] **T014 [US4]**: Implement `record_filter_event(user_id, article_id, prohibited_term_id)` in `src/services/moderation_service.py`; use a transaction that commits metadata only and rolls back safely on failure.
- [ ] **T015 [US4]**: Update `create_comment()` in `src/services/comment_service.py` to evaluate active prohibited terms after basic content validation and before constructing `Comment`; on a match, record a filter event and return a generic `400` policy message without creating a comment.
- [ ] **T016 [US4]**: Ensure `src/routes.py` retains the current authenticated-comment behavior and returns the generic filter rejection without exposing a prohibited term, internal rule ID, or exception details.
- [ ] **T017 [US4]**: Implement admin service operations in `src/services/moderation_service.py` to list, create, activate/deactivate, and delete prohibited terms; normalize before write, reject duplicate normalized values, and audit each configuration change.
- [ ] **T018 [US4]**: Implement bounded, admin-only filter-event listing in `src/services/moderation_service.py`, returning submitting user/article/rule category/outcome/time metadata only; omit rejected text and all recoverable representations.
- [ ] **T019 [US4]**: Add protected prohibited-term CRUD and filter-event endpoints to `src/routes.py`: `GET/POST /api/admin/moderation/prohibited-terms`, `PATCH/DELETE /api/admin/moderation/prohibited-terms/<term_id>`, and `GET /api/admin/moderation/filter-events`.
- [ ] **T020 [P] [US4]**: Add `src/tests/test_moderation_routes.py` tests for anonymous/non-admin rejection, prohibited-term rule CRUD validation, and safe filter-event response serialization.
- [ ] **T021 [US4]**: Add service/route tests for active vs. inactive rules, word/phrase false positives, generic blocked response, no-comment persistence, one filter event per rejection, and configuration audit rows.

**Checkpoint**: A matching new comment can never reach a public comment list; rule management and filter activity are restricted to admins.

---

## Phase 3: User Story 1 — Report and Hide Harmful Comments (Priority: P1)

**Goal**: Let readers report visible comments and let admins resolve reports by hiding content immediately and audibly.

**Independent Test**: A reader reports another user's visible comment; an admin sees it in the open queue, hides it with a reason, and the comment/count disappears from the public article endpoint.

- [ ] **T022 [US1]**: Implement `create_comment_report()` in `src/services/moderation_service.py` with authentication-compatible validation, visible-target lookup, self-report prevention, allowed reasons, required `other` explanation, and idempotent `(reporter, comment)` behavior.
- [ ] **T023 [US1]**: Add `POST /api/comments/<comment_id>/reports` to `src/routes.py` using existing authenticated JSON helpers; return `201` for new and `200` for idempotent reports without reporter details.
- [ ] **T024 [US1]**: Update `get_article_comments()` in `src/services/comment_service.py` to apply the shared public-visibility predicate before computing total, pagination, and returned items.
- [ ] **T025 [US1]**: Update `get_user_comments()` and `delete_user_comment()` in `src/services/dashboard_service.py` to suppress hidden comments and resolve related open reports safely when the author self-deletes a comment, without deleting audits.
- [ ] **T026 [US1]**: Implement `get_moderation_summary()` and open-report queue query in `src/services/moderation_service.py`; include comment excerpt, article title/link, author identity/status, aggregate report reasons/count, and oldest open report while using bounded pagination/eager loading.
- [ ] **T027 [US1]**: Implement atomic `hide_comment()` in `src/services/moderation_service.py`: validate state/reason, create action/audit records, set hidden metadata, resolve all open reports with the action ID, and be idempotent without duplicate audit entries.
- [ ] **T028 [US1]**: Add protected `GET /api/admin/moderation/summary`, `GET /api/admin/moderation/comments`, and `POST /api/admin/moderation/comments/<comment_id>/hide` endpoints to `src/routes.py` behind `_get_admin_user()`.
- [ ] **T029 [US1]**: Extend comment rendering in `src/static/js/article.js` with an authenticated report control, accessible report-reason form/dialog, generic success/error feedback, and safe DOM text insertion; guests use the existing login prompt.
- [ ] **T030 [US1]**: Add any necessary semantic report-dialog markup to `src/templates/article.html` and focused responsive/focus styles to `src/static/css/frontend.css`.
- [ ] **T031 [US1]**: Add tests for report idempotency, self-report rejection, invalid/`other` reason validation, report queue filtering, hide transition, report resolution, audit creation, public suppression/counting, and dashboard suppression.

**Checkpoint**: Reader reports and admin hide work end-to-end; a hidden comment is absent from public article and dashboard comment paths.

---

## Phase 4: User Story 2 — Search, Restore, and Manage Comments (Priority: P1)

**Goal**: Give admins a complete, reversible moderation workflow for reported and proactively found comments.

**Independent Test**: An admin searches for an author/article, filters hidden comments, opens full context, restores one with a reason, and verifies it reappears with its original text/timestamp.

- [ ] **T032 [US2]**: Extend the moderation queue in `src/services/moderation_service.py` with combined `q`, `status`, `report_state`, `reason`, `author_id`, `article_id`, `page`, and `per_page` validation/filtering; use SQLAlchemy expressions only.
- [ ] **T033 [US2]**: Implement `get_moderation_comment_detail()` in `src/services/moderation_service.py` returning admin-only comment/article/author context, action timeline, report summary, author's recent-hidden count, reaction aggregates, and bounded recent reaction activity.
- [ ] **T034 [US2]**: Implement atomic `restore_comment()` in `src/services/moderation_service.py` with reason/note validation, idempotent state handling, action/audit writes, no reopening of resolved reports, and `409` for permanently deleted comments.
- [ ] **T035 [US2]**: Implement `delete_comment_permanently()` in `src/services/moderation_service.py`, requiring explicit confirmation and reason, closing reports, retaining minimal action/audit metadata, and making later restoration return `404`/`409` according to the chosen model state.
- [ ] **T036 [US2]**: Implement `dismiss_comment_report()` in `src/services/moderation_service.py` with required reason, open-state validation, action/audit rows, and idempotent/`409` behavior as specified.
- [ ] **T037 [US2]**: Add protected detail, restore, permanent-delete, and report-dismissal endpoints in `src/routes.py`; ensure no endpoint returns raw internal notes or reporter data to public clients.
- [ ] **T038 [US2]**: Add service/route tests for combined filters/pagination caps, detail context, restore, confirmed deletion, report dismissal, state conflicts, transaction rollback, and audit row integrity.

**Checkpoint**: Admins can proactively find, inspect, restore, delete, and dismiss reports without compromising public visibility or audit history.

---

## Phase 5: User Story 3 — Reaction Context (Priority: P2)

**Goal**: Surface bounded reaction context for administrators without changing public reaction privacy or behavior.

**Independent Test**: With seeded reactions, an admin opens a moderation detail view and sees aggregate totals/recent bounded activity; a non-admin cannot access it and public reaction summary remains aggregate-only.

- [ ] **T039 [US3]**: Complete reaction aggregate and bounded recent-activity serialization in `src/services/moderation_service.py`; confirm it is only reachable through admin detail/list paths and contains no unnecessary user data.
- [ ] **T040 [US3]**: Add/extend tests for admin reaction context, reaction list bounds, non-admin `403`, and regression of the public `GET /api/articles/<article_id>/reactions/summary` aggregate-only contract.

**Checkpoint**: Reaction signals assist human investigation without exposing individual reaction history publicly.

---

## Phase 6: Admin Dashboard Workspace

**Purpose**: Deliver the administrative UI that consumes the completed moderation contracts without full-page reloads.

- [ ] **T041**: Add a **Community Moderation** tab, open-report badge/live label, queue/filter region, context dialog/drawer, prohibited-terms sub-panel, and filter-event activity region to `src/templates/admin.html`.
- [ ] **T042**: Add admin moderation API loaders, bounded query-string builder, summary badge refresh, queue pagination/filter state, and escaped renderer functions to `src/static/js/admin.js`.
- [ ] **T043**: Implement the admin detail dialog/drawer in `src/static/js/admin.js` with article/author links, report breakdown, reaction context, moderation timeline, focus management, and no `innerHTML` interpolation of unescaped user comment data.
- [ ] **T044**: Implement hide, restore, permanent-delete, and dismiss-report confirmations in `src/static/js/admin.js`, requiring reason/confirmation input and refreshing only affected admin data after success.
- [ ] **T045**: Implement prohibited-term list/create/activate/deactivate/delete controls and filter-event pagination in `src/static/js/admin.js`; never render rejected comment text.
- [ ] **T046**: Add/adjust responsive, keyboard-focus, long-text wrapping, badge, dialog, and mobile styles in `src/static/css/frontend.css` for the moderation workspace.
- [ ] **T047**: Manually verify admin workflow on desktop and mobile: queue filters, report badge, dialog focus, all action confirmations, prohibited-term controls, filter events, error/empty/loading states, and existing User Management hand-off.

**Checkpoint**: An admin can execute all v1 moderation functions through the dashboard without a page reload.

---

## Phase 7: Final Verification and Release Gate

- [ ] **T048**: Apply the new migration to a non-production/test PostgreSQL/Supabase database; verify upgrade and downgrade, constraints/indexes, and compatibility with existing comments before production rollout.
- [ ] **T049**: Run focused tests in the activated project environment: `venv\Scripts\python -m unittest tests.test_moderation_service tests.test_moderation_routes tests.test_routes tests.test_dashboard`.
- [ ] **T050**: Run the complete existing unit test suite and resolve regressions for comment/reaction APIs, dashboard activity, authentication/ban behavior, Admin Dashboard, and public article views.
- [ ] **T051**: Run `venv\Scripts\python -m compileall -q models.py routes.py services\comment_service.py services\dashboard_service.py services\moderation_service.py` and `git diff --check`.
- [ ] **T052**: Perform role-based manual verification as guest, normal user, banned user, and admin. Confirm public clients cannot access hidden comments, report details, prohibited terms, filter events, individual reaction history, internal notes, or rejected comment text.
- [ ] **T053**: Update the completion status in `src/specs/013-admin-moderation/spec.md` and `src/specs/013-admin-moderation/plan.md` only after T048–T052 pass; record the applied migration revision and release verification result.

---

## Dependency Order

```text
T001–T012
  → T013–T021 (US4: prohibited-term filtering)
  → T022–T031 (US1: report and hide)
  → T032–T038 (US2: search, restore, delete)
  → T039–T040 (US3: reaction context)
  → T041–T047 (Admin Dashboard workspace)
  → T048–T053 (release gate)
```

- T002–T005 are sequential because the model relationships share `src/models.py`; T006 follows them.
- T008–T010 depend on T007. T011–T012 can begin once the core models/helpers have stable interfaces.
- US4 starts after the foundation and is an independent MVP for automatic filtering.
- US1 requires the foundation and public visibility predicate; its report UI may proceed after T023 and its API contract are stable.
- US2 depends on T026–T028 because it extends the queue and reuses action/audit primitives.
- US3 depends on T033's admin detail serializer.
- Dashboard work starts when endpoint contracts T019, T028, and T037 are stable; T041–T046 are intentionally sequential because they share `admin.html`, `admin.js`, and CSS.
- T049–T053 are release blockers; T048 must be completed before any production database migration.

## Parallel Opportunities

- After T007, T008 (normalization), T009 (validation), and T010 (audit helper) can be implemented in parallel only if their shared constants/API signatures are agreed first.
- T020 route tests can be written in parallel with T017–T019 after the admin API response schema is fixed.
- T029–T030 article UI work can proceed in parallel with T026–T028 after the report endpoint is available.
- T038 test cases can be prepared in parallel with T032–T037, but should be run only after routes are integrated.
- T046 styling can start after the markup IDs/classes from T041 are settled.

## MVP Scope

The first demonstrable slice is **T001–T021**: admin-configured prohibited terms block matching new comments before persistence, record only safe filter metadata, and give admins control over the rules. The next usable moderation slice is **T022–T031**, which adds reporting and hide/suppression. Full Community Moderation requires all tasks through T053.
