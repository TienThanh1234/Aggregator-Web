# Implementation Plan: User Dashboard (Bảng điều khiển Người dùng)

**Branch**: `009-user-dashboard` | **Date**: 2026-08-10 | **Spec**: [spec.md](spec.md)

## Summary

This plan implements a four-module User Dashboard for authenticated users of the Tell Me More News Aggregator. The feature transforms the application from a passive reading experience into a personalized, interactive workspace. Implementation spans 6 database tables, 3 new service modules, 16 API endpoints, 1 new Jinja2 template, 1 new JavaScript controller, and modifications to 8 existing files — delivered across 5 sequential phases.

---

## Technical Context

**Language/Version**: Python 3.11+, HTML5, CSS3, ES6+ JavaScript

**Primary Dependencies**: Flask 3.1.3, Flask-SQLAlchemy 3.1.1, Werkzeug 3.1.8, Flask-Migrate 4.1.0, APScheduler 3.11.2, python-dotenv 1.2.2, `google-generativeai` (new — for Gemini LLM API)

**Storage**: PostgreSQL via Supabase (production) / localhost (development)

**Existing State**:
- The `User` model ([`models.py:18-48`](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py#L18-L48)) has auth fields, avatar, session versioning, and a `bookmarks` relationship.
- The `Bookmark` model ([`models.py:136-148`](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py#L136-L148)) exists but has **zero API routes or service functions** — only used in cascade relationships.
- The `ROLE_REDIRECT_MAP` in [`auth_service.py:33-37`](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py#L33-L37) already maps `"user" → "/dashboard/user"` but the route does **not** exist yet.
- The Admin Dashboard ([`admin.html`](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/admin.html), [`admin.js`](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/admin.js)) provides a proven tab-navigation SPA pattern to follow.
- The `base.html` header dropdown ([lines 63-68](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/base.html#L63-L68)) has the Admin Dashboard link; a User Dashboard link needs to be added.
- No `Comment`, `Reaction`, or AI integration models/code exist. The `/api/gemini/*` endpoints are hardcoded stubs.
- The scheduler ([`scheduler_service.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/scheduler_service.py)) uses APScheduler `IntervalTrigger` and `CronTrigger`; the daily brief job will be added here.

**Project Type**: Flask MVC application with Jinja2 templates and vanilla frontend assets (no build step).

---

## Constitution Check

The implementation plan conforms to the constitution in the following ways:

- **Strict MVC Pattern (Principle II)**: Route handlers in `routes.py` remain thin and delegate to `dashboard_service.py`, `brief_service.py`, and `comment_service.py`. Database schema stays in `models.py`; presentation stays in `templates/` and `static/`.
- **Environment Configuration (Principle III — NON-NEGOTIABLE)**: LLM API keys, email credentials, and database URLs are loaded exclusively from `.env`. No secrets are hardcoded.
- **Data Integrity (Principle IV)**: Unique constraints on (`user_id`, `article_id`) for reactions and (`user_id`, `brief_date`) for daily briefs prevent duplicate records at the database level.
- **Code Organization (Principle V)**: Models use PascalCase, services use snake_case functions, constants use UPPER_SNAKE_CASE. New files follow the existing directory structure.
- **Error Handling (Principle VI)**: LLM API failures fall back gracefully to raw article lists. All operations use try/except with structured logging. No silent failures.
- **Frontend Stack**: Vanilla HTML5/CSS3/JS only. No framework dependencies introduced. The dashboard follows the same IIFE + `window.TMM` pattern used by `core.js` and `admin.js`.
- **Environment Governance (Principle VIII)**: All migration, test, and runtime commands run within the activated `venv` context.

---

## Project Structure (Post-Implementation)

```text
src/
├── app.py                              # [MODIFY] — Import new models
├── models.py                           # [MODIFY] — Add 4 models + 2 association tables + User relationships
├── routes.py                           # [MODIFY] — Add 1 page route + 16 API endpoints
├── services/
│   ├── __init__.py                     # [EXISTING]
│   ├── auth_service.py                 # [EXISTING]
│   ├── article_service.py             # [MODIFY] — Personalized feed (add user_id param)
│   ├── profile_service.py             # [EXISTING]
│   ├── scheduler_service.py           # [MODIFY] — Add daily_brief_generator cron job
│   ├── email_service.py               # [MODIFY] — Add send_daily_brief_email()
│   ├── dashboard_service.py           # [NEW] — Preferences, bookmarks, comments, reactions
│   ├── brief_service.py               # [NEW] — AI daily brief generation + LLM integration
│   └── comment_service.py             # [NEW] — Article-level comment/reaction operations
├── templates/
│   ├── base.html                       # [MODIFY] — Add "Dashboard" dropdown link
│   ├── dashboard.html                  # [NEW] — User Dashboard template (tab-based layout)
│   ├── article.html                    # [MODIFY] — Add comment section + reaction buttons
│   └── partials/
│       └── _comment_section.html       # [NEW] — Reusable comment/reaction partial for article page
├── static/
│   ├── css/
│   │   └── frontend.css               # [MODIFY] — Dashboard styles (append ~400 lines)
│   └── js/
│       ├── core.js                     # [EXISTING]
│       ├── dashboard.js               # [NEW] — Dashboard SPA controller (~500 lines)
│       └── article.js                 # [MODIFY] — Add comment/reaction interaction handlers
├── migrations/
│   └── versions/
│       └── 20260810_user_dashboard_schema.py  # [NEW] — Alembic migration for 6 tables
├── .env.example                        # [MODIFY] — Add LLM_API_KEY, LLM_API_URL, LLM_MODEL
├── requirements.txt                    # [MODIFY] — Add google-generativeai
└── tests/
    └── test_dashboard.py              # [NEW] — API and service-layer tests
```

---

## Implementation Phases

### Phase 1 — Database Schema Evolution & Migration

**Objective**: Define all new models and association tables in `models.py`, generate and apply the Alembic migration.

**Spec Reference**: [§3 Database Schema & Architecture](spec.md#3-database-schema--architecture-mvc-model-layer)

#### Work Items

##### 1.1 [MODIFY] [`src/models.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py)

Add the following **before** the existing `User` class definition (association tables must be defined before models that reference them):

```python
from datetime import datetime, time  # add 'time' to existing import

# ── USER DASHBOARD ASSOCIATION TABLES ──

user_category_subscriptions = db.Table(
    "user_category_subscriptions",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    db.Column("category_id", db.Integer, db.ForeignKey("categories.id", ondelete="CASCADE"), primary_key=True),
    db.Column("created_at", db.DateTime, nullable=False, default=lambda: datetime.utcnow()),
)

user_source_subscriptions = db.Table(
    "user_source_subscriptions",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    db.Column("source_id", db.Integer, db.ForeignKey("scraper_configs.id", ondelete="CASCADE"), primary_key=True),
    db.Column("created_at", db.DateTime, nullable=False, default=lambda: datetime.utcnow()),
)
```

Add the following **after** the existing `SystemSetting` model (at end of file):

```python
class Comment(db.Model):
    """Represents a user's comment on an article."""
    __tablename__ = "comments"
    # ... (full definition per spec §3.1.3)

class Reaction(db.Model):
    """Represents a user's emotional response (like/upvote) to an article."""
    __tablename__ = "reactions"
    __table_args__ = (db.UniqueConstraint("user_id", "article_id", name="uq_user_article_reaction"),)
    # ... (full definition per spec §3.1.4)

class DailyBrief(db.Model):
    """Stores an AI-generated daily news digest for a specific user."""
    __tablename__ = "daily_briefs"
    __table_args__ = (db.UniqueConstraint("user_id", "brief_date", name="uq_user_brief_date"),)
    # ... (full definition per spec §3.1.5)

class UserBriefPreference(db.Model):
    """Stores per-user AI daily brief delivery preferences."""
    __tablename__ = "user_brief_preferences"
    # ... (full definition per spec §3.1.6)
```

Extend the `User` model with two new relationships (add after existing `bookmarks` relationship on line 39):

```python
    subscribed_categories = db.relationship(
        "Category", secondary=user_category_subscriptions,
        backref=db.backref("subscribed_users", lazy="dynamic"), lazy="subquery",
    )
    subscribed_sources = db.relationship(
        "ScraperConfig", secondary=user_source_subscriptions,
        backref=db.backref("subscribed_users", lazy="dynamic"), lazy="subquery",
    )
```

##### 1.2 [MODIFY] [`src/app.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/app.py)

Update the models import on line 10 to include new models:

```python
from models import db, User, Article, Category, Bookmark, Comment, Reaction, DailyBrief, UserBriefPreference
```

##### 1.3 Generate & Apply Alembic Migration

```powershell
cd src
venv\Scripts\Activate.ps1
flask db migrate -m "user_dashboard_schema"
flask db upgrade
```

This will auto-generate the migration creating 6 tables: `user_category_subscriptions`, `user_source_subscriptions`, `comments`, `reactions`, `daily_briefs`, `user_brief_preferences`.

##### 1.4 [MODIFY] [`src/requirements.txt`](file:///c:/Users/user/Documents/repos/news-aggregator/src/requirements.txt)

Add:
```
google-generativeai==0.8.5
```

##### 1.5 [MODIFY] [`src/.env.example`](file:///c:/Users/user/Documents/repos/news-aggregator/src/.env.example)

Add:
```
LLM_API_KEY=replace-with-gemini-api-key
LLM_API_URL=https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent
LLM_MODEL=gemini-2.0-flash
```

#### Acceptance Criteria

- Migration completes without errors on PostgreSQL.
- All existing user, article, and bookmark records remain intact.
- New tables are visible via `\dt` in psql or Supabase dashboard.
- `pip install google-generativeai` succeeds within the venv.

---

### Phase 2 — Service Layer: Dashboard, Comments & Brief

**Objective**: Build the three new service modules containing all business logic, keeping route handlers thin per constitution Principle II.

**Spec Reference**: [§4.7 Service Module Responsibilities](spec.md#47-service-module-responsibilities)

#### Work Items

##### 2.1 [NEW] `src/services/dashboard_service.py`

This is the primary orchestration service for the dashboard. Functions:

| Function | Spec Section | Description |
|---|---|---|
| `get_user_preferences(user_id)` | §4.2 | Returns all categories + sources with `is_subscribed` boolean per user |
| `update_user_preferences(user_id, category_ids, source_ids)` | §4.2 | Atomic subscription replacement via `db.session.execute(delete + insert)` |
| `get_user_bookmarks(user_id, page, per_page, sort, keyword)` | §4.4 | Paginated bookmarks with article metadata, soft-delete awareness |
| `remove_bookmark(user_id, bookmark_id)` | §4.4 | Ownership-verified bookmark deletion |
| `get_user_comments(user_id, page, per_page)` | §4.5 | Paginated comment history with parent article metadata |
| `delete_user_comment(user_id, comment_id)` | §4.5 | Ownership-verified soft-delete (`is_deleted = True`) |
| `get_user_reactions(user_id, page, per_page)` | §4.5 | Paginated reaction history |
| `remove_user_reaction(user_id, reaction_id)` | §4.5 | Ownership-verified reaction deletion |

**Implementation Notes**:
- Bookmark query must join `Article` **without** filtering on `is_deleted`, since soft-deleted articles must remain visible in bookmarks (spec §AS-BM-05). The `is_article_available` flag is computed as `not article.is_deleted`.
- Preference update uses `DELETE + INSERT` within a single transaction for atomicity. Invalid IDs are silently filtered by inner-joining against existing records.
- Comment deletion sets `is_deleted = True` rather than removing the row, preserving admin audit trail capability.
- All pagination follows the same pattern as `get_admin_articles()` in `admin_service.py`: returns `(items, pagination_dict)`.

##### 2.2 [NEW] `src/services/comment_service.py`

Article-level interaction service powering the public comment/reaction UI on article detail pages.

| Function | Spec Section | Description |
|---|---|---|
| `create_comment(user_id, article_id, content)` | §4.6 #13 | Validated comment creation (1-2000 chars, XSS sanitization) |
| `get_article_comments(article_id, page, per_page)` | §4.6 #14 | Public paginated comments with author info (excludes soft-deleted) |
| `toggle_reaction(user_id, article_id, reaction_type)` | §4.6 #15 | Idempotent toggle: create if not exists, delete if exists |
| `get_reaction_summary(article_id, user_id=None)` | §4.6 #16 | Aggregate count + user's own reaction state |

**Implementation Notes**:
- XSS sanitization: use `html.escape()` on comment content before storage. Strip all HTML tags via a simple regex or `markupsafe.escape()` (already available via Jinja2 dependency).
- Reaction toggle: query `Reaction.query.filter_by(user_id=..., article_id=...)`. If found → delete → return `"removed"`. If not found → create → return `"created"`. Return updated total count.
- Comment author serialization must include `id`, `username`, `full_name`, `avatar_url` for frontend rendering.

##### 2.3 [NEW] `src/services/brief_service.py`

AI Daily Brief generation and preference management.

| Function | Spec Section | Description |
|---|---|---|
| `generate_daily_brief(user_id)` | §5.1 | Core generation: query articles → call LLM → persist DailyBrief |
| `generate_all_daily_briefs()` | §5.1 | Batch: iterate all enabled users, call `generate_daily_brief()` each |
| `get_latest_brief(user_id)` | §4.3 #3 | Returns most recent DailyBrief with source article metadata |
| `mark_brief_read(user_id, brief_id)` | §4.3 #4 | Set `is_read = True` with ownership check |
| `get_brief_preferences(user_id)` | §4.3 #5 | Returns UserBriefPreference or defaults |
| `update_brief_preferences(user_id, prefs)` | §4.3 #6 | Upsert preference record |
| `_call_llm_api(prompt)` | §5.2 | Internal: calls Gemini API via `google-generativeai` SDK |
| `_build_fallback_brief(articles)` | §5.2 | Internal: builds raw article list when LLM is unavailable |

**Implementation Notes**:
- LLM integration uses `google.generativeai` SDK. The API key is loaded from `os.getenv("LLM_API_KEY")`. If the key is not configured, the service falls back to non-AI summaries silently.
- The prompt template from spec §5.2 is used to generate 3-4 bullet points in Vietnamese.
- `generate_daily_brief()` checks for an existing brief for today's date via the unique constraint `(user_id, brief_date)` and skips if already generated.
- Error handling: wrap LLM call in try/except. On failure, call `_build_fallback_brief()` and log `logger.error()`.

##### 2.4 [MODIFY] [`src/services/article_service.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/article_service.py)

Extend `get_feed_articles()` (line 180) with a new optional `user_id` parameter for personalized feed ordering:

```python
def get_feed_articles(
    category: str | None = None,
    page: int = 1,
    per_page: int = 20,
    user_id: int | None = None,  # NEW
) -> tuple[list[dict[str, Any]], int, int]:
```

**Personalization Algorithm** (spec §4.8):
1. If `user_id` is provided and `category` is not explicitly filtered:
   - Query `user_category_subscriptions` and `user_source_subscriptions` for this user.
   - If subscriptions exist: use `case()` + `order_by` to rank preferred articles first.
2. If no subscriptions or `user_id` is None: fall back to existing default ordering.
3. If an explicit `category` filter is applied: ignore preferences (category tab takes precedence).

**Implementation approach**: Use SQLAlchemy `case()` expression to add a computed `priority` column (0 for preferred, 1 for general), then `order_by(priority, published_at.desc())`.

##### 2.5 [MODIFY] [`src/services/scheduler_service.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/scheduler_service.py)

Add the daily brief cron job in `init_app()` (after line 91):

```python
from apscheduler.triggers.cron import CronTrigger

# Inside init_app(), after the cleanup job registration:
SchedulerService._scheduler.add_job(
    func=SchedulerService._daily_brief_job,
    trigger=CronTrigger(hour=7, minute=0, timezone="Asia/Ho_Chi_Minh"),
    id="daily_brief_generator",
    name="Daily AI Brief Generator",
    replace_existing=True,
    max_instances=1,
)
```

Add the `_daily_brief_job()` static method:

```python
@staticmethod
def _daily_brief_job() -> None:
    """Generate daily briefs for all opted-in users (runs in background thread)."""
    app = SchedulerService._app
    if not app:
        logger.error("[ERROR] No Flask app reference for daily brief job")
        return
    try:
        with app.app_context():
            from services.brief_service import generate_all_daily_briefs
            count = generate_all_daily_briefs()
            logger.info("[SUCCESS] Generated %d daily briefs", count)
    except Exception as exc:
        logger.error("[ERROR] Daily brief job failed: %s", exc, exc_info=True)
```

##### 2.6 [MODIFY] [`src/services/email_service.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/email_service.py)

Add a new function `send_daily_brief_email(email, brief_content, brief_date)` following the same `smtplib` pattern as `send_password_reset_email()`. Uses a simple HTML template with the brief bullet points.

#### Acceptance Criteria

- All service functions can be called from a Flask shell session.
- `get_user_preferences()` returns all categories/sources with correct subscription state.
- `update_user_preferences()` atomically replaces subscriptions.
- `create_comment()` rejects empty content, >2000 chars, and XSS payloads.
- `toggle_reaction()` creates on first call, removes on second call.
- `generate_daily_brief()` produces a brief even when LLM is unavailable (fallback).
- Feed personalization correctly ranks subscribed content first.

---

### Phase 3 — Route Layer: Page Route & API Endpoints

**Objective**: Wire the dashboard page route and all 16 API endpoints in `routes.py`, keeping handlers thin.

**Spec Reference**: [§4 API & Controller Specification](spec.md#4-api--controller-specification-mvc-controller--service-layer)

#### Work Items

##### 3.1 [MODIFY] [`src/routes.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py)

**Add imports** (after existing service imports, around line 40):

```python
from services.dashboard_service import (
    get_user_preferences, update_user_preferences,
    get_user_bookmarks, remove_bookmark,
    get_user_comments, delete_user_comment,
    get_user_reactions, remove_user_reaction,
)
from services.brief_service import (
    get_latest_brief, mark_brief_read,
    get_brief_preferences, update_brief_preferences,
)
from services.comment_service import (
    create_comment, get_article_comments,
    toggle_reaction, get_reaction_summary,
)
```

**Add page route** — `GET /dashboard/user`:

```python
@main_bp.get("/dashboard/user")
def user_dashboard_page():
    """Render the authenticated User Dashboard."""
    auth_data, _ = get_current_user()
    if not auth_data.get("authenticated"):
        return redirect(url_for("main.index", auth_intent="login", next="/dashboard/user"))
    user = auth_data.get("user", {})
    if user.get("role") == "admin":
        return redirect(url_for("main.admin_dashboard_page"))
    return render_template("dashboard.html", user=user)
```

**Add 12 dashboard API endpoints** (`/api/dashboard/*`):

| # | Method | Path | Handler | Service Function |
|---|---|---|---|---|
| 1 | GET | `/api/dashboard/preferences` | `api_dashboard_preferences_get` | `get_user_preferences` |
| 2 | PUT | `/api/dashboard/preferences` | `api_dashboard_preferences_put` | `update_user_preferences` |
| 3 | GET | `/api/dashboard/brief/latest` | `api_dashboard_brief_latest` | `get_latest_brief` |
| 4 | POST | `/api/dashboard/brief/mark-read` | `api_dashboard_brief_mark_read` | `mark_brief_read` |
| 5 | GET | `/api/dashboard/brief/preferences` | `api_dashboard_brief_prefs_get` | `get_brief_preferences` |
| 6 | PUT | `/api/dashboard/brief/preferences` | `api_dashboard_brief_prefs_put` | `update_brief_preferences` |
| 7 | GET | `/api/dashboard/bookmarks` | `api_dashboard_bookmarks` | `get_user_bookmarks` |
| 8 | DELETE | `/api/dashboard/bookmarks/<id>` | `api_dashboard_bookmark_delete` | `remove_bookmark` |
| 9 | GET | `/api/dashboard/comments` | `api_dashboard_comments` | `get_user_comments` |
| 10 | DELETE | `/api/dashboard/comments/<id>` | `api_dashboard_comment_delete` | `delete_user_comment` |
| 11 | GET | `/api/dashboard/reactions` | `api_dashboard_reactions` | `get_user_reactions` |
| 12 | DELETE | `/api/dashboard/reactions/<id>` | `api_dashboard_reaction_delete` | `remove_user_reaction` |

**Add 4 article-level interaction endpoints** (`/api/articles/<id>/*`):

| # | Method | Path | Handler | Service Function |
|---|---|---|---|---|
| 13 | POST | `/api/articles/<id>/comments` | `api_article_comment_create` | `create_comment` |
| 14 | GET | `/api/articles/<id>/comments` | `api_article_comments_list` | `get_article_comments` |
| 15 | POST | `/api/articles/<id>/reactions` | `api_article_reaction_toggle` | `toggle_reaction` |
| 16 | GET | `/api/articles/<id>/reactions/summary` | `api_article_reaction_summary` | `get_reaction_summary` |

All dashboard endpoints use `_get_authenticated_user_id()` guard. Article comment listing (#14) and reaction summary (#16) are public (no auth required but pass optional user_id).

**Modify the homepage route** (`/` on line 259) to pass `user_id` for personalized feed:

```python
@main_bp.get("/")
def index():
    category = request.args.get("category", "").strip() or None
    page = request.args.get("page", 1, type=int) or 1
    articles, total_pages, current_page = get_feed_articles(
        category=category, page=page, per_page=20,
        user_id=_optional_current_user_id(),  # NEW
    )
    # ... rest unchanged
```

#### Acceptance Criteria

- `GET /dashboard/user` renders the dashboard template for authenticated users.
- `GET /dashboard/user` redirects to login for unauthenticated users.
- `GET /dashboard/user` redirects admins to `/dashboard/admin`.
- All 16 API endpoints return correct JSON responses per spec §4 contracts.
- All dashboard API endpoints return 401 for unauthenticated requests.
- Ownership checks prevent users from deleting others' bookmarks/comments/reactions.

---

### Phase 4 — Frontend: Template, Styles & JavaScript

**Objective**: Build the User Dashboard UI as a tab-based SPA-within-a-page, following the same architecture as the Admin Dashboard.

**Spec Reference**: [§6 Frontend GUI Design](spec.md#6-frontend-gui-design--existing-theme-alignment)

#### Work Items

##### 4.1 [MODIFY] [`src/templates/base.html`](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/base.html)

Add a "Dashboard" link in the user dropdown menu (after line 65, before "Profile Settings"):

```html
<a id="menu-item-user-dashboard" class="dropdown-item hide" href="/dashboard/user">
  <i data-lucide="layout-grid"></i><span>My Dashboard</span>
</a>
```

The `hide` class is toggled by `core.js` — shown only for `role === "user"`. The Admin Dashboard link is already conditionally shown for admin role.

Update `core.js` `checkAuthState()` logic to show `menu-item-user-dashboard` for role `"user"`.

##### 4.2 [NEW] `src/templates/dashboard.html`

Extends `base.html`. Structure follows the admin dashboard pattern:

```html
{% extends "base.html" %}
{% block title %}Dashboard — Tell Me More{% endblock %}
{% block content %}
<section class="dashboard-shell" data-user-id="{{ user.id }}">
  <!-- Morning Brief Card (above tabs) -->
  <div class="morning-brief-card" id="morning-brief">...</div>

  <!-- Tab Navigation -->
  <nav class="dashboard-tabs" role="tablist">
    <button class="dashboard-tab active" data-tab="preferences" role="tab">
      <i data-lucide="sliders"></i> Preferences
    </button>
    <button class="dashboard-tab" data-tab="bookmarks" role="tab">
      <i data-lucide="bookmark"></i> Bookmarks
    </button>
    <button class="dashboard-tab" data-tab="comments" role="tab">
      <i data-lucide="message-square"></i> Comments
    </button>
    <button class="dashboard-tab" data-tab="reactions" role="tab">
      <i data-lucide="heart"></i> Reactions
    </button>
  </nav>

  <!-- Tab Content Panels -->
  <section id="panel-preferences" class="dashboard-panel">...</section>
  <section id="panel-bookmarks" class="dashboard-panel hide">...</section>
  <section id="panel-comments" class="dashboard-panel hide">...</section>
  <section id="panel-reactions" class="dashboard-panel hide">...</section>

  <!-- Brief Preferences Modal -->
  <div class="modal-overlay" id="brief-prefs-modal" style="display:none;">...</div>
</section>
{% endblock %}
{% block page_scripts %}
<script src="{{ url_for('static', filename='js/dashboard.js') }}"></script>
{% endblock %}
```

Full wireframe content for each panel is defined in spec §6.3–§6.5.

##### 4.3 [NEW] `src/static/js/dashboard.js`

IIFE controller following the `admin.js` pattern:

```javascript
(() => {
  "use strict";
  const byId = id => document.getElementById(id);
  const state = { tab: "preferences", bookmarkPage: 1, commentPage: 1, reactionPage: 1 };

  // ── API HELPER ──
  async function requestJson(url, options = {}) { ... }

  // ── TAB NAVIGATION ──
  function switchTab(tabName) { ... }

  // ── PREFERENCES ──
  async function loadPreferences() { ... }
  async function savePreferences() { ... }

  // ── MORNING BRIEF ──
  async function loadMorningBrief() { ... }
  async function markBriefRead(briefId) { ... }
  async function loadBriefPreferences() { ... }
  async function saveBriefPreferences() { ... }

  // ── BOOKMARKS ──
  async function loadBookmarks(page = 1) { ... }
  async function removeBookmark(bookmarkId) { ... }
  function filterBookmarksLocally(keyword) { ... }

  // ── COMMENTS ──
  async function loadComments(page = 1) { ... }
  async function deleteComment(commentId) { ... }

  // ── REACTIONS ──
  async function loadReactions(page = 1) { ... }
  async function removeReaction(reactionId) { ... }

  // ── EMPTY STATES ──
  function showEmptyState(panelId, message) { ... }

  // ── INIT ──
  document.addEventListener("DOMContentLoaded", () => {
    // Tab click handlers
    // Load initial tab data
    // Morning brief auto-fetch
    // Lucide icons re-render
  });
})();
```

Key behaviors:
- Uses `window.TMM.showToast()` from `core.js` for notifications.
- Tab switching uses `.classList.add("hide")` / `.classList.remove("hide")` pattern.
- Bookmark search is client-side filtering with a debounced input handler.
- "Remove" actions show a brief inline confirmation tooltip before calling the API.
- Pagination renders "Load More" buttons at the bottom of each list.

##### 4.4 [MODIFY] [`src/templates/article.html`](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/article.html)

Add a comment section and reaction bar below the article body (after line 33, before the meander separator):

```html
<!-- Reaction Bar -->
<div class="article-reactions" id="article-reactions">
  <button class="reaction-btn" id="btn-toggle-reaction" data-article-id="{{ article.id }}">
    <i data-lucide="thumbs-up"></i>
    <span id="reaction-count">0</span>
  </button>
</div>

<!-- Comment Section -->
<section class="article-comments" id="article-comments">
  <h3><i data-lucide="message-square"></i> Discussion</h3>
  <form id="comment-form" class="comment-compose hide">
    <textarea id="comment-input" placeholder="Share your thoughts..." maxlength="2000"></textarea>
    <button type="submit" class="btn-primary">Post Comment</button>
  </form>
  <div id="comment-list"></div>
</section>
```

The comment compose form is shown only when the user is authenticated (controlled by JS checking `window.TMM` auth state).

##### 4.5 [NEW] `src/templates/partials/_comment_section.html`

Optional — if the comment/reaction HTML is complex enough to warrant a partial. Otherwise, inline in `article.html`.

##### 4.6 [MODIFY] [`src/static/js/article.js`](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/js/article.js)

Add interaction handlers for:
- Loading comments on page load via `GET /api/articles/<id>/comments`
- Loading reaction summary via `GET /api/articles/<id>/reactions/summary`
- Posting new comments via `POST /api/articles/<id>/comments`
- Toggling reactions via `POST /api/articles/<id>/reactions`
- Show/hide comment form based on auth state

##### 4.7 [MODIFY] [`src/static/css/frontend.css`](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css)

Append ~400 new lines at the end of the file covering:

| CSS Section | Key Selectors |
|---|---|
| Dashboard Shell | `.dashboard-shell`, `.dashboard-tabs`, `.dashboard-tab`, `.dashboard-panel` |
| Morning Brief Card | `.morning-brief-card`, `.brief-header`, `.brief-content`, `.brief-bullets`, `.brief-sources` |
| Preferences Tab | `.preference-grid`, `.preference-card`, `.toggle-btn`, `.preferences-actions` |
| Bookmarks Tab | `.bookmarks-toolbar`, `.bookmark-list`, `.bookmark-card`, `.bookmark-thumb`, `.bookmark-meta` |
| Comments Tab | `.comment-history-list`, `.comment-history-card`, `.comment-article-ref`, `.comment-meta` |
| Reactions Tab | `.reaction-history-list`, `.reaction-history-card`, `.reaction-badge` |
| Empty States | `.empty-state`, `.empty-icon` |
| Article Comments | `.article-comments`, `.comment-compose`, `.comment-card`, `.article-reactions`, `.reaction-btn` |
| Brief Modal | `.modal-overlay`, `.modal-card`, `.modal-header`, `.modal-close` |
| Responsive | `@media (max-width: 768px)` — tab dropdown, card stacking |

Design tokens must match the existing editorial theme (spec §6.2): dark obsidian backgrounds, indigo accents, slate typography, glassmorphic card surfaces.

#### Acceptance Criteria

- Dashboard loads with 4 tabs and morning brief card.
- Tab switching is instant (no page reload).
- Preferences tab shows all categories/sources with correct toggle states.
- Bookmarks tab shows saved articles with search, sort, and remove.
- Comments tab shows user's comment history with delete capability.
- Reactions tab shows liked articles with remove capability.
- Article detail page shows comments and reaction button.
- All UI is responsive at 768px and 480px breakpoints.
- UI is visually consistent with the existing admin dashboard theme.

---

### Phase 5 — Verification & Regression Safety

**Objective**: Verify all features work end-to-end and no existing functionality is broken.

#### Work Items

##### 5.1 [NEW] `src/tests/test_dashboard.py`

Automated tests covering:

| Test Group | Test Cases |
|---|---|
| **Auth Guards** | All `/api/dashboard/*` endpoints return 401 without session |
| **Preferences** | GET returns correct subscription state; PUT atomically updates |
| **Bookmarks** | GET returns paginated list; DELETE removes with ownership check; Soft-deleted articles appear with `is_article_available: false` |
| **Comments** | POST creates comment; POST rejects XSS/overlength; DELETE soft-deletes; DELETE rejects non-owner |
| **Reactions** | POST toggles create/remove; GET summary returns correct counts; DELETE removes with ownership |
| **Brief** | GET latest returns most recent brief; POST mark-read updates flag |
| **Feed Personalization** | Homepage with logged-in user shows preferred articles first |

##### 5.2 Run Existing Tests

```powershell
cd src
venv\Scripts\Activate.ps1
pytest tests/ -v
```

Ensure no regressions in auth, profile, search, or admin features.

##### 5.3 Manual Verification Checklist

1. **Authentication Flow**: Login as a regular user → redirect to `/dashboard/user` ✓
2. **Admin Redirect**: Login as admin → `/dashboard/user` redirects to `/dashboard/admin` ✓
3. **Preferences**: Follow 2 categories + 1 source → save → homepage shows personalized feed ✓
4. **Bookmarks**: Navigate to feed → bookmark an article → Dashboard Bookmarks tab shows it → Remove → disappears ✓
5. **Bookmark Preservation**: Soft-delete an article via admin → bookmark still shows title ✓
6. **Comments**: Open article → post a comment → see it in the list → check Dashboard Comments tab → delete from dashboard ✓
7. **Reactions**: Open article → click Like → count increments → Dashboard Reactions tab shows it → click Unlike → removed ✓
8. **Morning Brief Card**: If a brief exists for today → card shows at dashboard top → "Mark as Read" works ✓
9. **Brief Preferences Modal**: Open → set time and frequency → save → confirm persisted ✓
10. **Empty States**: New user with no data → all tabs show polished empty states ✓
11. **Responsive**: Resize to mobile (375px) → tabs collapse, cards stack, no overflow ✓
12. **Existing Features**: Homepage feed, search, profile page, admin dashboard — all still work ✓

---

## Dependency Graph

```mermaid
flowchart LR
    P1["Phase 1<br/>DB Schema<br/>& Migration"]
    P2["Phase 2<br/>Service Layer"]
    P3["Phase 3<br/>Route Layer"]
    P4["Phase 4<br/>Frontend"]
    P5["Phase 5<br/>Verification"]

    P1 --> P2
    P2 --> P3
    P3 --> P4
    P4 --> P5

    P2 --> P2A["2.1 dashboard_service"]
    P2 --> P2B["2.2 comment_service"]
    P2 --> P2C["2.3 brief_service"]
    P2 --> P2D["2.4 article_service<br/>(personalization)"]
    P2 --> P2E["2.5 scheduler_service<br/>(cron job)"]

    P4 --> P4A["4.1 base.html<br/>(nav link)"]
    P4 --> P4B["4.2 dashboard.html<br/>(template)"]
    P4 --> P4C["4.3 dashboard.js<br/>(controller)"]
    P4 --> P4D["4.4 article.html<br/>(comments/reactions)"]
    P4 --> P4E["4.7 frontend.css<br/>(styles)"]
```

---

## Verification Plan

### Automated Verification

```powershell
cd src
venv\Scripts\Activate.ps1
# Run all tests including new dashboard tests
pytest tests/ -v --tb=short
# Run only dashboard tests
pytest tests/test_dashboard.py -v
```

### Manual Verification Checklist

- [ ] Regular user can access `/dashboard/user` and see a tabbed dashboard
- [ ] Preferences tab shows categories/sources with correct toggle states
- [ ] Saving preferences personalizes the homepage feed
- [ ] Bookmarks tab shows saved articles with search, sort, and pagination
- [ ] Bookmarks of soft-deleted articles show title with "unavailable" badge
- [ ] Comments tab shows user's comment history with delete
- [ ] Reactions tab shows liked articles with remove
- [ ] Article page shows working comment form and reaction button
- [ ] Morning Brief card appears when a brief exists
- [ ] Brief Preferences modal saves correctly
- [ ] All dashboard APIs return 401 for unauthenticated requests
- [ ] Ownership checks prevent cross-user data access
- [ ] Dashboard UI is responsive at mobile breakpoints
- [ ] No regression in existing homepage, search, profile, or admin features

---

## Risk Assessment

| Risk | Likelihood | Impact | Mitigation |
|---|---|---|---|
| LLM API key not configured | High (dev) | Brief generation fails | Fallback to raw article list; log warning on startup |
| Large user base slows brief generation | Low (MVP) | Job timeout | Process users sequentially with per-user error isolation |
| Bookmark cascade breaks on article hard-delete | Medium | Data loss | All FKs use `ON DELETE CASCADE`; soft-delete is the primary pattern |
| Frontend CSS conflicts with existing styles | Medium | Visual regression | All new selectors use `.dashboard-*` prefix namespace |
| Migration fails on Supabase | Low | Deploy blocked | Test migration on a staging DB first; include downgrade() |

---

**Estimated Effort**: 3-4 development days across all phases.

**Version**: 1.0.0 | **Author**: AI Planning Agent | **Date**: 2026-08-10
