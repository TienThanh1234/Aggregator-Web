# Tasks: User Dashboard (Bảng điều khiển Người dùng)

**Branch**: `009-user-dashboard` | **Spec**: [spec.md](spec.md) | **Plan**: [plan.md](plan.md)

---

## Phase 1: Database Schema Evolution & Migration

- [x] **T001**: Add `user_category_subscriptions` and `user_source_subscriptions` association tables to `models.py` (composite PK on `user_id` + `category_id`/`source_id`, `ON DELETE CASCADE`, `created_at` timestamp).
- [x] **T002**: Add `Comment` model to `models.py` (fields: `user_id`, `article_id`, `content`, `is_deleted`, `created_at`, `updated_at`; indexes on `user_id`, `article_id`, `created_at`; relationships to `User` and `Article` with cascade delete-orphan).
- [x] **T003**: Add `Reaction` model to `models.py` (fields: `user_id`, `article_id`, `reaction_type`; unique constraint `uq_user_article_reaction` on `(user_id, article_id)`; relationships to `User` and `Article` with cascade delete-orphan).
- [x] **T004**: Add `DailyBrief` model to `models.py` (fields: `user_id`, `content`, `source_article_ids`, `generated_at`, `brief_date`, `is_read`; unique constraint `uq_user_brief_date` on `(user_id, brief_date)`; relationship to `User` with cascade delete-orphan).
- [x] **T005**: Add `UserBriefPreference` model to `models.py` (fields: `user_id` UNIQUE, `is_enabled`, `delivery_time`, `frequency`, `email_delivery`, `updated_at`; one-to-one relationship to `User` via `uselist=False`).
- [x] **T006**: Extend `User` model in `models.py` with `subscribed_categories` and `subscribed_sources` relationships using the new association tables (lazy="subquery", dynamic backref on `Category` and `ScraperConfig`).
- [x] **T007**: Update model imports in `app.py` to include `Comment`, `Reaction`, `DailyBrief`, `UserBriefPreference`.
- [x] **T008**: Generate and apply Alembic migration (`flask db migrate -m "user_dashboard_schema"` → `flask db upgrade`). Verify all 6 new tables exist and existing data is intact.
- [x] **T009**: Add `google-generativeai` to `requirements.txt` and install in venv.
- [X] **T010**: Add `LLM_API_KEY`, `LLM_API_URL`, `LLM_MODEL` placeholder entries to `.env.example`.

---

## Phase 2: Service Layer — Dashboard, Comments & Brief

- [x] **T011**: Create `services/dashboard_service.py` — implement `get_user_preferences(user_id)` returning all categories (from `categories` table) and sources (from `scraper_configs` table) with `is_subscribed` boolean per user.
- [x] **T012**: Implement `update_user_preferences(user_id, category_ids, source_ids)` in `dashboard_service.py` — atomic subscription replacement using `DELETE + INSERT` in a single transaction. Invalid IDs silently filtered by inner-join validation.
- [x] **T013**: Implement `get_user_bookmarks(user_id, page, per_page, sort, keyword)` in `dashboard_service.py` — paginated bookmark query joining `Article` WITHOUT filtering `is_deleted` (soft-deleted articles remain visible with `is_article_available: false`). Support sort by `newest`/`oldest` and optional keyword search on article title.
- [x] **T014**: Implement `remove_bookmark(user_id, bookmark_id)` in `dashboard_service.py` — ownership-verified hard-delete of `Bookmark` record.
- [x] **T015**: Implement `get_user_comments(user_id, page, per_page)` and `delete_user_comment(user_id, comment_id)` in `dashboard_service.py` — paginated comment history with parent article metadata; ownership-verified soft-delete (`is_deleted = True`).
- [x] **T016**: Implement `get_user_reactions(user_id, page, per_page)` and `remove_user_reaction(user_id, reaction_id)` in `dashboard_service.py` — paginated reaction history with article metadata; ownership-verified hard-delete.
- [x] **T017**: Create `services/comment_service.py` — implement `create_comment(user_id, article_id, content)` with XSS sanitization via `markupsafe.escape()`, length validation (1–2000 chars), and article existence check.
- [x] **T018**: Implement `get_article_comments(article_id, page, per_page)` in `comment_service.py` — public paginated comment list excluding soft-deleted comments, with author info serialization (`id`, `username`, `full_name`, `avatar_url`).
- [x] **T019**: Implement `toggle_reaction(user_id, article_id, reaction_type)` in `comment_service.py` — idempotent toggle (create if not exists → return `"created"`, delete if exists → return `"removed"`). Return updated total reaction count.
- [x] **T020**: Implement `get_reaction_summary(article_id, user_id=None)` in `comment_service.py` — aggregate reaction count + optional `user_reacted` and `user_reaction_type` fields when `user_id` is provided.
- [X] **T021**: Create `services/brief_service.py` — implement `_call_llm_api(prompt)` using `google.generativeai` SDK with API key from `os.getenv("LLM_API_KEY")`, and `_build_fallback_brief(articles)` for raw article list fallback when LLM is unavailable.
- [X] **T022**: Implement `generate_daily_brief(user_id)` in `brief_service.py` — query top articles from last 24h matching user's subscribed categories/sources (or trending fallback if no subscriptions), call LLM API with prompt template from spec §5.2, persist `DailyBrief` record. Skip if brief already exists for today (`uq_user_brief_date`).
- [x] **T023**: Implement `generate_all_daily_briefs()` in `brief_service.py` — batch iterate all users with `UserBriefPreference.is_enabled = True`, call `generate_daily_brief()` per user with per-user error isolation. Optionally trigger email delivery via `email_service.py` if `email_delivery = True`.
- [x] **T024**: Implement `get_latest_brief(user_id)`, `mark_brief_read(user_id, brief_id)`, `get_brief_preferences(user_id)`, and `update_brief_preferences(user_id, prefs)` in `brief_service.py` — CRUD for brief retrieval, read-status update, and preference upsert with validation (`delivery_time` HH:MM, `frequency` daily/weekly).
- [x] **T025**: Modify `get_feed_articles()` in `article_service.py` — add optional `user_id` parameter. When provided, query user subscriptions and use SQLAlchemy `case()` expression to compute priority column (0=preferred, 1=general), `order_by(priority, published_at.desc())`. Category tab filter overrides preferences.
- [x] **T026**: Add `_daily_brief_job()` static method and `daily_brief_generator` CronTrigger (07:00 ICT) registration in `scheduler_service.py` `init_app()`, following the existing `_cleanup_job` pattern with Flask `app_context()`.
- [X] **T027**: Add `send_daily_brief_email(email, brief_content, brief_date)` function to `email_service.py` following the existing `smtplib` pattern from `send_password_reset_email()`.

---

## Phase 3: Route Layer — Page Route & 16 API Endpoints

- [x] **T028**: Add `GET /dashboard/user` page route in `routes.py` — auth guard redirecting unauthenticated users to login (`?auth_intent=login&next=/dashboard/user`), admin redirect to `/dashboard/admin`, render `dashboard.html` template with user data.
- [x] **T029**: Add Preferences API endpoints in `routes.py`:
  - `GET /api/dashboard/preferences` → delegates to `get_user_preferences(user_id)`.
  - `PUT /api/dashboard/preferences` → parses `category_ids` and `source_ids` from JSON body, delegates to `update_user_preferences(user_id, category_ids, source_ids)`.
- [x] **T030**: Add Daily Brief API endpoints in `routes.py`:
  - `GET /api/dashboard/brief/latest` → delegates to `get_latest_brief(user_id)`.
  - `POST /api/dashboard/brief/mark-read` → parses `brief_id` from JSON body, delegates to `mark_brief_read(user_id, brief_id)`.
  - `GET /api/dashboard/brief/preferences` → delegates to `get_brief_preferences(user_id)`.
  - `PUT /api/dashboard/brief/preferences` → parses and validates prefs from JSON body, delegates to `update_brief_preferences(user_id, prefs)`.
- [x] **T031**: Add Bookmark Ledger API endpoints in `routes.py`:
  - `GET /api/dashboard/bookmarks` → parses `page`, `per_page`, `sort`, `q` from query params, delegates to `get_user_bookmarks()`.
  - `DELETE /api/dashboard/bookmarks/<int:bookmark_id>` → delegates to `remove_bookmark(user_id, bookmark_id)`, returns 404 if not found/not owned.
- [x] **T032**: Add Community Interaction API endpoints in `routes.py`:
  - `GET /api/dashboard/comments` → paginated, delegates to `get_user_comments(user_id, page, per_page)`.
  - `DELETE /api/dashboard/comments/<int:comment_id>` → delegates to `delete_user_comment(user_id, comment_id)`, returns 403 if not owned.
  - `GET /api/dashboard/reactions` → paginated, delegates to `get_user_reactions(user_id, page, per_page)`.
  - `DELETE /api/dashboard/reactions/<int:reaction_id>` → delegates to `remove_user_reaction(user_id, reaction_id)`.
- [x] **T033**: Add Article-level interaction endpoints in `routes.py`:
  - `POST /api/articles/<int:article_id>/comments` → auth required, parses `content` from JSON, delegates to `create_comment()`, returns 201.
  - `GET /api/articles/<int:article_id>/comments` → public (no auth required), delegates to `get_article_comments()`.
  - `POST /api/articles/<int:article_id>/reactions` → auth required, parses `reaction_type`, delegates to `toggle_reaction()`.
  - `GET /api/articles/<int:article_id>/reactions/summary` → public, passes optional `user_id`, delegates to `get_reaction_summary()`.
- [x] **T034**: Modify homepage route (`GET /`) in `routes.py` to extract optional `user_id` from session and pass to `get_feed_articles(user_id=...)` for personalized feed ordering.

---

## Phase 4: Frontend — Template, Styles & JavaScript

- [x] **T035**: Add "My Dashboard" link in `base.html` header dropdown menu (after Admin Dashboard link, before Profile Settings). Conditionally shown for `role === "user"` via `core.js` `checkAuthState()` logic.
- [X] **T036**: Create `templates/dashboard.html` extending `base.html` — implement the Morning Brief card (header with sunrise icon, bullet-point content, "Mark as Read" button, expandable source article list via `<details>`).
- [x] **T037**: Implement tab navigation bar in `dashboard.html` — 4 tabs (Preferences, Bookmarks, Comments, Reactions) using `<button>` elements with `data-tab` attributes and Lucide icons, following the `admin.html` `data-tab` pattern.
- [x] **T038**: Implement Preferences tab panel in `dashboard.html` — category grid with toggle buttons (`class="toggle-btn"`, `aria-pressed`), source grid with domain labels and toggle buttons, and "Save Preferences" action button.
- [ ] **T039**: Implement Bookmarks tab panel in `dashboard.html` — search input with Lucide search icon, sort controls (Newest/Oldest buttons), bookmark card list container (`#bookmark-list`), and empty state with bookmark icon and CTA link to homepage.
- [x] **T040**: Implement Comments tab panel in `dashboard.html` — comment history list container (`#comment-list`), comment cards with article reference link, comment text, timestamp, and delete button. Empty state with message-square icon.
- [ ] **T041**: Implement Reactions tab panel in `dashboard.html` — reaction history list container (`#reaction-list`), reaction cards with thumbs-up badge, article link, timestamp, and remove button. Empty state with heart icon.
- [x] **T042**: Implement Brief Preferences modal in `dashboard.html` — overlay with form containing: enable toggle checkbox, delivery time input (`type="time"`), frequency select (daily/weekly), email delivery checkbox, and save button.
- [x] **T043**: Create `static/js/dashboard.js` — IIFE controller with `requestJson()` helper, tab switching logic (show/hide panels via `.classList.add/remove("hide")`), and DOMContentLoaded initialization with `lucide.createIcons()` call.
- [x] **T044**: Implement Preferences module in `dashboard.js` — `loadPreferences()` fetching `GET /api/dashboard/preferences`, rendering toggle cards, and `savePreferences()` collecting toggled IDs and calling `PUT /api/dashboard/preferences` with `window.TMM.showToast()` feedback.
- [x] **T045**: Implement Morning Brief module in `dashboard.js` — `loadMorningBrief()` fetching `GET /api/dashboard/brief/latest`, rendering bullet-point content or "preparing" placeholder, `markBriefRead(briefId)` calling `POST /api/dashboard/brief/mark-read`, and brief preferences modal open/save handlers.
- [X] **T046**: Implement Bookmarks module in `dashboard.js` — `loadBookmarks(page)` fetching `GET /api/dashboard/bookmarks`, rendering bookmark cards with image proxy thumbnails, `removeBookmark(id)` with fade-out animation, client-side search filtering via debounced input handler, sort toggle, and "Load More" pagination.
- [X] **T047**: Implement Comments module in `dashboard.js` — `loadComments(page)` fetching `GET /api/dashboard/comments`, rendering comment history cards, `deleteComment(id)` with inline confirmation tooltip and slide-up removal animation, and pagination.
- [X] **T048**: Implement Reactions module in `dashboard.js` — `loadReactions(page)` fetching `GET /api/dashboard/reactions`, rendering reaction cards with type badge, `removeReaction(id)` with removal animation, and pagination.
- [x] **T049**: Modify `article.html` — add reaction bar (thumbs-up button with count) and comment section (compose form with textarea + submit button, comment list container) below the article body text, before the meander separator.
- [x] **T050**: Modify `static/js/article.js` — add handlers for: loading comments on page load (`GET /api/articles/<id>/comments`), loading reaction summary (`GET /api/articles/<id>/reactions/summary`), posting new comments (`POST /api/articles/<id>/comments`), toggling reactions (`POST /api/articles/<id>/reactions`), and show/hide comment form based on auth state from `window.TMM`.
- [x] **T051**: Append dashboard-specific CSS to `frontend.css` — dashboard shell layout, tab navigation (active state with indigo border-bottom), morning brief card (gradient header, bullet list), preference grid and toggle buttons (active/inactive states), bookmark card list (thumbnail, metadata, remove button), comment/reaction history cards, empty states (centered icon + text), article comment section and reaction button, brief preferences modal, and responsive breakpoints (`@media max-width: 768px` for tab dropdown collapse and card stacking).
- [x] **T052**: Update `core.js` `checkAuthState()` function to toggle visibility of `#menu-item-user-dashboard` dropdown link based on `user.role === "user"`.

---

## Phase 5: Automated Testing & Verification

- [X] **T053**: Create `tests/test_dashboard.py` — auth guard tests verifying all `/api/dashboard/*` endpoints return HTTP 401 for unauthenticated requests.
- [X] **T054**: Add preferences API tests — `GET` returns correct subscription state for a user with/without subscriptions; `PUT` atomically replaces subscriptions and silently ignores invalid IDs.
- [X] **T055**: Add bookmark API tests — `GET` returns paginated bookmarks sorted by newest/oldest with search; `DELETE` removes owned bookmarks and returns 404 for non-owned; soft-deleted articles appear with `is_article_available: false`.
- [X] **T056**: Add comment API tests — `POST /api/articles/<id>/comments` creates comment and rejects empty/overlength/XSS content; `DELETE /api/dashboard/comments/<id>` soft-deletes owned comments and returns 403 for non-owned.
- [X] **T057**: Add reaction API tests — `POST /api/articles/<id>/reactions` toggles create/remove correctly; `GET summary` returns correct aggregate counts and `user_reacted` state; `DELETE /api/dashboard/reactions/<id>` removes owned reactions.
- [X] **T058**: Add feed personalization test — homepage with authenticated user having active subscriptions returns preferred articles before general articles; explicit category filter overrides preferences.
- [X] **T059**: Run full test suite (`pytest tests/ -v`) and verify zero regressions in existing auth, profile, search, and admin features.
- [X] **T060**: Perform end-to-end manual verification of all User Dashboard features: login redirect, all 4 tabs, morning brief card, preferences saving, bookmark management, comment/reaction CRUD on article page, responsive layout at 768px and 480px breakpoints.
