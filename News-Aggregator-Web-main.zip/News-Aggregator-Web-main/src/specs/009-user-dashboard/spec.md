# Feature Specification: User Dashboard (Bảng điều khiển Người dùng)

**Feature Branch**: `009-user-dashboard`  
**Created**: 2026-08-09  
**Status**: Draft  
**Target Specification Location**: `src/specs/009-user-dashboard/spec.md`  
**Constitution Authority**: Built strictly in compliance with [constitution.md](../../.specify/memory/constitution.md) (MVC Pattern, Flask-SQLAlchemy, Environment Configuration, Vanilla HTML5/CSS3/JS, Security Governance).

---

## 1. Executive Summary & Scope

The **User Dashboard** feature introduces a dedicated, authenticated control center for logged-in users of the Tell Me More News Aggregator. It transforms the reading experience from a passive, one-size-fits-all news feed into a personalized, interactive workspace.

This specification covers four interconnected feature groups:

1. **Preferences / Topic Channel Subscriptions** — Cho phép người dùng đăng ký theo dõi chủ đề và nguồn báo, hệ thống tự động điều chỉnh News Feed theo sở thích cá nhân.
2. **Personalized AI Daily Brief** — Bản tin tóm tắt AI tự động tổng hợp top tin nóng hổi nhất trong 24h dựa trên sở thích đã đăng ký.
3. **Personal Bookmark Ledger** — Không gian lưu trữ cá nhân để quản lý, tìm kiếm và sắp xếp bài viết đã lưu.
4. **Community Interactions** — Quản lý bình luận đã đăng và lịch sử phản hồi cảm xúc (Reactions) trên nền tảng.

### 1.1 Target URL & Entry Point

The User Dashboard will be accessible at `/dashboard/user` (confirmed via the existing `ROLE_REDIRECT_MAP` in [`auth_service.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/auth_service.py#L33-L37)). Upon login, users with `role == "user"` are already redirected to this path, but the route does not yet exist.

### 1.2 Relationship to Existing Features

| Existing Feature | Relationship |
|---|---|
| `004-user-profile-management` | User Dashboard extends the profile page with new dashboard tabs. Profile settings (name, email, avatar, password) remain under `/profile`. |
| `007-admin-dashboard` | Separate admin-only dashboard at `/dashboard/admin`. The User Dashboard follows similar route-guard and template patterns but is for `role == "user"`. |
| `003-account-authentication` | Relies on existing session management, `get_current_user()`, and `_get_authenticated_user_id()` helpers in `routes.py`. |
| `001-database-and-scraper` | Bookmark Ledger depends on the existing `Bookmark` model and `Article` model with `is_deleted` soft-delete flag. |

> [!NOTE]
> Per the project constitution, this specification defines backend contracts, database schema changes, security controls, and frontend GUI expectations. No implementation code is executed during this specification phase.

---

## 2. User Stories & Acceptance Criteria

### 2.1 User Story 1 — Topic & Source Preferences (Priority: P1)

**As a** registered user,  
**I want to** follow or unfollow specific news categories (e.g., Technology, Economy, Politics, Science) and individual news sources (e.g., VnExpress, Tuổi Trẻ),  
**So that** the homepage News Feed automatically prioritizes content I care about, eliminating information overload.

#### Acceptance Scenarios:

- **AS-PREF-01 (Preferences Load)**: Given an authenticated user visits the Dashboard Preferences tab, when the page loads, then the system displays all available categories (from `categories` table) and all registered sources (from `scraper_configs` table) with toggle states reflecting the user's current subscriptions.
- **AS-PREF-02 (Follow Category)**: Given the user toggles a category to "Follow", when the preference is saved, then the `user_category_subscriptions` association is created and the homepage feed immediately filters to include articles from that category.
- **AS-PREF-03 (Unfollow Category)**: Given the user toggles a category to "Unfollow", when the preference is saved, then the subscription row is removed and the homepage feed stops prioritizing that category.
- **AS-PREF-04 (Follow Source)**: Given the user toggles a source to "Follow", when the preference is saved, then the `user_source_subscriptions` association is created and articles from that source domain are prioritized in the feed.
- **AS-PREF-05 (Feed Personalization)**: Given a user with active preferences visits the homepage (`/`), when the feed loads, then articles matching at least one subscribed category or source are displayed first, followed by general content. Users with zero preferences see the default global feed.
- **AS-PREF-06 (Bulk Save)**: Given the user adjusts multiple preferences and clicks "Save Preferences", when the request completes, then all changes are persisted atomically and a success toast is displayed.

---

### 2.2 User Story 2 — Personalized AI Daily Brief (Priority: P2)

**As a** registered user with active preferences,  
**I want to** receive an AI-generated daily brief that summarizes the top stories from the past 24 hours matching my interests,  
**So that** I can catch up on the most important news in under 2 minutes every morning.

#### Acceptance Scenarios:

- **AS-BRIEF-01 (Daily Digest Generation)**: Given a user has active category/source subscriptions and the configured brief time arrives (default: 07:00 UTC+7), when the background scheduler triggers the digest job, then the system queries the top articles (by `truth_score` and cross-source coverage) published within the last 24 hours matching the user's preferences, sends them to the configured LLM API, and persists a 3–4 bullet-point summary as a `DailyBrief` record.
- **AS-BRIEF-02 (Dashboard Card Display)**: Given a fresh daily brief exists for the current day, when the user opens the Dashboard, then the brief is rendered as a prominent "Morning Brief" card at the top of the dashboard with bullet points, article links, and a generation timestamp.
- **AS-BRIEF-03 (Customizable Schedule)**: Given the user navigates to Brief Preferences in the Dashboard, when they set the delivery time (e.g., 07:00 AM) and frequency (Daily or Weekly), then the system updates `UserBriefPreference` and the scheduler adjusts accordingly.
- **AS-BRIEF-04 (Email Delivery — Optional)**: Given the user opts in to email delivery, when a brief is generated, then an email is sent via the existing `email_service.py` infrastructure with the brief content in a styled HTML template.
- **AS-BRIEF-05 (No Preferences Fallback)**: Given a user has no active subscriptions, when the brief job runs, then the system uses trending articles across all categories as the source pool instead of returning an empty brief.
- **AS-BRIEF-06 (LLM Unavailability Fallback)**: Given the LLM API is unreachable or returns an error, when the digest job runs, then the system falls back to displaying the top 5 article titles + descriptions without AI summarization, and logs the failure event.

---

### 2.3 User Story 3 — Personal Bookmark Ledger (Priority: P1)

**As a** registered user,  
**I want to** view, search, sort, and manage all articles I have bookmarked,  
**So that** I can maintain a personal reading library for future reference.

#### Acceptance Scenarios:

- **AS-BM-01 (Bookmark List Load)**: Given an authenticated user visits the Bookmarks tab, when the page loads, then all bookmarked articles are displayed as cards showing title, source, category badge, bookmark date, and a "Remove" action — sorted by "Ngày lưu mới nhất" by default.
- **AS-BM-02 (Sort Toggle)**: Given the bookmark list is displayed, when the user selects "Cũ nhất", then the list re-sorts in ascending `created_at` order. Selecting "Mới nhất" reverts to descending order.
- **AS-BM-03 (Search Within Bookmarks)**: Given the user types a keyword in the bookmark search field, when 2+ characters are entered, then the list is filtered client-side by article title matching (case-insensitive). For larger datasets, a server-side search API is available.
- **AS-BM-04 (Remove Bookmark)**: Given the user clicks "Remove" on a bookmarked article, when confirmed, then the `Bookmark` record is deleted from the database and the card is removed from the list with a fade-out animation.
- **AS-BM-05 (Soft-Deleted Article Preservation)**: Given an article has been soft-deleted (`is_deleted = True`) on the main feed, when it appears in the user's bookmark list, then the bookmark card still displays the preserved title and AI summary (from the `ai_summary` field), but links to the article detail page show a "This article is no longer available" message instead of a 404.
- **AS-BM-06 (Empty State)**: Given the user has no bookmarks, when they visit the Bookmarks tab, then a visually polished empty state is displayed with an illustration and a "Start saving articles from the feed" call-to-action link back to the homepage.
- **AS-BM-07 (Pagination)**: Given the user has more than 20 bookmarks, when they scroll to the bottom, then the system loads the next page of bookmarks (paginated, 20 per page).

---

### 2.4 User Story 4 — Community Interactions (Priority: P3)

**As a** registered user,  
**I want to** review my comment history and reaction (like/upvote) history from a dedicated dashboard section,  
**So that** I can manage my digital footprint and revisit discussions I participated in.

#### Acceptance Scenarios:

- **AS-CI-01 (Comment History)**: Given the user visits the "My Comments" tab, when the list loads, then all comments authored by the user are displayed in reverse chronological order, each showing the comment text, the parent article title (as a clickable link), and the posting timestamp.
- **AS-CI-02 (Navigate to Original Article)**: Given a comment entry is displayed, when the user clicks the article title, then the browser navigates to the corresponding article detail page (`/articles/<id>`).
- **AS-CI-03 (Delete Own Comment)**: Given a comment entry is displayed, when the user clicks "Delete" and confirms, then the comment is soft-deleted (or hard-deleted per policy), the entry is removed from the list, and a success toast is shown.
- **AS-CI-04 (Reaction History)**: Given the user visits the "My Reactions" tab, when the list loads, then all articles the user has reacted to (like/upvote) are displayed with the reaction type badge, article title, and reaction timestamp.
- **AS-CI-05 (Remove Reaction)**: Given a reaction entry is displayed, when the user clicks "Unlike" or "Remove", then the reaction record is deleted and the article's aggregate reaction count is decremented.
- **AS-CI-06 (Empty States)**: Given the user has no comments or reactions, then a polished empty-state illustration is displayed with an encouraging message.

---

## 3. Database Schema & Architecture (MVC Model Layer)

In compliance with Section II of `constitution.md`, all persistent data stays in the SQLAlchemy data model layer inside [`src/models.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py).

### 3.1 New Entities

#### 3.1.1 `UserCategorySubscription` (Association Table)

Links a `User` to followed `Category` records.

| Column | Data Type | Constraints | Description |
|---|---|---|---|
| `user_id` | `INTEGER` | PK, FK → `users.id`, ON DELETE CASCADE | Subscribing user |
| `category_id` | `INTEGER` | PK, FK → `categories.id`, ON DELETE CASCADE | Followed category |
| `created_at` | `TIMESTAMP` | NOT NULL, DEFAULT NOW | Subscription timestamp |

```python
user_category_subscriptions = db.Table(
    "user_category_subscriptions",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    db.Column("category_id", db.Integer, db.ForeignKey("categories.id", ondelete="CASCADE"), primary_key=True),
    db.Column("created_at", db.DateTime, nullable=False, default=lambda: datetime.utcnow()),
)
```

#### 3.1.2 `UserSourceSubscription` (Association Table)

Links a `User` to followed `ScraperConfig` (news source) records.

| Column | Data Type | Constraints | Description |
|---|---|---|---|
| `user_id` | `INTEGER` | PK, FK → `users.id`, ON DELETE CASCADE | Subscribing user |
| `source_id` | `INTEGER` | PK, FK → `scraper_configs.id`, ON DELETE CASCADE | Followed news source |
| `created_at` | `TIMESTAMP` | NOT NULL, DEFAULT NOW | Subscription timestamp |

```python
user_source_subscriptions = db.Table(
    "user_source_subscriptions",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    db.Column("source_id", db.Integer, db.ForeignKey("scraper_configs.id", ondelete="CASCADE"), primary_key=True),
    db.Column("created_at", db.DateTime, nullable=False, default=lambda: datetime.utcnow()),
)
```

#### 3.1.3 `Comment` Model

| Column | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | `INTEGER` | PK, Auto-increment | Unique comment identifier |
| `user_id` | `INTEGER` | FK → `users.id`, NOT NULL, INDEX | Comment author |
| `article_id` | `INTEGER` | FK → `articles.id` ON DELETE CASCADE, NOT NULL, INDEX | Parent article |
| `content` | `TEXT` | NOT NULL | Comment body text |
| `is_deleted` | `BOOLEAN` | NOT NULL, DEFAULT FALSE | Soft-delete flag |
| `created_at` | `TIMESTAMP` | NOT NULL, DEFAULT NOW, INDEX | Creation timestamp |
| `updated_at` | `TIMESTAMP` | Nullable, ON UPDATE NOW | Last edit timestamp |

```python
class Comment(db.Model):
    """Represents a user's comment on an article."""

    __tablename__ = "comments"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id", ondelete="CASCADE"), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    is_deleted = db.Column(db.Boolean, nullable=False, default=False)
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.utcnow(), index=True)
    updated_at = db.Column(db.DateTime, nullable=True, onupdate=lambda: datetime.utcnow())

    user = db.relationship("User", backref=db.backref("comments", lazy=True, cascade="all, delete-orphan"))
    article = db.relationship("Article", backref=db.backref("comments", lazy=True, cascade="all, delete-orphan"))
```

#### 3.1.4 `Reaction` Model

| Column | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | `INTEGER` | PK, Auto-increment | Unique reaction identifier |
| `user_id` | `INTEGER` | FK → `users.id`, NOT NULL, INDEX | Reacting user |
| `article_id` | `INTEGER` | FK → `articles.id` ON DELETE CASCADE, NOT NULL, INDEX | Target article |
| `reaction_type` | `VARCHAR(20)` | NOT NULL, DEFAULT "like" | Reaction type: `like`, `upvote` |
| `created_at` | `TIMESTAMP` | NOT NULL, DEFAULT NOW | Reaction timestamp |

**Unique Constraint**: (`user_id`, `article_id`) — one reaction per user per article.

```python
class Reaction(db.Model):
    """Represents a user's emotional response (like/upvote) to an article."""

    __tablename__ = "reactions"
    __table_args__ = (
        db.UniqueConstraint("user_id", "article_id", name="uq_user_article_reaction"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id", ondelete="CASCADE"), nullable=False, index=True)
    reaction_type = db.Column(db.String(20), nullable=False, default="like")
    created_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.utcnow())

    user = db.relationship("User", backref=db.backref("reactions", lazy=True, cascade="all, delete-orphan"))
    article = db.relationship("Article", backref=db.backref("reactions", lazy=True, cascade="all, delete-orphan"))
```

#### 3.1.5 `DailyBrief` Model

| Column | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | `INTEGER` | PK, Auto-increment | Unique brief identifier |
| `user_id` | `INTEGER` | FK → `users.id`, NOT NULL, INDEX | Target user |
| `content` | `TEXT` | NOT NULL | AI-generated brief content (Markdown bullet points) |
| `source_article_ids` | `TEXT` | Nullable | JSON array of article IDs used to generate the brief |
| `generated_at` | `TIMESTAMP` | NOT NULL, DEFAULT NOW, INDEX | Generation timestamp |
| `brief_date` | `DATE` | NOT NULL, INDEX | The date this brief covers |
| `is_read` | `BOOLEAN` | NOT NULL, DEFAULT FALSE | Read status tracking |

**Unique Constraint**: (`user_id`, `brief_date`) — one brief per user per day.

```python
class DailyBrief(db.Model):
    """Stores an AI-generated daily news digest for a specific user."""

    __tablename__ = "daily_briefs"
    __table_args__ = (
        db.UniqueConstraint("user_id", "brief_date", name="uq_user_brief_date"),
    )

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    source_article_ids = db.Column(db.Text, nullable=True)
    generated_at = db.Column(db.DateTime, nullable=False, default=lambda: datetime.utcnow(), index=True)
    brief_date = db.Column(db.Date, nullable=False, index=True)
    is_read = db.Column(db.Boolean, nullable=False, default=False)

    user = db.relationship("User", backref=db.backref("daily_briefs", lazy=True, cascade="all, delete-orphan"))
```

#### 3.1.6 `UserBriefPreference` Model

| Column | Data Type | Constraints | Description |
|---|---|---|---|
| `id` | `INTEGER` | PK, Auto-increment | Unique preference record |
| `user_id` | `INTEGER` | FK → `users.id`, UNIQUE, NOT NULL | Owner user (one record per user) |
| `is_enabled` | `BOOLEAN` | NOT NULL, DEFAULT TRUE | Brief generation toggle |
| `delivery_time` | `TIME` | NOT NULL, DEFAULT 07:00 | Preferred delivery time (UTC+7) |
| `frequency` | `VARCHAR(20)` | NOT NULL, DEFAULT "daily" | `daily` or `weekly` |
| `email_delivery` | `BOOLEAN` | NOT NULL, DEFAULT FALSE | Whether to send via email |
| `updated_at` | `TIMESTAMP` | DEFAULT NOW, ON UPDATE NOW | Last preference update |

```python
class UserBriefPreference(db.Model):
    """Stores per-user AI daily brief delivery preferences."""

    __tablename__ = "user_brief_preferences"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), unique=True, nullable=False)
    is_enabled = db.Column(db.Boolean, nullable=False, default=True)
    delivery_time = db.Column(db.Time, nullable=False, default=lambda: time(7, 0))
    frequency = db.Column(db.String(20), nullable=False, default="daily")
    email_delivery = db.Column(db.Boolean, nullable=False, default=False)
    updated_at = db.Column(db.DateTime, default=lambda: datetime.utcnow(), onupdate=lambda: datetime.utcnow())

    user = db.relationship("User", backref=db.backref("brief_preference", uselist=False))
```

### 3.2 Existing Entity Extensions

#### 3.2.1 `User` Model — New Relationships

Add the following relationships to the existing `User` model in [`models.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/models.py#L18-L48):

```python
# New relationships on User model
subscribed_categories = db.relationship(
    "Category",
    secondary=user_category_subscriptions,
    backref=db.backref("subscribed_users", lazy="dynamic"),
    lazy="subquery",
)
subscribed_sources = db.relationship(
    "ScraperConfig",
    secondary=user_source_subscriptions,
    backref=db.backref("subscribed_users", lazy="dynamic"),
    lazy="subquery",
)
```

### 3.3 Entity Relationship Diagram

```mermaid
erDiagram
    User ||--o{ UserCategorySubscription : subscribes
    User ||--o{ UserSourceSubscription : follows
    User ||--o{ Bookmark : saves
    User ||--o{ Comment : writes
    User ||--o{ Reaction : reacts
    User ||--o| UserBriefPreference : configures
    User ||--o{ DailyBrief : receives

    Category ||--o{ UserCategorySubscription : "followed by"
    ScraperConfig ||--o{ UserSourceSubscription : "followed by"

    Article ||--o{ Bookmark : "saved in"
    Article ||--o{ Comment : "discussed on"
    Article ||--o{ Reaction : "reacted to"
    Article ||--o{ DailyBrief : "summarized in"

    UserCategorySubscription {
        int user_id PK
        int category_id PK
        timestamp created_at
    }

    UserSourceSubscription {
        int user_id PK
        int source_id PK
        timestamp created_at
    }

    Comment {
        int id PK
        int user_id FK
        int article_id FK
        text content
        boolean is_deleted
        timestamp created_at
        timestamp updated_at
    }

    Reaction {
        int id PK
        int user_id FK
        int article_id FK
        varchar reaction_type
        timestamp created_at
    }

    DailyBrief {
        int id PK
        int user_id FK
        text content
        text source_article_ids
        timestamp generated_at
        date brief_date
        boolean is_read
    }

    UserBriefPreference {
        int id PK
        int user_id FK
        boolean is_enabled
        time delivery_time
        varchar frequency
        boolean email_delivery
    }
```

### 3.4 Migration Strategy

An Alembic migration file will be generated at:
```
src/migrations/versions/20260809_user_dashboard_schema.py
```

Migration operations:
1. Create `user_category_subscriptions` table
2. Create `user_source_subscriptions` table
3. Create `comments` table with indexes
4. Create `reactions` table with unique constraint and indexes
5. Create `daily_briefs` table with unique constraint and indexes
6. Create `user_brief_preferences` table

All tables use `ON DELETE CASCADE` for foreign keys referencing `users`, `articles`, `categories`, and `scraper_configs` to maintain referential integrity when parent records are removed.

---

## 4. API & Controller Specification (MVC Controller & Service Layer)

The route layer in [`src/routes.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/routes.py) remains thin and delegates business logic to new and existing service modules. All endpoints under `/api/dashboard/*` require authentication via the existing `_get_authenticated_user_id()` helper.

### 4.1 Dashboard Page Route

#### `GET /dashboard/user`

- **Description**: Renders the authenticated User Dashboard page with all tab content.
- **Guard**: Redirects to login if not authenticated. Redirects to `/dashboard/admin` if user is admin.
- **Template**: `dashboard.html`
- **Server-Side Data**: User profile, latest daily brief, bookmark count, comment count.

---

### 4.2 Preferences API Endpoints

#### 1. `GET /api/dashboard/preferences`

- **Description**: Returns the user's current category and source subscription state.
- **Response (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "categories": [
      { "id": 1, "name": "Economy", "is_subscribed": true },
      { "id": 2, "name": "Technology", "is_subscribed": false },
      { "id": 3, "name": "Politics", "is_subscribed": true },
      { "id": 4, "name": "Science", "is_subscribed": false }
    ],
    "sources": [
      { "id": 1, "name": "VnExpress", "domain": "vnexpress.net", "is_subscribed": true },
      { "id": 2, "name": "Tuổi Trẻ", "domain": "tuoitre.vn", "is_subscribed": false }
    ]
  }
}
```

#### 2. `PUT /api/dashboard/preferences`

- **Description**: Replaces the user's entire subscription set atomically.
- **Request Body**:
```json
{
  "category_ids": [1, 3],
  "source_ids": [1]
}
```
- **Response (200 OK)**:
```json
{
  "status": "success",
  "message": "Preferences updated successfully.",
  "data": {
    "subscribed_categories": 2,
    "subscribed_sources": 1
  }
}
```
- **Validation**: All IDs must reference existing records. Invalid IDs are silently ignored.

---

### 4.3 Daily Brief API Endpoints

#### 3. `GET /api/dashboard/brief/latest`

- **Description**: Returns the user's most recent daily brief.
- **Response (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "id": 42,
    "content": "• **Kinh tế:** VN-Index tăng 1.2% phiên sáng nhờ dòng tiền ngoại...\n• **Công nghệ:** Apple ra mắt chip M5 Ultra tại sự kiện WWDC...\n• **Thể thao:** Đội tuyển Việt Nam thắng 2-0 trận vòng loại World Cup...",
    "source_articles": [
      { "id": 101, "title": "VN-Index tăng mạnh phiên sáng", "canonical_path": "/articles/101" },
      { "id": 205, "title": "Apple WWDC 2026: Chip M5 Ultra", "canonical_path": "/articles/205" }
    ],
    "generated_at": "2026-08-09T07:00:00+07:00",
    "brief_date": "2026-08-09",
    "is_read": false
  }
}
```
- **Response (404)**: When no brief exists for the current period.

#### 4. `POST /api/dashboard/brief/mark-read`

- **Description**: Marks the latest daily brief as read.
- **Request Body**:
```json
{ "brief_id": 42 }
```
- **Response (200 OK)**:
```json
{ "status": "success", "message": "Brief marked as read." }
```

#### 5. `GET /api/dashboard/brief/preferences`

- **Description**: Returns the user's brief delivery preferences.
- **Response (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "is_enabled": true,
    "delivery_time": "07:00",
    "frequency": "daily",
    "email_delivery": false
  }
}
```

#### 6. `PUT /api/dashboard/brief/preferences`

- **Description**: Updates the user's brief delivery preferences.
- **Request Body**:
```json
{
  "is_enabled": true,
  "delivery_time": "07:00",
  "frequency": "daily",
  "email_delivery": true
}
```
- **Validation**:
  - `delivery_time` must be a valid HH:MM string (00:00–23:59).
  - `frequency` must be `"daily"` or `"weekly"`.
- **Response (200 OK)**:
```json
{ "status": "success", "message": "Brief preferences updated." }
```

---

### 4.4 Bookmark Ledger API Endpoints

#### 7. `GET /api/dashboard/bookmarks`

- **Description**: Returns the user's paginated bookmark list with article metadata.
- **Query Params**: `page` (default: 1), `per_page` (default: 20), `sort` (`newest` | `oldest`, default: `newest`), `q` (search keyword, optional).
- **Response (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "bookmarks": [
      {
        "bookmark_id": 15,
        "article_id": 101,
        "title": "VN-Index tăng mạnh phiên sáng",
        "summary": "Thị trường chứng khoán Việt Nam ghi nhận phiên tăng...",
        "category": "Economy",
        "source_domain": "vnexpress.net",
        "image": "/api/image-proxy?url=...",
        "bookmarked_at": "2026-08-08T14:30:00Z",
        "is_article_available": true,
        "canonical_path": "/articles/101"
      }
    ],
    "pagination": {
      "current_page": 1,
      "total_pages": 3,
      "total_items": 47
    }
  }
}
```
- **Note on Soft-Deleted Articles**: When `article.is_deleted == True`, the bookmark entry still appears with `is_article_available: false`. The title and AI summary are preserved from the stored `Article` record. The `canonical_path` links to the article but the article detail page will show an "unavailable" notice.

#### 8. `DELETE /api/dashboard/bookmarks/<int:bookmark_id>`

- **Description**: Removes a specific bookmark.
- **Response (200 OK)**:
```json
{ "status": "success", "message": "Bookmark removed." }
```
- **Response (404)**: Bookmark not found or does not belong to the authenticated user.

---

### 4.5 Community Interaction API Endpoints

#### 9. `GET /api/dashboard/comments`

- **Description**: Returns the authenticated user's comment history.
- **Query Params**: `page` (default: 1), `per_page` (default: 20).
- **Response (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "comments": [
      {
        "id": 88,
        "content": "Bài phân tích rất hay, cảm ơn tác giả!",
        "article_id": 101,
        "article_title": "VN-Index tăng mạnh phiên sáng",
        "article_path": "/articles/101",
        "created_at": "2026-08-07T10:15:00Z"
      }
    ],
    "pagination": {
      "current_page": 1,
      "total_pages": 1,
      "total_items": 5
    }
  }
}
```

#### 10. `DELETE /api/dashboard/comments/<int:comment_id>`

- **Description**: Soft-deletes a comment owned by the authenticated user.
- **Response (200 OK)**:
```json
{ "status": "success", "message": "Comment deleted." }
```
- **Response (403)**: Comment does not belong to the authenticated user.
- **Response (404)**: Comment not found.

#### 11. `GET /api/dashboard/reactions`

- **Description**: Returns articles the user has reacted to (liked/upvoted).
- **Query Params**: `page` (default: 1), `per_page` (default: 20).
- **Response (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "reactions": [
      {
        "id": 200,
        "reaction_type": "like",
        "article_id": 205,
        "article_title": "Apple WWDC 2026: Chip M5 Ultra",
        "article_path": "/articles/205",
        "reacted_at": "2026-08-06T18:45:00Z"
      }
    ],
    "pagination": {
      "current_page": 1,
      "total_pages": 1,
      "total_items": 12
    }
  }
}
```

#### 12. `DELETE /api/dashboard/reactions/<int:reaction_id>`

- **Description**: Removes a reaction owned by the authenticated user.
- **Response (200 OK)**:
```json
{ "status": "success", "message": "Reaction removed." }
```

---

### 4.6 Article-Level Interaction Endpoints (Public-Facing)

These endpoints power the comment/reaction UI on article detail pages, which feeds data into the Dashboard's Community Interactions view.

#### 13. `POST /api/articles/<int:article_id>/comments`

- **Description**: Adds a comment to an article.
- **Request Body**:
```json
{ "content": "Great analysis on the economic implications." }
```
- **Validation**: `content` must be 1–2000 characters, sanitized for XSS.
- **Response (201 Created)**:
```json
{
  "status": "success",
  "data": {
    "id": 89,
    "content": "Great analysis on the economic implications.",
    "created_at": "2026-08-09T12:00:00Z",
    "author": { "id": 5, "username": "johndoe", "avatar_url": "/static/uploads/avatars/5.png" }
  }
}
```

#### 14. `GET /api/articles/<int:article_id>/comments`

- **Description**: Returns paginated comments for an article (public, no auth required).
- **Query Params**: `page`, `per_page`.
- **Response**: Array of comment objects with author info.

#### 15. `POST /api/articles/<int:article_id>/reactions`

- **Description**: Toggles a reaction on an article (creates if not exists, removes if exists).
- **Request Body**:
```json
{ "reaction_type": "like" }
```
- **Response (200 OK)**:
```json
{
  "status": "success",
  "data": {
    "action": "created",
    "total_reactions": 15
  }
}
```

#### 16. `GET /api/articles/<int:article_id>/reactions/summary`

- **Description**: Returns aggregate reaction counts for an article (public).
- **Response**:
```json
{
  "status": "success",
  "data": {
    "total": 15,
    "user_reacted": true,
    "user_reaction_type": "like"
  }
}
```

---

### 4.7 Service Module Responsibilities

Following MVC Principle II, all business logic is delegated to service modules:

#### [NEW] `src/services/dashboard_service.py`

Primary service for dashboard data orchestration:
- `get_user_preferences(user_id)` → Returns current subscriptions with all available options.
- `update_user_preferences(user_id, category_ids, source_ids)` → Atomic subscription replacement.
- `get_user_bookmarks(user_id, page, per_page, sort, keyword)` → Paginated bookmark retrieval with article metadata.
- `remove_bookmark(user_id, bookmark_id)` → Ownership-verified bookmark deletion.
- `get_user_comments(user_id, page, per_page)` → Paginated comment history.
- `delete_user_comment(user_id, comment_id)` → Ownership-verified soft-delete.
- `get_user_reactions(user_id, page, per_page)` → Paginated reaction history.
- `remove_user_reaction(user_id, reaction_id)` → Ownership-verified reaction removal.

#### [NEW] `src/services/brief_service.py`

AI Daily Brief generation and management:
- `generate_daily_brief(user_id)` → Queries articles, calls LLM API, persists brief.
- `get_latest_brief(user_id)` → Returns the most recent brief.
- `mark_brief_read(user_id, brief_id)` → Updates read status.
- `get_brief_preferences(user_id)` → Returns delivery preferences.
- `update_brief_preferences(user_id, prefs)` → Updates delivery preferences.

#### [NEW] `src/services/comment_service.py`

Comment and reaction operations for article detail pages:
- `create_comment(user_id, article_id, content)` → Validated comment creation.
- `get_article_comments(article_id, page, per_page)` → Public paginated comments.
- `toggle_reaction(user_id, article_id, reaction_type)` → Idempotent toggle.
- `get_reaction_summary(article_id, user_id=None)` → Aggregate counts.

#### [MODIFY] `src/services/article_service.py`

Extend `get_feed_articles()` to accept an optional `user_id` parameter. When provided, the function queries the user's subscribed categories and sources to produce a personalized feed ordering:

```python
def get_feed_articles(
    category: str | None = None,
    page: int = 1,
    per_page: int = 20,
    user_id: int | None = None,  # NEW: for personalized feed
) -> tuple[list[dict[str, Any]], int, int]:
```

---

### 4.8 Feed Personalization Algorithm

When a logged-in user with active preferences visits the homepage:

1. **Query user's subscriptions** from `user_category_subscriptions` and `user_source_subscriptions`.
2. **If subscriptions exist**: Partition the feed query into two pools:
   - **Preferred Pool**: Articles matching at least one subscribed category OR originating from a subscribed source domain.
   - **General Pool**: All remaining articles.
3. **Ordering**: Preferred Pool articles appear first (sorted by `published_at DESC`), followed by General Pool articles.
4. **If no subscriptions**: Fall back to the existing default feed (no change in behavior).
5. **Category filter override**: If the user selects a specific category tab on the homepage, that explicit filter takes precedence over preferences.

---

## 5. Daily Brief Scheduler Integration

### 5.1 Background Job Architecture

The daily brief generation integrates with the existing APScheduler infrastructure in [`scheduler_service.py`](file:///c:/Users/user/Documents/repos/news-aggregator/src/services/scheduler_service.py).

#### New Scheduler Job: `daily_brief_generator`

```python
# Added to SchedulerService.init_app()
SchedulerService._scheduler.add_job(
    func=SchedulerService._daily_brief_job,
    trigger=CronTrigger(hour=7, minute=0, timezone="Asia/Ho_Chi_Minh"),
    id="daily_brief_generator",
    name="Daily AI Brief Generator",
    replace_existing=True,
    max_instances=1,
)
```

#### Job Execution Flow:

```mermaid
flowchart TD
    A["CronTrigger fires at 07:00 ICT"] --> B["Query all users with brief_preference.is_enabled = True"]
    B --> C{"For each user"}
    C --> D["Query subscribed categories & sources"]
    D --> E["Fetch top articles from last 24h matching preferences"]
    E --> F{"Articles found?"}
    F -->|Yes| G["Send article titles + summaries to LLM API"]
    F -->|No| H["Use trending articles as fallback"]
    H --> G
    G --> I{"LLM API success?"}
    I -->|Yes| J["Persist DailyBrief with AI-generated content"]
    I -->|No| K["Persist DailyBrief with raw article list fallback"]
    J --> L{"email_delivery enabled?"}
    K --> L
    L -->|Yes| M["Send brief via email_service"]
    L -->|No| N["Done for this user"]
    M --> N
    N --> C
```

### 5.2 LLM API Integration

#### Environment Configuration

Add to `.env.example`:
```
LLM_API_KEY=replace-with-llm-api-key
LLM_API_URL=https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent
LLM_MODEL=gemini-2.0-flash
```

#### LLM Prompt Template

```text
You are a news editor for "Tell Me More", a Vietnamese-English news aggregator.
Summarize the following {count} articles into a daily brief for the reader.

Rules:
- Write 3-4 concise bullet points in Vietnamese
- Each bullet should be 1-2 sentences maximum
- Group by topic category
- Prioritize impact and relevance
- Include the article ID reference in brackets after each bullet

Articles:
{article_summaries}
```

#### Fallback Behavior

If the LLM API is unreachable (timeout, 5xx, auth failure):
1. Log the error with `logger.error()`.
2. Generate a simple fallback brief: list the top 5 article titles with their descriptions.
3. Mark the brief with a `"fallback"` flag in `source_article_ids` JSON.

---

## 6. Frontend GUI Design & Existing Theme Alignment

The User Dashboard must follow the same premium neoclassical visual system established in [`index.html`](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/index.html), [`admin.html`](file:///c:/Users/user/Documents/repos/news-aggregator/src/templates/admin.html), and [`frontend.css`](file:///c:/Users/user/Documents/repos/news-aggregator/src/static/css/frontend.css).

### 6.1 Dashboard Layout Architecture

The dashboard follows a tab-based navigation pattern similar to the Admin Dashboard but designed for the user persona:

```
┌──────────────────────────────────────────────────────────────┐
│  HEADER (shared base.html — logo, nav, user avatar)          │
├──────────────────────────────────────────────────────────────┤
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  MORNING BRIEF CARD (prominent, full-width)             │ │
│  │  ▸ AI-generated summary bullets                         │ │
│  │  ▸ "View Sources" expandable                            │ │
│  │  ▸ "Mark as Read" action                                │ │
│  └─────────────────────────────────────────────────────────┘ │
│                                                              │
│  ┌──────┬────────────┬──────────┬──────────────┐            │
│  │ 📊   │ 📑         │ 💬       │ ❤️            │            │
│  │Prefer│ Bookmarks  │ Comments │ Reactions     │            │
│  │ences │            │          │               │            │
│  └──────┴────────────┴──────────┴──────────────┘            │
│                                                              │
│  ┌─────────────────────────────────────────────────────────┐ │
│  │  ACTIVE TAB CONTENT AREA                                │ │
│  │  (dynamic content loaded per selected tab)              │ │
│  └─────────────────────────────────────────────────────────┘ │
├──────────────────────────────────────────────────────────────┤
│  FOOTER                                                      │
└──────────────────────────────────────────────────────────────┘
```

### 6.2 Visual Design Constraints

Consistent with the existing design system:

| Token | Value | Usage |
|---|---|---|
| Background (page) | `#0F0F0F` – `#1A1A1A` | Dark obsidian base |
| Card surface | `rgba(255, 255, 255, 0.03)` | Glassmorphic card backgrounds |
| Card border | `rgba(255, 255, 255, 0.08)` | Subtle card borders |
| Primary accent | `#6366F1` (Indigo-500) | Active tab indicators, CTAs |
| Secondary accent | `#818CF8` (Indigo-400) | Hover states, links |
| Success | `#10B981` (Emerald-500) | Success toasts, follow badges |
| Text primary | `#F8FAFC` (Slate-50) | Headlines, card titles |
| Text secondary | `#94A3B8` (Slate-400) | Metadata, timestamps |
| Typography heading | `'Playfair Display', serif` | Card titles, brief heading |
| Typography body | `'Inter', sans-serif` | Body text, UI labels |

### 6.3 Tab Content Wireframes

#### Tab 1: Preferences

```html
<section class="dashboard-tab-content" id="tab-preferences">
  <div class="preferences-section">
    <h3 class="section-heading">
      <i data-lucide="layers"></i> Topic Categories
    </h3>
    <div class="preference-grid">
      <!-- Repeatable toggle cards for each category -->
      <div class="preference-card" data-category-id="1">
        <div class="preference-icon"><i data-lucide="bar-chart-2"></i></div>
        <span class="preference-name">Economy</span>
        <button class="toggle-btn active" aria-pressed="true">Following</button>
      </div>
      <!-- ... more category cards -->
    </div>
  </div>

  <div class="preferences-section">
    <h3 class="section-heading">
      <i data-lucide="newspaper"></i> News Sources
    </h3>
    <div class="preference-grid">
      <div class="preference-card" data-source-id="1">
        <span class="preference-name">VnExpress</span>
        <span class="preference-domain">vnexpress.net</span>
        <button class="toggle-btn" aria-pressed="false">Follow</button>
      </div>
    </div>
  </div>

  <div class="preferences-actions">
    <button id="btn-save-preferences" class="btn-primary">
      <i data-lucide="save"></i> Save Preferences
    </button>
  </div>
</section>
```

#### Tab 2: Bookmarks

```html
<section class="dashboard-tab-content" id="tab-bookmarks">
  <div class="bookmarks-toolbar">
    <div class="search-inline">
      <i data-lucide="search"></i>
      <input type="text" id="bookmark-search" placeholder="Search saved articles..." />
    </div>
    <div class="sort-controls">
      <button class="sort-btn active" data-sort="newest">Newest</button>
      <button class="sort-btn" data-sort="oldest">Oldest</button>
    </div>
  </div>

  <div class="bookmark-list" id="bookmark-list">
    <!-- Dynamically populated bookmark cards -->
    <div class="bookmark-card">
      <img class="bookmark-thumb" src="/api/image-proxy?url=..." alt="..." />
      <div class="bookmark-info">
        <span class="bookmark-category-badge">Economy</span>
        <h4 class="bookmark-title">
          <a href="/articles/101">VN-Index tăng mạnh phiên sáng</a>
        </h4>
        <p class="bookmark-summary">Thị trường chứng khoán...</p>
        <div class="bookmark-meta">
          <span><i data-lucide="clock"></i> Saved 2 days ago</span>
          <span class="bookmark-source">vnexpress.net</span>
        </div>
      </div>
      <button class="btn-remove-bookmark" data-bookmark-id="15">
        <i data-lucide="x"></i>
      </button>
    </div>
  </div>

  <!-- Empty state (hidden by default) -->
  <div class="empty-state" id="bookmarks-empty" style="display: none;">
    <i data-lucide="bookmark" class="empty-icon"></i>
    <h3>No saved articles yet</h3>
    <p>Start saving articles from the <a href="/">news feed</a> to build your personal library.</p>
  </div>
</section>
```

#### Tab 3: Comments

```html
<section class="dashboard-tab-content" id="tab-comments">
  <div class="comment-history-list" id="comment-list">
    <div class="comment-history-card">
      <div class="comment-article-ref">
        <i data-lucide="file-text"></i>
        <a href="/articles/101" class="comment-article-link">VN-Index tăng mạnh phiên sáng</a>
      </div>
      <p class="comment-content">"Bài phân tích rất hay, cảm ơn tác giả!"</p>
      <div class="comment-meta">
        <span><i data-lucide="clock"></i> 2 days ago</span>
        <button class="btn-delete-comment" data-comment-id="88">
          <i data-lucide="trash-2"></i> Delete
        </button>
      </div>
    </div>
  </div>
</section>
```

#### Tab 4: Reactions

```html
<section class="dashboard-tab-content" id="tab-reactions">
  <div class="reaction-history-list" id="reaction-list">
    <div class="reaction-history-card">
      <div class="reaction-badge like">
        <i data-lucide="thumbs-up"></i>
      </div>
      <div class="reaction-info">
        <a href="/articles/205" class="reaction-article-link">Apple WWDC 2026: Chip M5 Ultra</a>
        <span class="reaction-meta"><i data-lucide="clock"></i> 3 days ago</span>
      </div>
      <button class="btn-remove-reaction" data-reaction-id="200">
        <i data-lucide="x-circle"></i> Remove
      </button>
    </div>
  </div>
</section>
```

### 6.4 Morning Brief Card Design

The daily brief card is a standalone component rendered above the tab system:

```html
<div class="morning-brief-card" id="morning-brief">
  <div class="brief-header">
    <div class="brief-icon-wrap">
      <i data-lucide="sunrise"></i>
    </div>
    <div>
      <h2 class="brief-title">Morning Brief</h2>
      <span class="brief-date">August 9, 2026 • Generated at 7:00 AM</span>
    </div>
    <button class="btn-mark-read" id="btn-mark-read" data-brief-id="42">
      <i data-lucide="check-circle"></i> Mark as Read
    </button>
  </div>
  <div class="brief-content">
    <!-- AI-generated markdown rendered as HTML bullet points -->
    <ul class="brief-bullets">
      <li><strong>Kinh tế:</strong> VN-Index tăng 1.2% phiên sáng nhờ dòng tiền ngoại... <a href="/articles/101">[Source]</a></li>
      <li><strong>Công nghệ:</strong> Apple ra mắt chip M5 Ultra tại sự kiện WWDC... <a href="/articles/205">[Source]</a></li>
      <li><strong>Thể thao:</strong> Đội tuyển Việt Nam thắng 2-0 trận vòng loại... <a href="/articles/310">[Source]</a></li>
    </ul>
  </div>
  <details class="brief-sources">
    <summary>View source articles (5)</summary>
    <ul class="brief-source-list">
      <li><a href="/articles/101">VN-Index tăng mạnh phiên sáng</a> — vnexpress.net</li>
      <li><a href="/articles/205">Apple WWDC 2026: Chip M5 Ultra</a> — tuoitre.vn</li>
    </ul>
  </details>
</div>
```

### 6.5 Brief Preferences Modal

```html
<div class="modal-overlay" id="brief-prefs-modal" style="display: none;">
  <div class="modal-card">
    <div class="modal-header">
      <h3><i data-lucide="settings"></i> Brief Preferences</h3>
      <button class="modal-close" id="close-brief-prefs"><i data-lucide="x"></i></button>
    </div>
    <form id="form-brief-preferences">
      <div class="form-group">
        <label>Enable Daily Brief</label>
        <input type="checkbox" id="brief-enabled" checked />
      </div>
      <div class="form-group">
        <label for="brief-time">Delivery Time</label>
        <input type="time" id="brief-time" value="07:00" />
      </div>
      <div class="form-group">
        <label for="brief-frequency">Frequency</label>
        <select id="brief-frequency">
          <option value="daily" selected>Daily</option>
          <option value="weekly">Weekly</option>
        </select>
      </div>
      <div class="form-group">
        <label>Email Delivery</label>
        <input type="checkbox" id="brief-email" />
      </div>
      <button type="submit" class="btn-primary">Save Preferences</button>
    </form>
  </div>
</div>
```

### 6.6 Frontend Interaction Requirements

1. **Tab Navigation**: Clicking a tab shows/hides content areas without page reload. Active tab is highlighted with the indigo accent border-bottom.
2. **Preference Toggles**: Clicking a toggle button changes its visual state immediately (optimistic UI). The "Save Preferences" button submits all changes as a single API call.
3. **Bookmark Actions**: "Remove" triggers a confirmation micro-animation and calls `DELETE /api/dashboard/bookmarks/<id>`. The card fades out on success.
4. **Comment/Reaction Deletion**: Inline confirmation with a brief "Are you sure?" tooltip. On success, the entry slides up and disappears.
5. **Morning Brief**: Auto-fetched on dashboard load. If no brief exists, the card displays a "Your brief is being prepared" placeholder with a subtle loading animation.
6. **Toasts**: Success and error toasts use the existing notification pattern from the profile page.
7. **Empty States**: All tabs display a styled empty state with relevant Lucide icon, heading, and CTA when no data exists.
8. **Responsive Design**: Dashboard must be fully responsive. On mobile (<768px), tabs collapse into a dropdown selector. Bookmark and comment cards stack vertically.

---

## 7. Security & Compliance Controls

### 7.1 Authentication & Authorization

- All `/api/dashboard/*` endpoints MUST verify authentication via `_get_authenticated_user_id()`.
- All data-modifying operations (delete bookmark, delete comment, remove reaction) MUST verify ownership: the authenticated `user_id` must match the record's `user_id`.
- The `/dashboard/user` page route MUST redirect unauthenticated users to login with `next=/dashboard/user`.
- Users with `role == "admin"` accessing `/dashboard/user` should be redirected to `/dashboard/admin`.

### 7.2 Input Validation & Sanitization

- Comment content MUST be sanitized to prevent XSS attacks. Strip HTML tags, escape special characters.
- Comment length MUST be enforced: minimum 1 character, maximum 2000 characters.
- Preference `category_ids` and `source_ids` MUST be validated as arrays of positive integers.
- Brief delivery time MUST be validated as a valid time string.
- All integer path parameters (`bookmark_id`, `comment_id`, `reaction_id`) MUST be validated as positive integers.

### 7.3 Rate Limiting

- Comment creation: Maximum 10 comments per user per 5-minute window (application-level).
- Reaction toggling: Maximum 30 reactions per user per minute (application-level).
- Brief preference updates: Maximum 5 updates per user per hour.

### 7.4 Data Privacy

- Users MUST only be able to view and manage their own data (bookmarks, comments, reactions, briefs).
- Comment deletion soft-deletes the record (`is_deleted = True`) to preserve referential integrity for admin audit trails.
- User account deletion (when implemented) MUST cascade-delete all associated dashboard data via the `ON DELETE CASCADE` foreign keys.

### 7.5 LLM API Security

- The LLM API key MUST be stored exclusively in `.env` per constitution.md Section III.
- User-generated content MUST NOT be sent to the LLM API. Only article titles and summaries (system-curated content) are sent.
- LLM API responses MUST be sanitized before storage and rendering.

---

## 8. Files to be Created / Modified

### [NEW] `src/services/dashboard_service.py`
- Contains business logic for preferences, bookmark management, comment history, and reaction history operations.

### [NEW] `src/services/brief_service.py`
- Contains AI daily brief generation, LLM API integration, and brief preference management.

### [NEW] `src/services/comment_service.py`
- Contains comment CRUD operations and reaction toggle logic for article detail pages.

### [NEW] `src/templates/dashboard.html`
- User Dashboard template extending `base.html` with tab navigation, morning brief card, and four tab content areas.

### [NEW] `src/static/js/dashboard.js`
- Client-side JavaScript for tab switching, preference toggles, bookmark/comment/reaction management, brief interaction, and API communication.

### [NEW] `src/migrations/versions/20260809_user_dashboard_schema.py`
- Alembic migration creating all new tables: `user_category_subscriptions`, `user_source_subscriptions`, `comments`, `reactions`, `daily_briefs`, `user_brief_preferences`.

---

### [MODIFY] `src/models.py`
- Add new model definitions: `Comment`, `Reaction`, `DailyBrief`, `UserBriefPreference`.
- Add new association tables: `user_category_subscriptions`, `user_source_subscriptions`.
- Extend `User` model with new relationships.

### [MODIFY] `src/routes.py`
- Add `GET /dashboard/user` page route with auth guard.
- Add all 16 API endpoints defined in Section 4.
- Import new service modules.

### [MODIFY] `src/services/article_service.py`
- Extend `get_feed_articles()` with optional `user_id` parameter for personalized feed.

### [MODIFY] `src/services/scheduler_service.py`
- Register the `daily_brief_generator` cron job in `init_app()`.
- Add `_daily_brief_job()` static method.

### [MODIFY] `src/static/css/frontend.css`
- Add dashboard-specific styles: tab navigation, preference cards, bookmark list, comment history, reaction history, morning brief card, empty states, modal, responsive breakpoints.

### [MODIFY] `src/templates/base.html`
- Add "Dashboard" link in the authenticated user navigation dropdown.

### [MODIFY] `src/templates/article.html`
- Add comment section and reaction buttons to the article detail page.

### [MODIFY] `src/.env.example`
- Add `LLM_API_KEY`, `LLM_API_URL`, `LLM_MODEL` environment variable placeholders.

### [MODIFY] `src/requirements.txt`
- Add `google-generativeai` (or equivalent LLM client library) if using the Gemini API directly.

---

## 9. Success Criteria

| ID | Criterion | Measurement |
|---|---|---|
| **SC-UD-001** | A logged-in user can access `/dashboard/user` and see a tabbed dashboard with Morning Brief, Preferences, Bookmarks, Comments, and Reactions sections. | Manual verification |
| **SC-UD-002** | A user can follow/unfollow categories and sources, and the homepage feed immediately reflects the personalized ordering. | Automated test + manual verification |
| **SC-UD-003** | The AI Daily Brief is generated at the configured time, contains 3-4 relevant bullet points, and appears as a card on the dashboard. | Scheduler log + manual verification |
| **SC-UD-004** | If the LLM API is unavailable, the brief falls back to a raw article list without errors. | Integration test with mocked LLM failure |
| **SC-UD-005** | Bookmarks of soft-deleted articles still display title and summary in the Bookmark Ledger. | Automated test |
| **SC-UD-006** | Users can search, sort (newest/oldest), and paginate through their bookmark list. | Manual verification |
| **SC-UD-007** | Users can view their comment history and navigate directly to the original article. | Manual verification |
| **SC-UD-008** | Users can delete their own comments but cannot delete other users' comments. | Security test |
| **SC-UD-009** | Reaction toggle creates/removes reactions correctly and updates aggregate counts. | Automated test |
| **SC-UD-010** | All dashboard API endpoints reject unauthenticated requests with HTTP 401. | Automated test |
| **SC-UD-011** | Comment content is sanitized to prevent XSS before storage and rendering. | Security test |
| **SC-UD-012** | The dashboard UI is fully responsive and visually consistent with the existing editorial theme. | Cross-device manual verification |

---

## 10. Notes for Implementation Planning

### 10.1 Implementation Phasing

Given the scope of 4 feature groups, implementation should be phased:

| Phase | Features | Dependencies |
|---|---|---|
| **Phase A** | Database schema migration + Preferences API + Bookmark Ledger API | Existing `Bookmark` model, `Category`, `ScraperConfig` |
| **Phase B** | Dashboard page + Tab UI + Preferences frontend + Bookmarks frontend | Phase A APIs |
| **Phase C** | Comment & Reaction models + Article-level endpoints + Community tab UI | Phase B dashboard shell |
| **Phase D** | AI Daily Brief — LLM integration, scheduler job, brief card UI | Phase A preferences + LLM API key |

### 10.2 Key Technical Decisions

1. **Feed Personalization Strategy**: The specification uses a two-pool approach (Preferred + General) rather than a strict filter. This ensures users always see some content even if their preferences don't match many articles. This is a deliberate UX choice to avoid "empty feed" situations.

2. **Comment Soft-Delete vs Hard-Delete**: Comments are soft-deleted (`is_deleted = True`) to preserve discussion context and enable admin audit trails. This aligns with the existing `Article.is_deleted` pattern used in the admin dashboard.

3. **Reaction Toggle Pattern**: The `POST /api/articles/<id>/reactions` endpoint uses a toggle pattern (create-or-remove) rather than separate create/delete endpoints. This simplifies the frontend implementation and provides a more intuitive API.

4. **LLM Fallback**: The specification mandates a graceful fallback when the LLM API is unavailable, ensuring the daily brief feature never completely fails. This aligns with constitution.md Principle VI (Error Handling & Resilience).

5. **Bookmark Preservation**: Soft-deleted articles remain visible in bookmarks (with preserved metadata) to respect the user's curation effort. This is a deliberate design choice that requires joining on the `Article` record regardless of `is_deleted` status when querying bookmarks.

### 10.3 Out of Scope

- Push notification delivery (browser Web Push API) — deferred to a future enhancement.
- Comment threading / reply chains — comments are flat for MVP.
- Rich text formatting in comments — plain text only for MVP.
- Reaction types beyond "like" — single reaction type for MVP, extensible via `reaction_type` column.
- Article recommendation engine (ML-based) — preferences provide basic personalization only.

---

**Version**: 1.0.0 | **Author**: AI Specification Agent | **Date**: 2026-08-09

---

*This specification is the governing document for the User Dashboard feature group. All implementation work must conform to the contracts, schema definitions, and behavioral requirements defined herein.*
