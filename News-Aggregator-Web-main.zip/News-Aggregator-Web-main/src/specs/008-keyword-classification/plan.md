# Implementation Plan: Keyword Mapping Classification

**Branch**: `008-keyword-classification` | **Date**: 2026-08-05 | **Spec**: [spec.md](spec.md)

**Input**: Feature specification from `/specs/008-keyword-classification/spec.md`

## Summary

This feature replaces the arbitrary auto-creation of categories during the article scraping process. Instead, we will define a fixed list of categories and a mapping mechanism (via a new `KeywordRule` database table) that scans the title, tags, and description of incoming articles to assign them to one or more predefined categories.

## Technical Context

**Language/Version**: Python 3.11+

**Primary Dependencies**: Flask, Flask-SQLAlchemy, Alembic

**Storage**: PostgreSQL

**Testing**: pytest

**Target Platform**: Linux server (WSGI/Gunicorn)

**Project Type**: web-service (News Aggregator)

**Performance Goals**: Keyword matching for a single article must complete in < 100ms.

**Constraints**: Strict MVC enforcement (no business logic in routes or views), backward compatibility with existing scraping modules.

**Scale/Scope**: Support for at least 100 keywords per category without performance degradation.

## Constitution Check

*GATE: Must pass before Phase 0 research. Re-check after Phase 1 design.*

- **MVC Pattern Enforcement**: PASSED. Keyword mapping logic will reside in a new service class (`ClassificationService`) rather than in routes or scraper base classes.
- **Data Integrity & Duplicate Prevention**: PASSED. Changes do not affect the duplicate checking mechanism, but improve category data integrity.
- **Configuration & Logging**: PASSED.

## Project Structure

### Documentation (this feature)

```text
specs/008-keyword-classification/
├── plan.md              # This file (/speckit.plan command output)
├── research.md          # Phase 0 output (/speckit.plan command)
├── data-model.md        # Phase 1 output (/speckit.plan command)
├── quickstart.md        # Phase 1 output (/speckit.plan command)
└── tasks.md             # Phase 2 output (/speckit.tasks command - NOT created by /speckit.plan)
```

### Source Code (repository root)

```text
src/
├── models.py                     # Add KeywordRule model
├── migrations/                   # Generate Alembic migration for new table
├── scraper/
│   └── dynamic_scraper.py        # Remove default category extraction logic if necessary
└── services/
    ├── scraper_service.py        # Remove category auto-creation; integrate classification
    └── classification_service.py # NEW: Implements keyword matching logic
```

**Structure Decision**: A single project layout using the existing standard MVC directories. Logic is encapsulated in `classification_service.py` to maintain modularity.

## Complexity Tracking

> **Fill ONLY if Constitution Check has violations that must be justified**

N/A
