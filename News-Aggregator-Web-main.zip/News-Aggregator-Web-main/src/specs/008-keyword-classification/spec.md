# Feature Specification: Keyword Mapping Classification

**Feature Branch**: `008-keyword-classification`

**Created**: 2026-08-05

**Status**: Draft

**Input**: User description: "Đặc tả tính năng phân loại bài báo sử dụng keyword mapping."

## User Scenarios & Testing *(mandatory)*

### User Story 1 - Automatic Article Classification via Keywords (Priority: P1)

The system automatically analyzes the title, description, and tags of a newly scraped article. It then checks these against a predefined set of keywords to classify the article into its corresponding fixed category.

**Why this priority**: This is the core of the feature. It reduces the manual effort of classification and cleans up junk data in the categories table.

**Independent Test**: This can be tested independently by mocking an article payload containing specific keywords and verifying that the system assigns the expected category.

**Acceptance Scenarios**:

1. **Given** an article containing the word "smartphone" or "AI", **When** the system saves the article, **Then** the article is automatically assigned to the "Technology" category.
2. **Given** an article containing no keywords that match the dictionary, **When** the system saves the article, **Then** the article is automatically assigned to a default category (e.g., "Miscellaneous").

---

### User Story 2 - Keyword and Category Configuration Management (Priority: P2)

Administrators can define and update the dictionary (mapping) between keywords and fixed categories, allowing the system to classify articles more flexibly and accurately over time without requiring code changes.

**Why this priority**: Essential for the long-term maintenance, expansion, and accuracy improvement of the classification feature.

**Independent Test**: An admin changes a keyword mapping, and the system immediately applies the new rule to newly scraped articles.

**Acceptance Scenarios**:

1. **Given** the dictionary lacks a rule for "football", **When** an admin adds the keyword "football" mapped to the "Sports" category, **Then** subsequent articles containing the word "football" are automatically assigned to the "Sports" category.

### Edge Cases

- How does the system handle an article containing multiple keywords belonging to different categories (e.g., containing both "technology" and "business")? -> **Decision**: Assign the article to all matched fixed categories (an article can belong to multiple categories).
- Is keyword matching case-sensitive or case-insensitive? -> **Decision**: Case-insensitive.

## Requirements *(mandatory)*

### Functional Requirements

- **FR-001**: The system MUST support defining a list of fixed categories.
- **FR-002**: The system MUST store and retrieve mapping rules (keyword -> fixed category).
- **FR-003**: When processing a scraped article, the system MUST extract relevant fields (title, tags, description) and search for matching keywords based on the mapping rules.
- **FR-004**: The system MUST bypass the arbitrary automatic `Category` creation mechanism of the legacy scraper (`DynamicScraper`).
- **FR-005**: If an article matches the rules, the system MUST assign it to the corresponding category (or categories). Otherwise, it MUST assign it to the "Miscellaneous" category or a default category designated by the Admin.

### Key Entities *(include if feature involves data)*

- **Category**: Fixed category (already exists but needs standardization).
- **KeywordRule (or ClassificationRule)**: The mapping rule from a list of keywords to a specific `Category`.

## Success Criteria *(mandatory)*

### Measurable Outcomes

- **SC-001**: The category data does not grow uncontrollably; 100% of scraped articles are saved into categories from the controlled list (fixed categories).
- **SC-002**: The processing time for keyword mapping classification of a single article takes under 100ms.
- **SC-003**: The system easily supports configuring at least 100 keywords per category without degrading scraping performance.

## Assumptions

- Keyword searching will be performed case-insensitively.
- The fixed categories will be pre-seeded via a script or the Admin interface.
- Since the source articles are in Vietnamese, the configured keywords will also be optimized for Vietnamese text.
