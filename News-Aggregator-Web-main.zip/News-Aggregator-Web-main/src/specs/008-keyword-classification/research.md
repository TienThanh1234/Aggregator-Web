# Keyword Mapping Classification Research

## 1. Efficient Keyword Matching in Python

**Decision**: Use pre-compiled Regular Expressions (Regex) or simple word boundary matching with `.lower()` for keyword matching. 
**Rationale**: We need to process an article in under 100ms. Since we anticipate around 100 keywords per category, simple string searching or regex is well within performance limits. Regex with word boundaries `\b` ensures we don't accidentally match sub-words (e.g., matching "art" inside "smart").
**Alternatives considered**: 
- *Aho-Corasick algorithm (FlashText)*: Highly performant for thousands of keywords, but adds an external dependency and is overkill for the MVP scale (~100s of keywords).
- *Full-text search (tsvector in PostgreSQL)*: Good for DB searches, but here we are mapping scraped text in memory before inserting.

## 2. Preventing Auto-Creation of Categories

**Decision**: Modify `scraper_service.py` to stop automatically instantiating and adding `Category` records for arbitrary strings returned by scrapers. Implement a `ClassificationService` that takes the raw text/tags and returns a list of mapped `Category` objects.
**Rationale**: Adheres to the Constitution (MVC enforcement), placing business logic in `services/`.
**Alternatives considered**: 
- *Modifying `DynamicScraper` directly*: Rejected because the scraper's job is just data extraction, while categorization is a business logic concern that belongs in the service layer.

## 3. Database Schema for Keyword Rules

**Decision**: Create a new `KeywordRule` (or `ClassificationRule`) table that maps a keyword string to a `category_id`.
**Rationale**: Allows Admins to add/remove keywords dynamically without touching code or redeploying.
**Alternatives considered**: 
- *Hardcoding in Python dictionary*: Fast, but violates the requirement (User Story 2) that Admins can manage the configuration.
- *JSON column in Category table*: Harder to query and manage individually compared to a dedicated rules table.
