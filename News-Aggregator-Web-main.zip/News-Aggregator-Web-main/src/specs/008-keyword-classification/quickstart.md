# Keyword Mapping Classification - Validation Guide

This guide documents how to manually validate that the keyword mapping classification feature works end-to-end.

## Prerequisites

1. The Flask application is configured and running.
2. The database is initialized and migrations have been run.

## Setup Commands

1. **Seed the Database with Test Data:**
   Use the Flask shell to insert test categories and keyword rules.
   ```bash
   flask shell
   ```
   ```python
   from models import db, Category, KeywordRule
   
   # Ensure categories exist
   tech = Category.query.filter_by(name="Technology").first() or Category(name="Technology")
   sports = Category.query.filter_by(name="Sports").first() or Category(name="Sports")
   misc = Category.query.filter_by(name="Miscellaneous").first() or Category(name="Miscellaneous")
   
   db.session.add_all([tech, sports, misc])
   db.session.commit()
   
   # Add keyword rules
   rule1 = KeywordRule(keyword="smartphone", category_id=tech.id)
   rule2 = KeywordRule(keyword="football", category_id=sports.id)
   
   db.session.add_all([rule1, rule2])
   db.session.commit()
   ```

## Test/Run Commands

We will simulate a scrape using the `scraper_service` directly to see if the categorization works.

1. **Open Flask Shell:**
   ```bash
   flask shell
   ```
2. **Execute Validation Scenario:**
   ```python
   from services.scraper_service import ScraperService
   from models import Article, db
   
   # Mock article data containing "smartphone"
   article_data_tech = {
       "source_url": "http://example.com/tech-news",
       "source_name": "Tech Mock",
       "title": "New smartphone released today",
       "description": "It features an amazing screen.",
       "raw_content": "Full text...",
   }
   
   # Mock article data containing "football" and "smartphone"
   article_data_both = {
       "source_url": "http://example.com/sports-tech",
       "source_name": "Mixed Mock",
       "title": "Football app on new smartphone",
       "description": "App review.",
       "raw_content": "Full text...",
   }
   
   # Mock article data containing no known keywords
   article_data_misc = {
       "source_url": "http://example.com/other-news",
       "source_name": "Misc Mock",
       "title": "Some random event",
       "description": "Nothing special.",
       "raw_content": "Full text...",
   }
   
   # Process them
   tech_article = ScraperService.process_article(article_data_tech)
   both_article = ScraperService.process_article(article_data_both)
   misc_article = ScraperService.process_article(article_data_misc)
   
   print("Tech Article Categories:", [c.name for c in tech_article.categories])
   print("Both Article Categories:", [c.name for c in both_article.categories])
   print("Misc Article Categories:", [c.name for c in misc_article.categories])
   ```

## Expected Outcomes

The output from the test execution should look exactly like this:
```text
Tech Article Categories: ['Technology']
Both Article Categories: ['Technology', 'Sports']
Misc Article Categories: ['Miscellaneous']
```
Additionally, verifying the `Category` table should show that no new junk categories were automatically created.
