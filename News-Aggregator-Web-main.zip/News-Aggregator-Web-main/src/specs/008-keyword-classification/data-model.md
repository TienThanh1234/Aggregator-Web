# Keyword Mapping Classification Data Model

## Entities

### Category (Existing)
*Represents a fixed topical category.*
- `id`: Integer (Primary Key)
- `name`: String (255), Unique, Indexed

*(Note: We need to ensure that categories are pre-seeded and no longer auto-created by the scraper).*

### KeywordRule (New)
*Represents a mapping between a specific keyword phrase and a fixed Category.*
- `id`: Integer (Primary Key)
- `keyword`: String (255), Unique, Indexed (The keyword or phrase to match)
- `category_id`: Integer, ForeignKey(`categories.id`), Indexed (The target category)
- `is_active`: Boolean, Default=True (Allows soft-disabling a rule)
- `created_at`: DateTime
- `updated_at`: DateTime

## Relationships

- `Category` has many `KeywordRules` (One-to-Many).
- `KeywordRule` belongs to one `Category`.

## State Transitions
- N/A

## Validation Rules
- `keyword` must be stored in lowercase to ensure case-insensitive matching is standardized.
- `keyword` must not be empty.
