---
description: "Task list for Keyword Mapping Classification feature"
---

# Tasks: Keyword Mapping Classification

**Input**: Design documents from `/specs/008-keyword-classification/`

**Prerequisites**: plan.md (required), spec.md (required for user stories), research.md, data-model.md, quickstart.md

**Organization**: Tasks are grouped by user story to enable independent implementation and testing of each story.

## Phase 1: Setup (Shared Infrastructure)

**Purpose**: Project initialization and basic structure (None required since project is already established)

---

## Phase 2: Foundational (Blocking Prerequisites)

**Purpose**: Core infrastructure that MUST be complete before ANY user story can be implemented

**⚠️ CRITICAL**: No user story work can begin until this phase is complete

- [x] T001 Create `KeywordRule` model in `src/models.py`
- [x] T002 Generate Alembic migration script for `KeywordRule` table (e.g., via `flask db migrate -m "Add KeywordRule table"`)
- [x] T003 Apply database migrations (e.g., via `flask db upgrade`)

**Checkpoint**: Foundation ready - user story implementation can now begin in parallel

---

## Phase 3: User Story 1 - Automatic Article Classification via Keywords (Priority: P1) 🎯 MVP

**Goal**: The system automatically analyzes the title, description, and tags of a newly scraped article and classifies the article into its corresponding fixed category.

**Independent Test**: Can be tested independently by mocking an article payload containing specific keywords and verifying that the system assigns the expected category.

### Implementation for User Story 1

- [x] T004 [P] [US1] Create `ClassificationService` class in `src/services/classification_service.py` with method to match text against active `KeywordRule` records.
- [x] T005 [US1] Remove automatic category creation (`Category(name=category_name)`) logic from `src/services/scraper_service.py`.
- [x] T006 [US1] Integrate `ClassificationService.classify(...)` into `src/services/scraper_service.py` to assign matched categories to the processed article.
- [x] T007 [US1] Update `DynamicScraper` in `src/scraper/dynamic_scraper.py` to optionally pass combined tags/breadcrumbs if needed by classification service.

**Checkpoint**: At this point, User Story 1 should be fully functional and testable independently using the `quickstart.md` mock scenario.

---

## Phase 4: User Story 2 - Keyword and Category Configuration Management (Priority: P2)

**Goal**: Administrators can define and update the dictionary (mapping) between keywords and fixed categories.

**Independent Test**: An admin changes a keyword mapping, and the system immediately applies the new rule to newly scraped articles.

### Implementation for User Story 2

- [x] T008 [P] [US2] Create or update the seed script (e.g. `src/seed_db.py` or new script) to pre-seed standard fixed categories ("Technology", "Sports", "Miscellaneous", etc.) and basic keyword rules.
- [x] T009 [US2] Verify that modifying rules in the DB (via shell) immediately changes the outcome for subsequent classifications without restarting the app.

**Checkpoint**: At this point, User Stories 1 AND 2 should both work independently.

---

## Phase 5: Polish & Cross-Cutting Concerns

**Purpose**: Improvements that affect multiple user stories

- [x] T010 [P] Run `quickstart.md` validation to ensure end-to-end functionality matches expected outcomes.
- [x] T011 Document the keyword rule mapping logic in code docstrings.

---

## Dependencies & Execution Order

### Phase Dependencies

- **Setup (Phase 1)**: N/A
- **Foundational (Phase 2)**: BLOCKS all user stories
- **User Stories (Phase 3+)**: All depend on Foundational phase completion
  - User Story 1 (P1) → User Story 2 (P2)
- **Polish (Final Phase)**: Depends on all desired user stories being complete

### Parallel Opportunities

- T004 can be implemented in parallel with Foundational DB tasks (if mock objects are used), but realistically depends on `models.py` definitions.
- T008 can be written in parallel with T004.
- T010 runs at the very end.

## Implementation Strategy

### MVP First (User Story 1 Only)

1. Complete Phase 2: Foundational (CRITICAL - blocks all stories)
2. Complete Phase 3: User Story 1
3. **STOP and VALIDATE**: Test User Story 1 independently using `quickstart.md`.
