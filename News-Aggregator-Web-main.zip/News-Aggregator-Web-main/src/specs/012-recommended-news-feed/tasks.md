# Tasks: Recommended News Feed

**Branch**: `012-recommended-news-feed` | **Spec**: [spec.md](spec.md) | **Plan**: [plan.md](plan.md)

---

## Phase 1: Foundation and Service Contract

- [x] **T001**: Review existing `User` subscriptions, `Bookmark`, `Article`, `ArticleStoryMembership`, `StoryCluster`, `truth_score`, and public article-card presentation fields against `spec.md` §5. Record any required compatibility adjustment before coding; do not add a migration by default.
  - **Acceptance**: v1 has a documented read-only data path and does not create a recommendation-history table or external dependency.
- [x] **T002**: Create `src/services/recommendation_service.py` with module docstring, type hints, structured logger, and named constants for the 30-day window, 250-candidate cap, default/maximum limit, score weights, and score cap.
- [x] **T003 [P]**: Implement safe request-limit validation in `recommendation_service.py` for integer values from 1 through 10, with a service-level validation error suitable for an HTTP `400` response.
- [x] **T004 [P]**: Implement pure helpers for effective article timestamp (`published_at`, then `scraped_at`), freshness score, null-safe Truth Score quality points, accepted Story Cluster identity, and deterministic ranking tuple.
- [x] **T005 [P]**: Implement pure reason selection with the required precedence: saved-story continuation, shared bookmarked topic, followed category, followed source. Do not allow freshness or Truth Score to become the displayed reason.
- [x] **T006**: Expose or safely reuse the existing public article-card presentation mapping from `src/services/article_service.py`; do not duplicate its title, image, canonical-path, source, category, or Story Cluster transformations in the recommendation service.
- [x] **T007**: Implement an empty-result view model that distinguishes no personal signal, no eligible candidates, and unavailable service without exposing internal error text.

---

## Phase 2: Candidate Retrieval and Deterministic Ranking

- [x] **T008**: Implement account-scoped loading of the current User, explicit category/source subscriptions, and active bookmarked seed articles in `recommendation_service.py`.
  - **Acceptance**: a missing/inactive account returns an empty/no-account result and no query can use another account's subscriptions or bookmarks.
- [x] **T009**: Implement the bounded candidate query: active public articles only, non-deleted, published/scraped within the last 30 days, excluding bookmarked article IDs at query time, ordered by recency, and limited to 250 before scoring.
- [x] **T010**: Preload categories, accepted Story Cluster membership, and clustering/score data required for ranking so the service does not perform one query per candidate.
- [x] **T011**: Implement the 45-point same accepted Story Cluster signal for a candidate that continues a bookmarked seed story.
- [x] **T012**: Implement the 25-point shared-category-with-bookmark signal. Multiple matching bookmarked articles/categories must not stack this signal.
- [x] **T013 [P]**: Implement the 15-point followed-category and 10-point followed-source signals. Each signal type applies once regardless of the number of matching categories/sources.
- [x] **T014 [P]**: Implement freshness (0–3) and quality (0–2) components exactly as specified, including null-safe and range-clamped behavior.
- [x] **T015**: Combine T011–T014 into a capped 0–100 `recommendation_score`; discard zero-score candidates and attach exactly one approved reason.
- [x] **T016**: Implement accepted Story Cluster diversity selection: return at most one candidate per cluster, preferring an eligible canonical article and otherwise the highest-ranked member. Preserve normal eligibility for unclustered articles.
- [x] **T017**: Implement deterministic final ordering: recommendation score, accepted cluster Trending Score, Truth Score, publication time, then Article ID; return at most the validated requested limit.
- [x] **T018**: Implement `get_recommendations(user_id: int, limit: int = 5)` returning `items`, non-sensitive metadata (`limit`, `has_preferences`, `has_bookmarks`), and an empty-state key. It must never write a database record.
- [x] **T019**: Add safe structured logs for `recommendation_generated`, `recommendation_empty`, and `recommendation_failed`, containing only account ID, candidate/returned counts, and safe error type.

---

## Phase 3: Route and Server-rendered Main Page

- [x] **T020**: Add a small recommendation view-model resolver to `src/routes.py` that calls the service only for an integer `_optional_current_user_id()`, catches service failures, logs safely, and supplies an unavailable state without blocking the public feed.
- [x] **T021**: Update `routes.py:index()` to calculate the optional user ID once, pass it both to `get_feed_articles()` and the recommendation resolver, and pass the recommendation view model to `index.html` only for authenticated accounts.
  - **Acceptance**: guest feed output and existing category/pagination behavior remain unchanged.
- [x] **T022**: Add authenticated `GET /api/recommendations` to `src/routes.py`, using `_get_authenticated_user_id()`, service-level `limit` validation, a standard success envelope, `400` for invalid limits, and `401` for unauthenticated sessions.
- [x] **T023**: Ensure the API response excludes bookmarked seed IDs, subscription IDs, internal signal details, raw article content, and private score inputs. `recommendation_score` may remain for diagnostics but must not be rendered as a truth claim.

---

## Phase 4: Reader UI and Optional Refresh

- [x] **T024**: Create `src/templates/partials/_recommended_news_panel.html` with a semantic, accessible “Recommended for you” panel: heading, up to five canonical article links, source/category metadata, one reason per item, and escaped title/reason content.
- [x] **T025**: Add explicit SSR empty and unavailable panel states, plus a refresh button with `type="button"`, accessible name, and live-status region. Keep the panel absent for guests.
- [x] **T026**: Include the recommendation partial in `src/templates/index.html` under the existing Trending Now widget for authenticated page renders only, and add the new page-specific JavaScript through the template's `page_scripts` block.
- [x] **T027**: Add responsive recommendation panel styles to `src/static/css/frontend.css`, following existing widget tokens. Cover focus-visible controls, long title/reason wrapping, image fallback, touch target size, sidebar layout, and mobile stacking.
- [x] **T028**: Create `src/static/js/recommendations.js` as optional progressive enhancement. Bind refresh, request `/api/recommendations?limit=5` through `window.TMM.readApiResponse`, set loading/`aria-busy` state, and preserve the SSR list on failure.
- [x] **T029**: Render all refreshed API text using DOM APIs and `textContent`; do not build item markup with unescaped `innerHTML`. Reinitialize icons only if the existing icon library requires it.
  - **Acceptance**: JavaScript disabled rendering remains useful and a refresh never changes feed order, URL, bookmarks, clusters, or scores.

---

## Phase 5: Automated Tests

- [x] **T030**: Create `src/tests/test_recommendation_service.py` with isolated SQLite fixtures for users, categories, source configs, articles, subscriptions, bookmarks, accepted Story Clusters, and Story Cluster memberships.
- [x] **T031**: Add service tests for category/source preference boosts, bookmark-topic boosts, saved-story boosts, reason precedence, score cap, and deterministic tie-break ordering.
- [x] **T032**: Add service tests ensuring bookmarked, soft-deleted, unavailable, older-than-30-day, and score-zero candidates are excluded; assert the 250-candidate pre-ranking cap.
- [x] **T033**: Add service tests for cluster diversity, canonical preference, non-canonical fallback, unclustered candidates, no-preference/no-bookmark empty state, and account isolation.
- [x] **T034**: Create `src/tests/test_recommendation_routes.py` covering anonymous API `401`, invalid limit `400`, authenticated JSON response schema, and absence of private seed/subscription data.
- [x] **T035**: Add page-contract tests for guest panel absence, authenticated SSR panel/link rendering, escaped title/reason output, and a simulated recommendation-service exception that still returns the main page with HTTP `200`.
- [x] **T036**: Run the complete project `unittest` suite inside the activated project virtual environment and resolve regressions in authentication, Hybrid MPA routes, search, dashboard/bookmarks, Story Cluster, and Truth Score behavior.

---

## Phase 6: Operational Verification and Release Gate

- [X] **T037**: In a representative non-production PostgreSQL/Supabase environment, inspect the recommendation candidate query plan and measure p95 latency with realistic data. Confirm existing indexes satisfy the bounded query before adding any migration.
- [X] **T038**: If T037 demonstrates an index gap, create a narrowly scoped additive Alembic migration and upgrade/downgrade verification; otherwise record that no migration is necessary.
- [X] **T039**: Manually verify a seeded account with subscriptions, bookmarks, clustered follow-up reports, old/deleted articles, and no-profile state on desktop and mobile widths. Check explanation wording, canonical links, one-cluster diversity, keyboard navigation, and refresh behavior.
- [X] **T040**: Review application logs after verification to confirm generated/empty/failure events contain no bookmark title, article body, session token, credential, or other private data.
- [X] **T041**: Update feature documentation status and release notes only after T036, T037, T039, and T040 pass. Do not claim that recommendations are AI-generated, externally verified, or based on unapproved behavioural tracking.

---

## Dependency Order

```text
T001–T007
  → T008–T019
  → T020–T023
  → T024–T029
  → T030–T036
  → T037–T041
```

- T003–T005 and T013–T014 can proceed in parallel after T002.
- T011–T014 depend on T008–T010; T015–T18 depend on all ranking signals.
- T020–T023 must use the completed service contract from T018.
- T024–T029 may begin after the view-model/API contract from T020–T023 is fixed.
- T036 is a release blocker. T038 is conditional and may start only if T037 presents evidence of an index gap.
