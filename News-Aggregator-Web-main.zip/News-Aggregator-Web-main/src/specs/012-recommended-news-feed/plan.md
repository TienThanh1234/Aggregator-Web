# Implementation Plan: Recommended News Feed

**Branch**: `012-recommended-news-feed` | **Date**: 2026-08-21 | **Spec**: [spec.md](spec.md)

## Summary

Implement an explainable, deterministic **Recommended for you** side panel on the server-rendered home page. For an authenticated account, the application will rank up to five active articles using existing topic/source subscriptions, bookmarks, accepted Story Clusters, freshness, Truth Score, and Trending Score.

The implementation adds no external API, LLM, embedding model, migration, behavioural tracking, or persistent recommendation history. It preserves the existing public feed ordering and degrades safely to an empty/unavailable panel if recommendation calculation fails.

## Technical Context

**Language/Runtime**: Python 3.11+, Flask, Flask-SQLAlchemy, Jinja2, Vanilla JavaScript  
**Storage**: PostgreSQL/Supabase in production; SQLite in the current `unittest` suite  
**Testing**: `python -m unittest discover -s tests -p "test_*.py" -v` from `src` with the project virtual environment active  
**UI model**: Hybrid MPA; server-rendered initial panel, optional fetch-based refresh

### Existing state to reuse

- `routes.py:index()` already calls `get_feed_articles(..., user_id=_optional_current_user_id())`, so it has the correct point to resolve current-account recommendations without changing guest feed behavior.
- `models.py` already provides `User.subscribed_categories`, `User.subscribed_sources`, `Bookmark`, `Article.categories`, `ArticleStoryMembership`, `StoryCluster`, `Article.truth_score`, and cluster Trending Score.
- `services/article_service.py` owns public article-card serialization and already contains Story Cluster presentation helpers. Recommendation output must reuse this mapping rather than introduce a second inconsistent card schema.
- `templates/index.html` has a left sidebar containing category navigation and Trending Now. The recommendation panel belongs in this sidebar and must only render for an authenticated account.
- `static/js/core.js` exposes `window.TMM.readApiResponse()`, toast helpers, and auth state, which the refresh controller can reuse.
- Existing tests use Flask's built-in `unittest` client plus an isolated SQLite database. New tests follow that pattern and must not require live Supabase, a scraper, Gemini, or browser automation.

## Constitution Check

- **MVC**: ranking/query logic stays in a service; `routes.py` only authenticates, validates input, calls the service, and renders/serializes output; templates render supplied values only.
- **Data integrity**: v1 is read-only with respect to recommendation data. It does not modify bookmarks, subscriptions, Article records, clusters, or scores.
- **Security**: the API scopes all queries to the authenticated account and returns `401` before any result work for an anonymous/invalid session. It exposes neither raw bookmark data nor another account's preference data.
- **Resilience**: a service exception is logged with safe metadata and does not prevent `GET /` from rendering the public feed.
- **Performance**: candidate retrieval is bounded to 250 recent public articles before in-memory deterministic scoring and diversity selection.
- **Environment**: no new dependency, secret, or environment variable is introduced.

## Design Decisions

| Decision | Plan |
|---|---|
| Algorithm type | Local, deterministic scoring described in spec §4; no ML/LLM calls. |
| “Reading preferences” source | Explicit subscriptions plus existing bookmarks only. The application has no approved read-history model, so it will not silently infer or persist behaviour. |
| Auth scope | Any active authenticated account may receive its own panel; guests do not receive a panel or API data. |
| Candidate scope | Non-deleted, not-yet-bookmarked articles from the last 30 days, with a hard pre-ranking cap of 250. |
| Cluster diversity | At most one candidate per accepted Story Cluster; use canonical article if it is eligible, else retain its highest-ranked eligible member. |
| No personal signal | Return an explicit empty result; do not backfill with generic trending content. |
| Initial rendering | Server-rendered in the main page response for JavaScript-disabled access. JavaScript only refreshes the same API response. |
| Score visibility | `recommendation_score` is returned by the private API for diagnostics/tests but is not rendered as a public truth/quality rating. |

## Project Structure (Post-Implementation)

```text
src/
├── routes.py                                      # [MODIFY] initial view-model + GET /api/recommendations
├── services/
│   ├── recommendation_service.py                  # [NEW] eligibility, ranking, explanations, diversity
│   └── article_service.py                         # [REUSE] public card serialization; minimal export only if needed
├── templates/
│   ├── index.html                                 # [MODIFY] authenticated recommendation panel
│   └── partials/
│       └── _recommended_news_panel.html           # [NEW] SSR panel and empty/unavailable states
├── static/
│   ├── css/frontend.css                           # [MODIFY] compact, responsive recommendation styles
│   └── js/recommendations.js                      # [NEW] optional safe refresh controller
└── tests/
    ├── test_recommendation_service.py             # [NEW] deterministic-ranking unit/integration tests
    └── test_recommendation_routes.py              # [NEW] API and SSR page-contract tests
```

No Alembic migration is planned. Before coding, confirm the existing production indexes cover `articles.is_deleted`, article publication/scrape timestamp, `bookmarks.user_id`, `bookmarks.article_id`, and Story Cluster membership lookups. Add an additive index migration only if the production query plan demonstrates a need; do not add one pre-emptively for SQLite tests.

## Implementation Phases

### Phase 1 — Recommendation Service and Pure Ranking Rules

**Objective**: Build a testable service with no HTTP/template assumptions.

1. Create `services/recommendation_service.py` with named constants for the 30-day window, 250 candidate cap, default/maximum result limit, score weights, and valid limit bounds.
2. Add small pure helpers for:
   - safe `limit` validation (`1..10`);
   - article effective timestamp (`published_at`, then `scraped_at`);
   - freshness points;
   - quality points, with null-safe clamping;
   - accepted cluster lookup/identity;
   - ranking tuple and reason selection.
3. Add `get_recommendations(user_id: int, limit: int = 5) -> dict` that:
   - loads only the requesting `User` and returns a typed empty state if absent/inactive;
   - loads active seed bookmarks and subscriptions for that user;
   - returns a no-profile empty state without querying global trending results when no preferences/seeds exist;
   - selects at most the 250 most-recent active, 30-day candidates and excludes seed bookmark article IDs at query time;
   - calculates scores in memory from preloaded relationship data, never one query per candidate;
   - drops zero-score candidates, chooses the reason by the spec precedence, applies cluster diversity, orders deterministically, and limits the final list;
   - returns `items` plus neutral metadata: `limit`, `has_preferences`, `has_bookmarks`, and an empty-state key.
4. Use existing `article_service` presentation output for the nested `article` object. If the suitable card serializer is private, make the smallest safe, documented service-level export rather than copy its fields.
5. Add structured safe logs: `recommendation_generated`, `recommendation_empty`, and `recommendation_failed`; log account ID and counts only.

**Acceptance criteria**

- Same persisted inputs produce the same candidates, scores, order, and reasons.
- No score-zero, soft-deleted, older-than-30-day, or already-bookmarked article is returned.
- A same-cluster candidate outranks a category-only candidate.
- No service path uses a network call, LLM, user activity tracking, or writes to the database.

### Phase 2 — Route Contracts and Server-Rendered Main Page

**Objective**: Surface the initial recommendation result without coupling the public feed to recommendation success.

1. Add a thin local helper in `routes.py` (or a narrow service wrapper) that resolves recommendations only when `_optional_current_user_id()` is an integer. Catch service exceptions, log safely, and return the specified unavailable view model.
2. Update `index()` to compute `user_id` once, pass it to `get_feed_articles`, and pass `recommendations`/`is_recommendations_available` to the template only for authenticated accounts.
3. Add `GET /api/recommendations`:
   - authorize using the existing `_get_authenticated_user_id()` helper;
   - validate the optional `limit` through `recommendation_service`, mapping bad input to `400`;
   - return the standard `{ "status": "success", "data": ... }` envelope;
   - do not include seed IDs, subscription IDs, internal match evidence, or raw ranking inputs in the response.
4. Preserve all existing API and feed responses. Do not alter `GET /api/articles`, search, Daily Brief, or existing feed personalization logic.

**Acceptance criteria**

- Anonymous `GET /` contains no panel markup/data; anonymous API request returns `401`.
- An authenticated home-page response succeeds even when recommendation calculation throws.
- Authenticated API responses have stable shape and invalid limit values return `400`.

### Phase 3 — Panel, Accessibility, and Progressive Refresh

**Objective**: Make recommendations visible, understandable, responsive, and safe without JavaScript.

1. Create `templates/partials/_recommended_news_panel.html`:
   - semantic `aside`/section landmark with an accessible heading;
   - up to five canonical article links, source/category metadata, a single escaped `reason`, and image `alt` handling consistent with article cards;
   - empty and unavailable states that avoid implying failure of the main feed;
   - a `type="button"` refresh control with accessible label and live status region.
2. Include the partial in the existing home sidebar under Trending Now only when the server has an authenticated recommendation view model.
3. Add focused styles to `static/css/frontend.css` matching existing sidebar/widget tokens. Verify desktop sidebar spacing plus mobile stacking/order, focus-visible state, minimum touch target, long title/reason wrapping, and image fallback.
4. Create `static/js/recommendations.js` as optional progressive enhancement:
   - bind the refresh control after DOM content is ready;
   - call `/api/recommendations?limit=5` using `window.TMM.readApiResponse`;
   - render API-provided title/source/reason via DOM `textContent`, not string-built `innerHTML`;
   - set loading/disabled/`aria-busy` state and update the live region;
   - on error, preserve the last server-rendered list and use an existing toast/error message rather than replacing it with unsafe data.
5. Add the page-specific script through `index.html`'s `page_scripts` block. Do not add recommendation logic to `core.js` beyond shared helper use.

**Acceptance criteria**

- Initial recommendation content is useful with JavaScript disabled.
- Refresh does not change page URL or affect the feed, bookmarks, scores, or clusters.
- Dynamic text cannot inject markup and controls are keyboard-accessible.

### Phase 4 — Tests, Query Review, and Documentation Consistency

**Objective**: prove the ranking contract and protect existing pages.

1. Add `tests/test_recommendation_service.py` using deterministic SQLite fixtures for user, categories, source configs, articles, bookmarks, accepted clusters, and deleted/old records. Cover all ten spec acceptance tests that can be automated at the service level.
2. Add `tests/test_recommendation_routes.py` for:
   - unauthenticated API `401` and guest main-page absence;
   - authenticated SSR panel rendering and canonical links;
   - invalid `limit` `400`;
   - API response schema and account isolation;
   - service failure leaving main page `200` with unavailable state;
   - HTML-like article/reason content rendered safely.
3. Extend `test_mpa_routes.py` only for high-level regression coverage if it avoids duplicating the dedicated route tests.
4. Run the full existing `unittest` suite inside the project's activated virtual environment. Resolve regressions in auth, MPA pages, search, bookmarks, Story Clusters, and Truth Score.
5. In PostgreSQL/Supabase staging, inspect the candidate query plan at a realistic data volume. Add only evidenced indexes/migration work, then document the result in the implementation PR.
6. Update this feature's status and task/checklist artifacts only in later Spec Kit workflow steps; this plan itself does not mark the feature implemented.

## Test Matrix

| Concern | Required coverage |
|---|---|
| Authentication | Guest page has no panel; unauthenticated API is `401`; session user only sees own results. |
| Preferences | Followed category/source provides exactly its defined boost and reason precedence. |
| Bookmarks | Bookmark topic match, same-cluster continuation, and bookmarked-candidate exclusion. |
| Eligibility | Soft-deleted, unavailable, old, null-date fallback, and zero-score candidates. |
| Diversity | One accepted cluster yields one recommendation; canonical preference and non-cluster coexistence. |
| Ordering | Score, Trending Score, Truth Score, timestamp, and ID tie-breakers are deterministic. |
| Resilience | Empty profile; missing user; service exception; no effect on feed response. |
| Presentation | Canonical link, empty state, safe escaping, refresh state, desktop/mobile manual review. |
| Performance | 250-candidate cap asserted in service tests; PostgreSQL plan reviewed before release. |

## Rollout and Verification

1. Deploy service and SSR panel behind normal authenticated rendering; no data backfill or feature flag is necessary because the feature is read-only.
2. Confirm guest pages show no personalized panel and existing feed/search/page response times remain stable.
3. Seed a non-production account with subscriptions, bookmarks, clustered articles, and soft-deleted articles; manually verify reason wording, one-cluster diversity, canonical links, and refresh behavior at desktop and mobile widths.
4. Inspect safe logs for generated/empty/failure events without article body, bookmark title, session, or secret leakage.
5. Monitor initial p95 service/query timing. If the 250 ms target is missed, profile SQL and add a narrowly scoped additive index migration only after review.

## Delivery Boundaries

This plan authorizes design and implementation sequencing only. It does not authorize new analytics collection, external data sharing, user-behaviour storage, database migrations without query-plan evidence, or modifications to recommendation score weights outside the approved specification.
