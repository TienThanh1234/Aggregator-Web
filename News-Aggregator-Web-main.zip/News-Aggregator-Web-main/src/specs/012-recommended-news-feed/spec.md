# Feature Specification: Recommended News Feed

**Feature Branch**: `012-recommended-news-feed`  
**Created**: 2026-08-21  
**Status**: Draft  
**Target Specification Location**: `src/specs/012-recommended-news-feed/spec.md`  
**Constitution Authority**: [constitution.md](../../.specify/memory/constitution.md)

---

## 1. Purpose and Scope

The **Recommended News Feed** gives every authenticated account a small, personalized list of newly relevant articles on the main page. It uses the account's explicit topic/source subscriptions and saved (bookmarked) articles to recommend related, active articles. The primary signals are shared category, followed source/category, and accepted Story Cluster membership.

The feature is an explainable, deterministic recommendation system. It does not use an external recommendation API, LLM, embeddings, personal data from other users, or hidden behavioural tracking in v1.

### Goals

- Show up to five useful recommendations in a side panel on the main page (`/`) for an authenticated account.
- Recommend recent, active articles that match saved topics/sources or continue a story the account bookmarked.
- Avoid repetitive results by showing at most one article from an accepted Story Cluster.
- Show a short human-readable reason for every recommendation, such as “Matches your followed Technology topic” or “More coverage of a saved story”.
- Keep the main feed usable if recommendations cannot be calculated.

### Non-goals

- Predicting interests from clicks, dwell time, browser history, or user data outside this application.
- Calling Gemini, another LLM, or an embedding/vector service for ranking.
- Changing the global feed ordering, the existing Daily Brief, Story Cluster rules, Truth Score formula, or bookmark semantics.
- Showing recommendations to guests or exposing one user's saved articles/preferences to another user.

## 2. Definitions

| Term | Meaning |
|---|---|
| Authenticated account | A current, active session returned by the existing authentication service. |
| Seed article | An active article bookmarked by the current account. |
| Candidate article | An active, non-bookmarked article eligible to appear in the recommendation panel. |
| Shared story | A candidate and a seed article with accepted membership in the same Story Cluster. |
| Recommendation reason | A concise explanation derived only from signals used to rank the candidate. |

## 3. User Stories and Acceptance Scenarios

### User Story 1 — View a personalized side panel (P1)

**As a** registered user,  
**I want** to see recommended articles in a side panel on the main page,  
**so that** I can quickly discover news related to my interests and saved stories.

- **AS-RNF-01**: Given an authenticated account opens `/`, when at least one eligible candidate exists, then the page displays a “Recommended for you” side panel with no more than five article cards.
- **AS-RNF-02**: Given a guest opens `/`, when the page renders, then no personalized panel or recommendation API data is displayed.
- **AS-RNF-03**: Given the account has no subscriptions and no bookmarks, when the panel loads, then it displays a helpful empty state and does not fabricate a personal recommendation.
- **AS-RNF-04**: Given recommendation generation fails, when the main page renders, then the public feed still returns successfully and the panel shows an unavailable/empty state without leaking internal errors.
- **AS-RNF-05**: Given a user clicks a recommendation, when the article page opens, then it uses the existing canonical route `/articles/<article_id>`.

### User Story 2 — Recommend related new articles (P1)

**As a** registered user with preferences or bookmarks,  
**I want** recommendations to reflect both what I follow and what I saved,  
**so that** results are relevant without requiring a separate search.

- **AS-RNF-06**: Given the account follows a category or source, when active recent candidates match it, then those candidates receive a preference score boost.
- **AS-RNF-07**: Given the account bookmarked an article, when a new active article shares one or more categories with that article, then it is eligible for a bookmark-topic score boost.
- **AS-RNF-08**: Given a bookmarked article belongs to an accepted Story Cluster, when another active article in that same cluster exists, then the candidate receives the highest relationship boost and the reason states that it provides more coverage of a saved story.
- **AS-RNF-09**: Given multiple candidates belong to the same accepted Story Cluster, when results are selected, then at most one canonical/representative candidate from that cluster appears in the panel.
- **AS-RNF-10**: Given a candidate is already bookmarked by the account, soft-deleted, or unavailable, when recommendations are calculated, then it is excluded.

### User Story 3 — Understand and refresh recommendations (P2)

**As a** registered user,  
**I want** to understand why an article was suggested and refresh the panel,  
**so that** the personalization feels useful and predictable.

- **AS-RNF-11**: Given a displayed recommendation, when the panel renders, then it includes one localized, plain-language reason derived from the highest-ranking signal.
- **AS-RNF-12**: Given the user refreshes the main page or invokes the refresh control, when candidates have changed, then the panel recalculates using current data and preserves the same deterministic order for unchanged inputs.
- **AS-RNF-13**: Given the user is not authenticated or the session is invalid, when `GET /api/recommendations` is requested, then the API returns `401` and no recommendation data.

## 4. Ranking and Eligibility

### 4.1 Candidate eligibility

A candidate MUST:

- have `is_deleted = false`;
- not already be bookmarked by the current account;
- have been published or scraped within the last 30 days; and
- be an active public article according to existing article-presentation rules.

The recommendation query MUST be bounded to the most recent 250 eligible articles before ranking. This prevents a full historical scan on every page load.

### 4.2 Deterministic score

The service calculates one integer `recommendation_score` for each candidate:

| Signal | Points | Rule |
|---|---:|---|
| Same accepted Story Cluster as a seed | 45 | Candidate and a bookmarked seed belong to the same accepted cluster. |
| Shared category with a seed | 25 | Candidate shares at least one category with a bookmarked seed. |
| Followed category | 15 | Candidate belongs to one or more categories followed by the account. |
| Followed source | 10 | Candidate source matches a followed source configuration. |
| Freshness | 0–3 | 3 points within 24h, 2 within 7d, 1 within 30d. |
| Existing quality signal | 0–2 | `round(truth_score / 50)`, clamped to 0–2. |

Signals add together. For category and source signals, each signal type is applied once even if there are multiple matching categories, sources, or bookmarks. `recommendation_score` is capped at 100.

Results are ordered by:

1. `recommendation_score DESC`;
2. accepted cluster `trending_score DESC` when available;
3. `truth_score DESC`;
4. `published_at DESC`, then `id DESC`.

The selected reason follows this precedence: same Story Cluster, shared bookmarked topic, followed category, followed source. Freshness and Truth Score never become the sole displayed reason.

### 4.3 Diversity and fallback

- Select at most one candidate per accepted Story Cluster. Prefer its canonical article when it is eligible; otherwise retain the highest-ranked eligible member.
- Articles not in a cluster may appear normally.
- If fewer than five personalized candidates exist, return the available personalized results. Do not fill remaining slots with non-personalized global trending articles in v1.
- The service MUST NOT return a candidate with score `0`.

## 5. Architecture and Data Model

### 5.1 Existing data reused

No database migration is required for v1. The feature reads existing data only:

| Existing data | Use |
|---|---|
| `User.subscribed_categories` | Explicit topic preference signal. |
| `User.subscribed_sources` | Explicit source preference signal. |
| `Bookmark` | Identifies the current account's seed articles and exclusions. |
| `Article.categories` | Finds shared topics. |
| `ArticleStoryMembership` and `StoryCluster` | Detects saved-story follow-ups and enforces diversity. |
| `Article.truth_score` and `StoryCluster.trending_score` | Stable ranking tie-breakers only. |

### 5.2 MVC responsibilities

- `services/recommendation_service.py`: bounded candidate query, eligibility, deterministic scoring, explanation, diversity, and serialization orchestration.
- `services/article_service.py`: continues to own reusable public article-card presentation; recommendation service must not duplicate its presentation mapping.
- `routes.py`: thin `GET /api/recommendations` endpoint and injection of initial recommendations into the main-page view model.
- `templates/index.html`: renders a side-panel region only for an authenticated account.
- `static/js/recommendations.js`: optional refresh enhancement. The initial panel must remain meaningful when JavaScript is unavailable.

## 6. API and UI Contracts

### 6.1 Main page

`GET /` renders the existing public feed. When a current account exists, it additionally supplies a `recommendations` view model to `index.html`. Guest rendering must not execute personalized result serialization beyond determining that no account is present.

The panel contains:

- heading: “Recommended for you”;
- up to five compact article cards using existing title, source, category, thumbnail, and canonical article link conventions;
- exactly one escaped explanation/reason per item;
- an empty state for no preferences, no saved articles, or no eligible results; and
- a refresh button available only to an authenticated account.

### 6.2 `GET /api/recommendations`

The endpoint requires an authenticated current user.

| Parameter | Default | Validation |
|---|---:|---|
| `limit` | `5` | Integer from 1 to 10. |

Successful response:

```json
{
  "status": "success",
  "data": {
    "items": [
      {
        "article": {
          "id": 123,
          "title": "...",
          "canonical_path": "/articles/123"
        },
        "reason": "More coverage of a saved story",
        "recommendation_score": 73
      }
    ],
    "meta": {
      "limit": 5,
      "has_preferences": true,
      "has_bookmarks": true
    }
  }
}
```

`recommendation_score` may be returned for diagnostics and automated tests but MUST NOT be displayed as a public quality/truth claim. Invalid `limit` returns `400`; missing/invalid authentication returns `401`.

## 7. Security, Privacy, and Resilience

- All recommendation queries are scoped to the current account ID; no API response exposes another account's bookmarks, subscription IDs, or reasons tied to another account.
- Routes use the existing authentication helper and services use SQLAlchemy expressions only; no raw SQL is interpolated from request input.
- User-generated or article-provided text displayed in the panel remains Jinja-autoescaped; JavaScript render paths must use safe text insertion.
- The service logs only account ID, candidate count, returned count, and error type. It MUST NOT log bookmark titles, article bodies, cookies, tokens, or secrets.
- Recommendation failure is non-fatal: log it, return an empty/unavailable panel state, and preserve the main feed response.

## 8. Performance and Observability

- The recommendation service should complete in under 250 ms at p95 for the bounded 250-candidate set, excluding database contention.
- Add/verify indexes for existing frequently filtered fields before implementation: `articles.is_deleted`, article timestamp, `bookmarks.user_id`, `bookmarks.article_id`, and Story Cluster membership lookup fields.
- Log structured `recommendation_generated`, `recommendation_empty`, and `recommendation_failed` events with account ID and counts only.
- No persistent recommendation history is written in v1, so refreshing does not create a new personal-data record.

## 9. Acceptance Tests

1. A guest receives no recommendation panel in `GET /` and `GET /api/recommendations` returns `401`.
2. A user who follows Technology receives eligible Technology candidates ahead of equally recent candidates with no matching signal.
3. A user who bookmarked a Technology article receives a new Technology candidate with the reason “Because you saved similar topics” (or approved localized equivalent).
4. A new accepted report in the same Story Cluster as a bookmarked article ranks above an article that only shares a category and receives the saved-story reason.
5. Already bookmarked, soft-deleted, unavailable, and older-than-30-day articles never appear.
6. Two candidates from the same accepted Story Cluster yield one displayed recommendation, preferring the canonical article when eligible.
7. With no subscriptions and no bookmarks, the endpoint returns an empty list and an explicit empty-state reason; it does not return global trending articles.
8. The same stored data returns the same ordered recommendations and explanations on repeated requests.
9. A malformed `limit`, an unauthenticated request, and an internal recommendation-service exception produce `400`, `401`, and a non-breaking main-page fallback respectively.
10. The rendered recommendation title and reason are escaped when they contain HTML-like content.

## 10. Delivery Boundaries

This specification defines only the recommendation feature. It does not authorize implementation, migrations, new external integrations, behavioural analytics, or changes to Story Cluster/Truth Score formulas. Those decisions belong to the implementation plan and task phases.
