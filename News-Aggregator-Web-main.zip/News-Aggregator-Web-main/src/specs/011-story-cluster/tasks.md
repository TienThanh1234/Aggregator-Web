# Tasks: Story Clusters & Trending Score

**Branch**: `011-story-cluster` | **Spec**: [spec.md](spec.md) | **Plan**: [plan.md](plan.md)

---

## Phase 1: Schema and Additive Migration

- [x] **T001**: Add `StoryCluster` to `src/models.py` with canonical article reference, Trending Score total/components, accepted member/domain counts, coverage timestamps, and audit timestamps.
  - **Acceptance**: all score components enforce their documented ranges and a new cluster defaults to score/count zero.
- [x] **T002**: Add `ArticleStoryMembership` to `src/models.py` with unique `article_id`, indexed `cluster_id`, confidence, `accepted`/`needs_review`/`rejected` state, match-signal JSON, and reviewer audit fields.
- [x] **T003**: Add `Article.story_membership` one-to-one relationship and model relationships for cluster canonical article/memberships without removing `Article.content_hash` or `primary_article_id`.
- [x] **T004**: Create an additive Alembic migration for T001–T003, including FKs, status/score/confidence checks and lookup indexes. Do not alter existing Article rows in the migration.
- [x] **T005**: Verify migration upgrade on a production-like copy preserves Article, Truth Score, Daily Brief, duplicate-console, and scraper data.

---

## Phase 2: Deterministic Candidate Discovery and Matching

- [x] **T006**: Create `src/services/story_cluster_service.py` with formula constants: 72-hour window, 100-candidate limit, automatic threshold `0.72`, review threshold `0.60`, and Trending Score component caps.
- [x] **T007**: Implement `normalize_text()` for Vietnamese-friendly lowercase, whitespace/punctuation normalization, configured stop-word removal, and diacritic preservation.
- [x] **T008**: Implement `extract_event_anchors()` for meaningful normalized numbers, dates, locations, organizations, and capitalized terms; ensure it does not log raw content.
- [x] **T009**: Implement indexed `find_candidates(article, limit=100)` filtering active Articles to the 72-hour window and category/shared-token eligibility.
  - **Acceptance**: no new article is compared with the full historical corpus.
- [x] **T010**: Implement title cosine similarity using normalized word and character n-grams without external API calls.
- [x] **T011**: Implement description/content similarity with a capped excerpt when description is missing.
- [x] **T012**: Implement entity overlap, time-proximity decay, and conflict safeguards for incompatible event anchors.
- [x] **T013**: Implement weighted `match_confidence()` using title 0.45, content 0.30, entity 0.15, and time 0.10; exact equal non-null `content_hash` returns 1.0.
- [x] **T014**: Implement cluster decision rules: auto-accept at ≥0.72, persist `needs_review` from 0.60 to <0.72, otherwise create/retain a standalone cluster.
- [x] **T015**: Add unit tests for T007–T014: exact hash, different-hash related reports, title-only review case, candidate limit, 72-hour exclusion, all threshold boundaries, and anchor conflicts.

---

## Phase 3: Membership Lifecycle and Trending Score

- [x] **T016**: Implement `assign_article_to_cluster(article)` to create a one-member accepted cluster when no valid auto-match exists, or persist the matching decision/membership when one does.
- [x] **T017**: Implement stable canonical selection: highest configured source reliability, then earliest publication/scrape time, then Article ID; synchronize `primary_article_id` for accepted non-canonical members.
- [x] **T018**: Implement `calculate_trending_score(cluster)` with the 0–35 independent coverage, 0–30 six-hour velocity, 0–20 exponential recency, and 0–15 source quality/diversity formula.
- [x] **T019**: Implement transactional `recalculate_cluster(cluster_id)` to refresh canonical article, accepted counts/domain counts, all Trending Score components, and timestamps.
- [x] **T020**: Implement admin lifecycle services: accept/reject membership, set canonical article, merge clusters, and split selected members into a new cluster; record reviewer and time.
- [x] **T021**: Implement idempotent `backfill_story_clusters(batch_size=200, dry_run=False)` with independent commits and aggregate scanned/created/accepted/review/error result counters.
- [x] **T022**: Add unit/integration tests for canonical ties, review exclusion, domain deduplication, velocity/recency decay, merge/split/review re-score behavior, and resumable backfill.

---

## Phase 4: Scraper, Truth Score, and Scheduler Integration

- [x] **T023**: Modify `ScraperService.process_raw_article()` to assign the flushed Article to a Story Cluster before calling Truth Score calculation and before the final promotion commit.
- [x] **T024**: Add failure isolation so Story Cluster matching cannot block Article promotion; create a one-member cluster when possible and log safe exception metadata.
- [x] **T025**: Modify `truth_score_service.py` so corroboration counts distinct domains among accepted active Story Cluster members; retain `content_hash` only as exact-match shortcut.
  - **Acceptance**: differing hashes in an accepted cross-source cluster affect Truth Score corroboration, while review/rejected memberships do not.
- [x] **T026**: Re-score every accepted active member’s Truth Score and recalculate Trending Score when membership/canonical state changes.
- [x] **T027**: Register hourly `story_cluster_maintenance` in `scheduler_service.py`, bounded to clusters/articles active in the preceding 72 hours and isolated from scraper/Daily Brief jobs.
- [x] **T028**: Add integration tests proving scraper promotion creates a cluster, different-hash accepted domains raise Truth Score corroboration, a same-domain variant does not, and scheduler maintenance is idempotent.

---

## Phase 5: Daily Brief, APIs, and Reader Presentation

- [x] **T029**: Modify `brief_service.py` to select accepted canonical Story Cluster candidates matching the existing preference and 24-hour filters.
- [x] **T030**: Implement Daily Brief candidate ranking with `0.55 * trending_score + 0.45 * truth_score`, then publication time and ID as deterministic tie-breakers.
- [x] **T031**: Add Daily Brief fallback behavior when fewer than five clusters are available, while preserving at most one canonical article per accepted cluster before fallback.
- [x] **T032**: Add admin-only endpoints for cluster listing/review, merge, split, and controlled backfill; return clear 404/400/403 responses and preserve audit details.
- [x] **T033**: Add API tests for T032, including authorization, review-state transitions, merge/split validation, and response serialization.
- [x] **T034**: Extend article/feed serialization with canonical article, accepted independent-source count, Trending Score only when count ≥2, and up to four accepted alternate headline/source links.
- [x] **T035**: Add a reusable grouped-coverage partial to reader cards/details. Do not display `needs_review`/`rejected` members, match confidence, or raw matching evidence publicly.
- [x] **T036**: Add reader UI tests/manual checks: one-source cluster does not claim multi-source coverage; grouped cards link to all accepted alternate reports; layout remains responsive.

---

## Phase 6: Quality Gates and Rollout

- [x] **T037**: Run a dry-run historical backfill against a production-like data copy and export aggregate results plus samples from auto-accepted/review/rejected outcomes.
- [x] **T038**: Have an editor/admin review a representative sample of automatic matches and tune thresholds/stop words/anchor rules before enabling automatic membership in production.
- [x] **T039**: Run the full automated suite (`pytest tests/ -v` or project-equivalent unittest command) and resolve regressions in scraper, Truth Score, Daily Brief, duplicate console, and public article routes.
- [x] **T040**: Roll out in stages: dry run → `needs_review` reporting → auto-accept for exact hashes → full threshold auto-accept; monitor false-positive rate, active review queue, cluster size, Trending Score distribution, and Daily Brief diversity.

---

## Dependency Order

```text
T001–T005
  → T006–T015
  → T016–T022
  → T023–T028
  → T029–T036
  → T037–T040
```

T029–T036 must not ship before accepted membership drives Truth Score corroboration (T025–T026). Story Cluster automatic matching must not be enabled in production before T037–T038 are complete.
