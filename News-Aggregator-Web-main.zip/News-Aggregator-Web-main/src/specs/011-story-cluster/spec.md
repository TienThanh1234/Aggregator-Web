# Feature Specification: Story Clusters & Trending Score

**Feature Branch**: `011-story-cluster`  
**Created**: 2026-08-17  
**Status**: Draft  
**Target Specification Location**: `src/specs/011-story-cluster/spec.md`

---

## 1. Purpose and Scope

News reports can describe the same real-world event using different titles, wording, images, and article bodies. Exact `content_hash` matching therefore misses cross-source coverage and makes Daily Brief select several variants of the same story.

This feature groups related reports into a **Story Cluster** and calculates a cluster-level **Trending Score** (0–100). It keeps every original Article; no article is deleted, rewritten, or treated as an exact duplicate merely because it belongs to the same event.

The feature covers deterministic candidate discovery, approximate matching, reviewable cluster membership, trending calculation, grouped feed presentation, and Daily Brief selection. It does not use Gemini or any external AI API.

## 2. Definitions

| Term | Meaning |
|---|---|
| Exact duplicate | The same article payload/URL; existing `content_hash` and URL safeguards handle this case. |
| Related report | A separate report about substantially the same event, potentially from another source and with different wording. |
| Story Cluster | A durable group of related reports representing one event or continuing news development. |
| Canonical article | The lead article selected for a Story Cluster; it is a presentation choice, not a claim that it is the only correct account. |
| Trending Score | The 0–100 measure of current news momentum for a Story Cluster. It is not a Truth Score. |

## 3. User Stories and Acceptance Scenarios

### User Story 1 — Grouped coverage

**As a** reader, **I want** several outlets covering one event grouped together, **so that** I can compare angles without seeing a repetitive feed.

- **AS-SC-01**: Given reports from separate domains describe the same event within 72 hours, when matching confidence reaches the automatic threshold, then they belong to one accepted Story Cluster.
- **AS-SC-02**: Given reports have similar wording but contradict important event numbers, places, or dates, when matching runs, then they are not automatically clustered.
- **AS-SC-03**: Given a cluster appears in a feed or Daily Brief, when shown to a reader, then a canonical report is shown with the number of independent sources and links to other member reports.

### User Story 2 — Accurate trends

**As a** reader, **I want** rapidly expanding cross-source coverage to appear as trending, **so that** I can identify important developing stories.

- **AS-SC-04**: Given two otherwise equal clusters, when one has more independent source domains and more reports in the most recent six hours, then it has a higher Trending Score.
- **AS-SC-05**: Given no report has arrived for a cluster recently, when its score is recalculated, then its recency component decreases over time.
- **AS-SC-06**: Given multiple URLs from one source cover the same event, when score is calculated, then that source counts once for cross-source coverage.

### User Story 3 — Editorial control

**As an** administrator, **I want** to review uncertain matches and correct cluster membership, **so that** automated grouping remains trustworthy.

- **AS-SC-07**: Given a match has confidence from 0.60 up to but not including 0.72, when it is created, then it is saved as `needs_review` and does not affect Trending Score or grouped reader UI.
- **AS-SC-08**: Given an administrator accepts, rejects, merges, or splits a cluster, when the action succeeds, then affected membership and scores are recalculated and the action is audited.

### User Story 4 — Daily Brief diversity

**As a** Daily Brief user, **I want** each brief to cover distinct events instead of several versions of one report, **so that** I receive a broader update.

- **AS-SC-09**: Given at least five accepted clusters match a user’s preferences, when a brief is generated, then it selects at most one canonical article per cluster.
- **AS-SC-10**: Given a cluster has both scores, when candidates are ranked, then `brief_rank = 0.55 * trending_score + 0.45 * truth_score` determines rank before recency tie-breakers.

## 4. Matching Pipeline

### 4.1 Candidate scope

On Article promotion and maintenance reprocessing, candidates MUST be limited to active reports that:

- are within 72 hours of the candidate article’s publication/scrape time;
- share at least one category when both articles have categories; and
- have at least one normalized title token or keyword in common.

The lookup MUST be indexed and bounded. It MUST NOT compare a new article to every historical article.

### 4.2 Matching signals

The service computes a deterministic confidence score from 0 to 1:

| Signal | Weight | Rule |
|---|---:|---|
| Title similarity | 0.45 | Cosine similarity using normalized Vietnamese-friendly word and character n-grams. |
| Description/content similarity | 0.30 | Cosine similarity using description, or a capped raw-content excerpt if description is absent. |
| Entity overlap | 0.15 | Normalized overlap of extracted capitalized terms, locations, organizations, and meaningful numbers. |
| Time proximity | 0.10 | 1.0 within six hours, decaying to 0 at 72 hours. |

The system MUST remove punctuation, normalize case/whitespace, discard configured stop words, and retain Vietnamese diacritics. Exact non-null `content_hash` matches receive confidence 1.0.

### 4.3 Conflict safeguards

Automatic clustering MUST be rejected when both articles contain conflicting high-confidence event anchors, such as different normalized dates, materially different casualty/count values, or incompatible named locations. The rejection reason is recorded for review.

### 4.4 Thresholds

- Confidence `>= 0.72`: automatically create/accept membership.
- Confidence `>= 0.60` and `< 0.72`: persist `needs_review`; exclude it from public grouping and scores.
- Confidence `< 0.60`: do not persist a membership proposal.

If multiple accepted clusters meet the threshold, select the highest confidence cluster. A deterministic tie uses the cluster with the oldest creation time.

## 5. Trending Score

Trending Score is an integer from 0–100 calculated for accepted memberships only.

| Component | Range | Rule |
|---|---:|---|
| Independent source coverage | 0–35 | 1 domain: 5; 2: 15; 3: 25; 4+: 35. |
| Recent coverage velocity | 0–30 | 5 points per accepted report published/scraped in the last six hours, capped at 30. |
| Recency | 0–20 | `round(20 * exp(-hours_since_latest / 18))`, capped at 20. |
| Source quality/diversity | 0–15 | Average configured `reliability_score` for distinct domains, normalized to 0–15. Unknown source is neutral 50. |

`trending_score = min(100, sum(components))`. The service MUST save components and calculation timestamp for auditability. A cluster with no accepted active member receives 0 and is not eligible for public display or Daily Brief.

## 6. Data Model

### 6.1 `story_clusters`

| Column | Type | Constraint | Description |
|---|---|---|---|
| `id` | integer | primary key | Cluster identifier. |
| `canonical_article_id` | integer | FK `articles.id`, nullable | Reader-facing lead report. |
| `trending_score` | integer | not null, default 0, 0–100 | Current total score. |
| `source_coverage_score` | integer | not null | 0–35 component. |
| `velocity_score` | integer | not null | 0–30 component. |
| `recency_score` | integer | not null | 0–20 component. |
| `source_quality_score` | integer | not null | 0–15 component. |
| `accepted_article_count` | integer | not null, default 0 | Current accepted member count. |
| `independent_domain_count` | integer | not null, default 0 | Current unique-domain count. |
| `last_covered_at` | timestamp | nullable, indexed | Most recent accepted report time. |
| `score_updated_at` | timestamp | nullable | Last calculation time. |
| `created_at`, `updated_at` | timestamp | not null | Audit fields. |

### 6.2 `article_story_memberships`

| Column | Type | Constraint | Description |
|---|---|---|---|
| `id` | integer | primary key | Membership identifier. |
| `article_id` | integer | FK, unique | An article belongs to one current cluster. |
| `cluster_id` | integer | FK, indexed | Target cluster. |
| `match_confidence` | float | 0–1 | Matching result. |
| `status` | string(20) | `accepted`, `needs_review`, `rejected` | Editorial state. |
| `match_signals_json` | text/JSON | not null | Component scores/conflicts for explainability. |
| `matched_at`, `reviewed_at` | timestamp | nullable | Lifecycle timestamps. |
| `reviewed_by_user_id` | integer | FK `users.id`, nullable | Admin reviewer. |

An accepted `article_story_memberships` row synchronizes `Article.primary_article_id` to the cluster’s canonical article for backwards compatibility. It MUST NOT overwrite the source article itself.

## 6.3 Truth Score Corroboration Integration

Story Cluster replaces exact `content_hash` equality as the source of **cross-source corroboration** for Truth Score.

- `content_hash` remains an exact-duplicate signal: equal non-null values produce matching confidence 1.0 and are eligible for immediate accepted membership.
- It MUST NOT be removed from `Article` or repurposed as a semantic-similarity score.
- For an article in an accepted Story Cluster, Truth Score’s corroboration component MUST count distinct normalized source domains among the cluster’s accepted, active members.
- `needs_review` and `rejected` memberships MUST NOT contribute to Truth Score, Trending Score, source coverage, or Daily Brief selection.
- An article outside a cluster, or in a one-domain cluster, receives zero Truth Score corroboration points.
- When an accepted membership is added, removed, merged, split, or its canonical article changes, the service MUST re-score all accepted cluster members’ Truth Score and then recompute the cluster Trending Score in the same transaction where practical.

This preserves the two concerns: exact hashes catch copies reliably, while Story Clusters recognize independently written coverage of the same event.

## 7. Processing Lifecycle

```text
RawArticle promotion
  → normalize text and find bounded candidates
  → calculate similarity and check conflicts
  → create accepted/review membership or new cluster
  → choose canonical article
  → recompute cluster Trending Score
  → recompute Truth Score corroboration for accepted cluster members
  → expose grouped result to Feed and Daily Brief
```

- New articles create a one-member accepted cluster when no auto-match exists.
- A maintenance job re-scores clusters with activity in the last 72 hours every hour.
- Cluster scoring/membership updates MUST commit atomically with an accepted promotion when possible.
- Any matching failure MUST preserve the Article as a one-member cluster, log a safe error, and not fail scraping.

## 8. API and UI Contracts

### Admin API

- `GET /api/admin/story-clusters?status=needs_review` lists clusters/members and matching evidence.
- `POST /api/admin/story-clusters/<cluster_id>/review` accepts `{ action: "accept" | "reject" | "set-canonical", article_id? }`.
- `POST /api/admin/story-clusters/<cluster_id>/merge` accepts a target cluster ID.
- `POST /api/admin/story-clusters/<cluster_id>/split` accepts member article IDs to move into a new cluster.

All are admin-only and record the acting user plus action time.

### Reader presentation

A grouped article card displays the canonical article, `Covered by N independent sources`, Trending Score only when `N >= 2`, and up to four accepted alternate headlines/source links. It does not show unreviewed memberships.

## 9. Non-functional Requirements

- No Gemini, embedding API, or external inference request is required in v1.
- Candidate comparison completes in under 300 ms for at most 100 candidates per article.
- Scoring is deterministic for the same stored inputs/configuration.
- Raw article bodies are not stored in logs or matching-audit JSON.
- Existing exact URL/content deduplication remains unchanged.

## 10. Acceptance Tests

1. Three reports from different domains about the same event with matching descriptions enter one accepted cluster and raise independent-domain coverage to 3.
2. Reports with similar titles but incompatible casualty counts remain separate or `needs_review`.
3. Several reports from one domain increase velocity but count once for coverage and source-quality diversity.
4. A six-hour burst scores higher than an equally covered cluster whose newest report is 48 hours old.
5. A `needs_review` membership changes neither public card source count nor Trending Score until accepted by an admin.
6. A Daily Brief selects one canonical article per eligible cluster and uses the documented blended rank.
7. Re-running matching and scoring with unchanged records produces identical memberships and scores.
8. Three accepted members from independent domains with different content hashes increase every active member’s Truth Score corroboration component according to the existing 1/2/3/4+ domain thresholds.
