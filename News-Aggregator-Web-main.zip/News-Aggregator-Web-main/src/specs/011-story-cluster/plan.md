# Implementation Plan: Story Clusters & Trending Score

**Branch**: `011-story-cluster` | **Date**: 2026-08-17 | **Spec**: [spec.md](spec.md)

## Summary

Implement a deterministic Story Cluster system that groups separately written reports of the same event, computes a cluster-level Trending Score, and uses accepted cross-source membership as the corroboration input for Truth Score. Exact `content_hash` remains the cheap, high-confidence duplicate signal; it is not replaced or treated as semantic similarity.

The release adds two persistence models, a bounded two-stage matching service, reviewable memberships, Trending Score maintenance, Truth Score integration, grouped presentation data, and distinct-event Daily Brief ranking. No Gemini, embedding API, or external inference request is required in v1.

## Technical Context

**Language/Version**: Python 3.11+, Flask, Flask-SQLAlchemy, Alembic, APScheduler

**Storage**: PostgreSQL / Supabase in production; SQLite in the current automated test suite.

**Existing State**:

- `Article` already has `content_hash`, `title_fingerprint`, `primary_article_id`, and `truth_score`.
- `truth_score_service.py` currently clusters only equal `content_hash` values and uses those members for corroboration.
- `ScraperService.process_raw_article()` computes the hash/fingerprint, classifies the Article, flushes it, then runs Truth Score persistence before commit.
- `brief_service.py` selects canonical (`primary_article_id IS NULL`) items first.
- Admin duplicate APIs already establish route/authorization conventions, but their purpose is data cleanup, not event clustering.

**Project Type**: Flask MVC application with Jinja templates and vanilla JavaScript. First delivery adds API/data capabilities; grouped reader cards can be delivered after the cluster service is proven.

## Constitution Check

- **MVC**: Models stay in `models.py`, matching/scoring lives in `story_cluster_service.py`, controllers in `routes.py` remain thin.
- **Data integrity**: accepted membership, canonical synchronization, Trending Score, and affected Truth Scores are recalculated in one transaction where possible.
- **Resilience**: matching failure falls back to a valid one-member accepted cluster and cannot fail scraping.
- **Security**: review, merge, split, and backfill operations are admin-only and auditable.
- **Cost control**: v1 uses local TF-IDF/n-gram/token calculations only; no API key or quota is consumed.

## Project Structure (Post-Implementation)

```text
src/
├── models.py                                      # [MODIFY] StoryCluster, ArticleStoryMembership, Article relation
├── routes.py                                      # [MODIFY] admin review/merge/split/list endpoints
├── services/
│   ├── story_cluster_service.py                   # [NEW] candidate retrieval, matching, review, Trending Score
│   ├── scraper_service.py                         # [MODIFY] create/update membership during promotion
│   ├── truth_score_service.py                     # [MODIFY] corroboration from accepted Story Cluster members
│   ├── brief_service.py                           # [MODIFY] cluster rank and canonical selection
│   ├── article_service.py                         # [MODIFY] grouped card serialization
│   └── scheduler_service.py                       # [MODIFY] hourly active-cluster maintenance
├── migrations/versions/
│   └── <revision>_story_clusters.py               # [NEW] tables, indexes, backwards-compatible fields
├── templates/partials/
│   └── _story_cluster_coverage.html               # [NEW] optional alternate-headline/source list
├── static/js/
│   └── admin_story_clusters.js                    # [NEW] review console controller, if admin UI ships in v1
└── tests/
    ├── test_story_cluster_service.py              # [NEW] matching and Trending Score tests
    ├── test_story_cluster_routes.py               # [NEW] admin API tests
    └── test_daily_brief_clusters.py               # [NEW] distinct-event brief tests
```

## Implementation Phases

### Phase 1 — Data Model and Additive Migration

**Objective**: Persist clusters/memberships without breaking existing Article or Truth Score behavior.

1. Add `StoryCluster` and `ArticleStoryMembership` SQLAlchemy models with the fields, constraints, and audit relationships from spec §6.
2. Add `Article.story_membership` one-to-one relationship. Keep `primary_article_id` for backwards compatibility; do not remove or change existing duplicate tools.
3. Create an additive Alembic migration:
   - tables and foreign keys;
   - unique `article_id` membership constraint;
   - checks for score/match-confidence ranges and membership status;
   - indexes for cluster/status, active maintenance, canonical article, and temporal candidate queries.
4. Do not backfill immediately in the migration. Existing articles remain valid standalone records until a controlled service backfill creates one-member clusters.

**Acceptance criteria**

- Upgrade retains all Article, Truth Score, and Daily Brief data.
- An article has at most one current membership.
- A cluster can exist without a canonical article only while it is being created inside a transaction.

### Phase 2 — Deterministic Candidate Matching

**Objective**: Match related reports reliably without external inference.

1. Add `services/story_cluster_service.py` with pure helpers:

| Function | Responsibility |
|---|---|
| `normalize_text()` | Lowercase, normalize whitespace/punctuation, retain Vietnamese diacritics, remove configured stop words. |
| `extract_event_anchors()` | Extract meaningful numbers, dates and named/capitalized terms for overlap/conflict checks. |
| `find_candidates(article, limit=100)` | Return active, indexed candidates within 72 hours sharing category/token signals. |
| `similarity_signals(article, candidate)` | Compute title, description/content, entity and time signals plus conflicts. |
| `match_confidence(signals)` | Apply the documented 0.45/0.30/0.15/0.10 weights. |
| `choose_cluster(article)` | Return accepted, review, or new-cluster decision using the 0.72/0.60 thresholds. |

2. Use exact equal `content_hash` as confidence 1.0 and an immediately accepted path.
3. Use token and character n-gram TF-IDF/cosine comparison for non-exact reports. The implementation may use `scikit-learn` only if already present/approved; otherwise implement a small deterministic token-vector cosine helper to avoid a new heavy runtime dependency.
4. Block automatic acceptance for conflicting anchor values. Persist explanation signals only, never raw article body.
5. Treat title-only candidates as `needs_review` unless the total score reaches the automatic threshold through additional description/entity/time evidence.

**Acceptance criteria**

- The three cross-source exam reports in the reference scenario are eligible candidates despite distinct hashes and titles.
- Same event reports above 0.72 enter one accepted cluster.
- Similar headlines with incompatible high-confidence anchors do not auto-cluster.
- Candidate work is bounded to 100 recent reports.

### Phase 3 — Membership Lifecycle and Trending Score

**Objective**: Make accepted membership and current momentum auditable and deterministic.

1. Implement create/update membership functions for `accepted`, `needs_review`, and `rejected` states.
2. Implement canonical selection: prefer the earliest accepted report from the highest-reliability configured source; ties use earliest publication/scrape time and ID. Synchronize accepted non-canonical Article records’ `primary_article_id`.
3. Implement `calculate_trending_score(cluster)` with source coverage, six-hour velocity, exponential recency, and source quality/diversity components from spec §5.
4. Implement `recalculate_cluster(cluster_id)` to refresh counts, score components, canonical article, and timestamps atomically.
5. Implement admin review actions: accept/reject membership, set canonical, merge clusters, and split members into a new cluster; all record reviewer and timestamp.
6. Implement `backfill_story_clusters(batch_size=200)` to create one-member clusters and attempt matching for historical active articles in independent batches.

**Acceptance criteria**

- `needs_review` items are excluded from every public count and score.
- Adding a fourth independent accepted domain yields 35 coverage points.
- Trend decays without new coverage and increases with a six-hour burst.
- Merge/split/review re-scores all affected clusters.

### Phase 4 — Pipeline, Truth Score, and Scheduler Integration

**Objective**: Make Story Cluster the authoritative source of cross-source corroboration while preserving exact duplicate safeguards.

1. Modify `ScraperService.process_raw_article()` after Article flush to call `assign_article_to_cluster(article)` before Truth Score calculation.
2. Modify `truth_score_service.py`:
   - retain `content_hash` as exact-match shortcut;
   - source corroboration members from the Article’s accepted Story Cluster where one exists;
   - otherwise score only the article itself;
   - re-score all active accepted cluster members after membership changes.
3. Modify `brief_service.py` to join/use `StoryCluster.trending_score`, rank canonical items with `0.55 * trending + 0.45 * truth`, and retain existing preference and recency filtering.
4. Add hourly `story_cluster_maintenance` job after scraper work that re-evaluates clusters active in 72 hours, then invokes the existing Truth Score maintenance path for affected articles.
5. Ensure any Story Cluster failure leaves the Article in a one-member accepted cluster or, if persistence itself fails, promotes the Article without a membership and logs a safe error. It must not create a fake score.

**Acceptance criteria**

- Different-hash accepted reports increase each other’s Truth Score corroboration by distinct domain count.
- One source’s multiple URLs count once for corroboration/coverage yet contribute to velocity.
- A Daily Brief selects distinct events before fallback candidate selection.

### Phase 5 — Admin APIs and Grouped Reader Presentation

**Objective**: Provide review controls and make grouping useful to readers.

1. Add admin-only list/review/merge/split API endpoints defined in spec §8, reusing `_get_admin_user()` authorization and existing JSON conventions.
2. Add server serialization for a clustered article: canonical article, accepted source count, Trending Score when source count >=2, and up to four alternate headline/source links.
3. Add a reusable reader partial beneath the canonical card/detail header. Do not expose unreviewed members or match scores publicly.
4. Add an admin review console only if the existing Admin Dashboard supports a tab without significant UX regression; otherwise ship API plus a documented maintenance procedure first.

**Acceptance criteria**

- Non-admin calls are denied.
- Reader UI shows a canonical report and alternate angles only for accepted members.
- A single-source cluster does not misleadingly claim cross-source coverage.

### Phase 6 — Tests and Rollout

1. Unit-test normalization, candidate bounding, all matching signals, threshold behavior, conflict safeguards, canonical ties, and Trending Score component boundaries.
2. Integration-test scraper assignment, Truth Score corroboration across differing hashes, Daily Brief blended ranking/diversity, review/merge/split, and API authorization.
3. Backfill a production-like copy with a dry-run report: articles scanned, clusters created, auto-accepted/review/rejected counts, score distribution, and false-positive sample review.
4. Enable automatic clustering only after reviewing a representative sample. Start with `needs_review` reporting enabled and monitor false positive/negative rates.

## Implementation Order

1. Schema/migration and pure matching tests.
2. Membership lifecycle and Trending Score service.
3. Controlled backfill/dry run with sample review.
4. Scraper and Truth Score integration.
5. Daily Brief integration.
6. Admin APIs, then reader UI.

## Key Decisions and Risks

| Decision/Risk | Handling |
|---|---|
| Exact copies versus related coverage | Preserve `content_hash` for exact matching; use Story Cluster for semantic event relation. |
| False positive event grouping | Use bounded signals, conflict safeguards, high auto threshold, and review band. |
| Vietnamese text quality | Retain diacritics and use word + character n-grams; evaluate real source samples before tuning thresholds. |
| New stories evolve over days | Restrict automatic matching to 72 hours; editorial merge can combine valid continuing coverage. |
| Trending overwhelms reliability | Blend Trending Score with Truth Score for Daily Brief rather than replacing it. |
| AI quota/cost | No Gemini or external embedding API in v1. |
