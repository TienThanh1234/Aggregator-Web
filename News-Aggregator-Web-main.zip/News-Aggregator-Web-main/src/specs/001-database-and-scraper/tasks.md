# Tasks: Database Schema and Automated Scraping Pipeline

**Input**: Design documents from [spec.md](spec.md) and [plan.md](plan.md)

**Prerequisites**: plan.md (required), spec.md (required for user stories)

**Branch**: `001-database-and-scraper`

## Phase 1: Foundation — Database and Environment Setup

**Purpose**: Establish the persistence layer and application configuration required before scraper implementation.

### Implementation Tasks

- [x] T001 [P] Create or update the Flask application configuration in [src/app.py](src/app.py) to initialize SQLAlchemy and load environment variables from .env.
  - **Acceptance Criteria**: The app imports successfully, loads database settings from environment variables, and creates the SQLAlchemy engine without hardcoded secrets.

- [x] T002 [P] Implement the SQLAlchemy models in [src/models.py](src/models.py) for User, Article, RawArticle, Category, Bookmark, and the article_categories association table.
  - **Acceptance Criteria**: The model classes are defined with the required fields, types, constraints, and relationships, and can be imported by the Flask app.

- [x] T003 [P] Create or update the environment configuration file [src/.env](src/.env) and provide a template example in [src/.env.example](src/.env.example) for Supabase PostgreSQL connection settings.
  - **Acceptance Criteria**: The application can read database host, port, database name, username, password, and SSL settings from environment variables without manual code edits.

- [x] T004 Create the database schema through Flask-SQLAlchemy initialization and perform migration steps using Flask-Migrate commands.
  - **Acceptance Criteria**: The database tables users, articles, categories, article_categories, and bookmarks are created in the target PostgreSQL instance, and the schema can be upgraded successfully.

---

## Phase 2: Scraper Core Development

**Purpose**: Build the ingestion pipeline with ETL(Extract, Transform, Load) process to collect article data from external sources and store it safely.

### Implementation Tasks

- [x] T005 Implement the HTTP request layer in the scraper module to fetch HTML from the target news listing page.
  - **Acceptance Criteria**: A request to the configured news source returns HTML content or a handled exception; the scraper catches timeouts, connection failures, and HTTP errors without crashing the app.
  - **Implementation**: `src/scraper/base_scraper.py:fetch_page()` implements requests.Session with Retry strategy (3 retries, 1s backoff), 10s timeout, User-Agent header, and comprehensive exception handling for Timeout, ConnectionError, HTTPError, and RequestException.

- [x] T006 Implement HTML parsing logic with BeautifulSoup to extract article links from the listing page and detail-page metadata from each article.
  - **Acceptance Criteria**: [Extract]: Successfully parse the HTML structure of the news listing page to identify article URLs. Fetch and extract core metadata (title, description, cover_image_url, published_at) and raw HTML content from individual article pages. Handle missing metadata gracefully with default values or nulls. [Transform]: Clean raw_content by stripping irrelevant HTML tags, e.g., <script>, <style>, <iframe>. Normalize published_at timestamps into Python datetime objects. Implement get_or_create logic for categories; map missing categories to a "General" group. [Load]: Encapsulate insertion within an atomic database transaction. Ensure Article records and article_categories associations commit together; rollback on any failure to maintain referential integrity. [Logging]: Log successes with: [SUCCESS] Parsed & Transformed: <title>. Log skips/failures with: [SKIP/FAIL] : <url> - Reason: <specific_error>.
  - **Implementation**: `src/scraper/vnexpress_scraper.py` implements concrete scraper with `_extract_article_links()` (parsing selector-based links), `_extract_article_data()` (parsing title, description, image, content), and `transform()` (normalizes data, handles nulls). Comprehensive error logging per constitution Principle VI.

- [x] T007 Implement duplicate prevention logic by checking each discovered article URL against the articles table using source_url before insertion.
  - **Acceptance Criteria**: When a URL already exists in the database, the scraper logs a skip event and does not create a duplicate row.
  - **Implementation**: `src/services/scraper_service.py:article_exists()` queries Article table by source_url; `save_raw_article()` checks before insert and logs [SKIP] on duplicate. IntegrityError handler provides fallback catch on DB constraint.

- [x] T008 Implement article persistence and category association handling so new articles are stored with their related categories.
  - **Acceptance Criteria**: A new article with valid data is inserted into the database and linked to the correct category rows through the intermediary table.
  - **Implementation**: `src/services/scraper_service.py:save_raw_article()` creates RawArticle to staging table with atomic commit. `process_raw_article()` transforms RawArticle to Article, creates/associates categories via article.categories.append(), and links raw_article.article_id. Full rollback on IntegrityError or SQLAlchemyError.

---

## Phase 3: Scheduling and Reliability

**Purpose**: Automatically run the scraper in the background and make the pipeline resilient to failures.

### Implementation Tasks

- [x] T009 Integrate APScheduler with the Flask application so the scraping job runs automatically in the background every hour.
  - **Acceptance Criteria**: The scheduler starts with the Flask app, runs the scraper job on the configured interval, and does not block UI request handling.
  - **Implementation**: `src/services/scheduler_service.py:SchedulerService` manages APScheduler initialization. `init_app()` registers `_scraper_job()` with `IntervalTrigger(hours=1)`. App teardown handler calls `shutdown()`. Job runs in background thread via BackgroundScheduler.

- [x] T010 Add structured logging and error-handling blocks for scraper execution, including success, skip, and failure events.
  - **Acceptance Criteria**: The application logs messages matching the required patterns such as [SUCCESS], [SKIP], and [ERROR], and exceptions are recorded with relevant context.
  - **Implementation**: `_scraper_job()` logs: [INFO] start/progress, [SUCCESS] import summary, [SKIP] duplicates/invalid, [ERROR] exceptions (with exc_info=True), [WARNING] minor issues. All logging follows constitution Principle VI.

- [x] T011 Implement safe transaction handling so database write failures rollback cleanly and do not leave partial state behind.
  - **Acceptance Criteria**: If a database commit fails, the session is rolled back and no inconsistent article/category state is persisted.
  - **Implementation**: `ScraperService` methods use try-except-finally: db.session.commit() with IntegrityError/SQLAlchemyError rollback handlers. Job execution isolated per run (no cross-job state). RawArticle staging table maintains audit trail.

---

## Phase 4: Verification and Test Coverage

**Purpose**: Validate the database and scraper flows through automated tests and cross-check review.

### Implementation Tasks

- [X] T012 Create unit tests for duplicate prevention logic in the scraper flow.
  - **Acceptance Criteria**: A test with an existing source_url proves that no duplicate article record is inserted and a skip event is logged.

- [x] T013 Create unit tests for database persistence and category association behavior.
  - **Acceptance Criteria**: A valid article payload creates a persisted article and associated category rows in the test database.

- [x] T014 Create unit tests for network and parsing failure handling.
  - **Acceptance Criteria**: A timeout or malformed HTML scenario is handled gracefully, logs an error, and returns a controlled failure result without crashing the application.

---

## Cross-Check Review Checklist

- [x] Reviewer confirms that all required tables and constraints exist in the target database.
- [x] Reviewer confirms that duplicate articles are skipped by source_url and logged.
- [x] Reviewer confirms that the scraper can run automatically on an hourly schedule.
- [x] Reviewer confirms that errors are logged and do not crash the application.
