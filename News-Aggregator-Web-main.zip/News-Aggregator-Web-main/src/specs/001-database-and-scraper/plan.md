# Implementation Plan: Database Schema and Automated Scraping Pipeline

**Branch**: `001-database-and-scraper` | **Date**: 2026-06-26 | **Spec**: [spec.md](spec.md)

## Summary

This plan implements the MVP foundation for the News Aggregator Web Application by introducing a structured PostgreSQL-backed data model, a modular scraping layer for Vietnamese news sources, and an automated scheduler that keeps the dataset fresh without interrupting the web app. The work is divided into four implementation phases: database and ORM setup, scraper development, scheduler integration, and reliability/testing hardening.

## Technical Context

**Language/Version**: Python 3.11+

**Primary Dependencies**: Flask, Flask-SQLAlchemy, psycopg2-binary or psycopg, Requests, beautifulsoup4, APScheduler, python-dotenv, pytest

**Storage**: PostgreSQL (Supabase-compatible) for production and local PostgreSQL for development/testing

**Testing**: pytest with isolated database fixtures and mocked HTTP responses

**Target Platform**: Linux-compatible server environment and local development workstation

**Project Type**: Web service

**Performance Goals**: Scraping job completes within a bounded interval, duplicate checks stay efficient, and page rendering remains responsive while background jobs run

**Constraints**: Network-dependent scraping, external site anti-bot protections, no hardcoded secrets, and respect for rate limiting and site terms

**Scale/Scope**: MVP covering one or two Vietnamese news sources with hourly background ingestion and basic persistence for articles, categories, users, and bookmarks

## Constitution Check

The implementation plan conforms to the constitution in the following ways:

- Modular scraping is enforced through a shared BaseScraper abstraction and source-specific subclasses under the scraper package.
- MVC boundaries remain intact by keeping ORM model definitions in models.py, route handlers thin in routes.py, and business logic in a new services layer.
- Configuration values and secrets are treated as environment variables loaded from .env and documented through a .env.example file.
- Duplicate prevention is handled through pre-insert checks and a unique constraint on articles.source_url.
- Logging is implemented with Python’s standard logging module and structured messages for success, skip, and error paths.
- Unit and integration tests are planned for scraper behavior, database persistence, and duplicate handling.

## Project Structure

```text
src/
├── app.py
├── models.py
├── routes.py
├── services/
│   ├── __init__.py
│   ├── scraper_service.py
│   └── scheduler_service.py
├── scraper/
│   ├── __init__.py
│   ├── base_scraper.py
│   └── vnexpress_scraper.py
├── templates/
├── static/
├── tests/
│   ├── unit/
│   └── integration/
└── .env.example
```

**Structure Decision**: The feature will follow a single Flask application layout with models in models.py, scraper logic in the scraper package, orchestration logic in services, and thin route handlers in routes.py.

## Implementation Phases

### Phase 1 — Database & Models Setup

**Objective**: Establish the relational foundation for all application data and ensure integrity constraints support future UI and AI features.

#### Work Items

1. Configure the Flask application to initialize SQLAlchemy and load environment-based database credentials from .env.
2. Define the SQLAlchemy models in models.py for the following entities:
   - User
   - Article
   - Category
   - ArticleCategory association table
   - Bookmark
3. Implement the required fields and constraints as follows:
   - users.id: integer primary key
   - users.email: unique, non-null string
   - users.password_hash: non-null string
   - users.role: string with default value user
   - users.created_at: datetime with default current UTC time
   - articles.id: integer primary key
   - articles.title: non-null string
   - articles.description: nullable text
   - articles.raw_content: nullable text
   - articles.source_url: non-null string with a database-level unique index for duplicate detection
   - articles.cover_image_url: nullable string
   - articles.published_at: nullable datetime
   - articles.scraped_at: datetime with default current UTC time
   - articles.ai_summary: nullable text
   - articles.truth_score: nullable float
   - categories.id: integer primary key
   - categories.name: unique, non-null string
   - article_categories.article_id: foreign key to articles.id
   - article_categories.category_id: foreign key to categories.id
   - bookmarks.id: integer primary key
   - bookmarks.user_id: foreign key to users.id, non-null
   - bookmarks.article_id: foreign key to articles.id, non-null
   - bookmarks.created_at: datetime with default current UTC time
4. Implement the relationships:
   - Many-to-many relation between Article and Category through the association table
   - Many-to-one relation from Bookmark to User and Bookmark to Article
5. Create the schema through SQLAlchemy initialization and, where applicable, Alembic migrations for versioned deployment.
6. Add a repository/service helper for duplicate checks using the normalized source URL.

#### Acceptance Criteria

- The database schema can be created successfully from the Flask app startup path.
- A new article can be inserted with the correct metadata and category mapping.
- A second insert with the same source_url is rejected or skipped before commit.

---

### Phase 2 — Scraper Development

**Objective**: Add a reusable scraping pipeline that can visit one or two Vietnamese news sources, extract article metadata, and store it safely in the database.

#### Architecture

1. Create a base abstraction named BaseScraper with the following contract:
   - scrape(): orchestrates the full ingestion flow
   - validate_data(): checks required fields before persistence
   - transform(): normalizes values into a consistent internal representation
2. Implement at least one concrete scraper subclass, such as VnExpressScraper, that inherits from BaseScraper and targets a specific site structure.
3. Place shared scraping logic in the base class, including retry handling, timeout configuration, HTML parsing helpers, and logging wrappers.
4. Use Requests for HTTP GET calls and BeautifulSoup to parse HTML.

#### Scraping Algorithm

1. Send an HTTP request to a category or homepage listing page.
2. Parse the listing HTML to extract links to the latest article detail pages.
3. For each discovered URL, check whether the article already exists by querying the database using source_url.
4. If the article is new, visit the detail page and parse:
   - title
   - description
   - cover image URL
   - raw_content
   - published_at
5. Normalize the extracted values and map them to the Article model.
6. Resolve or create relevant Category instances and link them to the article.
7. Persist the article through Flask-SQLAlchemy and commit the transaction safely.

#### Duplicate Prevention Logic

- Before inserting a new article, query the database for an existing article with the same source_url.
- If a match exists, log a skip event and continue to the next URL.
- This prevents database errors, duplicate records, and unnecessary resource consumption.

#### Acceptance Criteria

- The scraper can fetch a listing page and a detail page successfully for a supported source.
- New articles are inserted into the database and linked to categories.
- Existing articles are skipped without creating duplicate rows.

---

### Phase 3 — Scheduler Integration

**Objective**: Run the scraper automatically in the background at a fixed interval without blocking user-facing requests.

#### Work Items

1. Create a scheduler service module that initializes an APScheduler BackgroundScheduler.
2. Register a job that calls the scraper service once every hour.
3. Start the scheduler during Flask app initialization and shut it down cleanly on application exit.
4. Ensure the job runs independently of request handling so that scraping work does not block normal UI traffic.
5. Configure job defaults such as misfire handling and a safe execution policy for repeated runs.

#### Implementation Notes

- The scheduler should be started once when the Flask app boots, not for every request.
- The job should be resilient to transient failures and should not raise unhandled exceptions that stop the scheduler loop.
- Logging should clearly indicate when the job starts, when it succeeds, and when it fails.

#### Acceptance Criteria

- The scheduler starts automatically when the Flask app is launched.
- The scraper job runs once per hour by default.
- A scraping failure does not crash the app or block other requests.

---

### Phase 4 — Error Handling, Logging & Testing

**Objective**: Make the ingestion pipeline safe, observable, and testable under real-world failure conditions.

#### Error Handling Plan

1. Wrap HTTP requests in try/except blocks to handle:
   - timeouts
   - connection errors
   - HTTP 404/403/429/500 responses
2. Wrap HTML parsing logic in defensive checks so malformed pages do not crash the process.
3. On any failed request or parse, log the exception with source context and continue to the next item where possible.
4. Use session rollback on database write failures to avoid leaving the database in an inconsistent state.

#### Logging Plan

Configure a structured logger with at least the following message patterns:

- [SUCCESS] Scraped X articles
- [SKIP] Article already exists
- [ERROR] Connection failed
- [ERROR] Parsing failed for article URL

Each log message should include context such as source name, article URL, and timestamp.

#### Unit Testing Plan

At minimum, the following unit tests should be implemented:

1. Test duplicate prevention logic:
   - Given an existing article with a matching source_url, the scraper should skip insertion and log a skip event.
2. Test database model persistence:
   - Given valid article data, the model should persist correctly and establish category associations through the association table.
3. Test HTTP failure handling:
   - Given a timeout or connection error, the scraper should log an error and return an empty result instead of crashing.
4. Optional but recommended: test data transformation and normalization logic to ensure title, description, and published date formatting remain consistent.

#### Acceptance Criteria

- Scraper failures are logged and contained without crashing the application.
- Unit tests pass for duplicate handling, persistence, and error recovery paths.
- The logging output provides enough detail to diagnose the latest scraping run.

## Implementation Order

1. Environment configuration and dependency installation
2. Data model creation and schema initialization
3. Base scraper abstraction and concrete scraper implementation
4. Database persistence and duplicate detection
5. Scheduler registration and hourly execution
6. Logging and tests

## Deliverables

- SQLAlchemy models for users, articles, categories, article_categories, and bookmarks
- A modular scraper package with one concrete source adapter
- A scheduled hourly ingestion job integrated into the Flask app lifecycle
- Logging and test coverage for critical scraper and persistence paths
