# Feature Specification: Database Schema and Automated Scraping Pipeline

**Feature Branch**: `001-database-and-scraper`

**Created**: 2026-06-26

**Status**: Draft

**Input**: User description: "Design a detailed database schema and automated news scraping pipeline for the News Aggregator Web Application, using Flask, Flask-SQLAlchemy, PostgreSQL (Supabase), BeautifulSoup4, Requests, and APScheduler."

## User Scenarios & Testing

### User Story 1 - Persist news content in a reliable data model (Priority: P1)

As a platform maintainer, I want the application to store articles and related metadata in a structured database so that news content can be displayed consistently and prepared for future AI-powered features.

**Why this priority**: This is the core foundation of the application. Without a stable schema, the web app cannot reliably store, query, or present articles.

**Independent Test**: A fresh database can be initialized, the scraper can run once, and the system can verify that article records and related relationships are created successfully.

**Acceptance Scenarios**:

1. **Given** an empty database, **When** the scraper processes a listing page and a detail page, **Then** a new article record is created with the expected metadata fields and a unique source URL.
2. **Given** a previously scraped article with the same source URL, **When** the scraper runs again, **Then** the duplicate article is skipped and no duplicate record is inserted.

---

### User Story 2 - Automatically collect fresh news from external sources (Priority: P2)

As an application operator, I want the scraper to run automatically on a schedule so that new news is collected without manual intervention.

**Why this priority**: Automation is essential for keeping the platform updated and reducing manual maintenance effort.

**Independent Test**: The scheduler starts with the Flask application and runs the scraping job at the configured interval without requiring a manual trigger.

**Acceptance Scenarios**:

1. **Given** the Flask app is running, **When** the scheduler is enabled, **Then** a background job executes the scraping task at the configured interval.
2. **Given** the scraper finds new article links on a source page, **When** the job completes, **Then** the relevant records are inserted into the database and become available to the application.

---

### User Story 3 - Handle scraping failures gracefully (Priority: P3)

As a developer or maintainer, I want the scraper to fail safely and log useful diagnostics when requests fail or HTML structure changes, so the app remains stable during network or anti-bot issues.

**Why this priority**: Robust error handling protects the application from crashes and makes debugging easier during real-world deployment.

**Independent Test**: The scraper can be run against an unavailable or malformed source, and the system must log the error while continuing to operate.

**Acceptance Scenarios**:

1. **Given** the target site rejects the request or returns an error, **When** the scraper attempts to fetch content, **Then** the exception is caught, logged, and the app continues running.
2. **Given** the HTML structure changes unexpectedly, **When** parsing fails for one field, **Then** the scraper stores available data safely and records the parsing issue in logs.

---

### Edge Cases

- If a request returns HTTP 403, 429, 500, or times out, the system must log the issue and stop that run gracefully instead of crashing the application.
- If an article is missing a title, description, or cover image, the scraper must store the available fields and leave the missing values as null or empty as appropriate.
- If a source page contains duplicate links or a malformed link, the system must avoid creating duplicate records and continue processing the remaining items.
- If category names already exist, the system must reuse the existing category row rather than creating duplicates.

## Requirements

### Functional Requirements

- **FR-001**: The system MUST define SQLAlchemy models for users, articles, categories, article_categories, and bookmarks using Flask-SQLAlchemy.
- **FR-002**: The system MUST use PostgreSQL as the relational database backend, with the connection configured for the Flask application and intended for deployment through Supabase.
- **FR-003**: The system MUST enforce uniqueness on users.email, articles.source_url, and categories.name.
- **FR-004**: The system MUST store the article metadata fields title, description, raw_content, source_url, cover_image_url, published_at, scraped_at, ai_summary, and truth_score using appropriate SQLAlchemy column types.
- **FR-005**: The system MUST support the relationship between articles and categories through an association table named article_categories.
- **FR-006**: The system MUST support the relationship between users and articles through bookmarks, where each bookmark belongs to exactly one user and one article.
- **FR-007**: The system MUST provide a scraper module that requests HTML content from one or two Vietnamese news sources such as VnExpress or Tuổi Trẻ.
- **FR-008**: The system MUST parse the listing page to discover the most recent article links and extract the relevant article URLs.
- **FR-009**: The system MUST detect duplicate articles by checking the articles.source_url column before inserting a new article row.
- **FR-010**: The system MUST parse each article detail page and extract title, short description, cover image URL, raw content text, and published timestamp.
- **FR-011**: The system MUST persist scraped data into the database through Flask-SQLAlchemy and commit changes safely using a transaction-safe session pattern.
- **FR-012**: The system MUST configure an APScheduler-based background job that runs the scraper automatically at a fixed interval of one hour.
- **FR-013**: The system MUST wrap network requests and HTML parsing in try/except blocks so that temporary failures do not crash the Flask application.
- **FR-014**: The system MUST log detailed execution results, including the number of successfully scraped articles, the number of duplicates skipped, and any exceptions encountered.
- **FR-015**: The system MUST continue processing subsequent articles even if a single page fails to parse, rather than aborting the entire batch.

### Database Schema Specification

The following entities and fields are required for the initial implementation:

- **User**
  - id: primary key
  - email: unique string
  - password_hash: string
  - role: enum or string with values such as guest, user, admin
  - created_at: timestamp

- **Article**
  - id: primary key
  - title: string
  - description: string
  - raw_content: text
  - source_url: unique string
  - cover_image_url: string
  - published_at: timestamp
  - scraped_at: timestamp
  - ai_summary: text, nullable, default null
  - truth_score: float, nullable, default null

- **Category**
  - id: primary key
  - name: unique string, for example: Kinh tế, Công nghệ, Thể thao

- **ArticleCategory**
  - This is an association table used to implement the many-to-many relationship between articles and categories.

- **Bookmark**
  - id: primary key
  - user_id: foreign key to users.id
  - article_id: foreign key to articles.id
  - created_at: timestamp

Suggested SQLAlchemy model structure:

```python
class User(db.Model):
    __tablename__ = "users"
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(255), unique=True, nullable=False)
    password_hash = db.Column(db.String(255), nullable=False)
    role = db.Column(db.String(50), nullable=False, default="user")
    created_at = db.Column(db.DateTime, default=datetime.utcnow)

class Article(db.Model):
    __tablename__ = "articles"
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(500), nullable=False)
    description = db.Column(db.Text)
    raw_content = db.Column(db.Text)
    source_url = db.Column(db.String(1000), unique=True, nullable=False)
    cover_image_url = db.Column(db.String(1000))
    published_at = db.Column(db.DateTime)
    scraped_at = db.Column(db.DateTime, default=datetime.utcnow)
    ai_summary = db.Column(db.Text, nullable=True)
    truth_score = db.Column(db.Float, nullable=True)

class Category(db.Model):
    __tablename__ = "categories"
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True, nullable=False)

article_categories = db.Table(
    "article_categories",
    db.Column("article_id", db.Integer, db.ForeignKey("articles.id"), primary_key=True),
    db.Column("category_id", db.Integer, db.ForeignKey("categories.id"), primary_key=True),
)

class Bookmark(db.Model):
    __tablename__ = "bookmarks"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id"), nullable=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
```

### Scraping Pipeline Workflow

The scraper will operate in the following sequence:

1. Send an HTTP request to a target news listing page.
2. Parse the HTML response with BeautifulSoup to identify article links from the latest section of the source.
3. Compare each discovered URL against the articles table using source_url to prevent duplicate insertion.
4. For each new article URL, request the detail page and parse the title, short description, cover image URL, raw content, and publication timestamp.
5. Create or associate categories as needed and store the article and its relationships in the database through Flask-SQLAlchemy.
6. Commit the session safely and log the outcome of the run.

### Key Entities

- **User**: Represents a platform account and is the owner of bookmarks.
- **Article**: Represents a scraped news item with metadata and raw content for later AI processing.
- **Category**: Represents one topical label used to classify articles.
- **Bookmark**: Represents a user’s saved article reference.
- **ArticleCategory**: Represents the many-to-many mapping between articles and categories.

## Success Criteria

### Measurable Outcomes

- **SC-001**: The system can initialize the database schema and insert at least one article after a successful scraping run.
- **SC-002**: Repeated runs do not create duplicate article rows for the same source URL.
- **SC-003**: The scheduler executes the scraper automatically at least once every hour during normal operation.
- **SC-004**: Network failures or parsing errors do not crash the application and are recorded in logs with sufficient detail for debugging.

## Assumptions

- The target news sources are publicly accessible and can be fetched over HTTP/HTTPS.
- The initial version focuses on 1-2 Vietnamese news sources and does not yet require a fully generalized scraping framework.
- A Supabase PostgreSQL instance or equivalent PostgreSQL service is available for development and testing.
- Initial scraping logic will use site-specific selectors and may need adjustment if the source HTML structure changes.
- AI summarization and truth scoring are deferred to a later phase and will use the stored raw_content field as input.
