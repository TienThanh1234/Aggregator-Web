"""HTTP controllers for page rendering and JSON interaction endpoints."""

from __future__ import annotations

import logging
import threading
import urllib.parse
import urllib.request
import uuid
from typing import Any

from flask import (
    Blueprint,
    Response,
    jsonify,
    redirect,
    render_template,
    request,
    url_for,
)

from services.article_service import (
    get_all_articles_legacy,
    get_article_detail,
    get_story_cluster_detail,
    get_categories,
    get_feed_articles,
    get_trending_articles,
)
from services.auth_service import (
    confirm_password_reset,
    get_current_user,
    login_user,
    logout_user,
    register_user,
    request_password_reset,
)
from services.profile_service import (
    change_password,
    get_profile_data,
    update_profile,
    upload_avatar,
)

from services.admin_service import (
    get_admin_articles,
    get_admin_users,
    get_dashboard_metrics,
    set_article_hidden,
    delete_article_permanently,
    set_user_active,
    get_scraper_runs,
    trigger_manual_scrape,
    get_suspect_duplicates,
    resolve_duplicates,
    get_pipeline_config,
    update_pipeline_config,
    delete_scraper_config,
    test_scraper_selectors,
)

from services.search_service import delete_user_search_history_entry, get_search_sources, get_trending_keywords, search_articles
from services.dashboard_service import get_user_preferences, update_user_preferences, get_user_bookmarks, remove_bookmark, toggle_article_bookmark, get_bookmark_status, get_user_comments, delete_user_comment, get_user_reactions, remove_user_reaction
from services.comment_service import create_comment, get_article_comments, toggle_reaction, get_reaction_summary
from services.moderation_service import (
    create_comment_report,
    create_prohibited_term,
    delete_comment_permanently,
    delete_prohibited_term,
    dismiss_comment_report,
    get_filter_events,
    get_moderation_comment_detail,
    get_moderation_comments,
    get_moderation_summary,
    hide_comment,
    list_prohibited_terms,
    restore_comment,
    update_prohibited_term,
)
from services.brief_service import generate_daily_brief, get_brief_history, get_latest_brief, get_todays_brief, mark_brief_read, get_brief_preferences, update_brief_preferences
from services.ai_service import fact_check_article, get_or_create_article_summary, summarize_article
from services.clarity_service import get_or_create_article_fact_check
from services.truth_score_service import backfill_truth_scores, get_truth_score_detail, score_article_and_cluster
from services.story_cluster_service import backfill_story_clusters, reset_story_clusters
from services.recommendation_service import (
    RecommendationValidationError,
    get_recommendations,
    validate_limit,
)

logger = logging.getLogger(__name__)
main_bp = Blueprint("main", __name__)


@main_bp.app_context_processor
def inject_search_sources() -> dict[str, list[str]]:
    """Expose available source hosts to the shared advanced-search form."""
    try:
        return {"search_sources": get_search_sources()}
    except Exception:
        logger.warning("Search source dropdown unavailable", exc_info=True)
        return {"search_sources": []}


def _get_auth_json_payload() -> tuple[
    dict[str, Any] | None,
    tuple[dict[str, str], int] | None,
]:
    """Return an object JSON request body or a consistent client error."""
    data = request.get_json(silent=True)
    if not isinstance(data, dict):
        return None, (
            {
                "status": "error",
                "message": "A JSON object request body is required.",
            },
            400,
        )
    return data, None


def _get_authenticated_user_id() -> tuple[
    int | None,
    tuple[dict[str, str], int] | None,
]:
    """Resolve the active session to a valid authenticated user id."""
    auth_data, _ = get_current_user()
    if not auth_data.get("authenticated"):
        return None, (
            {"status": "error", "message": "Authentication is required."},
            401,
        )
    user_id = auth_data.get("user", {}).get("id")
    if not isinstance(user_id, int):
        return None, (
            {"status": "error", "message": "Authentication is required."},
            401,
        )
    return user_id, None


def _optional_current_user_id() -> int | None:
    """Return the current session user id when available to a public route."""
    auth_data, _ = get_current_user()
    user_id = auth_data.get("user", {}).get("id") if auth_data.get("authenticated") else None
    return user_id if isinstance(user_id, int) else None


def _recommendation_view_model(user_id: int | None) -> dict[str, Any] | None:
    """Resolve non-critical home-page recommendations without breaking the feed."""
    if user_id is None:
        return None
    try:
        return get_recommendations(user_id)
    except Exception as exc:
        logger.warning(
            "recommendation_failed user_id=%s error_type=%s",
            user_id,
            type(exc).__name__,
            exc_info=True,
        )
        return {
            "items": [],
            "meta": {
                "limit": 5,
                "has_preferences": False,
                "has_bookmarks": False,
                "empty_state": "unavailable",
            },
        }


@main_bp.post("/api/auth/register")
def auth_register():
    """Register an account through the authentication service."""
    data, error = _get_auth_json_payload()
    if error:
        result, status = error
        return jsonify(result), status

    def clean_string(value: object) -> str:
        return value.strip() if isinstance(value, str) else ""

    result, status = register_user(
        username=clean_string(data.get("username")),
        email=clean_string(data.get("email")),
        password=clean_string(data.get("password")),
        full_name=clean_string(data.get("full_name")) or None,
    )
    return jsonify(result), status


@main_bp.post("/api/auth/login")
def auth_login():
    """Authenticate an account through the authentication service."""
    data, error = _get_auth_json_payload()
    if error:
        result, status = error
        return jsonify(result), status
    identity = data.get("identity")
    password = data.get("password")
    result, status = login_user(
        identity.strip() if isinstance(identity, str) else "",
        password if isinstance(password, str) else "",
    )
    return jsonify(result), status


@main_bp.post("/api/auth/logout")
def auth_logout():
    """Invalidate the active authentication session."""
    result, status = logout_user()
    return jsonify(result), status


@main_bp.get("/api/auth/me")
def auth_me():
    """Return the profile associated with the active session."""
    result, status = get_current_user()
    return jsonify(result), status


@main_bp.get("/api/profile")
def get_profile():
    """Return safe profile data for the authenticated user."""
    user_id, error = _get_authenticated_user_id()
    if error:
        result, status = error
        return jsonify(result), status
    result, status = get_profile_data(user_id)
    return jsonify(result), status


@main_bp.patch("/api/profile")
def patch_profile():
    """Update authenticated personal information."""
    user_id, auth_error = _get_authenticated_user_id()
    if auth_error:
        result, status = auth_error
        return jsonify(result), status
    data, payload_error = _get_auth_json_payload()
    if payload_error:
        result, status = payload_error
        return jsonify(result), status
    result, status = update_profile(
        user_id,
        data.get("full_name"),
        data.get("email"),
    )
    return jsonify(result), status


@main_bp.post("/api/profile/password")
def post_profile_password():
    """Rotate the authenticated user's password."""
    user_id, auth_error = _get_authenticated_user_id()
    if auth_error:
        result, status = auth_error
        return jsonify(result), status
    data, payload_error = _get_auth_json_payload()
    if payload_error:
        result, status = payload_error
        return jsonify(result), status
    result, status = change_password(
        user_id,
        data.get("current_password"),
        data.get("new_password"),
        data.get("confirm_password"),
    )
    return jsonify(result), status


@main_bp.post("/api/profile/avatar")
def post_profile_avatar():
    """Store an avatar upload for the authenticated user."""
    user_id, auth_error = _get_authenticated_user_id()
    if auth_error:
        result, status = auth_error
        return jsonify(result), status
    result, status = upload_avatar(user_id, request.files.get("avatar"))
    return jsonify(result), status


@main_bp.post("/api/auth/password-reset/request")
def password_reset_request():
    """Request password-reset delivery."""
    data, error = _get_auth_json_payload()
    if error:
        result, status = error
        return jsonify(result), status
    email = data.get("email")
    result, status = request_password_reset(
        email.strip() if isinstance(email, str) else ""
    )
    return jsonify(result), status


@main_bp.post("/api/auth/password-reset/confirm")
def password_reset_confirm():
    """Confirm an opaque reset token."""
    data, error = _get_auth_json_payload()
    if error:
        result, status = error
        return jsonify(result), status
    token = data.get("token")
    password = data.get("password")
    result, status = confirm_password_reset(
        token if isinstance(token, str) else "",
        password if isinstance(password, str) else "",
    )
    return jsonify(result), status


@main_bp.get("/")
def index():
    """Render the paginated, server-delivered news feed."""
    category = request.args.get("category", "").strip() or None
    page = request.args.get("page", 1, type=int) or 1
    user_id = _optional_current_user_id()
    articles, total_pages, current_page = get_feed_articles(
        category=category,
        page=page,
        per_page=20,
        user_id=user_id,
    )
    return render_template(
        "index.html",
        articles=articles,
        categories=get_categories(),
        trending=get_trending_articles(),
        active_category=category or "All Dispatches",
        current_page=current_page,
        total_pages=total_pages,
        recommendations=_recommendation_view_model(user_id),
    )


@main_bp.get("/api/recommendations")
def api_recommendations():
    """Return the current account's deterministic recommended articles."""
    user_id, auth_error = _get_authenticated_user_id()
    if auth_error:
        result, status = auth_error
        return jsonify(result), status
    try:
        limit = validate_limit(request.args.get("limit"))
    except RecommendationValidationError as exc:
        return jsonify({"status": "error", "message": str(exc)}), 400
    try:
        return jsonify({"status": "success", "data": get_recommendations(user_id, limit)})
    except Exception as exc:
        logger.warning(
            "recommendation_failed user_id=%s error_type=%s",
            user_id,
            type(exc).__name__,
            exc_info=True,
        )
        return jsonify({"status": "error", "message": "Recommendations are temporarily unavailable."}), 503


@main_bp.get("/search")
def search_page():
    """Render the addressable, server-delivered search results page."""
    raw_params = request.args.to_dict()
    if not raw_params.get("q", "").strip():
        return render_template("search.html", result=None, categories=get_categories(), error=None)
    try:
        result = search_articles(raw_params, _optional_current_user_id())
    except ValueError as exc:
        return render_template("search.html", result=None, categories=get_categories(), error=str(exc)), 400
    return render_template("search.html", result=result, categories=get_categories(), error=None)


@main_bp.get("/articles/<int:article_id>")
def article_page(article_id: int):
    """Render a canonical, directly addressable article."""
    article = get_article_detail(article_id)
    if article is None:
        return render_template("404.html"), 404
    return render_template("article.html", article=article)


@main_bp.get("/story-clusters/<int:cluster_id>")
def story_cluster_page(cluster_id: int):
    """Render all accepted perspectives grouped under one story cluster."""
    cluster = get_story_cluster_detail(cluster_id)
    if cluster is None:
        return render_template("404.html"), 404
    return render_template("story_cluster.html", cluster=cluster)


@main_bp.get("/profile")
def profile_page():
    """Render protected profile settings for the active user."""
    auth_data, _ = get_current_user()
    if not auth_data.get("authenticated"):
        return redirect(
            url_for("main.index", auth_intent="login", next="/profile")
        )
    user_id = auth_data.get("user", {}).get("id")
    if not isinstance(user_id, int):
        return redirect(url_for("main.index", auth_intent="login"))
    profile_result, status = get_profile_data(user_id)
    if status != 200:
        logger.warning("Profile page could not load user %s", user_id)
        return redirect(url_for("main.index", auth_intent="login"))
    return render_template(
        "profile.html",
        profile=profile_result.get("profile", {}),
    )

@main_bp.get("/dashboard/user")
def user_dashboard_page():
    auth_data, _ = get_current_user()
    if not auth_data.get("authenticated"):
        return redirect(url_for("main.index", auth_intent="login", next="/dashboard/user"))
    if auth_data.get("user", {}).get("role") == "admin": return redirect(url_for("main.admin_dashboard_page"))
    return render_template("dashboard.html", user=auth_data["user"])

@main_bp.route("/api/dashboard/preferences", methods=["GET", "PUT"])
def dashboard_preferences():
    user_id, error = _get_authenticated_user_id()
    if error: result,status=error; return jsonify(result),status
    if request.method == "GET": return jsonify({"status":"success","data":get_user_preferences(user_id)})
    data,payload_error=_get_auth_json_payload()
    if payload_error: result,status=payload_error; return jsonify(result),status
    result,status=update_user_preferences(user_id,data.get("category_ids"),data.get("source_ids")); return jsonify(result),status

@main_bp.get("/api/dashboard/bookmarks")
def dashboard_bookmarks():
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error; return jsonify(result),status
    return jsonify({"status":"success","data":get_user_bookmarks(user_id,request.args.get("page"),request.args.get("per_page"),request.args.get("sort","newest"),request.args.get("q", ""))})

@main_bp.delete("/api/dashboard/bookmarks/<int:bookmark_id>")
def dashboard_delete_bookmark(bookmark_id):
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error; return jsonify(result),status
    result,status=remove_bookmark(user_id,bookmark_id);return jsonify(result),status

@main_bp.get("/api/articles/bookmarks/status")
def article_bookmark_status():
    user_id, error = _get_authenticated_user_id()
    if error:
        result, status = error
        return jsonify(result), status
    raw_ids = request.args.get("article_ids", "").split(",")
    article_ids = []
    for value in raw_ids:
        try: article_ids.append(int(value))
        except ValueError: pass
    return jsonify({"status": "success", "data": get_bookmark_status(user_id, article_ids)})

@main_bp.post("/api/articles/<int:article_id>/bookmark")
def article_bookmark(article_id):
    user_id, error = _get_authenticated_user_id()
    if error:
        result, status = error
        return jsonify(result), status
    result, status = toggle_article_bookmark(user_id, article_id)
    return jsonify(result), status

@main_bp.route("/api/dashboard/brief/preferences", methods=["GET","PUT"])
def dashboard_brief_preferences():
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    if request.method=="GET":return jsonify({"status":"success","data":get_brief_preferences(user_id)})
    data,payload_error=_get_auth_json_payload()
    if payload_error: result,status=payload_error;return jsonify(result),status
    result,status=update_brief_preferences(user_id,data);return jsonify(result),status

@main_bp.get("/api/dashboard/brief/latest")
def dashboard_brief_latest():
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    return jsonify({"status":"success","data":get_latest_brief(user_id)})

@main_bp.post("/api/dashboard/brief/generate-today")
def dashboard_generate_todays_brief():
    """Manually create today's brief once; the scheduled job will skip it later."""
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    if get_todays_brief(user_id):
        return jsonify({"status":"error","message":"Today's brief has already been generated.","data":get_latest_brief(user_id)}),409
    generate_daily_brief(user_id)
    return jsonify({"status":"success","data":get_latest_brief(user_id),"message":"Today's brief has been generated."}),201

@main_bp.get("/api/dashboard/brief/history")
def dashboard_brief_history():
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    return jsonify({"status":"success","data":get_brief_history(user_id, request.args.get("limit", 30))})

@main_bp.post("/api/dashboard/brief/mark-read")
def dashboard_brief_mark_read():
    user_id,error=_get_authenticated_user_id(); data,payload_error=_get_auth_json_payload()
    if error: result,status=error;return jsonify(result),status
    if payload_error: result,status=payload_error;return jsonify(result),status
    result,status=mark_brief_read(user_id,data.get("brief_id"));return jsonify(result),status

@main_bp.get("/api/dashboard/comments")
def dashboard_comments():
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    return jsonify({"status":"success","data":get_user_comments(user_id,request.args.get("page"),request.args.get("per_page"))})

@main_bp.delete("/api/dashboard/comments/<int:comment_id>")
def dashboard_delete_comment(comment_id):
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    result,status=delete_user_comment(user_id,comment_id);return jsonify(result),status

@main_bp.get("/api/dashboard/reactions")
def dashboard_reactions():
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    return jsonify({"status":"success","data":get_user_reactions(user_id,request.args.get("page"),request.args.get("per_page"))})

@main_bp.delete("/api/dashboard/reactions/<int:reaction_id>")
def dashboard_delete_reaction(reaction_id):
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    result,status=remove_user_reaction(user_id,reaction_id);return jsonify(result),status

@main_bp.route("/api/articles/<int:article_id>/comments", methods=["GET","POST"])
def article_comments(article_id):
    if request.method=="GET": return jsonify({"status":"success","data":get_article_comments(article_id,request.args.get("page"),request.args.get("per_page"))})
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    data,payload_error=_get_auth_json_payload()
    if payload_error: result,status=payload_error;return jsonify(result),status
    result,status=create_comment(user_id,article_id,data.get("content"));return jsonify(result),status

@main_bp.post("/api/articles/<int:article_id>/reactions")
def article_reactions(article_id):
    user_id,error=_get_authenticated_user_id()
    if error: result,status=error;return jsonify(result),status
    data=request.get_json(silent=True) or {}; result,status=toggle_reaction(user_id,article_id,data.get("reaction_type","like"));return jsonify(result),status


@main_bp.post("/api/comments/<int:comment_id>/reports")
def comment_report(comment_id: int):
    """Submit one private moderation report for a visible public comment."""
    user_id, error = _get_authenticated_user_id()
    if error:
        result, status = error
        return jsonify(result), status
    data, payload_error = _get_auth_json_payload()
    if payload_error:
        result, status = payload_error
        return jsonify(result), status
    result, status = create_comment_report(user_id, comment_id, data)
    return jsonify(result), status


@main_bp.post("/api/articles/<int:article_id>/fact-check")
def article_fact_check(article_id: int):
    """Lazily generate and cache verification plus clarity findings for a detail-page article."""
    result = get_or_create_article_fact_check(article_id)
    if result is None:
        return jsonify({"status": "error", "message": "Article not found."}), 404
    return jsonify({"status": "success", "data": result})


@main_bp.get("/api/articles/<int:article_id>/truth-score")
def article_truth_score(article_id: int):
    """Expose the explainable Truth Score breakdown for the article reader."""
    data = get_truth_score_detail(article_id)
    if data is None:
        return jsonify({"status": "error", "message": "Article not found."}), 404
    return jsonify({"status": "success", "data": data})

@main_bp.get("/api/articles/<int:article_id>/reactions/summary")
def article_reaction_summary(article_id):
    return jsonify({"status":"success","data":get_reaction_summary(article_id,_optional_current_user_id())})


@main_bp.app_errorhandler(404)
def page_not_found(_error: Exception):
    """Render a shared not-found response."""
    return render_template("404.html"), 404


SVG_PLACEHOLDER = """<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 800 500">
  <rect width="100%" height="100%" fill="#F8FAFC"/>
  <pattern id="dots" width="24" height="24" patternUnits="userSpaceOnUse">
    <circle cx="2" cy="2" r="1" fill="#E2E8F0"/>
  </pattern>
  <rect width="100%" height="100%" fill="url(#dots)"/>
  <g transform="translate(400,250)" text-anchor="middle">
    <text font-family="sans-serif" font-size="18" fill="#4F46E5">TELL ME MORE DISPATCH</text>
  </g>
</svg>"""


@main_bp.get("/api/image-proxy")
def image_proxy():
    """Proxy allowlisted source images, falling back to an SVG placeholder."""
    image_url = request.args.get("url", "").strip()
    if request.args.get("default") or not image_url:
        return Response(
            SVG_PLACEHOLDER,
            status=200,
            headers={"Content-Type": "image/svg+xml"},
        )
    if not image_url.startswith(("http://", "https://")):
        return Response("Invalid URL scheme", status=400)

    from models import ScraperConfig
    
    allowed_domains = {"vnecdn.net", "vnexpress.net"}
    for domain, cdn_domains in ScraperConfig.query.with_entities(
        ScraperConfig.source_domain, ScraperConfig.image_cdn_domains
    ).all():
        if domain:
            allowed_domains.add(domain.lower())
        allowed_domains.update(
            item.strip().lower()
            for item in (cdn_domains or "").split(",")
            if item.strip()
        )
            
    parsed = urllib.parse.urlparse(image_url)
    hostname = (parsed.hostname or "").lower()
    if not any(
        hostname == domain or hostname.endswith(f".{domain}")
        for domain in allowed_domains
    ):
        return Response("Domain not allowed", status=403)

    try:
        proxy_request = urllib.request.Request(
            image_url,
            headers={
                "User-Agent": "Mozilla/5.0",
                "Referer": f"https://{hostname}/",
                "Accept": "image/avif,image/webp,image/*,*/*;q=0.8",
            },
        )
        with urllib.request.urlopen(proxy_request, timeout=5) as source:
            content_type = source.headers.get("Content-Type", "image/jpeg")
            image_data = source.read()
        return Response(
            image_data,
            status=200,
            headers={
                "Content-Type": content_type,
                "Cache-Control": "public, max-age=86400",
            },
        )
    except Exception as exc:
        logger.warning("Image proxy fallback for %s: %s", image_url, exc)
        return Response(
            SVG_PLACEHOLDER,
            status=200,
            headers={"Content-Type": "image/svg+xml"},
        )


@main_bp.get("/api/articles")
def get_articles():
    """Return the legacy article collection for compatibility clients."""
    try:
        return jsonify(get_all_articles_legacy())
    except Exception as exc:
        logger.error("Failed to serialize articles: %s", exc)
        return jsonify({"error": "Unable to load articles."}), 500


@main_bp.get("/api/search")
def api_search():
    """Return the search result contract for progressive enhancement clients."""
    try:
        result = search_articles(request.args.to_dict(), _optional_current_user_id())
        return jsonify({"status": "success", "data": result})
    except ValueError as exc:
        return jsonify({"status": "error", "message": str(exc)}), 400
    except Exception:
        logger.exception("Search API failed")
        return jsonify({"status": "error", "message": "An internal error occurred. Please try again later."}), 500


@main_bp.get("/api/search/trending")
def api_search_trending():
    """Return trend and optional recent-search data without requiring login."""
    try:
        return jsonify({"status": "success", "data": get_trending_keywords(request.args.get("limit"), _optional_current_user_id())})
    except ValueError as exc:
        return jsonify({"status": "error", "message": str(exc)}), 400
    except Exception:
        logger.exception("Trending search API failed")
        return jsonify({"status": "error", "message": "An internal error occurred. Please try again later."}), 500


@main_bp.delete("/api/search/history")
def api_delete_search_history_entry():
    """Delete one personal search-history term for the signed-in user."""
    user_id, error = _get_authenticated_user_id()
    if error:
        result, status = error
        return jsonify(result), status
    payload, payload_error = _get_auth_json_payload()
    if payload_error:
        result, status = payload_error
        return jsonify(result), status
    try:
        deleted = delete_user_search_history_entry(user_id, payload.get("keyword"))
    except ValueError as exc:
        return jsonify({"status": "error", "message": str(exc)}), 400
    return jsonify({"status": "success", "deleted": deleted})


@main_bp.post("/api/gemini/summarize")
def gemini_summarize():
    """Return a persisted article summary, or an uncached dialogue summary."""
    data = request.get_json(silent=True) or {}
    article_id = data.get("article_id")
    if article_id is not None:
        try:
            article_id = int(article_id)
        except (TypeError, ValueError):
            return jsonify({"status": "error", "message": "article_id must be an integer."}), 400
        if article_id < 1:
            return jsonify({"status": "error", "message": "article_id must be a positive integer."}), 400
        result = get_or_create_article_summary(article_id)
        if result is None:
            return jsonify({"status": "error", "message": "Article not found."}), 404
        return jsonify(result)
    title = data.get("title", "") if isinstance(data.get("title"), str) else ""
    article_text = data.get("text", "") if isinstance(data.get("text"), str) else ""
    return jsonify(summarize_article(title, article_text))


@main_bp.post("/api/gemini/factcheck")
def gemini_factcheck():
    """Return a Gemini claim assessment grounded in supplied article text."""
    data = request.get_json(silent=True) or {}
    title = data.get("title", "") if isinstance(data.get("title"), str) else ""
    article_text = data.get("text", "") if isinstance(data.get("text"), str) else ""
    return jsonify(fact_check_article(title, article_text))


@main_bp.post("/api/gemini/chat")
def gemini_chat():
    """Return a conversational acknowledgement."""
    data = request.get_json(silent=True) or {}
    message = data.get("message", "")
    return jsonify(
        {
            "response": (
                f"I received your question: '{message}'. "
                "Which part of the story should we examine further?"
            )
        }
    )

# Admin Dashboard 
def _get_admin_user():
    auth_data, _ = get_current_user()

    if not auth_data.get("authenticated"):
        return None, (
            {
                "status": "error",
                "message": "Authentication is required."
            },
            401,
        )

    user = auth_data.get("user", {})

    if user.get("role") != "admin":
        return None, (
            {
                "status": "error",
                "message": "Administrator access is required."
            },
            403,
        )

    return user, None

# Trang chính của Admin Dashboard
@main_bp.get("/dashboard/admin")
def admin_dashboard_page():

    admin_user, error = _get_admin_user()

    if error:
        _, status = error

        # Chưa login
        if status == 401:
            return redirect(
                url_for(
                    "main.index",
                    auth_intent="login",
                    next="/dashboard/admin",
                )
            )

        # Login rồi nhưng không phải admin
        return redirect(url_for("main.index"))

    pipeline_config = get_pipeline_config()

    return render_template(
        "admin.html",
        admin_user=admin_user,
        pipeline_config=pipeline_config,
    )

# Metrics Admin Dashboard
@main_bp.get("/api/admin/metrics")
def api_admin_metrics():

    _, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    return jsonify({
        "status": "success",
        "data": get_dashboard_metrics(),
    })


@main_bp.get("/api/admin/moderation/summary")
def api_admin_moderation_summary():
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    return jsonify({"status": "success", "data": get_moderation_summary()})


@main_bp.get("/api/admin/moderation/comments")
def api_admin_moderation_comments():
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    return jsonify({"status": "success", "data": get_moderation_comments(request.args.to_dict())})


@main_bp.get("/api/admin/moderation/comments/<int:comment_id>")
def api_admin_moderation_comment_detail(comment_id: int):
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    data = get_moderation_comment_detail(comment_id)
    if data is None:
        return jsonify({"status": "error", "message": "Comment not found."}), 404
    return jsonify({"status": "success", "data": data})


def _admin_moderation_payload():
    admin, error = _get_admin_user()
    if error:
        return None, None, error
    data, payload_error = _get_auth_json_payload()
    if payload_error:
        return None, None, payload_error
    return admin, data, None


@main_bp.post("/api/admin/moderation/comments/<int:comment_id>/hide")
def api_admin_hide_comment(comment_id: int):
    admin, data, error = _admin_moderation_payload()
    if error:
        result, status = error
        return jsonify(result), status
    result, status = hide_comment(comment_id, admin["id"], data)
    return jsonify(result), status


@main_bp.post("/api/admin/moderation/comments/<int:comment_id>/restore")
def api_admin_restore_comment(comment_id: int):
    admin, data, error = _admin_moderation_payload()
    if error:
        result, status = error
        return jsonify(result), status
    result, status = restore_comment(comment_id, admin["id"], data)
    return jsonify(result), status


@main_bp.delete("/api/admin/moderation/comments/<int:comment_id>")
def api_admin_delete_comment(comment_id: int):
    admin, data, error = _admin_moderation_payload()
    if error:
        result, status = error
        return jsonify(result), status
    result, status = delete_comment_permanently(comment_id, admin["id"], data)
    return jsonify(result), status


@main_bp.post("/api/admin/moderation/reports/<int:report_id>/dismiss")
def api_admin_dismiss_comment_report(report_id: int):
    admin, data, error = _admin_moderation_payload()
    if error:
        result, status = error
        return jsonify(result), status
    result, status = dismiss_comment_report(report_id, admin["id"], data)
    return jsonify(result), status


@main_bp.route("/api/admin/moderation/prohibited-terms", methods=["GET", "POST"])
def api_admin_prohibited_terms():
    admin, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    if request.method == "GET":
        return jsonify({"status": "success", "data": list_prohibited_terms(request.args.to_dict())})
    data, payload_error = _get_auth_json_payload()
    if payload_error:
        result, status = payload_error
        return jsonify(result), status
    result, status = create_prohibited_term(admin["id"], data)
    return jsonify(result), status


@main_bp.route("/api/admin/moderation/prohibited-terms/<int:term_id>", methods=["PATCH", "DELETE"])
def api_admin_prohibited_term(term_id: int):
    admin, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    if request.method == "DELETE":
        result, status = delete_prohibited_term(term_id, admin["id"])
    else:
        data, payload_error = _get_auth_json_payload()
        if payload_error:
            result, status = payload_error
            return jsonify(result), status
        result, status = update_prohibited_term(term_id, admin["id"], data)
    return jsonify(result), status


@main_bp.get("/api/admin/moderation/filter-events")
def api_admin_filter_events():
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    return jsonify({"status": "success", "data": get_filter_events(request.args.to_dict())})

# Quản lý bài đăng trên Admin Dashboard
@main_bp.get("/api/admin/articles")
def api_admin_articles():

    _, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    data = get_admin_articles(
        page=request.args.get("page", 1),
        per_page=request.args.get("per_page", 10),
        status=request.args.get("status", "all"),
        keyword=request.args.get("q", ""),
    )

    return jsonify({
        "status": "success",
        "data": data,
    })

# Ẩn bài đăng trên Admin Dashboard
@main_bp.patch("/api/admin/articles/<int:article_id>/hide")
def api_admin_hide_article(article_id):

    admin_user, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    result, status = set_article_hidden(
        article_id,
        True,
        admin_id=admin_user.get("id"),
    )

    return jsonify(result), status

# Khôi phục bài đăng trên Admin Dashboard
@main_bp.patch("/api/admin/articles/<int:article_id>/restore")
def api_admin_restore_article(article_id):

    admin_user, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    result, status = set_article_hidden(
        article_id,
        False,
        admin_id=admin_user.get("id"),
    )
    return jsonify(result), status

# Xóa vĩnh viễn bài đăng trên Admin Dashboard
@main_bp.delete("/api/admin/articles/<int:article_id>")
def api_admin_delete_article(article_id):

    admin_user, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    result, status = delete_article_permanently(
        article_id,
        admin_id=admin_user.get("id"),
    )
    return jsonify(result), status

# Quản lý người dùng trên Admin Dashboard
@main_bp.get("/api/admin/users")
def api_admin_users():

    _, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    data = get_admin_users(
        page=request.args.get("page", 1),
        per_page=request.args.get("per_page", 10),
        status=request.args.get("status", "all"),
        keyword=request.args.get("q", ""),
    )

    return jsonify({
        "status": "success",
        "data": data,
    })

# Ban User trên Admin Dashboard
@main_bp.patch("/api/admin/users/<int:user_id>/ban")
def api_admin_ban_user(user_id):

    admin_user, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    result, status = set_user_active(
        user_id,
        active=False,
        acting_admin_id=int(admin_user["id"]),
    )

    return jsonify(result), status

# Unban User trên Admin Dashboard
@main_bp.patch("/api/admin/users/<int:user_id>/unban")
def api_admin_unban_user(user_id):

    admin_user, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    result, status = set_user_active(
        user_id,
        active=True,
        acting_admin_id=int(admin_user["id"]),
    )

    return jsonify(result), status


# Lấy lịch sử và trạng thái Scraper Runs
@main_bp.get("/api/admin/scraper/runs")
def api_admin_scraper_runs():

    _, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    limit = request.args.get("limit", 20, type=int)
    data = get_scraper_runs(limit=limit)

    return jsonify({
        "status": "success",
        "data": data,
    })


# Kích hoạt Scraper thủ công trên Admin Dashboard
@main_bp.post("/api/admin/scraper/runs")
def api_admin_trigger_scraper():

    admin_user, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    payload = request.get_json(silent=True) or {}
    source_id = payload.get("source_id")
    max_articles = payload.get("max_articles")
    
    if source_id is not None:
        try:
            source_id = int(source_id)
            if source_id <= 0:
                source_id = None
        except ValueError:
            source_id = None
            
    if max_articles is not None:
        try:
            max_articles = int(max_articles)
            if max_articles <= 0:
                max_articles = None
        except ValueError:
            max_articles = None

    result, status = trigger_manual_scrape(
        admin_id=int(admin_user["id"]),
        source_id=source_id,
        max_articles=max_articles
    )

    return jsonify(result), status


# Lấy danh sách nghi ngờ trùng lặp (Duplicates Console)
@main_bp.get("/api/admin/duplicates")
def api_admin_duplicates():

    _, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    limit = request.args.get("limit", 10, type=int)
    data = get_suspect_duplicates(limit=limit)

    return jsonify({
        "status": "success",
        "data": data,
    })


# Xử lý trùng lặp bài viết
@main_bp.post("/api/admin/duplicates/resolve")
def api_admin_resolve_duplicates():

    admin_user, error = _get_admin_user()

    if error:
        result, status = error
        return jsonify(result), status

    payload = request.get_json(silent=True) or {}
    primary_id = payload.get("primary_id")
    duplicate_ids = payload.get("duplicate_ids", [])

    if not primary_id or not isinstance(primary_id, int):
        return jsonify({"status": "error", "message": "Valid primary_id is required."}), 400

    result, status = resolve_duplicates(
        primary_id=primary_id,
        duplicate_ids=duplicate_ids,
        admin_id=int(admin_user["id"]),
    )

    return jsonify(result), status


@main_bp.get("/api/admin/articles/<int:article_id>/truth-score")
def api_admin_article_truth_score(article_id: int):
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    data = get_truth_score_detail(article_id)
    if data is None:
        return jsonify({"status": "error", "message": "Article not found."}), 404
    return jsonify({"status": "success", "data": data})


@main_bp.post("/api/admin/articles/<int:article_id>/truth-score/recalculate")
def api_admin_recalculate_truth_score(article_id: int):
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    article = score_article_and_cluster(article_id)
    if article is None:
        return jsonify({"status": "error", "message": "Article not found."}), 404
    return jsonify({"status": "success", "data": get_truth_score_detail(article_id)})


@main_bp.post("/api/admin/truth-scores/backfill")
def api_admin_backfill_truth_scores():
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    payload = request.get_json(silent=True) or {}
    batch_size = payload.get("batch_size", 200)
    rescore_all = bool(payload.get("rescore_all", False))
    try:
        batch_size = max(1, min(int(batch_size), 500))
    except (TypeError, ValueError):
        return jsonify({"status": "error", "message": "batch_size must be an integer."}), 400
    from flask import current_app
    app = current_app._get_current_object()
    job_id = str(uuid.uuid4())

    def run_backfill() -> None:
        with app.app_context():
            try:
                result = backfill_truth_scores(batch_size=batch_size, rescore_all=rescore_all)
                logger.info("Truth-score backfill job_id=%s result=%s", job_id, result)
            except Exception:
                logger.exception("Truth-score backfill job_id=%s failed", job_id)

    threading.Thread(target=run_backfill, name=f"truth-score-backfill-{job_id}", daemon=True).start()
    return jsonify({"status": "accepted", "job_id": job_id}), 202


@main_bp.post("/api/admin/story-clusters/backfill")
def api_admin_backfill_story_clusters():
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status
    payload = request.get_json(silent=True) or {}
    try:
        batch_size = max(1, min(int(payload.get("batch_size", 100)), 500))
    except (TypeError, ValueError):
        return jsonify({"status": "error", "message": "batch_size must be an integer."}), 400
    rebuild = payload.get("rebuild", False) is True
    from flask import current_app
    app, job_id = current_app._get_current_object(), str(uuid.uuid4())

    def run_backfill() -> None:
        with app.app_context():
            try:
                reset_result = reset_story_clusters() if rebuild else None
                result = backfill_story_clusters(batch_size=batch_size)
                # Truth Scores must use accepted cluster membership after clustering.
                backfill_truth_scores(batch_size=batch_size, rescore_all=True)
                logger.info("Story-cluster backfill job_id=%s reset=%s result=%s", job_id, reset_result, result)
            except Exception:
                logger.exception("Story-cluster backfill job_id=%s failed", job_id)

    threading.Thread(target=run_backfill, name=f"story-cluster-backfill-{job_id}", daemon=True).start()
    return jsonify({"status": "accepted", "job_id": job_id, "rebuild": rebuild}), 202


# ---------------------------------------------------------
# PHASE 5: PIPELINE & SCRAPER CONFIGURATION
# ---------------------------------------------------------

@main_bp.get("/api/admin/pipeline/config")
def api_admin_get_pipeline_config():
    _, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status

    data = get_pipeline_config()
    return jsonify({"status": "success", "data": data})


@main_bp.post("/api/admin/pipeline/config")
def api_admin_update_pipeline_config():
    admin_user, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status

    payload = request.get_json(silent=True) or {}
    result, status = update_pipeline_config(payload, admin_id=int(admin_user["id"]))
    return jsonify(result), status


@main_bp.delete("/api/admin/pipeline/config/<int:config_id>")
def api_admin_delete_pipeline_source(config_id: int):
    """Permanently remove one source configuration."""
    admin_user, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status

    result, status = delete_scraper_config(config_id, admin_id=int(admin_user["id"]))
    return jsonify(result), status


@main_bp.post("/api/admin/scraper/test")
def api_admin_test_scraper():
    admin_user, error = _get_admin_user()
    if error:
        result, status = error
        return jsonify(result), status

    payload = request.get_json(silent=True) or {}
    result, status = test_scraper_selectors(payload)
    return jsonify(result), status


