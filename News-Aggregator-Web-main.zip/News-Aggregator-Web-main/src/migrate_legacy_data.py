import logging
from app import create_app
from models import db, Article, Category, KeywordRule
from services.classification_service import ClassificationService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

FIXED_CATEGORIES = ["Technology", "Sports", "Business", "Health", "Entertainment", "Science", "General"]

def migrate_old_data():
    app = create_app()
    with app.app_context():
        # 1. Re-classify all existing articles
        articles = Article.query.all()
        logger.info(f"Found {len(articles)} articles to re-classify.")
        
        for article in articles:
            # Re-run classification based on title and description
            # Since we didn't store raw tags from previous scrapes, we just use title/desc
            matched_categories = ClassificationService.classify(
                title=article.title, 
                description=article.description,
                tags=[]
            )
            
            # Clear old associations
            article.categories = []
            
            # Apply new associations
            for cat in matched_categories:
                article.categories.append(cat)
                
        db.session.commit()
        logger.info("Successfully re-classified all articles.")
        
        # 2. Cleanup Legacy Categories
        # Delete any category that is NOT in the FIXED_CATEGORIES list
        legacy_cats = Category.query.filter(~Category.name.in_(FIXED_CATEGORIES)).all()
        logger.info(f"Found {len(legacy_cats)} legacy categories to delete.")
        
        for cat in legacy_cats:
            # Because of cascade rules or just normal deletion, 
            # this will also delete entries in the article_categories join table 
            # for these old categories (which we already cleared anyway)
            db.session.delete(cat)
            
        db.session.commit()
        logger.info("Successfully deleted legacy categories.")

if __name__ == "__main__":
    migrate_old_data()
