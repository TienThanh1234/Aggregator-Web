import atexit
import logging
import os
from typing import Optional

from flask import Flask
from flask_migrate import Migrate
from dotenv import load_dotenv

from models import db, User, Article, Category, Bookmark, Comment, Reaction, DailyBrief, UserBriefPreference
from services.scheduler_service import SchedulerService

# Thiết lập cấu hình log cơ bản hiển thị ra Console
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s"
)
logger = logging.getLogger(__name__)


def create_app(config_override: dict = None) -> Flask:
    """Create and configure the Flask application instance."""
    # Nạp tệp cấu hình môi trường .env
    load_dotenv(os.path.join(os.path.dirname(__file__), ".env"))

    app = Flask(__name__)
    
    # Cấu hình các thông số hệ thống
    database_uri = _build_database_uri()
    app.config.update(
        SECRET_KEY=os.getenv("SECRET_KEY", "dev-secret-key"),
        SQLALCHEMY_DATABASE_URI=database_uri,
        SQLALCHEMY_TRACK_MODIFICATIONS=False,
        SQLALCHEMY_ENGINE_OPTIONS=_build_engine_options(database_uri),
    )

    if config_override:
        app.config.update(config_override)

    # Khởi tạo Database và công cụ Migration
    db.init_app(app)
    Migrate(app, db)

    # Register frontend blueprints and routes
    from routes import main_bp
    app.register_blueprint(main_bp)

    @app.get("/health")
    def health_check():
        # Khuyến nghị bảo mật cho đồ án: Không nên trả về raw URI chứa mật khẩu ra JSON public
        return {
            "status": "ok", 
            "environment": os.getenv("FLASK_ENV", "development"),
            "database_connected": "postgresql" in app.config["SQLALCHEMY_DATABASE_URI"]
        }

    # Database schema is managed exclusively by Alembic migrations.

    # Initialize background scheduler for periodic scraping (T009)
    if not app.config.get("TESTING"):
        try:
            SchedulerService.init_app(app)
            logger.info("[INFO] Background scheduler initialized for hourly scraping")
        except Exception as exc:
            logger.error(
                "[ERROR] Failed to initialize scheduler: %s",
                exc,
                exc_info=True,
            )

        # Register shutdown handler — atexit fires once when the process exits,
        # not after every request like teardown_appcontext would.
        atexit.register(SchedulerService.shutdown)

    return app


def _build_database_uri() -> str:
    raw_uri = os.getenv("DATABASE_URL", "").strip()
    if not raw_uri:
        logger.warning("WARNING: DATABASE_URL not found in .env. Falling back to Local localhost database.")
        return "postgresql://postgres:postgres@localhost:5432/news_aggregator"
        
    # Sửa lỗi giao thức postgres:// của các môi trường deploy cũ sang postgresql:// để SQLAlchemy hiểu
    if raw_uri.startswith("postgres://"):
        raw_uri = raw_uri.replace("postgres://", "postgresql://", 1)
    return raw_uri


def _build_engine_options(database_uri: str) -> dict:
    options: dict = {
        "pool_pre_ping": True,     # Cơ chế tự động ping kiểm tra kết nối sống trước khi query
        "pool_recycle": 280        # Tự động làm mới kết nối sau mỗi 280 giây tránh bị ngắt bởi Supabase
    }
    # Nếu kết nối đến cloud database (Supabase), bắt buộc phải yêu cầu SSL Mode
    if (
        database_uri.startswith("postgresql")
        and "localhost" not in database_uri
        and "127.0.0.1" not in database_uri
    ):
        options["connect_args"] = {"sslmode": "require"}
    return options


app = create_app()


if __name__ == "__main__":
    app.run(
        host="0.0.0.0",
        port=int(os.getenv("PORT", "5000")),
        debug=os.getenv("FLASK_DEBUG", "0") == "1",
    )
