"""Lazy, cached verification and ambiguity analysis for article detail reads."""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import unicodedata
from typing import Any
from urllib.parse import urlsplit, urlunsplit

import requests

from models import AmbiguousWord, Article, ArticleStoryMembership, ArticleTruthScore, db
from services.ai_service import is_configured, verify_article_against_evidence
from services.time_service import vietnam_now
from services.truth_score_service import CALCULATION_VERSION, apply_linguistic_clarity, normalize_source_domain, score_article_and_cluster

CLARITY_MODEL_VERSION = "verification-ambiguity-v4"
SEVERITY_PENALTIES = {"low": 3, "medium": 6, "high": 10}
MAX_AMBIGUITY_PENALTY = 20
MAX_CLUSTER_EVIDENCE_ARTICLES = 3
MAX_TAVILY_EVIDENCE_ARTICLES = 3
MAX_TAVILY_SEARCH_RESULTS = 5
MAX_TAVILY_QUERY_ATTEMPTS = 3
DEFAULT_TAVILY_SEMANTIC_MIN_SCORE = 0.85
DEFAULT_TAVILY_FALLBACK_SEARCH_DEPTH = "advanced"
EVENT_SEARCH_STOP_WORDS = {
    "a", "an", "and", "at", "by", "cho", "cua", "da", "duoc", "for", "from", "in", "la", "lam",
    "lien", "mot", "nhung", "nguoi", "o", "of", "on", "the", "to", "trong", "tu", "va", "ve", "vu", "with",
}
logger = logging.getLogger(__name__)


def _content_hash(article: Article) -> str:
    if article.content_hash:
        return article.content_hash
    source = "\n".join((article.title or "", article.raw_content or article.description or ""))
    return hashlib.sha256(source.encode("utf-8")).hexdigest()


def _dictionary_findings(article: Article) -> list[dict[str, str]]:
    text = "\n".join((article.title or "", article.raw_content or article.description or ""))
    findings: list[dict[str, str]] = []
    for word in AmbiguousWord.query.filter_by(is_active=True).order_by(AmbiguousWord.id).all():
        match = re.search(rf"(?<!\w){re.escape(word.term)}(?!\w)", text, re.IGNORECASE)
        if match:
            start, end = max(0, match.start() - 72), min(len(text), match.end() + 120)
            findings.append({"term": word.term, "language": word.language, "severity": word.severity if word.severity in SEVERITY_PENALTIES else "medium", "excerpt": text[start:end].strip(), "explanation": word.explanation})
    return findings


def _ambiguity_penalty(findings: list[dict[str, str]]) -> int:
    return min(MAX_AMBIGUITY_PENALTY, sum(SEVERITY_PENALTIES.get(item.get("severity", "medium"), 6) for item in findings))


def _cluster_evidence(article: Article) -> list[dict[str, str]]:
    """Favor independent sources, then story similarity and base-score quality."""
    membership = article.story_membership
    if not membership or membership.status != "accepted":
        return []
    peers = (db.session.query(Article, ArticleTruthScore, ArticleStoryMembership)
        .join(ArticleStoryMembership, ArticleStoryMembership.article_id == Article.id)
        .outerjoin(ArticleTruthScore, ArticleTruthScore.article_id == Article.id)
        .filter(ArticleStoryMembership.cluster_id == membership.cluster_id, ArticleStoryMembership.status == "accepted", Article.id != article.id, Article.is_deleted.is_(False)).all())
    target_domain = normalize_source_domain(article.source_url)
    peers.sort(key=lambda item: (normalize_source_domain(item[0].source_url) == target_domain, -(item[2].match_confidence or 0), -(item[1].base_score or 0), -(item[0].id or 0)))
    return [{"id": f"cluster-{peer.id}", "article_id": str(peer.id), "title": peer.title or "Untitled article", "url": peer.canonical_url or peer.source_url or "", "text": (peer.raw_content or peer.description or "")[:5_000]} for peer, _detail, _membership in peers[:MAX_CLUSTER_EVIDENCE_ARTICLES] if (peer.raw_content or peer.description)]


def _normalized_article_url(url: str | None) -> str:
    """Compare URLs without tracking parameters, fragments, or an incidental trailing slash."""
    if not url:
        return ""
    parsed = urlsplit(url.strip())
    if not parsed.scheme or not parsed.netloc:
        return url.strip().rstrip("/").casefold()
    path = parsed.path.rstrip("/") or "/"
    return urlunsplit((parsed.scheme.casefold(), parsed.netloc.casefold(), path, "", ""))


def _event_terms(value: str | None) -> set[str]:
    """Return meaningful, accent-insensitive terms used to match a news event."""
    normalized = unicodedata.normalize("NFKD", str(value or "").casefold())
    normalized = "".join(char for char in normalized if not unicodedata.combining(char))
    return {
        term for term in re.findall(r"[a-z0-9]+", normalized)
        if (len(term) >= 2 or term.isdigit()) and term not in EVENT_SEARCH_STOP_WORDS
    }


def _event_relevance(article: Article, result: dict[str, Any]) -> tuple[float, int] | None:
    """Reject broad topical pages while allowing high-confidence cross-language matches."""
    target_terms = _event_terms(article.title)
    if not target_terms:
        return None
    result_title_terms = _event_terms(str(result.get("title") or ""))
    result_terms = result_title_terms | _event_terms(str(result.get("content") or ""))
    title_hits = len(target_terms & result_title_terms)
    total_hits = len(target_terms & result_terms)
    coverage = total_hits / len(target_terms)
    minimum_hits = 1 if len(target_terms) <= 2 else 2
    minimum_coverage = 0.5 if len(target_terms) <= 3 else 0.35
    if title_hits < minimum_hits or coverage < minimum_coverage:
        # Tavily returns an embedding-based score.  Vietnamese headlines may
        # correctly retrieve an English report, for which token overlap is
        # necessarily near zero.  Only accept an exceptionally strong semantic
        # match; ordinary broad-topic results must still fail the lexical gate.
        try:
            semantic_score = float(result.get("score", 0))
            minimum_semantic_score = float(os.getenv("TAVILY_SEMANTIC_MIN_SCORE", str(DEFAULT_TAVILY_SEMANTIC_MIN_SCORE)))
        except (TypeError, ValueError):
            semantic_score, minimum_semantic_score = 0.0, DEFAULT_TAVILY_SEMANTIC_MIN_SCORE
        if semantic_score < max(0.0, min(1.0, minimum_semantic_score)):
            return None
        return semantic_score, 0
    return coverage, title_hits


def _tavily_queries(article: Article) -> list[str]:
    """Return increasingly broad, event-focused queries for a news article.

    An exact-title query is precise but commonly misses a breaking Vietnamese
    article before Tavily has indexed syndications.  Retrying the same title
    without quotes lets the search engine match reports that shorten or
    rephrase the headline, while the relevance gate below remains responsible
    for rejecting topic-only pages.
    """
    title = " ".join((article.title or "").split())[:1_500]
    if not title:
        return []
    queries = [f'"{title}"', title]

    # Headlines often lead with editorial boilerplate (for example, "Dịp
    # 2-9, chú ý...").  A concise tail query gives Tavily a third chance to
    # find independent reports that retain the location and event.
    clauses = [part.strip(" -–—:;,.\t") for part in re.split(r"[,|]", title) if part.strip()]
    if len(clauses) > 1:
        queries.append(" ".join(clauses[1:]))
    return list(dict.fromkeys(query for query in queries if query))[:MAX_TAVILY_QUERY_ATTEMPTS]


def _tavily_evidence(article: Article) -> list[dict[str, str]]:
    """Find independent Tavily reports without making an Extract request."""
    api_key = os.getenv("TAVILY_API_KEY", "").strip()
    if not api_key:
        logger.warning("Tavily evidence lookup skipped: TAVILY_API_KEY is not configured (article_id=%s)", article.id)
        return []
    try:
        configured_max = int(os.getenv("TAVILY_MAX_RESULTS", "3"))
    except ValueError:
        configured_max = 3
    # Request extra candidates: the target's own URL and duplicate domains are
    # discarded, while Gemini should still receive up to three distinct URLs.
    max_results = min(
        MAX_TAVILY_SEARCH_RESULTS,
        max(MAX_TAVILY_EVIDENCE_ARTICLES + 2, configured_max),
    )
    topic = os.getenv("TAVILY_TOPIC", "news").strip().lower()
    if topic not in {"news", "general"}:
        topic = "news"
    target_urls = {_normalized_article_url(url) for url in (article.canonical_url, article.source_url)} - {""}
    ranked_evidence: list[tuple[tuple[float, int], dict[str, str]]] = []
    seen_urls = set(target_urls)

    def collect_results(query: str, search_depth: str, search_topic: str, attempt: str) -> None:
        search_payload = {
            "query": query,
            "search_depth": search_depth,
            "topic": search_topic,
            "max_results": max_results,
            "include_answer": False,
            "include_raw_content": False,
        }
        if search_topic == "news":
            search_payload["time_range"] = os.getenv("TAVILY_TIME_RANGE", "month").strip() or "month"
        response = requests.post("https://api.tavily.com/search", headers={"Authorization": f"Bearer {api_key}"}, json=search_payload, timeout=10)
        response.raise_for_status()
        payload = response.json()
        results = payload.get("results", []) if isinstance(payload, dict) else []
        logger.info("Tavily evidence lookup completed (article_id=%s, attempt=%s, depth=%s, topic=%s, result_count=%s)", article.id, attempt, search_depth, search_topic, len(results))
        for index, item in enumerate(results, start=1):
            text = str(item.get("content") or "").strip() if isinstance(item, dict) else ""
            result_url = str(item.get("url") or "") if isinstance(item, dict) else ""
            normalized_url = _normalized_article_url(result_url)
            relevance = _event_relevance(article, item) if text else None
            if relevance and normalized_url and normalized_url not in seen_urls:
                seen_urls.add(normalized_url)
                ranked_evidence.append((relevance, {"id": f"tavily-{attempt}-{index}", "title": str(item.get("title") or "Search result"), "url": result_url, "text": text[:5_000]}))

    search_depth = os.getenv("TAVILY_SEARCH_DEPTH", "basic").strip().lower() or "basic"
    if search_depth not in {"basic", "advanced"}:
        search_depth = "basic"
    for attempt, query in enumerate(_tavily_queries(article), start=1):
        collect_results(query, search_depth, topic, str(attempt))
        # One independent report is sufficient to compare rather than spending
        # more Tavily requests.  The initial query can still supply up to three
        # results; later queries exist solely to recover from a no-match.
        if ranked_evidence:
            break
    if not ranked_evidence and article.title:
        # Tavily's news/basic index can miss Vietnamese syndications even when
        # its general advanced index has independent coverage.  This costly
        # fallback runs only after every normal event query has failed.
        fallback_depth = os.getenv("TAVILY_FALLBACK_SEARCH_DEPTH", DEFAULT_TAVILY_FALLBACK_SEARCH_DEPTH).strip().lower()
        if fallback_depth not in {"basic", "advanced"}:
            fallback_depth = DEFAULT_TAVILY_FALLBACK_SEARCH_DEPTH
        fallback_query = f'"{" ".join(article.title.split())}"'[:1_500]
        collect_results(fallback_query, fallback_depth, "general", "recall")
    ranked_evidence.sort(key=lambda item: item[0], reverse=True)
    logger.info("Tavily evidence filtering finished (article_id=%s, accepted_count=%s)", article.id, len(ranked_evidence))
    return [item[1] for item in ranked_evidence[:MAX_TAVILY_EVIDENCE_ARTICLES]]


def _load_json(raw: str | None) -> list[dict[str, Any]]:
    try:
        value = json.loads(raw or "[]")
        return value if isinstance(value, list) else []
    except (TypeError, ValueError):
        return []


def _serialize(detail: ArticleTruthScore) -> dict[str, Any]:
    verification, penalty = int(detail.verification_score or 0), int(detail.ambiguity_penalty or 0)
    return {"article_id": detail.article_id, "base_score": detail.base_score, "verification_score": verification, "ambiguity_penalty": penalty, "clarity_score": max(0, verification - penalty), "clarity_points": detail.linguistic_clarity_score, "final_truth_score": detail.total_score, "status": detail.clarity_status, "report": detail.clarity_report, "verification_report": detail.verification_report, "verification_source_type": detail.verification_source_type, "citations": _load_json(detail.verification_citations_json), "claim_results": _load_json(detail.verification_claims_json), "findings": _load_json(detail.clarity_findings_json), "analyzed_at": detail.clarity_analyzed_at.isoformat() if detail.clarity_analyzed_at else None, "cached": detail.clarity_status == "completed", "retry_after_ms": 1200 if detail.clarity_status == "processing" else None}


def get_or_create_article_fact_check(article_id: int) -> dict[str, Any] | None:
    """Verify an article on-demand and cache the result for its current content version."""
    article = db.session.get(Article, article_id)
    if article is None or article.is_deleted:
        return None
    if article.truth_score_detail is None or article.truth_score_version != CALCULATION_VERSION:
        article = score_article_and_cluster(article_id)
        if article is None:
            return None
    detail = ArticleTruthScore.query.filter_by(article_id=article_id).with_for_update().first()
    if detail is None:
        return None
    content_hash = _content_hash(article)
    if detail.clarity_status == "completed" and detail.clarity_content_hash == content_hash and detail.clarity_model_version == CLARITY_MODEL_VERSION:
        return _serialize(detail)
    if detail.clarity_status == "processing":
        return _serialize(detail)
    detail.clarity_status, detail.clarity_content_hash, detail.clarity_model_version = "processing", content_hash, CLARITY_MODEL_VERSION
    db.session.commit()
    try:
        findings, penalty = _dictionary_findings(article), 0
        penalty = _ambiguity_penalty(findings)
        evidence, source_type = _cluster_evidence(article), "cluster"
        if not evidence:
            source_type = "tavily" if os.getenv("TAVILY_API_KEY", "").strip() else "tavily-unconfigured"
            evidence = _tavily_evidence(article)
        if not evidence or not is_configured():
            detail = ArticleTruthScore.query.filter_by(article_id=article_id).first()
            detail.clarity_findings_json, detail.ambiguity_penalty, detail.verification_score = json.dumps(findings, ensure_ascii=False), penalty, 0
            if not evidence:
                if source_type == "tavily-unconfigured":
                    report = "Verification is unavailable because the Tavily search service is not configured."
                    verification_source_type = source_type
                else:
                    report = "No sufficiently relevant independent evidence was found for this specific news event."
                    verification_source_type = f"{source_type}-no-match"
            else:
                report = "Verification is unavailable until Gemini and supporting evidence are configured."
                verification_source_type = source_type
            detail.verification_source_type, detail.clarity_report, detail.clarity_status = verification_source_type, report, "unavailable"
            detail.verification_article_ids = detail.verification_citations_json = detail.verification_claims_json = "[]"
            detail.verification_report = None
            apply_linguistic_clarity(detail, 0)
            db.session.commit()
            return _serialize(detail)
        verified = verify_article_against_evidence(article.title, article.raw_content or article.description or "", evidence)
        if not verified:
            raise RuntimeError("Gemini verification did not return a valid result")
        detail = ArticleTruthScore.query.filter_by(article_id=article_id).first()
        verification_score, clarity_score = verified["verification_score"], max(0, verified["verification_score"] - penalty)
        citations = [{"id": item["id"], "title": item["title"], "url": item["url"]} for item in evidence]
        detail.clarity_findings_json, detail.verification_score, detail.ambiguity_penalty = json.dumps(findings, ensure_ascii=False), verification_score, penalty
        detail.verification_source_type, detail.verification_article_ids = source_type, json.dumps([item.get("article_id") for item in evidence if item.get("article_id")])
        detail.verification_citations_json, detail.verification_claims_json, detail.verification_report = json.dumps(citations, ensure_ascii=False), json.dumps(verified["claim_results"], ensure_ascii=False), verified["report"]
        detail.clarity_report, detail.clarity_status = verified["report"] or "Verification was calculated from the supplied evidence sources.", "completed"
        detail.clarity_analyzed_at = detail.verification_checked_at = vietnam_now()
        apply_linguistic_clarity(detail, round(clarity_score * 20 / 100))
        db.session.commit()
        return _serialize(detail)
    except Exception:
        logger.exception("Fact-check evidence lookup failed (article_id=%s)", article_id)
        db.session.rollback()
        detail = ArticleTruthScore.query.filter_by(article_id=article_id).first()
        if detail:
            detail.clarity_status = "failed"
            db.session.commit()
            return _serialize(detail)
        raise
