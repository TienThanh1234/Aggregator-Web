"""Queries and mutations owned by the authenticated user dashboard."""
from __future__ import annotations

from models import Article, Bookmark, Category, Comment, CommentReport, Reaction, ScraperConfig, User, db
from services.moderation_service import public_comment_filter


def _page(value, default=1, maximum=100):
    try: return max(1, min(int(value), maximum))
    except (TypeError, ValueError): return default

def _paginate(query, page, per_page):
    page, per_page = _page(page), _page(per_page, 20)
    total = query.count()
    return query.offset((page - 1) * per_page).limit(per_page).all(), {"page": page, "per_page": per_page, "total": total, "has_more": page * per_page < total}

def get_user_preferences(user_id):
    user = db.session.get(User, user_id)
    category_ids = {item.id for item in user.subscribed_categories} if user else set()
    source_ids = {item.id for item in user.subscribed_sources} if user else set()
    return {"categories": [{"id": c.id, "name": c.name, "is_subscribed": c.id in category_ids} for c in Category.query.order_by(Category.name).all()], "sources": [{"id": s.id, "name": s.source_name, "domain": s.source_domain, "is_subscribed": s.id in source_ids} for s in ScraperConfig.query.order_by(ScraperConfig.source_name).all()]}

def update_user_preferences(user_id, category_ids, source_ids):
    user = db.session.get(User, user_id)
    if not user: return {"status": "error", "message": "User not found."}, 404
    category_ids = [x for x in (category_ids or []) if isinstance(x, int)]
    source_ids = [x for x in (source_ids or []) if isinstance(x, int)]
    user.subscribed_categories = Category.query.filter(Category.id.in_(category_ids)).all() if category_ids else []
    user.subscribed_sources = ScraperConfig.query.filter(ScraperConfig.id.in_(source_ids)).all() if source_ids else []
    db.session.commit()
    return {"status": "success", "message": "Preferences saved.", "data": get_user_preferences(user_id)}, 200

def _article(article):
    return {"id": article.id, "title": article.title, "summary": article.ai_summary or article.description or "", "source_url": article.source_url, "image_url": article.cover_image_url, "categories": [c.name for c in article.categories], "is_article_available": not article.is_deleted}

def get_user_bookmarks(user_id, page=1, per_page=20, sort="newest", keyword=""):
    query = Bookmark.query.join(Article).filter(Bookmark.user_id == user_id)
    if keyword: query = query.filter(Article.title.ilike(f"%{keyword.strip()}%"))
    query = query.order_by(Bookmark.created_at.asc() if sort == "oldest" else Bookmark.created_at.desc())
    rows, meta = _paginate(query, page, per_page)
    return {"items": [{"id": b.id, "created_at": b.created_at.isoformat(), "article": _article(b.article)} for b in rows], **meta}

def remove_bookmark(user_id, bookmark_id):
    item = Bookmark.query.filter_by(id=bookmark_id, user_id=user_id).first()
    if not item: return {"status": "error", "message": "Bookmark not found."}, 404
    db.session.delete(item); db.session.commit()
    return {"status": "success", "message": "Bookmark removed."}, 200

def toggle_article_bookmark(user_id, article_id):
    article = Article.query.filter_by(id=article_id, is_deleted=False).first()
    if not article:
        return {"status": "error", "message": "Article not found."}, 404
    bookmark = Bookmark.query.filter_by(user_id=user_id, article_id=article_id).first()
    if bookmark:
        db.session.delete(bookmark)
        action = "removed"
    else:
        db.session.add(Bookmark(user_id=user_id, article_id=article_id))
        action = "saved"
    db.session.commit()
    return {"status": "success", "action": action, "is_bookmarked": action == "saved"}, 200

def get_bookmark_status(user_id, article_ids):
    valid_ids = [item for item in article_ids if isinstance(item, int)]
    saved = Bookmark.query.filter(Bookmark.user_id == user_id, Bookmark.article_id.in_(valid_ids)).all() if valid_ids else []
    return {"article_ids": [item.article_id for item in saved]}

def get_user_comments(user_id, page=1, per_page=20):
    query = (
        Comment.query.join(Article)
        .filter(Comment.user_id == user_id, *public_comment_filter())
        .order_by(Comment.created_at.desc())
    )
    rows, meta = _paginate(query, page, per_page)
    return {"items": [{"id": c.id, "content": c.content, "created_at": c.created_at.isoformat(), "article": _article(c.article)} for c in rows], **meta}

def delete_user_comment(user_id, comment_id):
    comment = db.session.get(Comment, comment_id)
    if not comment: return {"status": "error", "message": "Comment not found."}, 404
    if comment.user_id != user_id: return {"status": "error", "message": "You cannot delete this comment."}, 403
    comment.is_deleted = True
    CommentReport.query.filter_by(comment_id=comment.id, status="open").update({"status": "resolved"}, synchronize_session=False)
    db.session.commit()
    return {"status": "success", "message": "Comment deleted."}, 200

def get_user_reactions(user_id, page=1, per_page=20):
    query = (
        Reaction.query.join(Article)
        .filter(Reaction.user_id == user_id)
        .order_by(Reaction.created_at.desc())
    )
    rows, meta = _paginate(query, page, per_page)
    return {"items": [{"id": r.id, "reaction_type": r.reaction_type, "created_at": r.created_at.isoformat(), "article": _article(r.article)} for r in rows], **meta}

def remove_user_reaction(user_id, reaction_id):
    reaction = db.session.get(Reaction, reaction_id)
    if not reaction: return {"status": "error", "message": "Reaction not found."}, 404
    if reaction.user_id != user_id: return {"status": "error", "message": "You cannot remove this reaction."}, 403
    db.session.delete(reaction); db.session.commit()
    return {"status": "success", "message": "Reaction removed."}, 200
