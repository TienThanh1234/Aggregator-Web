"""Deterministic, account-scoped article recommendations."""

from __future__ import annotations

import logging
from datetime import timedelta
from typing import Any
from urllib.parse import urlparse

from sqlalchemy import and_, or_
from sqlalchemy.orm import load_only, selectinload

from models import (
    Article,
    ArticleStoryMembership,
    Bookmark,
    StoryCluster,
    User,
)
from services.article_service import get_article_card_presentation
from services.time_service import vietnam_now

logger = logging.getLogger(__name__)

RECOMMENDATION_WINDOW_DAYS = 30
CANDIDATE_LIMIT = 100
DEFAULT_LIMIT = 5
MAX_LIMIT = 10
SAME_STORY_POINTS = 45
SAVED_TOPIC_POINTS = 25
FOLLOWED_CATEGORY_POINTS = 15
FOLLOWED_SOURCE_POINTS = 10
MAX_SCORE = 100


class RecommendationValidationError(ValueError):
    """Raised when a recommendation API parameter is invalid."""


def validate_limit(value: object, default: int = DEFAULT_LIMIT) -> int:
    """Validate a requested result limit without accepting arbitrary values."""
    if value in (None, ""):
        return default
    try:
        limit = int(str(value))
    except (TypeError, ValueError) as exc:
        raise RecommendationValidationError("limit must be an integer from 1 to 10.") from exc
    if not 1 <= limit <= MAX_LIMIT:
        raise RecommendationValidationError("limit must be an integer from 1 to 10.")
    return limit


def _effective_timestamp(article: Article):
    """Return the public recency timestamp used by eligibility and ordering."""
    return article.published_at or article.scraped_at


def _freshness_points(article: Article, now) -> int:
    """Return the bounded freshness component for an eligible candidate."""
    timestamp = _effective_timestamp(article)
    if timestamp is None:
        return 0
    age = now - timestamp
    if age <= timedelta(days=1):
        return 3
    if age <= timedelta(days=7):
        return 2
    if age <= timedelta(days=RECOMMENDATION_WINDOW_DAYS):
        return 1
    return 0


def _quality_points(article: Article) -> int:
    """Return a small null-safe quality tie component from the stored Truth Score."""
    try:
        score = float(article.truth_score or 0)
    except (TypeError, ValueError):
        score = 0
    if score <= 1:
        score *= 100
    return max(0, min(2, round(score / 50)))


def _source_domain(value: str | None) -> str:
    """Normalize a configured source domain or article URL host for comparison."""
    raw = (value or "").strip().lower()
    if not raw:
        return ""
    parsed = urlparse(raw if "://" in raw else f"https://{raw}")
    host = parsed.hostname or ""
    return host.removeprefix("www.")


def _accepted_cluster(article: Article) -> StoryCluster | None:
    """Return an article's accepted cluster, excluding review/rejected memberships."""
    membership = article.story_membership
    if membership and membership.status == "accepted":
        return membership.cluster
    return None


def _rank_tuple(item: dict[str, Any]) -> tuple[Any, ...]:
    """Build deterministic descending ranking fields for a scored candidate."""
    article = item["article_model"]
    cluster = item["cluster"]
    timestamp = _effective_timestamp(article)
    return (
        item["recommendation_score"],
        int(cluster.trending_score or 0) if cluster else 0,
        float(article.truth_score or 0),
        timestamp,
        article.id,
    )


def _reason(
    same_story: bool,
    saved_topic: bool,
    followed_category: bool,
    followed_source: bool,
) -> str:
    """Choose the reader explanation by the documented signal precedence."""
    if same_story:
        return "More coverage of a saved story"
    if saved_topic:
        return "Because you saved similar topics"
    if followed_category:
        return "Matches a followed topic"
    if followed_source:
        return "Matches a followed source"
    return ""


def _empty_result(
    limit: int,
    has_preferences: bool,
    has_bookmarks: bool,
    empty_state: str,
) -> dict[str, Any]:
    """Build a stable empty response without exposing internal details."""
    return {
        "items": [],
        "meta": {
            "limit": limit,
            "has_preferences": has_preferences,
            "has_bookmarks": has_bookmarks,
            "empty_state": empty_state,
        },
    }


def get_recommendations(user_id: int, limit: int = DEFAULT_LIMIT) -> dict[str, Any]:
    """Return a bounded, personalized recommendation result for one account."""
    safe_limit = validate_limit(limit)
    user = User.query.filter_by(id=user_id, is_active=True).first()
    if user is None:
        logger.info("recommendation_empty user_id=%s state=no_account", user_id)
        return _empty_result(safe_limit, False, False, "no_account")

    followed_category_ids = {category.id for category in user.subscribed_categories}
    followed_source_domains = {
        domain
        for source in user.subscribed_sources
        if (domain := _source_domain(source.source_domain))
    }
    has_preferences = bool(followed_category_ids or followed_source_domains)

    seeds = (
        Bookmark.query.join(Article)
        .filter(
            Bookmark.user_id == user.id,
            Article.is_deleted.is_(False),
        )
        .options(
            selectinload(Bookmark.article)
            .selectinload(Article.categories),
            selectinload(Bookmark.article)
            .selectinload(Article.story_membership)
            .joinedload(ArticleStoryMembership.cluster),
        )
        .all()
    )
    seed_articles = [bookmark.article for bookmark in seeds if bookmark.article]
    seed_ids = {article.id for article in seed_articles}
    has_bookmarks = bool(seed_ids)
    if not has_preferences and not has_bookmarks:
        logger.info("recommendation_empty user_id=%s state=no_profile", user.id)
        return _empty_result(safe_limit, False, False, "no_profile")

    seed_category_ids = {
        category.id for article in seed_articles for category in article.categories
    }
    seed_cluster_ids = {
        cluster.id
        for article in seed_articles
        if (cluster := _accepted_cluster(article)) is not None
    }
    now = vietnam_now()
    since = now - timedelta(days=RECOMMENDATION_WINDOW_DAYS)
    recent_timestamp = or_(
        Article.published_at >= since,
        and_(Article.published_at.is_(None), Article.scraped_at >= since),
    )
    candidate_query = Article.query.filter(
        Article.is_deleted.is_(False),
        recent_timestamp,
    )
    if seed_ids:
        candidate_query = candidate_query.filter(~Article.id.in_(seed_ids))
    candidates = (
        candidate_query.options(
            # Recommendation cards do not need full article bodies.  Deferring
            # these columns prevents their transfer for every candidate.
            load_only(
                Article.id,
                Article.title,
                Article.description,
                Article.source_url,
                Article.cover_image_url,
                Article.published_at,
                Article.scraped_at,
                Article.ai_summary,
                Article.truth_score,
            ),
            selectinload(Article.categories),
            selectinload(Article.story_membership).joinedload(
                ArticleStoryMembership.cluster
            ),
            selectinload(Article.reactions),
            selectinload(Article.comments),
        )
        .order_by(
            Article.published_at.desc().nullslast(),
            Article.scraped_at.desc(),
            Article.id.desc(),
        )
        .limit(CANDIDATE_LIMIT)
        .all()
    )

    scored: list[dict[str, Any]] = []
    for article in candidates:
        category_ids = {category.id for category in article.categories}
        cluster = _accepted_cluster(article)
        same_story = bool(cluster and cluster.id in seed_cluster_ids)
        saved_topic = bool(category_ids & seed_category_ids)
        followed_category = bool(category_ids & followed_category_ids)
        followed_source = _source_domain(article.source_url) in followed_source_domains
        personalization_score = (
            (SAME_STORY_POINTS if same_story else 0)
            + (SAVED_TOPIC_POINTS if saved_topic else 0)
            + (FOLLOWED_CATEGORY_POINTS if followed_category else 0)
            + (FOLLOWED_SOURCE_POINTS if followed_source else 0)
        )
        if personalization_score == 0:
            continue
        score = (
            personalization_score
            + _freshness_points(article, now)
            + _quality_points(article)
        )
        if score <= 0:
            continue
        scored.append(
            {
                "article_model": article,
                "cluster": cluster,
                "recommendation_score": min(MAX_SCORE, score),
                "reason": _reason(
                    same_story, saved_topic, followed_category, followed_source
                ),
            }
        )

    scored.sort(key=_rank_tuple, reverse=True)
    selected: list[dict[str, Any]] = []
    processed_cluster_ids: set[int] = set()
    for item in scored:
        cluster = item["cluster"]
        if cluster is None:
            selected.append(item)
        elif cluster.id not in processed_cluster_ids:
            cluster_items = [
                candidate
                for candidate in scored
                if candidate["cluster"] is not None
                and candidate["cluster"].id == cluster.id
            ]
            canonical_item = next(
                (
                    candidate
                    for candidate in cluster_items
                    if candidate["article_model"].id == cluster.canonical_article_id
                ),
                None,
            )
            selected.append(canonical_item or cluster_items[0])
            processed_cluster_ids.add(cluster.id)
        if len(selected) >= safe_limit:
            break

    items = [
        {
            "article": get_article_card_presentation(item["article_model"]),
            "reason": item["reason"],
            "recommendation_score": item["recommendation_score"],
        }
        for item in selected
    ]
    if not items:
        logger.info(
            "recommendation_empty user_id=%s state=no_candidates candidates=%s",
            user.id,
            len(candidates),
        )
        return _empty_result(safe_limit, has_preferences, has_bookmarks, "no_candidates")
    logger.info(
        "recommendation_generated user_id=%s candidates=%s returned=%s",
        user.id,
        len(candidates),
        len(items),
    )
    return {
        "items": items,
        "meta": {
            "limit": safe_limit,
            "has_preferences": has_preferences,
            "has_bookmarks": has_bookmarks,
            "empty_state": None,
        },
    }
