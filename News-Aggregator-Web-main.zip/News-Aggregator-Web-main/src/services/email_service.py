"""SMTP delivery helpers for account-authentication email messages."""

import logging
import os
import smtplib
from email.message import EmailMessage
from html import escape
from urllib.parse import urlencode

logger = logging.getLogger(__name__)


def send_password_reset_email(email: str, token: str) -> bool:
    """Deliver a password-reset link without logging sensitive token content.

    Args:
        email: Recipient email address.
        token: Opaque, one-time reset token.

    Returns:
        True when SMTP accepts the message; otherwise False.
    """
    server = os.getenv("MAIL_SERVER", "").strip()
    username = os.getenv("MAIL_USERNAME", "").strip()
    # Gmail displays app passwords in groups; remove copied formatting spaces
    # before SMTP authentication without changing the secret's actual value.
    password = "".join(os.getenv("MAIL_PASSWORD", "").split())
    sender = os.getenv("MAIL_FROM", "").strip()
    reset_url = os.getenv("PASSWORD_RESET_URL", "").strip()
    try:
        port = int(os.getenv("MAIL_PORT", "587"))
    except ValueError:
        logger.error("[AUTH][ERROR] Password reset email configuration has an invalid port")
        return False

    if not all((server, sender, reset_url)):
        logger.error("[AUTH][ERROR] Password reset email configuration is incomplete")
        return False

    separator = "&" if "?" in reset_url else "?"
    link = f"{reset_url}{separator}{urlencode({'reset_token': token})}"
    message = EmailMessage()
    message["Subject"] = "Reset your Tell Me More password"
    message["From"] = sender
    message["To"] = email
    message.set_content(
        "A password reset was requested for your Tell Me More account. "
        f"Use this link within 30 minutes: {link}\n\n"
        "If you did not request this reset, you can safely ignore this email."
    )

    try:
        with smtplib.SMTP(server, port, timeout=10) as smtp:
            smtp.starttls()
            if username and password:
                smtp.login(username, password)
            smtp.send_message(message)
        logger.info("[AUTH][SUCCESS] Password reset email accepted by SMTP")
        return True
    except (OSError, smtplib.SMTPException) as exc:
        logger.error("[AUTH][ERROR] Password reset email delivery failed: %s", type(exc).__name__)
        return False


def send_daily_brief_email(email: str, brief_content: str, brief_date: str, article_ids: list[int]) -> bool:
    """Deliver a persisted Daily Brief without exposing SMTP configuration in logs."""
    server = os.getenv("MAIL_SERVER", "").strip()
    username = os.getenv("MAIL_USERNAME", "").strip()
    password = "".join(os.getenv("MAIL_PASSWORD", "").split())
    sender = os.getenv("MAIL_FROM", "").strip()
    base_url = os.getenv("APP_BASE_URL", "").strip().rstrip("/")
    try:
        port = int(os.getenv("MAIL_PORT", "587"))
    except ValueError:
        logger.error("[BRIEF][ERROR] Daily brief email configuration has an invalid port")
        return False
    if not all((server, sender)):
        logger.error("[BRIEF][ERROR] Daily brief email configuration is incomplete")
        return False

    safe_content = escape(brief_content).replace("\n", "<br>")
    links = "".join(
        f'<li><a href="{base_url}/articles/{article_id}">Dispatch {article_id}</a></li>'
        if base_url else f"<li>Dispatch {article_id}</li>"
        for article_id in article_ids
    )
    references = f"<h2>Referenced dispatches</h2><ul>{links}</ul>" if links else ""
    message = EmailMessage()
    message["Subject"] = f"Daily Brief — {brief_date}"
    message["From"] = sender
    message["To"] = email
    message.set_content(f"Daily Brief — {brief_date}\n\n{brief_content}\n\nReferenced dispatches: {', '.join(map(str, article_ids))}")
    message.add_alternative(
        f"<html><body><h1>Daily Brief — {escape(brief_date)}</h1><p>{safe_content}</p>{references}</body></html>",
        subtype="html",
    )
    try:
        with smtplib.SMTP(server, port, timeout=10) as smtp:
            smtp.starttls()
            if username and password:
                smtp.login(username, password)
            smtp.send_message(message)
        logger.info("[BRIEF][SUCCESS] Daily brief email accepted by SMTP")
        return True
    except (OSError, smtplib.SMTPException) as exc:
        logger.error("[BRIEF][ERROR] Daily brief email delivery failed: %s", type(exc).__name__)
        return False
