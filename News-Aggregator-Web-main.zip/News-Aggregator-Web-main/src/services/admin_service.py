"""Business logic for Admin Dashboard."""

from __future__ import annotations

from math import ceil
import re
from typing import Any, Optional

from sqlalchemy import or_
from sqlalchemy.exc import SQLAlchemyError

from models import Article, RawArticle, User, AdminAuditLog, db, ScraperConfig
from services.time_service import vietnam_now


ARTICLE_STATUSES = {"all", "visible", "hidden"}
USER_STATUSES = {"all", "active", "banned"}


def _safe_page(value, default=1):
    try:
        return max(1, int(value))
    except (TypeError, ValueError):
        return default


def _safe_per_page(value, default=10):
    try:
        return max(1, min(50, int(value)))
    except (TypeError, ValueError):
        return default


def _iso(value):
    return value.isoformat() if value else None


def _normalize_image_cdn_domains(value: Any) -> str:
    """Normalize a comma/newline-separated list of safe CDN hostnames."""
    domains = []
    for raw_domain in re.split(r"[,\s]+", str(value or "").lower()):
        domain = raw_domain.strip().rstrip(".")
        if not domain:
            continue
        if not re.fullmatch(r"(?=.{1,253}$)(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}", domain):
            raise ValueError(f"Invalid image CDN domain: {raw_domain}")
        if domain not in domains:
            domains.append(domain)
    return ",".join(domains)


# ============================================================
# OVERVIEW
# ============================================================

def get_dashboard_metrics() -> dict[str, int]:
    return {
        "total_articles": Article.query.count(),

        "visible_articles": Article.query.filter(
            Article.is_deleted.is_(False)
        ).count(),

        "hidden_articles": Article.query.filter(
            Article.is_deleted.is_(True)
        ).count(),

        "total_users": User.query.count(),

        "active_users": User.query.filter(
            User.is_active.is_(True)
        ).count(),

        "banned_users": User.query.filter(
            User.is_active.is_(False)
        ).count(),

        "raw_pending": RawArticle.query.filter(
            RawArticle.status == "pending"
        ).count(),

        "raw_failed": RawArticle.query.filter(
            RawArticle.error_message.isnot(None)
        ).count(),
    }


# ============================================================
# ARTICLE MANAGEMENT
# ============================================================

def get_admin_articles(
    page=1,
    per_page=10,
    status="all",
    keyword="",
) -> dict[str, Any]:

    page = _safe_page(page)
    per_page = _safe_per_page(per_page)

    if status not in ARTICLE_STATUSES:
        status = "all"

    keyword = " ".join((keyword or "").split())[:200]

    query = Article.query

    if status == "visible":
        query = query.filter(
            Article.is_deleted.is_(False)
        )

    elif status == "hidden":
        query = query.filter(
            Article.is_deleted.is_(True)
        )

    if keyword:
        pattern = f"%{keyword}%"

        query = query.filter(
            or_(
                Article.title.ilike(pattern),
                Article.description.ilike(pattern),
                Article.source_url.ilike(pattern),
            )
        )

    query = query.order_by(
        Article.published_at.desc().nullslast(),
        Article.scraped_at.desc(),
        Article.id.desc(),
    )

    total = query.count()

    articles = (
        query
        .offset((page - 1) * per_page)
        .limit(per_page)
        .all()
    )

    return {
        "articles": [
            {
                "id": article.id,
                "title": article.title,
                "source_url": article.source_url,
                "published_at": _iso(article.published_at),
                "scraped_at": _iso(article.scraped_at),
                "is_deleted": bool(article.is_deleted),
            }
            for article in articles
        ],

        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": ceil(total / per_page) if total else 0,
        }
    }


def set_article_hidden(
    article_id: int,
    hidden: bool,
    admin_id: int | None = None,
) -> tuple[dict, int]:

    article = db.session.get(Article, article_id)

    if article is None:
        return {
            "status": "error",
            "message": "Article not found."
        }, 404

    try:
        article.is_deleted = hidden

        if admin_id:
            audit = AdminAuditLog(
                admin_id=admin_id,
                action="HIDE_ARTICLE" if hidden else "RESTORE_ARTICLE",
                target_type="article",
                target_id=article.id,
                details=f"Article '{article.title[:50]}' set to {'hidden' if hidden else 'visible'}",
            )
            db.session.add(audit)

        db.session.commit()

    except SQLAlchemyError:
        db.session.rollback()

        return {
            "status": "error",
            "message": "Unable to update article."
        }, 500

    return {
        "status": "success",
        "message": (
            "Article hidden successfully."
            if hidden
            else "Article restored successfully."
        ),
        "article": {
            "id": article.id,
            "is_deleted": article.is_deleted,
        }
    }, 200


def delete_article_permanently(
    article_id: int,
    admin_id: int | None = None,
) -> tuple[dict, int]:

    article = db.session.get(Article, article_id)

    if article is None:
        return {
            "status": "error",
            "message": "Article not found."
        }, 404

    try:
        title_snippet = article.title[:50] if article.title else str(article.id)
        db.session.delete(article)

        if admin_id:
            audit = AdminAuditLog(
                admin_id=admin_id,
                action="DELETE_ARTICLE",
                target_type="article",
                target_id=article_id,
                details=f"Permanently deleted Article '{title_snippet}'",
            )
            db.session.add(audit)

        db.session.commit()

    except SQLAlchemyError:
        db.session.rollback()

        return {
            "status": "error",
            "message": "Unable to delete article."
        }, 500

    return {
        "status": "success",
        "message": "Article permanently deleted.",
    }, 200


# ============================================================
# USER MANAGEMENT
# ============================================================

def get_admin_users(
    page=1,
    per_page=10,
    status="all",
    keyword="",
) -> dict[str, Any]:

    page = _safe_page(page)
    per_page = _safe_per_page(per_page)

    if status not in USER_STATUSES:
        status = "all"

    keyword = " ".join((keyword or "").split())[:200]

    query = User.query

    if status == "active":
        query = query.filter(
            User.is_active.is_(True)
        )

    elif status == "banned":
        query = query.filter(
            User.is_active.is_(False)
        )

    if keyword:
        pattern = f"%{keyword}%"

        query = query.filter(
            or_(
                User.username.ilike(pattern),
                User.email.ilike(pattern),
                User.full_name.ilike(pattern),
            )
        )

    query = query.order_by(
        User.created_at.desc(),
        User.id.desc(),
    )

    total = query.count()

    users = (
        query
        .offset((page - 1) * per_page)
        .limit(per_page)
        .all()
    )

    return {
        "users": [
            {
                "id": user.id,
                "username": user.username,
                "email": user.email,
                "full_name": user.full_name,
                "role": user.role,
                "is_active": bool(user.is_active),
                "created_at": _iso(user.created_at),
                "last_login": _iso(user.last_login),
            }
            for user in users
        ],

        "pagination": {
            "page": page,
            "per_page": per_page,
            "total": total,
            "total_pages": ceil(total / per_page) if total else 0,
        }
    }


def set_user_active(
    user_id: int,
    active: bool,
    admin_id: int | None = None,
    acting_admin_id: int | None = None,
) -> tuple[dict, int]:

    user = db.session.get(User, user_id)

    if user is None:
        return {
            "status": "error",
            "message": "User not found."
        }, 404

    # Không cho admin tự ban mình
    if acting_admin_id and user.id == acting_admin_id:
        return {
            "status": "error",
            "message": "You cannot ban your own account."
        }, 400

    # Không cho ban admin khác
    if user.role == "admin":
        return {
            "status": "error",
            "message": "Administrator accounts cannot be banned."
        }, 403

    try:
        user.is_active = active

        # Làm session hiện tại của user đó hết hiệu lực
        user.session_version += 1

        effective_admin_id = acting_admin_id or admin_id
        if effective_admin_id:
            audit = AdminAuditLog(
                admin_id=effective_admin_id,
                action="UNBAN_USER" if active else "BAN_USER",
                target_type="user",
                target_id=user.id,
                details=f"User '{user.email}' set to {'active' if active else 'banned'}",
            )
            db.session.add(audit)

        db.session.commit()

    except SQLAlchemyError:
        db.session.rollback()

        return {
            "status": "error",
            "message": "Unable to update user status."
        }, 500

    return {
        "status": "success",
        "message": (
            "User unbanned successfully."
            if active
            else "User banned successfully."
        ),
        "user": {
            "id": user.id,
            "is_active": user.is_active,
        }
    }, 200


# ============================================================
# SCRAPER RUNS & TELEMETRY
# ============================================================

def get_scraper_runs(limit: int = 20) -> dict[str, Any]:
    """Retrieve recent scraper execution logs and current running state."""
    from models import ScraperRun
    from services.scheduler_service import SchedulerService
    from services.time_service import vietnam_now

    limit = max(1, min(100, int(limit)))

    runs = (
        ScraperRun.query
        .order_by(ScraperRun.started_at.desc(), ScraperRun.id.desc())
        .limit(limit)
        .all()
    )

    return {
        "is_running": SchedulerService.is_locked(),
        "runs": [
            {
                "id": run.id,
                "trigger_type": run.trigger_type,
                "triggered_by": run.triggered_by.email if run.triggered_by else "System Schedule",
                "status": run.status,
                "started_at": _iso(run.started_at),
                "completed_at": _iso(run.completed_at),
                "articles_scraped": run.articles_scraped,
                "articles_created": run.articles_created,
                "duplicates_found": run.duplicates_found,
                "error_count": run.error_count,
            }
            for run in runs
        ],
    }


def trigger_manual_scrape(admin_id: int, source_id: Optional[int] = None, max_articles: Optional[int] = None) -> tuple[dict, int]:
    """Trigger a manual scraper execution in a background thread with lock & cooldown."""
    import threading
    from datetime import datetime, timedelta
    from models import ScraperRun
    from services.scheduler_service import SchedulerService

    if SchedulerService.is_locked():
        return {
            "status": "error",
            "message": "Scraper is already running. Please wait for the current job to finish."
        }, 409

    # Check 60s cooldown
    recent_manual = (
        ScraperRun.query
        .filter(ScraperRun.trigger_type == "manual")
        .order_by(ScraperRun.started_at.desc())
        .first()
    )
    if recent_manual and recent_manual.started_at:
        seconds_since = (vietnam_now() - recent_manual.started_at).total_seconds()
        if seconds_since < 60:
            cooldown_left = int(60 - seconds_since)
            return {
                "status": "error",
                "message": f"Rate limit reached. Please wait {cooldown_left}s before triggering again."
            }, 429

    # Record Audit Log
    try:
        audit = AdminAuditLog(
            admin_id=admin_id,
            action="TRIGGER_SCRAPER",
            target_type="scraper",
            target_id=None,
            details="Manual scraper run triggered from Admin Dashboard",
        )
        db.session.add(audit)
        db.session.commit()
    except Exception:
        db.session.rollback()

    # Launch in background thread
    thread = threading.Thread(
        target=SchedulerService.execute_scraper_run,
        kwargs={"trigger_type": "manual", "admin_id": admin_id, "source_id": source_id, "max_articles": max_articles},
        daemon=True,
    )
    thread.start()

    return {
        "status": "success",
        "message": "Manual scraping job started successfully.",
    }, 202


# ============================================================
# DUPLICATE MODERATION CONSOLE
# ============================================================

def get_suspect_duplicates(limit: int = 10) -> dict[str, Any]:
    """Find clusters of articles with matching title fingerprints or content hashes."""
    from sqlalchemy import func

    # Group by title_fingerprint where count > 1
    fp_query = (
        db.session.query(Article.title_fingerprint, func.count(Article.id).label("match_count"))
        .filter(Article.title_fingerprint.isnot(None), Article.is_deleted.is_(False))
        .group_by(Article.title_fingerprint)
        .having(func.count(Article.id) > 1)
        .limit(limit)
        .all()
    )

    clusters = []
    for fp, count in fp_query:
        matching_articles = (
            Article.query
            .filter(Article.title_fingerprint == fp, Article.is_deleted.is_(False))
            .order_by(Article.published_at.desc().nullslast(), Article.id.asc())
            .all()
        )
        if len(matching_articles) > 1:
            clusters.append({
                "match_type": "title_fingerprint",
                "match_key": fp,
                "count": len(matching_articles),
                "articles": [
                    {
                        "id": a.id,
                        "title": a.title,
                        "source_url": a.source_url,
                        "published_at": _iso(a.published_at),
                        "scraped_at": _iso(a.scraped_at),
                    }
                    for a in matching_articles
                ]
            })

    return {"clusters": clusters}


def resolve_duplicates(
    primary_id: int,
    duplicate_ids: list[int],
    admin_id: int,
) -> tuple[dict, int]:
    """Soft-hide secondary duplicate articles and link them to designated primary article."""
    primary = db.session.get(Article, primary_id)
    if not primary:
        return {"status": "error", "message": "Primary article not found."}, 404

    if not duplicate_ids:
        return {"status": "error", "message": "No duplicate article IDs specified."}, 400

    try:
        resolved_count = 0
        for dup_id in duplicate_ids:
            if dup_id == primary_id:
                continue
            dup_article = db.session.get(Article, dup_id)
            if dup_article and not dup_article.is_deleted:
                dup_article.is_deleted = True
                dup_article.primary_article_id = primary_id
                resolved_count += 1

        audit = AdminAuditLog(
            admin_id=admin_id,
            action="RESOLVE_DUPLICATE",
            target_type="article",
            target_id=primary_id,
            details=f"Merged/soft-hidden {resolved_count} duplicate articles into primary Article #{primary_id}",
        )
        db.session.add(audit)
        db.session.commit()

        return {
            "status": "success",
            "message": f"Successfully resolved {resolved_count} duplicates under primary Article #{primary_id}.",
            "primary_id": primary_id,
            "resolved_count": resolved_count,
        }, 200

    except SQLAlchemyError as exc:
        db.session.rollback()
        return {"status": "error", "message": f"Failed to resolve duplicates: {str(exc)}"}, 500


# ============================================================
# SCRAPER CONFIGURATION MANAGEMENT
# ============================================================

def get_scraper_configs() -> dict[str, Any]:
    configs = ScraperConfig.query.order_by(ScraperConfig.source_name).all()
    return {
        "configs": [
            {
                "id": c.id,
                "source_name": c.source_name,
                "base_url": c.base_url,
                "listing_url": c.listing_url,
                "link_selector": c.link_selector,
                "title_selector": c.title_selector,
                "description_selector": c.description_selector,
                "content_selector": c.content_selector,
                "excluded_html_selectors": c.excluded_html_selectors,
                "image_selector": c.image_selector,
                "image_cdn_domains": c.image_cdn_domains,
                "date_selector": c.date_selector,
                "breadcrumb_selector": c.breadcrumb_selector,
                "is_active": c.is_active,
                "created_at": _iso(c.created_at),
                "updated_at": _iso(c.updated_at),
            }
            for c in configs
        ]
    }


def get_scraper_config(config_id: int) -> tuple[dict, int]:
    config = db.session.get(ScraperConfig, config_id)
    if not config:
        return {"status": "error", "message": "Scraper config not found."}, 404

    return {
        "status": "success",
        "config": {
            "id": config.id,
            "source_name": config.source_name,
            "base_url": config.base_url,
            "listing_url": config.listing_url,
            "link_selector": config.link_selector,
            "title_selector": config.title_selector,
            "description_selector": config.description_selector,
            "content_selector": config.content_selector,
            "image_selector": config.image_selector,
            "date_selector": config.date_selector,
            "breadcrumb_selector": config.breadcrumb_selector,
            "is_active": config.is_active,
            "created_at": _iso(config.created_at),
            "updated_at": _iso(config.updated_at),
        }
    }, 200


def save_scraper_config(data: dict, admin_id: int, config_id: int | None = None) -> tuple[dict, int]:
    from sqlalchemy.exc import IntegrityError

    required_fields = ["source_name", "base_url", "listing_url", "link_selector", "title_selector"]
    for field in required_fields:
        if not data.get(field):
            return {"status": "error", "message": f"Field '{field}' is required."}, 400

    try:
        if config_id:
            config = db.session.get(ScraperConfig, config_id)
            if not config:
                return {"status": "error", "message": "Scraper config not found."}, 404
            action = "UPDATE_SCRAPER_CONFIG"
            details = f"Updated scraper config '{data['source_name']}'"
        else:
            config = ScraperConfig()
            db.session.add(config)
            action = "CREATE_SCRAPER_CONFIG"
            details = f"Created new scraper config '{data['source_name']}'"

        config.source_name = data["source_name"]
        config.base_url = data["base_url"]
        config.listing_url = data["listing_url"]
        config.link_selector = data["link_selector"]
        config.title_selector = data["title_selector"]
        config.description_selector = data.get("description_selector")
        config.content_selector = data.get("content_selector")
        config.image_selector = data.get("image_selector")
        config.date_selector = data.get("date_selector")
        config.breadcrumb_selector = data.get("breadcrumb_selector")
        
        if "is_active" in data:
            config.is_active = bool(data["is_active"])

        db.session.flush()  # Ensures config.id is available if newly created

        audit = AdminAuditLog(
            admin_id=admin_id,
            action=action,
            target_type="scraper_config",
            target_id=config.id,
            details=details,
        )
        db.session.add(audit)
        
        db.session.commit()

        return {
            "status": "success",
            "message": "Scraper config saved successfully.",
            "config": {
                "id": config.id,
                "source_name": config.source_name,
                "base_url": config.base_url,
                "listing_url": config.listing_url,
                "link_selector": config.link_selector,
                "title_selector": config.title_selector,
                "description_selector": config.description_selector,
                "content_selector": config.content_selector,
                "image_selector": config.image_selector,
                "date_selector": config.date_selector,
                "breadcrumb_selector": config.breadcrumb_selector,
                "is_active": config.is_active,
                "created_at": _iso(config.created_at),
                "updated_at": _iso(config.updated_at),
            }
        }, 200

    except IntegrityError:
        db.session.rollback()
        return {"status": "error", "message": f"Scraper config with source_name '{data['source_name']}' already exists."}, 409
    except SQLAlchemyError as exc:
        db.session.rollback()
        return {"status": "error", "message": f"Database error: {str(exc)}"}, 500


def delete_scraper_config(config_id: int, admin_id: int) -> tuple[dict, int]:
    config = db.session.get(ScraperConfig, config_id)
    if not config:
        return {"status": "error", "message": "Scraper config not found."}, 404

    try:
        source_name = config.source_name
        db.session.delete(config)

        audit = AdminAuditLog(
            admin_id=admin_id,
            action="DELETE_SCRAPER_CONFIG",
            target_type="scraper_config",
            target_id=config_id,
            details=f"Deleted scraper config '{source_name}'",
        )
        db.session.add(audit)
        db.session.commit()

        return {
            "status": "success",
            "message": "Scraper config deleted successfully.",
        }, 200

    except SQLAlchemyError as exc:
        db.session.rollback()
        return {"status": "error", "message": f"Database error: {str(exc)}"}, 500


def test_scraper_selectors(data: dict) -> tuple[dict, int]:
    from scraper.dynamic_scraper import DynamicScraper
    
    test_url = data.get("test_url")
    if not test_url:
        return {"status": "error", "message": "Field 'test_url' is required for testing."}, 400

    try:
        preview = DynamicScraper.test_selectors(test_url, data)
        return {
            "status": "success",
            "preview": preview,
        }, 200
    except Exception as exc:
        return {"status": "error", "message": f"Test failed: {str(exc)}"}, 500


def get_pipeline_config() -> dict[str, Any]:
    """Retrieve all scraper configs and system settings."""
    from models import SystemSetting
    
    configs = ScraperConfig.query.order_by(ScraperConfig.id).all()
    settings = SystemSetting.query.all()
    
    return {
        "sources": [
            {
                "id": c.id,
                "source_name": c.source_name,
                "source_domain": c.source_domain,
                "target_url": c.target_url,
                "is_enabled": c.is_enabled,
                "max_articles_per_run": c.max_articles_per_run,
                "article_list_selector": c.article_list_selector,
                "title_selector": c.title_selector,
                "description_selector": c.description_selector,
                "content_selector": c.content_selector,
                "excluded_html_selectors": c.excluded_html_selectors,
                "image_selector": c.image_selector,
                "image_cdn_domains": c.image_cdn_domains,
                "published_date_selector": c.published_date_selector,
            }
            for c in configs
        ],
        "settings": {s.key: s.value for s in settings}
    }


def update_pipeline_config(data: dict, admin_id: int) -> tuple[dict, int]:
    """Update scraper configs and system settings, then reschedule if needed."""
    from models import SystemSetting
    from services.scheduler_service import SchedulerService

    try:
        for source_data in data.get("sources", []):
            if "image_cdn_domains" in source_data:
                source_data["image_cdn_domains"] = _normalize_image_cdn_domains(
                    source_data["image_cdn_domains"]
                )
    except ValueError as exc:
        return {"status": "error", "message": str(exc)}, 400

    try:
        # Update settings
        settings_data = data.get("settings", {})
        for key, value in settings_data.items():
            setting = db.session.get(SystemSetting, key)
            if setting:
                setting.value = str(value)
            else:
                new_setting = SystemSetting(key=key, value=str(value))
                db.session.add(new_setting)

        # Update or create sources
        sources_data = data.get("sources", [])
        for source_data in sources_data:
            source_id = source_data.get("id")
            
            if source_id and not str(source_id).startswith("new_"):
                config = db.session.get(ScraperConfig, int(source_id))
            else:
                config = ScraperConfig()
                db.session.add(config)
                
            if config:
                if "source_name" in source_data and source_data["source_name"].strip():
                    config.source_name = source_data["source_name"].strip()
                elif not config.source_name:
                    config.source_name = "Untitled Source"
                    
                target_url = (source_data.get("target_url") or "").strip()
                if target_url:
                    if not target_url.startswith(("http://", "https://")):
                        target_url = "https://" + target_url
                    from urllib.parse import urlparse
                    domain = urlparse(target_url).netloc
                    config.source_domain = domain if domain else "unknown"
                    config.target_url = target_url
                elif not config.target_url:
                    config.target_url = "https://example.com"
                    config.source_domain = "example.com"
                
                if "is_enabled" in source_data:
                    config.is_enabled = bool(source_data["is_enabled"])
                    
                if "max_articles_per_run" in source_data:
                    try:
                        config.max_articles_per_run = int(source_data["max_articles_per_run"])
                    except (ValueError, TypeError):
                        pass
                
                # Selectors
                if "article_list_selector" in source_data:
                    config.article_list_selector = source_data["article_list_selector"].strip()
                if "title_selector" in source_data:
                    config.title_selector = source_data["title_selector"].strip()
                if "description_selector" in source_data:
                    config.description_selector = source_data["description_selector"].strip()
                if "content_selector" in source_data:
                    config.content_selector = source_data["content_selector"].strip()
                if "excluded_html_selectors" in source_data:
                    config.excluded_html_selectors = source_data["excluded_html_selectors"].strip()
                if "image_selector" in source_data:
                    config.image_selector = source_data["image_selector"].strip()
                if "image_cdn_domains" in source_data:
                    config.image_cdn_domains = source_data["image_cdn_domains"]
                if "published_date_selector" in source_data:
                    config.published_date_selector = source_data["published_date_selector"].strip()
                
        # Audit log
        audit = AdminAuditLog(
            admin_id=admin_id,
            action="UPDATE",
            target_type="pipeline_config",
            details="Updated pipeline configurations and settings."
        )
        db.session.add(audit)
        
        db.session.commit()
        
        # Reschedule scraper job
        if "scraping_interval_minutes" in settings_data:
            SchedulerService.reschedule_scraper_job()
            
        return {"status": "success", "message": "Pipeline configuration updated successfully."}, 200
        
    except Exception as exc:
        db.session.rollback()
        return {"status": "error", "message": f"Failed to update config: {str(exc)}"}, 500
