"""Business logic for authenticated user profile management."""

import logging
import re
from datetime import datetime
from pathlib import Path
from typing import Any
from uuid import uuid4

from flask import current_app
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from werkzeug.datastructures import FileStorage
from werkzeug.utils import secure_filename

from models import User, db
from services.time_service import vietnam_now


logger = logging.getLogger(__name__)

EMAIL_REGEX = re.compile(r"^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$")
PASSWORD_REGEX = re.compile(r"^(?=.*[A-Za-z])(?=.*\d).{8,}$")
MAX_AVATAR_SIZE_BYTES = 5 * 1024 * 1024
ALLOWED_AVATAR_TYPES = {
    ".jpg": "image/jpeg",
    ".jpeg": "image/jpeg",
    ".png": "image/png",
    ".gif": "image/gif",
    ".webp": "image/webp",
}


def _serialize_profile(user: User) -> dict[str, Any]:
    """Return a JSON-safe profile representation without authentication secrets."""
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role,
        "avatar_url": user.avatar_url,
        "avatar_mime_type": user.avatar_mime_type,
        "avatar_uploaded_at": (
            user.avatar_uploaded_at.isoformat() if user.avatar_uploaded_at else None
        ),
    }


def _get_user(user_id: int) -> User | None:
    """Look up a user by primary key."""
    return db.session.get(User, user_id)


def _avatar_upload_directory() -> Path:
    """Return a configured avatar directory constrained to Flask's static root."""
    static_root = Path(current_app.static_folder).resolve()
    configured_directory = current_app.config.get("PROFILE_AVATAR_UPLOAD_DIR")
    directory = (
        Path(configured_directory).resolve()
        if configured_directory
        else static_root / "uploads" / "avatars"
    )
    try:
        directory.relative_to(static_root)
    except ValueError as exc:
        raise ValueError("Avatar upload directory must be inside the static directory.") from exc
    return directory


def get_profile_data(user_id: int) -> tuple[dict[str, Any], int]:
    """Get safe profile data for a user.

    Args:
        user_id: Primary key of the authenticated user.

    Returns:
        A JSON-compatible response payload and HTTP status code.
    """
    try:
        user = _get_user(user_id)
        if user is None:
            return {"status": "error", "message": "User account was not found."}, 404
        return {"status": "success", "profile": _serialize_profile(user)}, 200
    except SQLAlchemyError as exc:
        logger.error("[PROFILE][ERROR] Failed to read profile: user_id=%s error=%s", user_id, exc, exc_info=True)
        return {"status": "error", "message": "Unable to load profile. Please try again later."}, 500


def update_profile(
    user_id: int, full_name: str | None, email: str | None
) -> tuple[dict[str, Any], int]:
    """Validate and atomically update a user's personal information."""
    normalized_name = full_name.strip() if isinstance(full_name, str) else ""
    normalized_email = email.strip().lower() if isinstance(email, str) else ""
    if not normalized_name:
        return {"status": "error", "message": "Full name is required."}, 400
    if not normalized_email or not EMAIL_REGEX.fullmatch(normalized_email):
        return {"status": "error", "message": "Please provide a valid email address."}, 400

    try:
        user = _get_user(user_id)
        if user is None:
            return {"status": "error", "message": "User account was not found."}, 404

        duplicate = User.query.filter(
            db.func.lower(User.email) == normalized_email,
            User.id != user_id,
        ).first()
        if duplicate is not None:
            logger.warning("[PROFILE][FAIL] Duplicate email update: user_id=%s", user_id)
            return {"status": "error", "message": "That email address is already in use."}, 400

        user.full_name = normalized_name
        user.email = normalized_email
        db.session.commit()
        logger.info("[PROFILE][SUCCESS] Profile updated: user_id=%s", user_id)
        return {"status": "success", "message": "Profile updated successfully.", "profile": _serialize_profile(user)}, 200
    except IntegrityError as exc:
        db.session.rollback()
        logger.warning("[PROFILE][FAIL] Email update integrity error: user_id=%s error=%s", user_id, exc)
        return {"status": "error", "message": "That email address is already in use."}, 400
    except SQLAlchemyError as exc:
        db.session.rollback()
        logger.error("[PROFILE][ERROR] Profile update failed: user_id=%s error=%s", user_id, exc, exc_info=True)
        return {"status": "error", "message": "Unable to update profile. Please try again later."}, 500


def change_password(
    user_id: int,
    current_password: str | None,
    new_password: str | None,
    confirm_password: str | None,
) -> tuple[dict[str, Any], int]:
    """Verify and rotate a user's password, invalidating existing sessions."""
    if not all(isinstance(value, str) and value for value in (current_password, new_password, confirm_password)):
        return {"status": "error", "message": "All password fields are required."}, 400
    if new_password != confirm_password:
        return {"status": "error", "message": "New password confirmation does not match."}, 400
    if not PASSWORD_REGEX.fullmatch(new_password):
        return {"status": "error", "message": "Password must be at least 8 characters and contain at least one letter and one number."}, 400

    try:
        user = _get_user(user_id)
        if user is None:
            return {"status": "error", "message": "User account was not found."}, 404
        if not user.check_password(current_password):
            logger.warning("[PROFILE][FAIL] Password change rejected: user_id=%s", user_id)
            return {"status": "error", "message": "Current password is incorrect."}, 401

        user.set_password(new_password)
        user.session_version += 1
        db.session.commit()
        logger.info("[PROFILE][SUCCESS] Password changed: user_id=%s", user_id)
        return {"status": "success", "message": "Password changed successfully."}, 200
    except SQLAlchemyError as exc:
        db.session.rollback()
        logger.error("[PROFILE][ERROR] Password change failed: user_id=%s error=%s", user_id, exc, exc_info=True)
        return {"status": "error", "message": "Unable to change password. Please try again later."}, 500


def upload_avatar(user_id: int, uploaded_file: FileStorage | None) -> tuple[dict[str, Any], int]:
    """Validate and persist an avatar file for a user.

    Images are kept below Flask's static directory so their stored URL is safe
    to render directly by the client.
    """
    if uploaded_file is None or not uploaded_file.filename:
        return {"status": "error", "message": "Please select an image file."}, 400

    filename = secure_filename(uploaded_file.filename)
    extension = Path(filename).suffix.lower()
    expected_mime_type = ALLOWED_AVATAR_TYPES.get(extension)
    if not filename or expected_mime_type is None:
        return {"status": "error", "message": "Avatar must be a JPG, PNG, GIF, or WebP image."}, 400
    if uploaded_file.mimetype != expected_mime_type:
        return {"status": "error", "message": "Avatar file type does not match its extension."}, 400

    try:
        uploaded_file.stream.seek(0, 2)
        file_size = uploaded_file.stream.tell()
        uploaded_file.stream.seek(0)
    except (AttributeError, OSError):
        return {"status": "error", "message": "Unable to read the uploaded image."}, 400
    if file_size > MAX_AVATAR_SIZE_BYTES:
        return {"status": "error", "message": "Avatar image must be 5 MB or smaller."}, 400

    saved_file: Path | None = None
    try:
        user = _get_user(user_id)
        if user is None:
            return {"status": "error", "message": "User account was not found."}, 404

        directory = _avatar_upload_directory()
        directory.mkdir(parents=True, exist_ok=True)
        stored_filename = f"{uuid4().hex}{extension}"
        saved_file = directory / stored_filename
        uploaded_file.save(saved_file)
        static_root = Path(current_app.static_folder).resolve()
        static_filename = saved_file.relative_to(static_root).as_posix()
        avatar_url = f"{current_app.static_url_path.rstrip('/')}/{static_filename}"

        user.avatar_url = avatar_url
        user.avatar_mime_type = expected_mime_type
        user.avatar_uploaded_at = vietnam_now()
        db.session.commit()
        logger.info("[PROFILE][SUCCESS] Avatar uploaded: user_id=%s", user_id)
        return {"status": "success", "message": "Avatar uploaded successfully.", "avatar_url": avatar_url, "profile": _serialize_profile(user)}, 200
    except (OSError, ValueError) as exc:
        db.session.rollback()
        if saved_file is not None:
            saved_file.unlink(missing_ok=True)
        logger.warning("[PROFILE][FAIL] Avatar upload rejected: user_id=%s error=%s", user_id, exc)
        return {"status": "error", "message": "Unable to store the avatar image."}, 400
    except SQLAlchemyError as exc:
        db.session.rollback()
        if saved_file is not None:
            saved_file.unlink(missing_ok=True)
        logger.error("[PROFILE][ERROR] Avatar upload failed: user_id=%s error=%s", user_id, exc, exc_info=True)
        return {"status": "error", "message": "Unable to upload avatar. Please try again later."}, 500
