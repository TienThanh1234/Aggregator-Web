"""Gemini-backed generation helpers with safe, local fallbacks."""

from __future__ import annotations

import json
import logging
import os
from typing import Any

from google import genai
from google.genai import types

from models import Article, db

logger = logging.getLogger(__name__)

DEFAULT_MODEL = "gemini-3.1-flash-lite"
MAX_CONTEXT_CHARS = 24_000


def _model_name() -> str:
    return os.getenv("GEMINI_MODEL", DEFAULT_MODEL).strip() or DEFAULT_MODEL


def is_configured() -> bool:
    """Return whether a server-side Gemini key is available."""
    return bool(os.getenv("GEMINI_API_KEY", "").strip())


def _request_json(instruction: str) -> dict[str, Any] | None:
    """Ask Gemini for a JSON object, returning ``None`` on any API failure."""
    key = os.getenv("GEMINI_API_KEY", "").strip()
    if not key:
        return None
    try:
        client = genai.Client(api_key=key)
        response = client.models.generate_content(
            model=_model_name(),
            contents=instruction[:MAX_CONTEXT_CHARS],
            config=types.GenerateContentConfig(
                response_mime_type="application/json",
                temperature=0.2,
            ),
        )
        parsed = json.loads(response.text or "{}")
        return parsed if isinstance(parsed, dict) else None
    except Exception as exc:
        logger.warning("Gemini request failed: %s", type(exc).__name__)
        return None


def _text(value: object, limit: int = 1_000) -> str:
    return value.strip()[:limit] if isinstance(value, str) else ""


def summarize_article(title: str, article_text: str) -> dict[str, Any]:
    """Create a concise article summary and key takeaways."""
    fallback = {
        "summary": ["AI summary is unavailable; review the article for the full context."],
        "confidenceScore": 0,
        "keyTakeaways": ["No AI response was generated."],
        "fallback": True,
    }
    data = _request_json(
        "You are a careful news editor. Summarize only the supplied article; "
        "do not add facts or claims. Return JSON exactly with summary (array of 3 short strings), "
        "confidenceScore (integer 0-100 describing confidence in the supplied text only), and "
        "keyTakeaways (array of 3 short strings).\n\n"
        f"TITLE: {_text(title, 500)}\nARTICLE:\n{_text(article_text, 20_000)}"
    )
    if not data:
        return fallback
    summary = [_text(item, 400) for item in data.get("summary", []) if _text(item, 400)]
    takeaways = [_text(item, 400) for item in data.get("keyTakeaways", []) if _text(item, 400)]
    if not summary:
        return fallback
    try:
        score = max(0, min(100, int(data.get("confidenceScore", 0))))
    except (TypeError, ValueError):
        score = 0
    return {
        "summary": summary[:4],
        "confidenceScore": score,
        "keyTakeaways": takeaways[:4] or summary[:3],
        "fallback": False,
    }


def _stored_summary(ai_summary: str | None) -> dict[str, Any] | None:
    """Return a valid summary response from stored article metadata."""
    if not ai_summary:
        return None
    try:
        metadata = json.loads(ai_summary)
    except (TypeError, ValueError):
        return None
    if not isinstance(metadata, dict):
        return None
    summary = [
        _text(item, 400)
        for item in metadata.get("summary", [])
        if _text(item, 400)
    ]
    if not summary:
        return None
    takeaways = [
        _text(item, 400)
        for item in metadata.get("keyTakeaways", [])
        if _text(item, 400)
    ]
    try:
        score = max(0, min(100, int(metadata.get("confidenceScore", 0))))
    except (TypeError, ValueError):
        score = 0
    return {
        "summary": summary[:4],
        "confidenceScore": score,
        "keyTakeaways": takeaways[:4] or summary[:3],
        "fallback": False,
        "cached": True,
    }


def get_or_create_article_summary(article_id: int) -> dict[str, Any] | None:
    """Reuse a stored article summary or generate and persist it once."""
    article = db.session.get(Article, article_id)
    if article is None or article.is_deleted:
        return None

    cached = _stored_summary(article.ai_summary)
    if cached:
        return cached

    generated = summarize_article(
        article.title,
        article.raw_content or article.description or "",
    )
    if generated.get("fallback"):
        return {**generated, "cached": False}

    try:
        metadata = json.loads(article.ai_summary) if article.ai_summary else {}
    except (TypeError, ValueError):
        metadata = {}
    if not isinstance(metadata, dict):
        metadata = {}
    metadata.update({
        "summary": generated["summary"],
        "confidenceScore": generated["confidenceScore"],
        "keyTakeaways": generated["keyTakeaways"],
    })
    article.ai_summary = json.dumps(metadata, ensure_ascii=False)
    db.session.commit()
    return {**generated, "cached": False}


def fact_check_article(title: str, article_text: str) -> dict[str, Any]:
    """Assess internal support in the supplied article without claiming web verification."""
    fallback = {
        "confidenceScore": 0,
        "verifiedClaims": [],
        "unverifiedClaims": [{
            "claim": "AI fact-check is unavailable.",
            "analysis": "No external verification was performed. Review the linked primary sources.",
        }],
        "fallback": True,
    }
    data = _request_json(
        "You are a cautious fact-checking assistant. Evaluate claims only against the article below. "
        "Never claim to have verified facts externally. Return JSON exactly with confidenceScore "
        "(integer 0-100), verifiedClaims (array of up to 3 claims supported by the supplied text), "
        "and unverifiedClaims (array of up to 3 objects with claim and analysis explaining uncertainty).\n\n"
        f"TITLE: {_text(title, 500)}\nARTICLE:\n{_text(article_text, 20_000)}"
    )
    if not data:
        return fallback
    verified = [_text(item, 500) for item in data.get("verifiedClaims", []) if _text(item, 500)]
    unverified = []
    for item in data.get("unverifiedClaims", []):
        if not isinstance(item, dict):
            continue
        claim, analysis = _text(item.get("claim"), 500), _text(item.get("analysis"), 800)
        if claim and analysis:
            unverified.append({"claim": claim, "analysis": analysis})
    try:
        score = max(0, min(100, int(data.get("confidenceScore", 0))))
    except (TypeError, ValueError):
        score = 0
    return {
        "confidenceScore": score,
        "verifiedClaims": verified[:3],
        "unverifiedClaims": unverified[:3] or fallback["unverifiedClaims"],
        "fallback": False,
    }


def analyze_article_clarity(
    title: str,
    article_text: str,
    candidate_terms: list[str],
) -> dict[str, Any] | None:
    """Assess linguistic clarity only; never claim an article is true or false."""
    terms = ", ".join(candidate_terms[:80])
    data = _request_json(
        "You are a cautious linguistic-clarity reviewer. Evaluate only the supplied article. "
        "Do not decide whether claims are true or false and do not claim external verification. "
        "Consider hedging, vague quantities, unnamed attribution, and claims lacking stated evidence. "
        "Return JSON exactly with clarityScore (integer 0-100), report (short plain-text explanation), "
        "and findings (array of objects with term, severity low|medium|high, excerpt, explanation). "
        "Only use a term when it occurs in the supplied candidate term list.\n\n"
        f"CANDIDATE TERMS: {terms}\nTITLE: {_text(title, 500)}\nARTICLE:\n{_text(article_text, 20_000)}"
    )
    if not data:
        return None
    try:
        clarity = max(0, min(100, int(data.get("clarityScore", 0))))
    except (TypeError, ValueError):
        return None
    allowed = {term.casefold() for term in candidate_terms}
    findings = []
    for item in data.get("findings", []):
        if not isinstance(item, dict):
            continue
        term = _text(item.get("term"), 120)
        severity = _text(item.get("severity"), 10).lower()
        if term.casefold() not in allowed or severity not in {"low", "medium", "high"}:
            continue
        findings.append({
            "term": term,
            "severity": severity,
            "excerpt": _text(item.get("excerpt"), 300),
            "explanation": _text(item.get("explanation"), 500),
        })
    return {
        "clarity_score": clarity,
        "report": _text(data.get("report"), 1_200),
        "findings": findings,
    }


def verify_article_against_evidence(
    title: str,
    article_text: str,
    evidence_sources: list[dict[str, str]],
) -> dict[str, Any] | None:
    """Compare supplied claims with supplied evidence; Gemini is not given web access."""
    evidence = []
    for index, source in enumerate(evidence_sources[:3], start=1):
        source_id = _text(source.get("id"), 80) or str(index)
        source_title = _text(source.get("title"), 500)
        source_url = _text(source.get("url"), 1_000)
        source_text = _text(source.get("text"), 5_000)
        if source_text:
            evidence.append(
                f"SOURCE {source_id}\nTITLE: {source_title}\nURL: {source_url}\nCONTENT: {source_text}"
            )
    if not evidence:
        return None
    data = _request_json(
        "You are a cautious news verification assistant. Compare the target article only with the "
        "supplied evidence sources. Do not browse, infer unseen facts, or state that anything is "
        "proven true. Score how well the article's material claims are corroborated: 0 means no "
        "usable support, 100 means the supplied sources strongly and independently support its "
        "major claims. Treat disagreement and missing evidence as uncertainty. Return JSON exactly "
        "with verificationScore (integer 0-100), report (short plain-text explanation), and "
        "claimResults (array up to 3 objects with claim, status supported|conflicting|insufficient_evidence, "
        "analysis, evidenceSourceIds array).\n\n"
        f"TARGET TITLE: {_text(title, 500)}\nTARGET ARTICLE:\n{_text(article_text, 8_000)}\n\n"
        "EVIDENCE SOURCES:\n" + "\n\n".join(evidence)
    )
    if not data:
        return None
    try:
        score = max(0, min(100, int(data.get("verificationScore", 0))))
    except (TypeError, ValueError):
        return None
    claims = []
    for item in data.get("claimResults", []):
        if not isinstance(item, dict):
            continue
        status = _text(item.get("status"), 40)
        if status not in {"supported", "conflicting", "insufficient_evidence"}:
            continue
        claim = _text(item.get("claim"), 500)
        analysis = _text(item.get("analysis"), 800)
        ids = [str(value)[:80] for value in item.get("evidenceSourceIds", []) if str(value).strip()]
        if claim and analysis:
            claims.append({"claim": claim, "status": status, "analysis": analysis, "evidence_source_ids": ids[:2]})
    return {
        "verification_score": score,
        "report": _text(data.get("report"), 1_200),
        "claim_results": claims,
    }


def generate_daily_brief(article_context: str, brief_date: str) -> str | None:
    """Return a short Markdown bullet list for a user's selected news."""
    data = _request_json(
        "You are a concise morning news editor. Use only the supplied articles. Return JSON exactly "
        "with bullets: an array of 3 or 4 short, useful news updates. The rendered brief must start "
        f"with this exact plain-text date heading: Daily Brief — {brief_date}. End each bullet with one or "
        "more supporting article IDs in square brackets, for example [2000] or [2000, 2050]. Use only "
        "the ARTICLE ID values supplied below. Do not use markdown links, do not invent facts, and explain "
        "uncertainty when relevant.\n\nARTICLES:\n"
        + article_context[:20_000]
    )
    if not data:
        return None
    bullets = [_text(item, 600) for item in data.get("bullets", []) if _text(item, 600)]
    if not bullets:
        return None
    return f"Daily Brief — {brief_date}\n" + "\n".join(f"- {bullet}" for bullet in bullets[:4])
