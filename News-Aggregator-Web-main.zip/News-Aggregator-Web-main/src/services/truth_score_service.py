"""Deterministic, auditable evidence-confidence scoring for articles.

The score ranks available reporting; it does not certify that a story is true.
No external/AI request is made by this module.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timedelta
from urllib.parse import urlparse

from sqlalchemy.orm import joinedload, load_only

from models import Article, ArticleStoryMembership, ArticleTruthScore, ScraperConfig, db
from services.time_service import vietnam_now

logger = logging.getLogger(__name__)

CALCULATION_VERSION = "v3-verify-clarity"
FALLBACK_VERSION = "v3-verify-fallback"
NEUTRAL_RELIABILITY = 100
FALLBACK_SCORE = 40
CLUSTER_WINDOW = timedelta(hours=72)

# The periodic scorer only needs metadata.  Article bodies and extracted image
# blocks are deliberately excluded to control database egress.
ARTICLE_SCORING_COLUMNS = (
    Article.id,
    Article.title,
    Article.description,
    Article.source_url,
    Article.published_at,
    Article.scraped_at,
    Article.canonical_url,
    Article.content_hash,
    Article.primary_article_id,
    Article.is_deleted,
)


def normalize_source_domain(url: str | None) -> str | None:
    """Return a normalized hostname for a valid HTTP(S) URL."""
    if not url:
        return None
    parsed = urlparse(url)
    if parsed.scheme not in {"http", "https"} or not parsed.hostname:
        return None
    return parsed.hostname.lower().removeprefix("www.")


def _source_config(article: Article) -> ScraperConfig | None:
    domain = normalize_source_domain(article.source_url)
    return ScraperConfig.query.filter(db.func.lower(ScraperConfig.source_domain) == domain).first() if domain else None


def _cluster_members(article: Article) -> list[Article]:
    """Use accepted Story Cluster membership; hash equality remains fallback."""
    if article.story_membership and article.story_membership.status == "accepted":
        members = [
            membership.article
            for membership in ArticleStoryMembership.query.options(
                joinedload(ArticleStoryMembership.article).load_only(*ARTICLE_SCORING_COLUMNS)
            ).filter_by(
                cluster_id=article.story_membership.cluster_id,
                status="accepted",
            ).all()
            if not membership.article.is_deleted
        ]
        if members:
            return members
    if not article.content_hash:
        return [article]
    candidates = Article.query.filter(
        Article.is_deleted.is_(False),
        Article.content_hash == article.content_hash,
        Article.id != article.id,
    ).options(load_only(*ARTICLE_SCORING_COLUMNS)).all()
    return [article, *candidates]


def _canonicalize(members: list[Article]) -> Article:
    canonical = min(members, key=lambda item: (item.published_at or item.scraped_at, item.id or 0))
    for item in members:
        item.primary_article_id = None if item is canonical else canonical.id
    return canonical


def calculate_score(article: Article, members: list[Article], source: ScraperConfig | None = None) -> dict:
    """Calculate score components from persisted metadata only."""
    reliability = source.reliability_score if source and source.reliability_score is not None else NEUTRAL_RELIABILITY
    reliability = max(0, min(100, int(reliability)))
    source_score = round(reliability / 100 * 50)

    domains = sorted({domain for domain in (normalize_source_domain(item.source_url) for item in members) if domain})
    corroboration_score = 0 if len(domains) <= 1 else 5 if len(domains) == 2 else 8 if len(domains) == 3 else 10

    metadata_score = 0
    metadata_score += 4 if article.published_at else 0
    metadata_score += 3 if normalize_source_domain(article.canonical_url) else 0
    metadata_score += 3 if source else 0

    content_score = 0
    content_score += 3 if article.title and article.title.strip() else 0
    content_score += 3 if article.description and len(article.description.strip()) >= 80 else 0
    # Fetch only the length for the body-content threshold, not the article
    # body itself.  This query returns a small scalar value.
    raw_content_length = db.session.query(db.func.length(Article.raw_content)).filter(
        Article.id == article.id
    ).scalar()
    content_score += 4 if (raw_content_length or 0) >= 500 else 0

    base_score = max(0, min(80, source_score + corroboration_score + metadata_score + content_score))
    return {
        "base_score": base_score,
        "source_reliability_score": source_score,
        "corroboration_score": corroboration_score,
        "metadata_score": metadata_score,
        "content_score": content_score,
        "corroborating_article_ids": sorted(item.id for item in members if item.id and item.id != article.id),
        "corroborating_domains": domains,
        "calculation_version": CALCULATION_VERSION,
    }


def _persist(article: Article, calculation: dict, detail: ArticleTruthScore | None = None) -> ArticleTruthScore:
    now = vietnam_now()
    detail = detail or ArticleTruthScore.query.filter_by(article_id=article.id).first() or ArticleTruthScore(article_id=article.id)
    clarity = (
        max(0, min(20, int(detail.linguistic_clarity_score or 0)))
        if detail.clarity_status == "completed"
        else 0
    )
    article.truth_score = calculation["base_score"] + clarity
    article.truth_score_version = calculation["calculation_version"]
    article.truth_score_updated_at = now
    detail.base_score = calculation["base_score"]
    detail.total_score = article.truth_score
    for key in ("source_reliability_score", "corroboration_score", "metadata_score", "content_score", "calculation_version"):
        setattr(detail, key, calculation[key])
    detail.corroborating_article_ids = json.dumps(calculation["corroborating_article_ids"])
    detail.corroborating_domains = json.dumps(calculation["corroborating_domains"])
    detail.calculated_at = now
    db.session.add(detail)
    return detail


def apply_linguistic_clarity(detail: ArticleTruthScore, clarity_score: int) -> ArticleTruthScore:
    """Persist cached clarity points and update the article's final 0-100 score."""
    points = max(0, min(20, int(clarity_score)))
    detail.linguistic_clarity_score = points
    detail.total_score = max(0, min(100, int(detail.base_score or 0) + points))
    detail.article.truth_score = detail.total_score
    detail.article.truth_score_version = CALCULATION_VERSION
    detail.article.truth_score_updated_at = vietnam_now()
    db.session.add_all([detail, detail.article])
    return detail


def persist_fallback_score(article: Article, reason: Exception | str | None = None) -> ArticleTruthScore:
    """Store a conservative value when normal orchestration fails."""
    logger.warning("Truth-score fallback for article_id=%s: %s", article.id, type(reason).__name__ if isinstance(reason, Exception) else reason)
    return _persist(article, {
        "base_score": FALLBACK_SCORE, "source_reliability_score": 0,
        "corroboration_score": 0, "metadata_score": 0, "content_score": 0,
        "corroborating_article_ids": [], "corroborating_domains": [],
        "calculation_version": FALLBACK_VERSION,
    })


def score_article(article: Article) -> list[Article]:
    """Score an article's cluster with batched detail/configuration reads."""
    members = _cluster_members(article)
    _canonicalize(members)
    article_ids = [member.id for member in members if member.id]
    details = {
        detail.article_id: detail
        for detail in ArticleTruthScore.query.filter(ArticleTruthScore.article_id.in_(article_ids)).all()
    }
    domains = {normalize_source_domain(member.source_url) for member in members}
    configs = {
        config.source_domain.lower(): config
        for config in ScraperConfig.query.filter(
            db.func.lower(ScraperConfig.source_domain).in_([domain for domain in domains if domain])
        ).all()
    }
    for member in members:
        domain = normalize_source_domain(member.source_url)
        _persist(member, calculate_score(member, members, configs.get(domain)), details.get(member.id))
    return members


def score_article_and_cluster(article_id: int) -> Article | None:
    article = db.session.get(Article, article_id)
    if not article or article.is_deleted:
        return None
    try:
        score_article(article)
        db.session.commit()
    except Exception as exc:
        db.session.rollback()
        try:
            persist_fallback_score(article, exc)
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise
    return article


def backfill_truth_scores(batch_size: int = 200, rescore_all: bool = False) -> dict:
    """Score active articles in small, independently committed batches."""
    batch_size = max(1, min(int(batch_size), 500))
    query = Article.query.filter(Article.is_deleted.is_(False))
    if not rescore_all:
        query = query.filter(Article.truth_score.is_(None))
    ids = [item[0] for item in query.with_entities(Article.id).order_by(Article.id).all()]
    result = {"scanned": len(ids), "scored": 0, "fallback": 0}
    scored_article_ids: set[int] = set()
    for start in range(0, len(ids), batch_size):
        for article_id in ids[start:start + batch_size]:
            if article_id in scored_article_ids:
                continue
            article = Article.query.options(load_only(*ARTICLE_SCORING_COLUMNS)).filter_by(id=article_id).first()
            if not article:
                continue
            try:
                members = score_article(article)
                newly_scored = {member.id for member in members} - scored_article_ids
                scored_article_ids.update(newly_scored)
                result["scored"] += len(newly_scored)
            except Exception as exc:
                persist_fallback_score(article, exc)
                scored_article_ids.add(article.id)
                result["fallback"] += 1
        try:
            db.session.commit()
        except Exception:
            db.session.rollback()
            raise
    return result


def rescore_recent_articles(hours: int = 72) -> dict:
    since = vietnam_now() - timedelta(hours=max(1, hours))
    ids = [item[0] for item in Article.query.filter(Article.is_deleted.is_(False), Article.scraped_at >= since).with_entities(Article.id).all()]
    result = {"scanned": len(ids), "scored": 0, "fallback": 0}
    for article_id in ids:
        article = Article.query.options(load_only(*ARTICLE_SCORING_COLUMNS)).filter_by(id=article_id).first()
        try:
            score_article(article)
            result["scored"] += 1
        except Exception as exc:
            persist_fallback_score(article, exc)
            result["fallback"] += 1
    db.session.commit()
    return result


def get_truth_score_detail(article_id: int) -> dict | None:
    article = db.session.get(Article, article_id)
    if not article:
        return None
    detail = article.truth_score_detail
    if not detail:
        return {"article_id": article.id, "truth_score": article.truth_score, "detail": None}
    return {
        "article_id": article.id, "truth_score": article.truth_score,
        "total_score": detail.total_score, "base_score": detail.base_score,
        "linguistic_clarity_score": detail.linguistic_clarity_score,
        "verification_score": detail.verification_score,
        "ambiguity_penalty": detail.ambiguity_penalty,
        "verification_source_type": detail.verification_source_type,
        "clarity_status": detail.clarity_status,
        "total_score": detail.total_score, "source_reliability_score": detail.source_reliability_score,
        "corroboration_score": detail.corroboration_score, "metadata_score": detail.metadata_score,
        "content_score": detail.content_score, "calculation_version": detail.calculation_version,
        "calculated_at": detail.calculated_at.isoformat(),
        "corroborating_article_ids": json.loads(detail.corroborating_article_ids or "[]"),
        "corroborating_domains": json.loads(detail.corroborating_domains or "[]"),
    }
