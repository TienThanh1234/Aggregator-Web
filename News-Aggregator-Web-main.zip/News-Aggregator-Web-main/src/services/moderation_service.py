"""Comment reporting, human moderation, and deterministic prohibited-term filtering."""

from __future__ import annotations

import logging
import re
import unicodedata
from math import ceil
from typing import Any

from sqlalchemy import func, or_
from sqlalchemy.exc import IntegrityError, SQLAlchemyError
from sqlalchemy.orm import joinedload

from models import (
    AdminAuditLog, Article, Comment, CommentFilterEvent, CommentModerationAction,
    CommentProhibitedTerm, CommentReport, Reaction, User, db,
)
from services.time_service import vietnam_now

logger = logging.getLogger(__name__)

REPORT_REASONS = {"spam", "harassment", "hate_or_abuse", "misinformation", "off_topic", "other"}
REPORT_STATUSES = {"open", "resolved", "dismissed"}
MODERATION_ACTIONS = {"hide", "restore", "delete", "dismiss_report"}
MAX_TERM_LENGTH = 120
MAX_CATEGORY_LENGTH = 80
MAX_REASON_LENGTH = 100
MAX_NOTE_LENGTH = 2_000
MAX_EXPLANATION_LENGTH = 1_000


def public_comment_filter():
    """Return the one predicate every public comment query must apply."""
    return Comment.is_deleted.is_(False), Comment.is_hidden.is_(False)


def normalize_text(value: object) -> str:
    """Normalize text for deterministic, accent-insensitive prohibited-term matching."""
    text = unicodedata.normalize("NFKD", str(value or "")).casefold()
    text = "".join(char for char in text if not unicodedata.combining(char))
    return " ".join(re.sub(r"[^\w]+", " ", text, flags=re.UNICODE).split())


def _clean(value: object, maximum: int) -> str:
    return " ".join(str(value or "").split())[:maximum]


def _page(value: object, default: int = 1, maximum: int = 1_000_000) -> int:
    try:
        return max(1, min(int(value), maximum))
    except (TypeError, ValueError):
        return default


def _per_page(value: object, default: int = 20) -> int:
    return _page(value, default, 50)


def _audit(admin_id: int, action: str, target_type: str, target_id: int | None, reason: str, note: str = "") -> None:
    db.session.add(AdminAuditLog(
        admin_id=admin_id, action=action, target_type=target_type, target_id=target_id,
        details=f"reason={reason}; note={note[:300]}" if note else f"reason={reason}",
    ))


def _action(comment: Comment, admin_id: int, action: str, reason: str, note: str = "") -> CommentModerationAction:
    record = CommentModerationAction(comment_id=comment.id, admin_id=admin_id, action=action, reason=reason, note=note or None)
    db.session.add(record)
    db.session.flush()
    _audit(admin_id, f"MODERATE_COMMENT_{action.upper()}", "comment", comment.id, reason, note)
    return record


def evaluate_prohibited_terms(content: object) -> CommentProhibitedTerm | None:
    """Return the active matching term without disclosing it to a public caller."""
    normalized = normalize_text(content)
    if not normalized:
        return None
    for term in CommentProhibitedTerm.query.filter_by(is_active=True).order_by(CommentProhibitedTerm.id).all():
        candidate = term.normalized_term
        if candidate and (candidate in normalized if " " in candidate else re.search(rf"(?<!\w){re.escape(candidate)}(?!\w)", normalized)):
            return term
    return None


def record_filter_event(user_id: int, article_id: int, term_id: int | None) -> None:
    """Persist metadata only; never accept rejected comment content here."""
    db.session.add(CommentFilterEvent(user_id=user_id, article_id=article_id, prohibited_term_id=term_id, outcome="blocked"))
    db.session.commit()


def create_comment_report(user_id: int, comment_id: int, payload: dict[str, Any]) -> tuple[dict[str, Any], int]:
    reason = _clean(payload.get("reason"), 50).lower()
    explanation = _clean(payload.get("explanation"), MAX_EXPLANATION_LENGTH)
    if reason not in REPORT_REASONS or (reason == "other" and not explanation):
        return {"status": "error", "message": "Select a valid report reason."}, 400
    comment = Comment.query.filter(Comment.id == comment_id, *public_comment_filter()).first()
    if comment is None:
        return {"status": "error", "message": "Comment not found."}, 404
    if comment.user_id == user_id:
        return {"status": "error", "message": "You cannot report your own comment."}, 400
    existing = CommentReport.query.filter_by(comment_id=comment_id, reporter_id=user_id).first()
    if existing:
        return {"status": "success", "message": "Report already received.", "report_id": existing.id, "duplicate": True}, 200
    try:
        report = CommentReport(comment_id=comment_id, reporter_id=user_id, reason=reason, explanation=explanation or None)
        db.session.add(report)
        db.session.commit()
        return {"status": "success", "message": "Report received.", "report_id": report.id, "duplicate": False}, 201
    except IntegrityError:
        db.session.rollback()
        existing = CommentReport.query.filter_by(comment_id=comment_id, reporter_id=user_id).first()
        return {"status": "success", "message": "Report already received.", "report_id": existing.id if existing else None, "duplicate": True}, 200
    except SQLAlchemyError:
        db.session.rollback()
        logger.exception("comment_report_failed comment_id=%s", comment_id)
        return {"status": "error", "message": "Unable to submit report."}, 500


def _comment_item(comment: Comment, include_text: bool = True) -> dict[str, Any]:
    open_reports = [item for item in comment.reports if item.status == "open"]
    return {
        "id": comment.id, "content": comment.content if include_text else None,
        "created_at": comment.created_at.isoformat(), "is_hidden": bool(comment.is_hidden),
        "is_deleted": bool(comment.is_deleted), "moderation_reason": comment.moderation_reason,
        "article": {"id": comment.article.id, "title": comment.article.title, "path": f"/articles/{comment.article.id}"},
        "author": {"id": comment.user.id, "username": comment.user.username, "email": comment.user.email, "full_name": comment.user.full_name, "is_active": bool(comment.user.is_active)},
        "reports": {"open_count": len(open_reports), "total_count": len(comment.reports), "reasons": sorted({item.reason for item in open_reports}), "open_ids": [item.id for item in open_reports]},
    }


def get_moderation_summary() -> dict[str, int]:
    return {"open_reports": CommentReport.query.filter_by(status="open").count()}


def get_moderation_comments(params: dict[str, Any]) -> dict[str, Any]:
    page, per_page = _page(params.get("page")), _per_page(params.get("per_page"))
    status = str(params.get("status") or "all")
    report_state = str(params.get("report_state") or "all")
    reason = _clean(params.get("reason"), 50).lower()
    query_text = _clean(params.get("q"), 200)
    query = Comment.query.options(joinedload(Comment.user), joinedload(Comment.article), joinedload(Comment.reports))
    # Keep soft-deleted comments out of the default moderation queue.  They
    # remain available to administrators only through the explicit Deleted
    # filter, which prevents a delete action from leaving the row onscreen.
    if status == "deleted":
        query = query.filter(Comment.is_deleted.is_(True))
    elif status == "hidden":
        query = query.filter(Comment.is_hidden.is_(True), Comment.is_deleted.is_(False))
    elif status == "visible":
        query = query.filter(Comment.is_deleted.is_(False), Comment.is_hidden.is_(False))
    else:
        query = query.filter(Comment.is_deleted.is_(False))
    if report_state in REPORT_STATUSES:
        query = query.join(CommentReport).filter(CommentReport.status == report_state)
    if reason in REPORT_REASONS:
        query = query.join(CommentReport).filter(CommentReport.reason == reason)
    if params.get("author_id"):
        query = query.filter(Comment.user_id == _page(params.get("author_id"), 0))
    if params.get("article_id"):
        query = query.filter(Comment.article_id == _page(params.get("article_id"), 0))
    if query_text:
        pattern = f"%{query_text}%"
        query = query.join(User, Comment.user_id == User.id).join(Article, Comment.article_id == Article.id).filter(or_(Comment.content.ilike(pattern), User.username.ilike(pattern), User.email.ilike(pattern), User.full_name.ilike(pattern), Article.title.ilike(pattern)))
    total = query.distinct(Comment.id).count()
    rows = query.order_by(Comment.created_at.desc(), Comment.id.desc()).offset((page - 1) * per_page).limit(per_page).all()
    return {"items": [_comment_item(item) for item in rows], "pagination": {"page": page, "per_page": per_page, "total": total, "total_pages": ceil(total / per_page) if total else 0}}


def get_moderation_comment_detail(comment_id: int) -> dict[str, Any] | None:
    comment = Comment.query.options(joinedload(Comment.user), joinedload(Comment.article), joinedload(Comment.reports).joinedload(CommentReport.reporter), joinedload(Comment.moderation_actions).joinedload(CommentModerationAction.admin)).filter_by(id=comment_id).first()
    if comment is None:
        return None
    data = _comment_item(comment)
    data["reports"]["items"] = [{"id": item.id, "reason": item.reason, "status": item.status, "created_at": item.created_at.isoformat()} for item in comment.reports]
    data["actions"] = [{"id": item.id, "action": item.action, "reason": item.reason, "note": item.note, "created_at": item.created_at.isoformat(), "admin": item.admin.full_name or item.admin.username or item.admin.email} for item in sorted(comment.moderation_actions, key=lambda row: row.created_at, reverse=True)]
    reactions = Reaction.query.filter_by(article_id=comment.article_id)
    data["reactions"] = {"like_count": reactions.filter_by(reaction_type="like").count(), "dislike_count": reactions.filter_by(reaction_type="dislike").count(), "recent_count": reactions.limit(20).count()}
    data["author_recent_hidden_count"] = Comment.query.filter_by(user_id=comment.user_id, is_hidden=True, is_deleted=False).count()
    return data


def _reason(value: object) -> str:
    return _clean(value, MAX_REASON_LENGTH)


def _mutation_comment(comment_id: int, admin_id: int, action_name: str, payload: dict[str, Any]) -> tuple[dict[str, Any], int]:
    reason, note = _reason(payload.get("reason")), _clean(payload.get("note"), MAX_NOTE_LENGTH)
    if not reason:
        return {"status": "error", "message": "A moderation reason is required."}, 400
    comment = db.session.get(Comment, comment_id)
    if comment is None:
        return {"status": "error", "message": "Comment not found."}, 404
    if action_name == "restore" and comment.is_deleted:
        return {"status": "error", "message": "Deleted comments cannot be restored."}, 409
    if action_name == "hide" and comment.is_hidden:
        return {"status": "success", "message": "Comment is already hidden.", "comment_id": comment.id}, 200
    if action_name == "restore" and not comment.is_hidden:
        return {"status": "success", "message": "Comment is already visible.", "comment_id": comment.id}, 200
    if action_name == "delete" and comment.is_deleted:
        return {"status": "success", "message": "Comment is already deleted.", "comment_id": comment.id}, 200
    try:
        action = _action(comment, admin_id, action_name, reason, note)
        if action_name == "hide":
            comment.is_hidden, comment.moderation_reason, comment.moderation_note = True, reason, note or None
            comment.moderated_by_id, comment.moderated_at = admin_id, vietnam_now()
        elif action_name == "restore":
            comment.is_hidden, comment.moderation_reason, comment.moderation_note = False, reason, note or None
            comment.moderated_by_id, comment.moderated_at = admin_id, vietnam_now()
        else:
            comment.is_deleted, comment.is_hidden, comment.moderation_reason = True, True, reason
            comment.moderation_note, comment.moderated_by_id, comment.moderated_at = note or None, admin_id, vietnam_now()
        if action_name in {"hide", "delete"}:
            CommentReport.query.filter_by(comment_id=comment.id, status="open").update({"status": "resolved", "resolved_at": vietnam_now(), "resolution_action_id": action.id}, synchronize_session=False)
        db.session.commit()
        return {"status": "success", "message": f"Comment {action_name}d successfully.", "comment_id": comment.id}, 200
    except SQLAlchemyError:
        db.session.rollback()
        logger.exception("moderation_comment_%s_failed comment_id=%s", action_name, comment_id)
        return {"status": "error", "message": "Unable to update comment."}, 500


def hide_comment(comment_id: int, admin_id: int, payload: dict[str, Any]) -> tuple[dict[str, Any], int]: return _mutation_comment(comment_id, admin_id, "hide", payload)
def restore_comment(comment_id: int, admin_id: int, payload: dict[str, Any]) -> tuple[dict[str, Any], int]: return _mutation_comment(comment_id, admin_id, "restore", payload)

def delete_comment_permanently(comment_id: int, admin_id: int, payload: dict[str, Any]) -> tuple[dict[str, Any], int]:
    if payload.get("confirmed") is not True:
        return {"status": "error", "message": "Permanent deletion must be confirmed."}, 400
    return _mutation_comment(comment_id, admin_id, "delete", payload)


def dismiss_comment_report(report_id: int, admin_id: int, payload: dict[str, Any]) -> tuple[dict[str, Any], int]:
    reason, note = _reason(payload.get("reason")), _clean(payload.get("note"), MAX_NOTE_LENGTH)
    if not reason: return {"status": "error", "message": "A dismissal reason is required."}, 400
    report = db.session.get(CommentReport, report_id)
    if report is None: return {"status": "error", "message": "Report not found."}, 404
    if report.status != "open": return {"status": "error", "message": "Report is no longer open."}, 409
    try:
        action = _action(report.comment, admin_id, "dismiss_report", reason, note)
        report.status, report.resolved_at, report.resolution_action_id = "dismissed", vietnam_now(), action.id
        db.session.commit()
        return {"status": "success", "message": "Report dismissed."}, 200
    except SQLAlchemyError:
        db.session.rollback()
        return {"status": "error", "message": "Unable to dismiss report."}, 500


def list_prohibited_terms(params: dict[str, Any]) -> dict[str, Any]:
    page, per_page = _page(params.get("page")), _per_page(params.get("per_page"))
    query = CommentProhibitedTerm.query.order_by(CommentProhibitedTerm.created_at.desc(), CommentProhibitedTerm.id.desc())
    total = query.count(); rows = query.offset((page - 1) * per_page).limit(per_page).all()
    return {"items": [{"id": row.id, "term": row.display_term, "category": row.category, "is_active": bool(row.is_active), "created_at": row.created_at.isoformat()} for row in rows], "pagination": {"page": page, "per_page": per_page, "total": total, "total_pages": ceil(total / per_page) if total else 0}}


def create_prohibited_term(admin_id: int, payload: dict[str, Any]) -> tuple[dict[str, Any], int]:
    display, category = _clean(payload.get("term"), MAX_TERM_LENGTH), _clean(payload.get("category"), MAX_CATEGORY_LENGTH)
    normalized = normalize_text(display)
    if not normalized: return {"status": "error", "message": "A prohibited term is required."}, 400
    if CommentProhibitedTerm.query.filter_by(normalized_term=normalized).first(): return {"status": "error", "message": "This prohibited term already exists."}, 409
    try:
        term = CommentProhibitedTerm(display_term=display, normalized_term=normalized, category=category or None, created_by_id=admin_id, updated_by_id=admin_id)
        db.session.add(term); db.session.flush(); _audit(admin_id, "CREATE_PROHIBITED_TERM", "prohibited_term", term.id, "configuration")
        db.session.commit(); return {"status": "success", "data": {"id": term.id, "term": term.display_term, "is_active": True}}, 201
    except SQLAlchemyError:
        db.session.rollback(); return {"status": "error", "message": "Unable to create prohibited term."}, 500


def update_prohibited_term(term_id: int, admin_id: int, payload: dict[str, Any]) -> tuple[dict[str, Any], int]:
    term = db.session.get(CommentProhibitedTerm, term_id)
    if term is None: return {"status": "error", "message": "Prohibited term not found."}, 404
    if not isinstance(payload.get("is_active"), bool): return {"status": "error", "message": "is_active must be a boolean."}, 400
    try:
        term.is_active, term.updated_by_id = payload["is_active"], admin_id
        _audit(admin_id, "UPDATE_PROHIBITED_TERM", "prohibited_term", term.id, "activated" if term.is_active else "deactivated")
        db.session.commit(); return {"status": "success", "data": {"id": term.id, "is_active": term.is_active}}, 200
    except SQLAlchemyError:
        db.session.rollback(); return {"status": "error", "message": "Unable to update prohibited term."}, 500


def delete_prohibited_term(term_id: int, admin_id: int) -> tuple[dict[str, Any], int]:
    term = db.session.get(CommentProhibitedTerm, term_id)
    if term is None: return {"status": "error", "message": "Prohibited term not found."}, 404
    try:
        # Retain blocked-submission history but detach it from the configuration
        # record before removing that record.  This avoids a foreign-key error
        # while making Remove an actual delete rather than a deactivation.
        CommentFilterEvent.query.filter_by(prohibited_term_id=term.id).update(
            {"prohibited_term_id": None}, synchronize_session=False
        )
        _audit(admin_id, "DELETE_PROHIBITED_TERM", "prohibited_term", term.id, "removed")
        db.session.delete(term)
        db.session.commit()
        return {"status": "success", "message": "Prohibited term removed."}, 200
    except SQLAlchemyError:
        db.session.rollback(); return {"status": "error", "message": "Unable to remove prohibited term."}, 500


def get_filter_events(params: dict[str, Any]) -> dict[str, Any]:
    page, per_page = _page(params.get("page")), _per_page(params.get("per_page"))
    query = CommentFilterEvent.query.options(joinedload(CommentFilterEvent.user), joinedload(CommentFilterEvent.article), joinedload(CommentFilterEvent.prohibited_term)).order_by(CommentFilterEvent.created_at.desc())
    total = query.count(); rows = query.offset((page - 1) * per_page).limit(per_page).all()
    return {"items": [{"id": row.id, "outcome": row.outcome, "created_at": row.created_at.isoformat(), "user": {"id": row.user.id, "name": row.user.full_name or row.user.username or row.user.email}, "article": {"id": row.article.id, "title": row.article.title}, "term": {"id": row.prohibited_term.id, "category": row.prohibited_term.category} if row.prohibited_term else None} for row in rows], "pagination": {"page": page, "per_page": per_page, "total": total, "total_pages": ceil(total / per_page) if total else 0}}
