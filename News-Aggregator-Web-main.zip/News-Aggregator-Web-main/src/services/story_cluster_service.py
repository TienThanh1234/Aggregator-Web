"""Local, deterministic story clustering and Trending Score calculation."""
from __future__ import annotations

import json
import math
import re
import unicodedata
from collections import Counter
from datetime import datetime, timedelta

from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import joinedload, load_only

from models import Article, ArticleStoryMembership, ScraperConfig, StoryCluster, db
from services.truth_score_service import ARTICLE_SCORING_COLUMNS, normalize_source_domain
from services.time_service import vietnam_now

WINDOW = timedelta(hours=72)
# A match needs actual topical overlap, not merely one or two generic news words.
# Keep borderline topic overlap (for example, articles that only share
# "Bộ Công an") out of an accepted story cluster.
MIN_MEANINGFUL_SIMILARITY = 0.24
STOP_WORDS = {
    "va", "la", "cua", "cho", "voi", "trong", "tai", "the", "nhung", "mot", "cac", "da", "duoc",
    "ve", "voi", "tu", "den", "o", "tai", "tren", "sau", "khi", "nhung", "cac", "mot", "nhieu",
    "se", "dang", "bi", "duoc", "co", "khong", "theo", "cho", "nay", "do", "va", "la",
    "thong", "tin", "nguoi", "trieu", "hang", "bai", "bao", "viec", "ngay", "moi", "nhat",
    "con", "cung", "tu", "khi", "nhieu", "qua", "lai", "truoc", "sau", "ra", "vao",
}


def normalize_text(value: str | None) -> str:
    text = unicodedata.normalize("NFD", (value or "").casefold())
    text = "".join(character for character in text if not unicodedata.combining(character)).replace("đ", "d")
    text = re.sub(r"[^\w\s]", " ", text, flags=re.UNICODE)
    return " ".join(token for token in text.split() if token not in STOP_WORDS)


def _tokens(value: str | None) -> Counter:
    return Counter(normalize_text(value).split())


def _cosine(left: str | None, right: str | None) -> float:
    a, b = _tokens(left), _tokens(right)
    if not a or not b:
        return 0.0
    dot = sum(a[token] * b[token] for token in a.keys() & b.keys())
    return dot / math.sqrt(sum(x * x for x in a.values()) * sum(x * x for x in b.values()))


def _anchors(article: Article) -> set[str]:
    text = f"{article.title or ''} {article.description or ''}"
    return set(re.findall(r"\b\d+(?:[.,]\d+)?\b|\b[A-ZÀ-Ỹ][\wÀ-ỹ-]+", text))


def _cluster_reference_time(article: Article) -> datetime:
    """Use ingestion time so a newly added article only joins recent clusters."""
    return article.scraped_at or vietnam_now()


def find_recent_clusters(article: Article) -> list[tuple[StoryCluster, Article]]:
    """Return every recent cluster with its canonical article in one query."""
    reference = _cluster_reference_time(article)
    since = reference - WINDOW
    return db.session.query(StoryCluster, Article).join(
        Article, StoryCluster.canonical_article_id == Article.id,
    ).filter(
        StoryCluster.created_at >= since,
        StoryCluster.created_at <= reference,
        StoryCluster.canonical_article_id.is_not(None),
        Article.is_deleted.is_(False),
    ).order_by(StoryCluster.created_at.desc()).all()


def similarity_signals(article: Article, candidate: Article) -> dict:
    if article.content_hash and article.content_hash == candidate.content_hash:
        return {"title": 1.0, "content": 1.0, "entity": 1.0, "time": 1.0, "confidence": 1.0, "exact_hash": True}
    title = _cosine(article.title, candidate.title)
    content = _cosine(article.description or (article.raw_content or '')[:2000], candidate.description or (candidate.raw_content or '')[:2000])
    shared_title_tokens = set(_tokens(article.title)) & set(_tokens(candidate.title))
    first, second = _anchors(article), _anchors(candidate)
    entity = len(first & second) / max(1, len(first | second))
    delta = abs(((article.published_at or article.scraped_at) - (candidate.published_at or candidate.scraped_at)).total_seconds()) / 3600
    time_score = max(0.0, 1 - delta / 72)
    # Time is recorded for diagnostics only. It must not make unrelated articles
    # look similar simply because they were ingested close together.
    raw_confidence = .60 * title + .25 * content + .15 * entity
    has_topic_evidence = (
        len(shared_title_tokens) >= 2
        and (
            title >= 0.25
            or (title >= 0.18 and content >= 0.20)
            or (entity >= 0.30 and content >= 0.15)
        )
    )
    confidence = raw_confidence if has_topic_evidence and raw_confidence >= MIN_MEANINGFUL_SIMILARITY else 0.0
    return {
        "title": round(title, 4), "content": round(content, 4), "entity": round(entity, 4),
        "time": round(time_score, 4), "shared_title_tokens": sorted(shared_title_tokens),
        "confidence": round(confidence, 4), "exact_hash": False,
    }


def _accepted_articles(cluster: StoryCluster) -> list[Article]:
    memberships = ArticleStoryMembership.query.options(
        joinedload(ArticleStoryMembership.article).load_only(*ARTICLE_SCORING_COLUMNS)
    ).filter_by(cluster_id=cluster.id, status="accepted").all()
    return [membership.article for membership in memberships if not membership.article.is_deleted]


def recalculate_cluster(cluster: StoryCluster) -> StoryCluster:
    articles = _accepted_articles(cluster)
    domains = sorted({normalize_source_domain(a.source_url) for a in articles if normalize_source_domain(a.source_url)})
    coverage = 5 if len(domains) == 1 else 15 if len(domains) == 2 else 25 if len(domains) == 3 else 35 if len(domains) >= 4 else 0
    now = vietnam_now()
    latest = max((a.published_at or a.scraped_at for a in articles), default=None)
    velocity = min(30, 5 * sum(1 for a in articles if (now - (a.published_at or a.scraped_at)).total_seconds() <= 21600))
    recency = round(20 * math.exp(-max(0, (now - latest).total_seconds() / 3600) / 18)) if latest else 0
    reliabilities = []
    for domain in domains:
        config = ScraperConfig.query.filter(db.func.lower(ScraperConfig.source_domain) == domain).first()
        reliabilities.append(config.reliability_score if config else 100)
    quality = round((sum(reliabilities) / len(reliabilities) / 100) * 15) if reliabilities else 0
    canonical = min(articles, key=lambda a: (a.published_at or a.scraped_at, a.id)) if articles else None
    cluster.canonical_article_id = canonical.id if canonical else None
    cluster.accepted_article_count, cluster.independent_domain_count = len(articles), len(domains)
    cluster.source_coverage_score, cluster.velocity_score, cluster.recency_score, cluster.source_quality_score = coverage, velocity, recency, quality
    cluster.trending_score, cluster.last_covered_at, cluster.score_updated_at = min(100, coverage + velocity + recency + quality), latest, now
    for article in articles:
        article.primary_article_id = None if article.id == cluster.canonical_article_id else cluster.canonical_article_id
    return cluster


def assign_article_to_cluster(article: Article) -> StoryCluster:
    """Join the best recent cluster above the threshold, otherwise create one."""
    existing_article_membership = ArticleStoryMembership.query.filter_by(article_id=article.id).first()
    if existing_article_membership:
        if existing_article_membership.status == "accepted":
            recalculate_cluster(existing_article_membership.cluster)
        return existing_article_membership.cluster

    best_cluster, best = None, None
    for cluster, canonical in find_recent_clusters(article):
        signals = similarity_signals(article, canonical)
        if best is None or signals["confidence"] > best["confidence"]:
            best_cluster, best = cluster, signals
    created_cluster = False
    if best_cluster and best and best["confidence"] > 0:
        cluster, status = best_cluster, "accepted"
    else:
        cluster, status = StoryCluster(created_at=_cluster_reference_time(article)), "accepted"
        created_cluster = True
        db.session.add(cluster)
        db.session.flush()
    match_signals = best or {"new_cluster": True, "confidence": 0.0}
    membership = ArticleStoryMembership(article_id=article.id, cluster_id=cluster.id, match_confidence=match_signals["confidence"], status=status, match_signals_json=json.dumps(match_signals))
    try:
        with db.session.begin_nested():
            db.session.add(membership)
            db.session.flush()
    except IntegrityError:
        if created_cluster:
            db.session.delete(cluster)
            db.session.flush()
        concurrent_membership = ArticleStoryMembership.query.filter_by(article_id=article.id).first()
        if concurrent_membership:
            return concurrent_membership.cluster
        raise
    if status == "accepted":
        recalculate_cluster(cluster)
    return cluster


def reset_story_clusters() -> dict:
    """Remove only derived Story Cluster data, preserving all articles."""
    db.session.query(Article).update({Article.primary_article_id: None}, synchronize_session=False)
    memberships = db.session.query(ArticleStoryMembership).delete(synchronize_session=False)
    clusters = db.session.query(StoryCluster).delete(synchronize_session=False)
    db.session.commit()
    return {"deleted_memberships": memberships, "deleted_clusters": clusters}


def backfill_story_clusters(batch_size: int = 200) -> dict:
    ids = [row[0] for row in Article.query.filter(
        Article.is_deleted.is_(False),
        ~Article.story_membership.has(),
    ).with_entities(Article.id).order_by(Article.scraped_at.asc(), Article.id.asc()).all()]
    result = {"scanned": len(ids), "clustered": 0}
    for article_id in ids:
        assign_article_to_cluster(db.session.get(Article, article_id)); result["clustered"] += 1
        if result["clustered"] % max(1, batch_size) == 0: db.session.commit()
    db.session.commit(); return result
