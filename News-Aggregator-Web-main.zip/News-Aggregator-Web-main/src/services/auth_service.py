"""
Authentication Service Module — Business Logic Layer

Provides registration, login, logout, and session management functions.
Route handlers in routes.py delegate to this service to keep controllers thin
per constitution.md Principle II (Strict MVC Pattern Enforcement).

All database operations are wrapped in try/except with db.session.rollback()
on failure. Structured logging follows constitution.md Principle VI.
"""

import hashlib
import hmac
import logging
import re
import secrets
from datetime import datetime, timedelta
from typing import Optional

from flask import session
from sqlalchemy.exc import IntegrityError, SQLAlchemyError

from models import db, User
from services.email_service import send_password_reset_email
from services.time_service import vietnam_now

logger = logging.getLogger(__name__)

# ── VALIDATION PATTERNS ──
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$')
PASSWORD_REGEX = re.compile(r'^(?=.*[A-Za-z])(?=.*\d).{8,}$')

# ── ROLE → REDIRECT MAPPING ──
ROLE_REDIRECT_MAP: dict[str, str] = {
    "guest": "/",
    "user": "/dashboard/user",
    "admin": "/dashboard/admin",
}
PASSWORD_RESET_TTL_MINUTES = 30
PASSWORD_RESET_REQUEST_MESSAGE = "If an active account matches this email, a password-reset link has been sent."
PASSWORD_RESET_INVALID_MESSAGE = "This password-reset link is invalid or has expired."


def serialize_user(user: User) -> dict:
    """Serialize a User model instance to a JSON-safe dictionary.

    Never includes password_hash in output.

    Args:
        user: The User ORM instance to serialize.

    Returns:
        Dictionary with user profile fields.
    """
    return {
        "id": user.id,
        "username": user.username,
        "email": user.email,
        "full_name": user.full_name,
        "role": user.role,
        "is_active": user.is_active,
    }


def register_user(
    username: str,
    email: str,
    password: str,
    full_name: Optional[str] = None,
) -> tuple[dict, int]:
    """Register a new user account.

    Validates input fields, checks for duplicates, hashes the password,
    and persists the new User record to the database.

    Args:
        username: Desired unique username.
        email: User email address.
        password: Plaintext password (will be hashed).
        full_name: Optional display name.

    Returns:
        Tuple of (response_dict, http_status_code).
    """
    # ── Input validation ──
    if not username:
        return {"status": "error", "message": "Username is required."}, 400

    if not email:
        return {"status": "error", "message": "Email is required."}, 400

    if not password:
        return {"status": "error", "message": "Password is required."}, 400

    if not EMAIL_REGEX.match(email):
        return {
            "status": "error",
            "message": "Invalid email format. Please provide a valid email address.",
        }, 400

    if not PASSWORD_REGEX.match(password):
        return {
            "status": "error",
            "message": "Password must be at least 8 characters and contain at least one letter and one number.",
        }, 400

    # ── Duplicate check ──
    existing_email = User.query.filter(
        db.func.lower(User.email) == email.lower()
    ).first()
    if existing_email:
        logger.warning(
            "[AUTH][FAIL] Registration rejected — duplicate: email=%s", email
        )
        return {
            "status": "error",
            "message": "Email or username already registered.",
        }, 400

    existing_username = User.query.filter(
        db.func.lower(User.username) == username.lower()
    ).first()
    if existing_username:
        logger.warning(
            "[AUTH][FAIL] Registration rejected — duplicate: username=%s", username
        )
        return {
            "status": "error",
            "message": "Email or username already registered.",
        }, 400

    # ── Create user ──
    try:
        new_user = User(
            username=username,
            email=email.lower(),
            full_name=full_name,
            role="user",
            is_active=True,
        )
        new_user.set_password(password)
        db.session.add(new_user)
        db.session.commit()

        logger.info(
            "[AUTH][SUCCESS] User registered: %s (%s)", username, email
        )

        return {
            "status": "success",
            "message": "Account created successfully.",
            "user": serialize_user(new_user),
        }, 201

    except IntegrityError as exc:
        db.session.rollback()
        logger.warning(
            "[AUTH][FAIL] Registration integrity error for %s: %s",
            username,
            exc,
        )
        return {
            "status": "error",
            "message": "Email or username already registered.",
        }, 400

    except SQLAlchemyError as exc:
        db.session.rollback()
        logger.error(
            "[AUTH][ERROR] Database error during registration: %s",
            exc,
            exc_info=True,
        )
        return {
            "status": "error",
            "message": "An internal error occurred. Please try again later.",
        }, 500


def login_user(identity: str, password: str) -> tuple[dict, int]:
    """Authenticate user credentials and establish a Flask session.

    Queries the User by username OR email (case-insensitive).
    On success, populates the Flask session with user_id and role,
    and returns a role-based redirect URL.

    Args:
        identity: Username or email address.
        password: Plaintext password to verify.

    Returns:
        Tuple of (response_dict, http_status_code).
    """
    GENERIC_ERROR = "Invalid username/email or password."

    if not identity or not password:
        return {"status": "error", "message": GENERIC_ERROR}, 401

    try:
        # Query by username OR email (case-insensitive)
        user = User.query.filter(
            db.or_(
                db.func.lower(User.username) == identity.lower(),
                db.func.lower(User.email) == identity.lower(),
            )
        ).first()

        # Verify user exists, password matches, and account is active
        if user is None:
            logger.info(
                "[AUTH][FAIL] Login failed for identity: %s (reason: user not found)",
                identity,
            )
            return {"status": "error", "message": GENERIC_ERROR}, 401

        if not user.check_password(password):
            logger.info(
                "[AUTH][FAIL] Login failed for identity: %s (reason: wrong password)",
                identity,
            )
            return {"status": "error", "message": GENERIC_ERROR}, 401

        if not user.is_active:
            logger.info(
                "[AUTH][FAIL] Login failed for identity: %s (reason: account inactive)",
                identity,
            )
            return {"status": "error", "message": GENERIC_ERROR}, 401

        # ── Success: update last_login and populate session ──
        user.last_login = vietnam_now()
        db.session.commit()

        session["user_id"] = user.id
        session["role"] = user.role
        session["session_version"] = user.session_version

        redirect_url = ROLE_REDIRECT_MAP.get(user.role, "/")

        logger.info(
            "[AUTH][SUCCESS] User logged in: %s (role: %s)",
            user.username,
            user.role,
        )

        return {
            "status": "success",
            "message": "Login successful.",
            "redirect_url": redirect_url,
            "user": serialize_user(user),
        }, 200

    except SQLAlchemyError as exc:
        db.session.rollback()
        logger.error(
            "[AUTH][ERROR] Database error during login: %s",
            exc,
            exc_info=True,
        )
        return {
            "status": "error",
            "message": "An internal error occurred. Please try again later.",
        }, 500


def request_password_reset(email: str) -> tuple[dict, int]:
    """Request a password reset without disclosing account existence.

    A raw token is only passed to the email delivery helper. Its SHA-256 digest
    is persisted so a database exposure cannot be used to reset an account.
    """
    response = {"status": "success", "message": PASSWORD_RESET_REQUEST_MESSAGE}
    if not email or not EMAIL_REGEX.match(email):
        return response, 202

    try:
        user = User.query.filter(db.func.lower(User.email) == email.lower()).first()
        if user is None or not user.is_active:
            logger.info("[AUTH][SUCCESS] Password reset request processed")
            return response, 202

        token = secrets.token_urlsafe(32)
        user.password_reset_token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
        user.password_reset_expires_at = vietnam_now() + timedelta(minutes=PASSWORD_RESET_TTL_MINUTES)
        db.session.commit()
        send_password_reset_email(user.email, token)
        logger.info("[AUTH][SUCCESS] Password reset request processed")
    except SQLAlchemyError as exc:
        db.session.rollback()
        logger.error("[AUTH][ERROR] Database error during password reset request: %s", exc, exc_info=True)
    except Exception as exc:
        db.session.rollback()
        logger.error("[AUTH][ERROR] Password reset request failed: %s", type(exc).__name__, exc_info=True)
    return response, 202


def confirm_password_reset(token: str, password: str) -> tuple[dict, int]:
    """Validate a single-use reset token and replace the user's password."""
    if not token or not password or not PASSWORD_REGEX.match(password):
        return {"status": "error", "message": PASSWORD_RESET_INVALID_MESSAGE}, 400

    token_hash = hashlib.sha256(token.encode("utf-8")).hexdigest()
    try:
        user = User.query.filter(User.password_reset_token_hash == token_hash).first()
        is_valid = (
            user is not None
            and user.password_reset_expires_at is not None
            and user.password_reset_expires_at >= vietnam_now()
            and hmac.compare_digest(user.password_reset_token_hash, token_hash)
        )
        if not is_valid:
            return {"status": "error", "message": PASSWORD_RESET_INVALID_MESSAGE}, 400

        user.set_password(password)
        user.password_reset_token_hash = None
        user.password_reset_expires_at = None
        user.session_version += 1
        db.session.commit()
        logger.info("[AUTH][SUCCESS] Password reset completed")
        return {
            "status": "success",
            "message": "Password reset successfully. Please sign in.",
        }, 200
    except SQLAlchemyError as exc:
        db.session.rollback()
        logger.error("[AUTH][ERROR] Database error during password reset confirmation: %s", exc, exc_info=True)
        return {"status": "error", "message": PASSWORD_RESET_INVALID_MESSAGE}, 400


def logout_user() -> tuple[dict, int]:
    """Invalidate the current Flask server session.

    Clears all session data including user_id and role keys.

    Returns:
        Tuple of (response_dict, http_status_code).
    """
    user_id = session.get("user_id")
    username = user_id or "unknown"

    # Attempt to log the username for audit trail
    try:
        if user_id:
            user = db.session.get(User, user_id)
            if user:
                username = user.username
    except SQLAlchemyError:
        pass  # Non-critical — proceed with logout regardless

    if user_id:
        try:
            from services.search_service import clear_user_search_history

            clear_user_search_history(user_id)
        except SQLAlchemyError:
            db.session.rollback()
            logger.warning(
                "[AUTH][WARNING] Could not clear search history during logout: user_id=%s",
                user_id,
                exc_info=True,
            )

    session.clear()

    logger.info("[AUTH][SUCCESS] User logged out: %s", username)

    return {
        "status": "success",
        "message": "Session invalidated successfully.",
        "redirect_url": "/",
    }, 200


def get_current_user() -> tuple[dict, int]:
    """Retrieve the currently authenticated user from the Flask session.

    Reads session['user_id'] and queries the database for the user profile.
    If no session exists or the user is not found/inactive, returns
    authenticated: false.

    Returns:
        Tuple of (response_dict, http_status_code).
    """
    user_id = session.get("user_id")

    if not user_id:
        return {"authenticated": False}, 200

    try:
        user = db.session.get(User, user_id)

        if (
            user is None
            or not user.is_active
            or session.get("session_version") != user.session_version
        ):
            # Session references a deleted or deactivated user — clear it
            session.clear()
            return {"authenticated": False}, 200

        return {
            "authenticated": True,
            "user": serialize_user(user),
        }, 200

    except SQLAlchemyError as exc:
        logger.error(
            "[AUTH][ERROR] Database error during session check: %s",
            exc,
            exc_info=True,
        )
        return {"authenticated": False}, 200
