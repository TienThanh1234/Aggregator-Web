"""Article query and presentation helpers for HTML pages and compatibility APIs."""

from __future__ import annotations

import json
import logging
import urllib.parse
from typing import Any

from sqlalchemy import case, inspect, or_

from models import Article, ArticleStoryMembership, Category, StoryCluster, User, db

logger = logging.getLogger(__name__)

DEFAULT_CATEGORY = "General"
ALL_DISPATCHES = "All Dispatches"

CATEGORY_MAP = {
    "Kinh doanh": "Economy",
    "Vĩ mô": "Economy",
    "Tài chính": "Economy",
    "Số hóa": "Technology",
    "Công nghệ": "Technology",
    "Khoa học công nghệ": "Technology",
    "Thời sự": "Politics",
    "Thế giới": "Politics",
    "Pháp luật": "Politics",
    "Khoa học": "Science",
    "Vũ trụ": "Science",
}

CATEGORY_ICONS = {
    ALL_DISPATCHES: "compass",
    "Economy": "bar-chart-2",
    "Technology": "cpu",
    "Politics": "landmark",
    "Science": "flask-conical",
}

DEFAULT_TAKEAWAYS = [
    "Scientific breakthrough expands human knowledge of the field.",
    "Tech validation process ensures safe long-term scaling.",
    "Additional expert analysis is pending on secondary parameters.",
]


def _map_category(raw_category: str | None) -> str:
    """Map a stored category to the public display category."""
    if not raw_category:
        return DEFAULT_CATEGORY
    return CATEGORY_MAP.get(raw_category, raw_category)


def _proxy_image_url(cover_image_url: str | None) -> str:
    """Return the safe internal URL used to render an article image."""
    if cover_image_url and cover_image_url.startswith(("http://", "https://")):
        quoted = urllib.parse.quote(cover_image_url, safe="")
        return f"/api/image-proxy?url={quoted}"
    return "/api/image-proxy?default=1"


def _parse_ai_metadata(ai_summary: str | None) -> dict[str, Any]:
    """Parse optional JSON metadata, logging malformed stored values."""
    if not ai_summary:
        return {}
    try:
        parsed = json.loads(ai_summary)
    except (TypeError, ValueError) as exc:
        logger.warning("Failed to parse article AI metadata: %s", exc)
        return {}
    if not isinstance(parsed, dict):
        logger.warning("Article AI metadata is not a JSON object")
        return {}
    return parsed


def _split_paragraphs(raw_content: str | None, description: str | None) -> list[str]:
    """Split stored article text into non-empty presentation paragraphs."""
    paragraphs = [
        paragraph.strip()
        for paragraph in (raw_content or "").split("\n\n")
        if paragraph.strip()
    ]
    return paragraphs or [description or "No content available."]


def _content_blocks(article: Article) -> list[dict[str, str]]:
    """Return validated ordered reader blocks, falling back for older articles."""
    try:
        blocks = json.loads(article.content_blocks_json or "[]")
    except (TypeError, ValueError) as exc:
        logger.warning("Failed to parse article content blocks: %s", exc)
        blocks = []
    if not isinstance(blocks, list):
        blocks = []

    valid_blocks = []
    for block in blocks:
        if not isinstance(block, dict) or block.get("type") not in {"paragraph", "image"}:
            continue
        if block["type"] == "paragraph" and isinstance(block.get("text"), str) and block["text"].strip():
            valid_blocks.append({"type": "paragraph", "text": block["text"].strip()})
        elif block["type"] == "image" and isinstance(block.get("url"), str) and block["url"].startswith(("http://", "https://")):
            valid_blocks.append({
                "type": "image", "url": _proxy_image_url(block["url"]),
                "alt": str(block.get("alt") or "Article image"),
                "caption": str(block.get("caption") or ""),
            })
    return valid_blocks or [{"type": "paragraph", "text": text} for text in _split_paragraphs(article.raw_content, article.description)]


def _article_category(article: Article) -> str:
    raw_category = article.categories[0].name if article.categories else None
    return _map_category(raw_category)


def _published_label(article: Article) -> str:
    timestamp = article.published_at or article.scraped_at
    return timestamp.strftime("%d/%m/%Y %H:%M") if timestamp else ""


def _base_presentation(article: Article) -> tuple[dict[str, Any], dict[str, Any]]:
    ai_meta = _parse_ai_metadata(article.ai_summary)
    # Feed and recommendation queries defer this large column.  Do not cause
    # another query solely to calculate a non-essential read-time label.
    raw_content = "" if "raw_content" in inspect(article).unloaded else article.raw_content or ""
    
    domain = ""
    if article.source_url:
        from urllib.parse import urlparse
        domain = urlparse(article.source_url).netloc.replace("www.", "").split(".")[0].capitalize()
        
    author = ai_meta.get("author")
    if not author or str(author).lower() in ["unknown", "none", "", "null"]:
        author = f"{domain} Reporter" if domain else "Reporter"
        
    membership = article.story_membership
    cluster = (
        membership.cluster
        if membership and membership.status == "accepted"
        else None
    )
    story_cluster = None
    if cluster and cluster.accepted_article_count > 1:
        story_cluster = {
            "id": cluster.id,
            "article_count": cluster.accepted_article_count,
            "source_count": cluster.independent_domain_count,
            "trending_score": cluster.trending_score,
        }

    presentation = {
        "id": article.id,
        "title": article.title,
        "category": _article_category(article),
        "categories": [_map_category(c.name) for c in article.categories] if article.categories else ["General"],
        "author": author,
        "date": _published_label(article),
        "source_url": article.source_url,
        "read_time": ai_meta.get(
            "readTime", f"{max(1, len(raw_content) // 1000)} min read"
        ),
        "image": _proxy_image_url(article.cover_image_url),
        "image_alt": article.title,
        "summary": article.description or "",
        # Legacy records stored this as a 0–1 fraction; Truth Score v1 stores
        # the actual 0–100 value. Never invent a value when it is unavailable.
        "confidence_score": (
            max(
                0,
                min(
                    100,
                    int(article.truth_score * 100)
                    if article.truth_score <= 1
                    else int(article.truth_score),
                ),
            )
            if article.truth_score is not None
            else None
        ),
        "canonical_path": f"/articles/{article.id}",
        "story_cluster": story_cluster,
        "interaction_counts": {
            "likes": sum(1 for reaction in article.reactions if reaction.reaction_type == "like"),
            "dislikes": sum(1 for reaction in article.reactions if reaction.reaction_type == "dislike"),
            "comments": sum(1 for comment in article.comments if not comment.is_deleted),
        },
    }
    return presentation, ai_meta


def _feed_presentation(article: Article) -> dict[str, Any]:
    presentation, _ = _base_presentation(article)
    return presentation


def get_article_card_presentation(article: Article) -> dict[str, Any]:
    """Return the public card fields shared by feed and search results."""
    return _feed_presentation(article)


def _detail_presentation(article: Article) -> dict[str, Any]:
    presentation, ai_meta = _base_presentation(article)
    content_blocks = _content_blocks(article)
    # The first in-article image is already shown as the cover/thumbnail. Do
    # not render it again inline, while preserving every later figure's order.
    inline_content_blocks = []
    cover_image_removed = False
    for block in content_blocks:
        if block["type"] == "image" and not cover_image_removed:
            cover_image_removed = True
            continue
        inline_content_blocks.append(block)
    presentation.update(
        {
            "paragraphs": _split_paragraphs(
                article.raw_content, article.description
            ),
            "content_blocks": content_blocks,
            "inline_content_blocks": inline_content_blocks,
            "key_takeaways": ai_meta.get("keyTakeaways", DEFAULT_TAKEAWAYS),
            "unverified_claim": ai_meta.get("unverifiedClaim", ""),
            "unverified_claim_analysis": ai_meta.get(
                "unverifiedClaimAnalysis", ""
            ),
        }
    )
    return presentation


def _ordered_query():
    return Article.query.filter(Article.is_deleted.is_(False)).order_by(
        Article.published_at.desc().nullslast(),
        Article.scraped_at.desc(),
    )


def _raw_categories_for(display_category: str) -> set[str]:
    raw_names = {
        raw_name
        for raw_name, public_name in CATEGORY_MAP.items()
        if public_name == display_category
    }
    raw_names.add(display_category)
    return raw_names


def get_feed_articles(
    category: str | None = None,
    page: int = 1,
    per_page: int = 20,
    user_id: int | None = None,
) -> tuple[list[dict[str, Any]], int, int]:
    """Return paginated feed cards, accounting for the full-width lead card."""
    safe_page = max(1, page)
    safe_per_page = max(1, min(per_page, 100))
    query = _ordered_query()

    if category and category != ALL_DISPATCHES:
        if category == DEFAULT_CATEGORY:
            query = query.filter(~Article.categories.any())
        else:
            query = query.filter(
                Article.categories.any(
                    Category.name.in_(_raw_categories_for(category))
                )
            )
    elif user_id:
        user = db.session.get(User, user_id)
        if user and (user.subscribed_categories or user.subscribed_sources):
            preferred = []
            if user.subscribed_categories:
                preferred.append(Article.categories.any(Category.id.in_([c.id for c in user.subscribed_categories])))
            if user.subscribed_sources:
                preferred.extend(Article.source_url.ilike(f"%{source.source_domain}%") for source in user.subscribed_sources)
            if preferred:
                query = query.order_by(None).order_by(
                    case((or_(*preferred), 0), else_=1),
                    Article.published_at.desc().nullslast(),
                    Article.scraped_at.desc(),
                )

    has_lead_card = not category or category == ALL_DISPATCHES
    first_page_size = safe_per_page + 1 if has_lead_card else safe_per_page
    total_items = query.count()

    if has_lead_card:
        remaining_items = max(0, total_items - first_page_size)
        total_pages = 1 + (
            (remaining_items + safe_per_page - 1) // safe_per_page
            if remaining_items
            else 0
        )
        offset = (
            0
            if safe_page == 1
            else first_page_size + (safe_page - 2) * safe_per_page
        )
        page_size = first_page_size if safe_page == 1 else safe_per_page
    else:
        total_pages = max(
            1,
            (total_items + safe_per_page - 1) // safe_per_page,
        )
        offset = (safe_page - 1) * safe_per_page
        page_size = safe_per_page

    articles = query.offset(offset).limit(page_size).all()
    return (
        [_feed_presentation(article) for article in articles],
        total_pages,
        safe_page,
    )


def get_article_detail(article_id: int) -> dict[str, Any] | None:
    """Return a complete article presentation or ``None`` when missing or soft-deleted."""
    article = Article.query.filter_by(id=article_id, is_deleted=False).first()
    return _detail_presentation(article) if article else None


def get_story_cluster_detail(cluster_id: int) -> dict[str, Any] | None:
    """Return the accepted, active articles belonging to a public story cluster."""
    cluster = db.session.get(StoryCluster, cluster_id)
    if not cluster:
        return None
    articles = (
        Article.query.join(
            ArticleStoryMembership,
            ArticleStoryMembership.article_id == Article.id,
        )
        .filter(
            ArticleStoryMembership.cluster_id == cluster.id,
            ArticleStoryMembership.status == "accepted",
            Article.is_deleted.is_(False),
        )
        .order_by(
            case((Article.id == cluster.canonical_article_id, 0), else_=1),
            Article.published_at.desc().nullslast(),
            Article.scraped_at.desc(),
        )
        .all()
    )
    if not articles:
        return None
    return {
        "id": cluster.id,
        "title": articles[0].title,
        "article_count": len(articles),
        "source_count": cluster.independent_domain_count,
        "trending_score": cluster.trending_score,
        "articles": [_feed_presentation(article) for article in articles],
    }


def get_categories() -> list[dict[str, str]]:
    """Return present public categories in the preferred navigation order."""
    present = {
        _map_category(category.name)
        for category in Category.query.order_by(Category.name.asc()).all()
        if category.articles.filter(Article.is_deleted.is_(False)).count() > 0
    }
    ordered_names = [
        name
        for name in CATEGORY_ICONS
        if name == ALL_DISPATCHES or name in present
    ]
    ordered_names.extend(sorted(present.difference(ordered_names)))
    return [
        {"name": name, "icon": CATEGORY_ICONS.get(name, "tag")}
        for name in ordered_names
    ]


def get_trending_articles(limit: int = 5) -> list[dict[str, Any]]:
    """Return the highest-confidence articles for the feed sidebar."""
    safe_limit = max(0, min(limit, 20))
    articles = (
        Article.query.filter(Article.is_deleted.is_(False))
        .order_by(
            Article.truth_score.desc().nullslast(),
            Article.published_at.desc().nullslast(),
            Article.scraped_at.desc(),
        )
        .limit(safe_limit)
        .all()
    )
    return [_feed_presentation(article) for article in articles]


def get_all_articles_legacy() -> list[dict[str, Any]]:
    """Return the legacy JSON representation expected by existing clients."""
    serialized: list[dict[str, Any]] = []
    for article in _ordered_query().all():
        detail = _detail_presentation(article)
        serialized.append(
            {
                "id": str(detail["id"]),
                "title": detail["title"],
                "category": detail["category"],
                "author": detail["author"],
                "date": detail["date"],
                "readTime": detail["read_time"],
                "image": detail["image"],
                "imageAlt": detail["image_alt"],
                "summary": detail["summary"],
                "confidenceScore": detail["confidence_score"],
                "unverifiedClaim": detail["unverified_claim"],
                "unverifiedClaimAnalysis": detail[
                    "unverified_claim_analysis"
                ],
                "paragraphs": detail["paragraphs"],
                "keyTakeaways": detail["key_takeaways"],
            }
        )
    return serialized
