import re
from typing import List
from models import Category, KeywordRule

class ClassificationService:
    """Service responsible for mapping textual content to Categories based on KeywordRules."""

    @classmethod
    def classify(cls, title: str, description: str, tags: List[str] = None) -> List[Category]:
        """
        Classifies an article into Categories based on keyword mappings.
        
        Args:
            title: The title of the article.
            description: The description or snippet of the article.
            tags: A list of tags or breadcrumbs associated with the article.
            
        Returns:
            A list of Category objects that matched. If no match is found,
            an empty list is returned.
        """
        text_to_search = (title or "") + " " + (description or "")
        if tags:
            text_to_search += " " + " ".join(tags)
            
        text_to_search = text_to_search.lower()
        
        # Fetch active keyword rules and pre-load categories
        rules = KeywordRule.query.filter_by(is_active=True).join(Category).all()
        
        matched_categories = {}
        for rule in rules:
            # We use a simple word boundary regex to avoid partial matches
            # e.g., matching "art" inside "smart"
            keyword = rule.keyword.lower()
            pattern = r'\b' + re.escape(keyword) + r'\b'
            if re.search(pattern, text_to_search):
                matched_categories[rule.category.id] = rule.category
                
        # If we have no matches, we return the "General" category
        if not matched_categories:
            misc_cat = Category.query.filter_by(name="General").first()
            if misc_cat:
                matched_categories[misc_cat.id] = misc_cat
                
        return list(matched_categories.values())
