"""Article discussion and reaction operations."""
from markupsafe import escape
from models import Article, Comment, Reaction, db
from services.moderation_service import (
    evaluate_prohibited_terms,
    public_comment_filter,
    record_filter_event,
)

def create_comment(user_id, article_id, content):
    content = content.strip() if isinstance(content, str) else ""
    if not 1 <= len(content) <= 2000: return {"status":"error", "message":"Comment must be between 1 and 2000 characters."}, 400
    if not Article.query.filter_by(id=article_id, is_deleted=False).first(): return {"status":"error", "message":"Article not found."}, 404
    prohibited_term = evaluate_prohibited_terms(content)
    if prohibited_term:
        try:
            record_filter_event(user_id, article_id, prohibited_term.id)
        except Exception:
            db.session.rollback()
            return {"status":"error", "message":"Unable to review this comment. Please try again."}, 500
        return {"status":"error", "message":"Your comment could not be posted because it violates community guidelines."}, 400
    item = Comment(user_id=user_id, article_id=article_id, content=str(escape(content)))
    db.session.add(item); db.session.commit()
    return {"status":"success", "comment":{"id":item.id, "content":item.content, "created_at":item.created_at.isoformat()}}, 201

def get_article_comments(article_id, page=1, per_page=20):
    query = Comment.query.filter(Comment.article_id == article_id, *public_comment_filter()).order_by(Comment.created_at.desc())
    try: page=max(1,int(page)); per_page=max(1,min(int(per_page),100))
    except (TypeError, ValueError): page,per_page=1,20
    total=query.count(); rows=query.offset((page-1)*per_page).limit(per_page).all()
    return {"items":[{"id":c.id,"content":c.content,"created_at":c.created_at.isoformat(),"author":{"id":c.user.id,"username":c.user.username,"full_name":c.user.full_name,"avatar_url":c.user.avatar_url}} for c in rows],"page":page,"total":total,"has_more":page*per_page<total}

def get_reaction_summary(article_id, user_id=None):
    reactions = Reaction.query.filter_by(article_id=article_id)
    item = reactions.filter_by(user_id=user_id).first() if user_id else None
    return {
        "count": reactions.count(),
        "like_count": reactions.filter_by(reaction_type="like").count(),
        "dislike_count": reactions.filter_by(reaction_type="dislike").count(),
        "user_reacted": bool(item),
        "user_reaction_type": item.reaction_type if item else None,
    }

def toggle_reaction(user_id, article_id, reaction_type="like"):
    if reaction_type not in {"like", "dislike"}: return {"status":"error", "message":"Unsupported reaction type."}, 400
    if not Article.query.filter_by(id=article_id, is_deleted=False).first(): return {"status":"error", "message":"Article not found."}, 404
    item=Reaction.query.filter_by(user_id=user_id, article_id=article_id).first()
    if item and item.reaction_type == reaction_type:
        db.session.delete(item); action="removed"
    elif item:
        item.reaction_type = reaction_type; action="updated"
    else:
        db.session.add(Reaction(user_id=user_id, article_id=article_id, reaction_type=reaction_type)); action="created"
    db.session.commit(); return {"status":"success", "action":action, **get_reaction_summary(article_id,user_id)}, 200
