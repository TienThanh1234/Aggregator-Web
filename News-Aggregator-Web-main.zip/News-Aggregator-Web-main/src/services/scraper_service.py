"""
Scraper Service Layer

Handles business logic for duplicate prevention, data validation, and persistence.
Orchestrates communication between scraper modules and database models.
"""

import hashlib
import logging
import re
from datetime import datetime, timedelta
from typing import List, Dict, Any, Tuple

from sqlalchemy.exc import SQLAlchemyError, IntegrityError

from models import db, RawArticle, Article, Category
from services.classification_service import ClassificationService
from services.truth_score_service import persist_fallback_score, score_article
from services.story_cluster_service import assign_article_to_cluster
from services.time_service import vietnam_now

logger = logging.getLogger(__name__)


def compute_content_hash(text: str | None) -> str | None:
    if not text or not text.strip():
        return None
    normalized = " ".join(text.lower().split())
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest()


def compute_title_fingerprint(title: str | None) -> str | None:
    if not title or not title.strip():
        return None
    clean = re.sub(r"[^\w\s]", "", title.lower())
    words = sorted(set(clean.split()))
    return "-".join(words)[:128]


class ScraperService:
    """
    Service for scraping pipeline orchestration and persistence.

    Responsibilities:
    - Check for duplicate articles by source_url
    - Persist raw scraped data to RawArticle staging table
    - Transform and promote RawArticle to Article with categories
    - Handle database transactions safely with rollback on failure
    """

    @staticmethod
    def article_exists(source_url: str) -> bool:
        """
        Check if an article with the given source_url already exists.

        Args:
            source_url: URL to check for duplicate

        Returns:
            True if article exists, False otherwise
        """
        try:
            existing = Article.query.filter_by(source_url=source_url).first()
            return existing is not None
        except SQLAlchemyError as exc:
            logger.error(
                "[ERROR] Database query failed checking duplicate: %s",
                exc,
            )
            return False

    @staticmethod
    def raw_article_exists(source_url: str) -> bool:
        """
        Check if a raw article with the given source_url already exists in staging.

        Args:
            source_url: URL to check for duplicate

        Returns:
            True if raw article exists, False otherwise
        """
        try:
            existing = RawArticle.query.filter_by(source_url=source_url).first()
            return existing is not None
        except SQLAlchemyError as exc:
            logger.error(
                "[ERROR] Database query failed checking raw article duplicate: %s",
                exc,
            )
            return False

    @staticmethod
    def save_raw_article(article_data: Dict[str, Any]) -> Tuple[bool, str]:
        """
        Persist raw article data to the staging table.

        Args:
            article_data: Raw scraped article dictionary

        Returns:
            Tuple of (success: bool, message: str)
        """
        try:
            source_url = article_data.get("source_url", "")

            # Check for duplicate in final articles table
            if ScraperService.article_exists(source_url):
                logger.info(
                    "[SKIP] Article already exists in articles table: %s",
                    source_url,
                )
                return False, "DUPLICATE"

            # Check for duplicate in raw_articles staging table
            if ScraperService.raw_article_exists(source_url):
                logger.info(
                    "[SKIP] Article already exists in raw_articles table: %s",
                    source_url,
                )
                return False, "DUPLICATE"

            # Create RawArticle record
            raw_article = RawArticle(
                source_url=article_data.get("source_url"),
                source_name=article_data.get("source_name"),
                title=article_data.get("title"),
                description=article_data.get("description"),
                raw_content=article_data.get("raw_content"),
                content_blocks_json=article_data.get("content_blocks_json"),
                raw_html=article_data.get("raw_html"),
                cover_image_url=article_data.get("cover_image_url"),
                published_at=article_data.get("published_at"),
                status="pending",
            )

            db.session.add(raw_article)
            db.session.commit()

            logger.info(
                "[SUCCESS] Saved raw article: %s",
                article_data.get("source_url"),
            )
            return True, f"CREATED:raw_article:{raw_article.id}"

        except IntegrityError as exc:
            db.session.rollback()
            logger.warning(
                "[SKIP] Article constraint violation (likely duplicate): %s",
                exc,
            )
            return False, "DUPLICATE"

        except SQLAlchemyError as exc:
            db.session.rollback()
            logger.error(
                "[ERROR] Failed to save raw article: %s",
                exc,
            )
            return False, f"DB_ERROR:{str(exc)}"

    @staticmethod
    def process_raw_article(
        raw_article_id: int,
        categories: List[str] = None,
    ) -> Tuple[bool, str]:
        """
        Transform a raw article from staging table to final Article table.

        Process:
        1. Fetch RawArticle record
        2. Validate data
        3. Create Article record
        4. Link categories
        5. Mark RawArticle as processed

        Args:
            raw_article_id: ID of RawArticle to process
            categories: List of category names to associate (optional)

        Returns:
            Tuple of (success: bool, message: str)
        """
        try:
            raw_article = RawArticle.query.get(raw_article_id)
            if not raw_article:
                logger.error(
                    "[ERROR] RawArticle not found: %d",
                    raw_article_id,
                )
                return False, f"NOT_FOUND"

            # Check again for duplicates in final table
            if ScraperService.article_exists(raw_article.source_url):
                raw_article.status = "skipped"
                raw_article.error_message = "Duplicate in final articles table"
                db.session.commit()
                logger.info(
                    "[SKIP] Article exists in final table: %s",
                    raw_article.source_url,
                )
                return False, "DUPLICATE"


            # Create final Article record
            article = Article(
                title=raw_article.title,
                description=raw_article.description,
                raw_content=raw_article.raw_content,
                content_blocks_json=raw_article.content_blocks_json,
                source_url=raw_article.source_url,
                cover_image_url=raw_article.cover_image_url,
                published_at=raw_article.published_at,
                content_hash=compute_content_hash(raw_article.raw_content or raw_article.description),
                title_fingerprint=compute_title_fingerprint(raw_article.title),
                canonical_url=raw_article.source_url,
            )

            db.session.add(article)

            # Classify using the new classification service
            matched_categories = ClassificationService.classify(
                title=raw_article.title,
                description=raw_article.description,
                tags=categories
            )
            for category in matched_categories:
                article.categories.append(category)

            db.session.flush()  # Flush to get article.id before assignment

            # Link to raw article (article.id is now available after flush)
            raw_article.article_id = article.id
            raw_article.status = "processed"

            try:
                assign_article_to_cluster(article)
                score_article(article)
            except Exception as exc:
                # A score must never prevent an otherwise valid scrape from being promoted.
                persist_fallback_score(article, exc)

            db.session.commit()

            logger.info(
                "[SUCCESS] Processed article: %s (ID: %d)",
                raw_article.source_url,
                article.id,
            )
            return True, f"CREATED:article:{article.id}"

        except IntegrityError as exc:
            db.session.rollback()
            logger.error(
                "[ERROR] Integrity error processing raw article: %s",
                exc,
            )
            return False, f"INTEGRITY_ERROR"

        except SQLAlchemyError as exc:
            db.session.rollback()
            logger.error(
                "[ERROR] Failed to process raw article: %s",
                exc,
            )
            return False, f"DB_ERROR"

    @staticmethod
    def bulk_save_raw_articles(
        articles: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Save multiple raw articles to staging table.

        Tracks success, duplicates, and errors for reporting.

        Args:
            articles: List of raw article dictionaries

        Returns:
            Summary dictionary with counts
        """
        summary = {
            "total": len(articles),
            "created": 0,
            "duplicates": 0,
            "errors": 0,
        }

        for article_data in articles:
            success, message = ScraperService.save_raw_article(article_data)

            if success:
                summary["created"] += 1
            elif message == "DUPLICATE":
                summary["duplicates"] += 1
            else:
                summary["errors"] += 1

        return summary

    @staticmethod
    def cleanup_old_articles(retention_days: int) -> int:
        """
        Delete articles older than retention_days.
        Rely on SQLAlchemy cascade deletes to clean up related bookmarks and raw_articles.

        Args:
            retention_days: Number of days to keep articles

        Returns:
            Number of deleted articles
        """
        try:
            limit_date = vietnam_now() - timedelta(days=retention_days)
            old_articles = Article.query.filter(Article.scraped_at < limit_date).all()
            deleted_count = len(old_articles)

            for article in old_articles:
                db.session.delete(article)

            db.session.commit()
            if deleted_count > 0:
                logger.info(
                    "[SUCCESS] Cleaned up %d old articles older than %d days",
                    deleted_count,
                    retention_days,
                )
            return deleted_count
        except SQLAlchemyError as exc:
            db.session.rollback()
            logger.error("[ERROR] Failed to clean up old articles: %s", exc)
            return 0
