"""Search domain logic for the HTML-first Hybrid MPA search experience."""

from __future__ import annotations

import logging
import re
from urllib.parse import urlparse
from datetime import datetime, timedelta
from math import ceil
from typing import Any

from sqlalchemy import case, func, or_

from models import Article, Category, SearchLog, article_categories, db
from services.article_service import get_article_card_presentation
from services.time_service import vietnam_now

logger = logging.getLogger(__name__)

TIME_FILTERS = {"24h": timedelta(hours=24), "7d": timedelta(days=7), "30d": timedelta(days=30)}
SORTS = {"relevant", "newest", "oldest"}
TSQUERY_OPERATORS = re.compile(r"[!|&():*<>]")


def sanitize_search_input(query: object) -> str:
    """Normalize a user query and reject empty or unsafe-length values."""
    value = " ".join(str(query or "").split())
    value = TSQUERY_OPERATORS.sub("", value).strip()
    if not value:
        raise ValueError("Search query is required.")
    if len(value) > 200:
        raise ValueError("Search query must be 200 characters or less.")
    return value


def _positive_int(value: object, name: str, default: int, maximum: int) -> int:
    if value in (None, ""):
        return default
    try:
        parsed = int(str(value))
    except (TypeError, ValueError) as exc:
        raise ValueError(f"Invalid parameter: {name}.") from exc
    if parsed < 1 or parsed > maximum:
        raise ValueError(f"Invalid parameter: {name}.")
    return parsed


def validate_search_parameters(params: dict[str, object]) -> dict[str, Any]:
    """Return validated search input suitable for service execution."""
    query = sanitize_search_input(params.get("q"))
    category = str(params.get("category") or "all").strip() or "all"
    source = str(params.get("source") or "all").strip() or "all"
    time_filter = str(params.get("time") or "all").strip() or "all"
    sort = str(params.get("sort") or "relevant").strip() or "relevant"
    if time_filter != "all" and time_filter not in TIME_FILTERS:
        raise ValueError("Invalid parameter: time.")
    if sort not in SORTS:
        raise ValueError("Invalid parameter: sort.")
    if len(source) > 255:
        raise ValueError("Invalid parameter: source.")
    exact = " ".join(str(params.get("exact") or "").split())
    include = " ".join(str(params.get("include") or "").split())
    exclude = " ".join(str(params.get("exclude") or "").split())
    if any(len(value) > 200 for value in (exact, include, exclude)):
        raise ValueError("Advanced search terms must be 200 characters or less.")
    if category != "all" and not Category.query.filter_by(name=category).first():
        raise ValueError("Invalid parameter: category.")
    return {
        "q": query,
        "category": category,
        "source": source,
        "time": time_filter,
        "sort": sort,
        "page": _positive_int(params.get("page"), "page", 1, 1_000_000),
        "per_page": _positive_int(params.get("per_page"), "per_page", 10, 50),
        "exact": exact,
        "include": include,
        "exclude": exclude,
    }


def _search_predicate(query: str):
    """Use PostgreSQL FTS in production and a deterministic SQLite test fallback."""
    dialect = db.session.get_bind().dialect.name
    if dialect == "postgresql":
        ts_query = func.plainto_tsquery("simple", query)
        return Article.search_vector.op("@@")(ts_query), func.ts_rank_cd(Article.search_vector, ts_query)
    pattern = f"%{query}%"
    predicate = or_(Article.title.ilike(pattern), Article.description.ilike(pattern), Article.raw_content.ilike(pattern))
    rank = case((Article.title.ilike(pattern), 2), (Article.description.ilike(pattern), 1), else_=0)
    return predicate, rank


def _record_search(keyword: str, user_id: int | None, total: int) -> None:
    """Persist a completed search without breaking a successful response on failure."""
    try:
        db.session.add(SearchLog(keyword=keyword.lower(), user_id=user_id, results_count=total))
        db.session.commit()
    except Exception:
        db.session.rollback()
        logger.exception("Could not record search event")


def search_articles(params: dict[str, object], current_user_id: int | None = None) -> dict[str, Any]:
    """Search articles and return presentation-ready results and metadata."""
    values = validate_search_parameters(params)
    search_text = " ".join(value for value in (values["q"], values["include"]) if value)
    predicate, relevance = _search_predicate(search_text)
    query = db.session.query(Article, relevance.label("relevance_score")).filter(predicate, Article.is_deleted.is_(False))
    if values["exact"]:
        exact_pattern = f"%{values['exact']}%"
        query = query.filter(or_(Article.title.ilike(exact_pattern), Article.description.ilike(exact_pattern), Article.raw_content.ilike(exact_pattern)))
    for term in values["exclude"].split():
        excluded_pattern = f"%{term}%"
        query = query.filter(~or_(Article.title.ilike(excluded_pattern), Article.description.ilike(excluded_pattern), Article.raw_content.ilike(excluded_pattern)))
    if values["category"] != "all":
        query = query.join(article_categories).join(Category).filter(Category.name == values["category"])
    if values["source"] != "all":
        query = query.filter(Article.source_url.ilike(f"%{values['source']}%"))
    if values["time"] != "all":
        query = query.filter(Article.published_at >= vietnam_now() - TIME_FILTERS[values["time"]])
    if values["sort"] == "newest":
        query = query.order_by(Article.published_at.desc().nullslast(), Article.id.desc())
    elif values["sort"] == "oldest":
        query = query.order_by(Article.published_at.asc().nullslast(), Article.id.asc())
    else:
        query = query.order_by(relevance.desc(), Article.published_at.desc().nullslast(), Article.id.desc())
    total = query.order_by(None).count()
    records = query.offset((values["page"] - 1) * values["per_page"]).limit(values["per_page"]).all()
    articles = []
    for article, score in records:
        result = get_article_card_presentation(article)
        result["relevance_score"] = float(score or 0)
        articles.append(result)
    pages = ceil(total / values["per_page"]) if total else 0
    _record_search(values["q"], current_user_id, total)
    return {
        "articles": articles,
        "pagination": {"current_page": values["page"], "per_page": values["per_page"], "total_results": total, "total_pages": pages, "has_next": values["page"] < pages, "has_prev": values["page"] > 1},
        "query": values["q"],
        "filters_applied": {key: values[key] for key in ("category", "source", "time", "sort", "exact", "include", "exclude")},
    }


def get_trending_keywords(limit: object = 5, current_user_id: int | None = None) -> dict[str, list[dict[str, Any]]]:
    """Return search suggestions scoped to the active user or anonymous session."""
    safe_limit = _positive_int(limit, "limit", 5, 10)
    since = vietnam_now() - timedelta(hours=24)
    owner_filter = (
        SearchLog.user_id == current_user_id
        if current_user_id is not None
        else SearchLog.user_id.is_(None)
    )
    trends = db.session.query(
        SearchLog.keyword,
        func.count(SearchLog.id).label("search_count"),
    ).filter(
        SearchLog.searched_at >= since,
        owner_filter,
    ).group_by(SearchLog.keyword).order_by(
        func.count(SearchLog.id).desc(),
        SearchLog.keyword.asc(),
    ).limit(safe_limit).all()
    recent: list[dict[str, Any]] = []
    if current_user_id:
        rows = db.session.query(SearchLog.keyword, func.max(SearchLog.searched_at).label("searched_at")).filter(SearchLog.user_id == current_user_id).group_by(SearchLog.keyword).order_by(func.max(SearchLog.searched_at).desc()).limit(5).all()
        recent = [{"keyword": row.keyword, "searched_at": row.searched_at.isoformat() + "Z"} for row in rows]
    return {"trending": [{"keyword": row.keyword, "search_count": row.search_count} for row in trends], "recent_searches": recent}


def clear_user_search_history(user_id: int) -> int:
    """Delete search history owned by one account and return the row count."""
    deleted = SearchLog.query.filter(SearchLog.user_id == user_id).delete(
        synchronize_session=False,
    )
    db.session.commit()
    return deleted


def delete_user_search_history_entry(user_id: int, keyword: object) -> int:
    """Remove one normalized search term from the requesting user's history."""
    normalized_keyword = sanitize_search_input(keyword).lower()
    deleted = SearchLog.query.filter(
        SearchLog.user_id == user_id,
        SearchLog.keyword == normalized_keyword,
    ).delete(synchronize_session=False)
    db.session.commit()
    return deleted


def get_search_sources() -> list[str]:
    """Return stable source host names available to the search dropdown."""
    hosts = {
        (urlparse(url).hostname or "").lower()
        for (url,) in db.session.query(Article.source_url).filter(Article.source_url.isnot(None), Article.is_deleted.is_(False)).all()
    }
    return sorted(host for host in hosts if host)
