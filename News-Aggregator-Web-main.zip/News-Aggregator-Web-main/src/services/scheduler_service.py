"""
Scheduler Service for Automated Scraping

Manages the APScheduler background job for periodic news scraping.
Provides integration with Flask app lifecycle and error handling per constitution.
"""

import json
import logging
import os
import threading
from datetime import datetime
from typing import Optional, Tuple, Dict, Any

from apscheduler.schedulers.background import BackgroundScheduler
from apscheduler.triggers.interval import IntervalTrigger
from apscheduler.triggers.cron import CronTrigger
from sqlalchemy.exc import SQLAlchemyError

from scraper.dynamic_scraper import DynamicScraper
from services.scraper_service import ScraperService
from services.time_service import vietnam_now
from models import RawArticle, ScraperRun, ScraperConfig, SystemSetting, db

logger = logging.getLogger(__name__)

_scraper_lock = threading.Lock()
_last_manual_trigger_time: Optional[datetime] = None


class SchedulerService:
    """
    Manages background scheduling for the scraper pipeline.

    Responsibilities:
    - Initialize APScheduler with Flask app
    - Register periodic scraping job
    - Handle job execution with comprehensive error handling & telemetry
    - Provide thread-safe manual scraper triggers
    """

    _scheduler: Optional[BackgroundScheduler] = None
    _app = None  # Flask app reference for app context in background thread

    @staticmethod
    def init_app(app) -> None:
        """
        Initialize the scheduler with a Flask application.

        Must be called in the Flask app context after app initialization.

        Args:
            app: Flask application instance
        """
        if SchedulerService._scheduler is not None:
            logger.warning("[WARNING] Scheduler already initialized")
            return

        # Store app reference for use in background threads
        SchedulerService._app = app

        try:
            SchedulerService._scheduler = BackgroundScheduler()

            # Fetch interval from SystemSettings or fallback to default
            interval_minutes = 60
            with app.app_context():
                setting = db.session.get(SystemSetting, "scraping_interval_minutes")
                if setting and setting.value.isdigit():
                    interval_minutes = int(setting.value)
            
            trigger = IntervalTrigger(minutes=interval_minutes)
            logger.info(f"[INFO] Scheduler interval set to {interval_minutes} minutes")

            # Register the periodic scraper job
            SchedulerService._scheduler.add_job(
                func=SchedulerService._scraper_job,
                trigger=trigger,
                id="scraper_job_hourly",
                name="Hourly News Scraper",
                replace_existing=True,
                max_instances=1,  # Prevent concurrent job executions
            )

            SchedulerService._scheduler.add_job(
                func=SchedulerService._daily_brief_job,
                trigger=CronTrigger(hour=7, minute=0, timezone="Asia/Ho_Chi_Minh"),
                id="daily_brief_generator",
                name="Daily User Brief Generator",
                replace_existing=True,
                max_instances=1,
            )

            SchedulerService._scheduler.add_job(
                func=SchedulerService._truth_score_maintenance_job,
                # Re-scoring every hour repeatedly transfers the same 72-hour
                # article window from the database.  A daily refresh is enough
                # for the non-real-time confidence score.
                trigger=CronTrigger(hour=3, minute=0, timezone="Asia/Ho_Chi_Minh"),
                id="truth_score_maintenance",
                name="Daily Truth Score Maintenance",
                replace_existing=True,
                max_instances=1,
            )
            SchedulerService._scheduler.add_job(
                func=SchedulerService._story_cluster_maintenance_job,
                # Run after truth scoring so the two jobs do not compete for
                # database bandwidth while reading recent articles.
                trigger=CronTrigger(hour=3, minute=30, timezone="Asia/Ho_Chi_Minh"),
                id="story_cluster_maintenance",
                name="Daily Story Cluster Maintenance",
                replace_existing=True,
                max_instances=1,
            )

            # Register the daily database cleanup job
            SchedulerService._scheduler.add_job(
                func=SchedulerService._cleanup_job,
                trigger=IntervalTrigger(days=1),
                id="database_cleanup_daily",
                name="Daily Database Cleanup",
                replace_existing=True,
                max_instances=1,  # Prevent concurrent job executions
            )

            # Start the scheduler
            SchedulerService._scheduler.start()
            logger.info("[SUCCESS] APScheduler initialized and started")

        except Exception as exc:
            logger.error(
                "[ERROR] Failed to initialize scheduler: %s",
                exc,
                exc_info=True,
            )
            raise

    @staticmethod
    def reschedule_scraper_job() -> None:
        """Dynamically reschedule the scraper job using interval from DB."""
        if not SchedulerService._scheduler or not SchedulerService._app:
            return

        with SchedulerService._app.app_context():
            setting = db.session.get(SystemSetting, "scraping_interval_minutes")
            interval_minutes = int(setting.value) if setting and setting.value.isdigit() else 60

        try:
            trigger = IntervalTrigger(minutes=interval_minutes)
            SchedulerService._scheduler.reschedule_job(
                job_id="scraper_job_hourly",
                trigger=trigger
            )
            logger.info(f"[SUCCESS] Rescheduled scraper_job_hourly to every {interval_minutes} minutes.")
        except Exception as exc:
            logger.error("[ERROR] Failed to reschedule job: %s", exc)

    @staticmethod
    def shutdown() -> None:
        """Gracefully shutdown the scheduler (idempotent — safe to call multiple times)."""
        if SchedulerService._scheduler and SchedulerService._scheduler.running:
            try:
                SchedulerService._scheduler.shutdown(wait=False)
                logger.info("[SUCCESS] Scheduler shut down cleanly")
            except Exception as exc:
                logger.error(
                    "[ERROR] Error during scheduler shutdown: %s",
                    exc,
                    exc_info=True,
                )

    @staticmethod
    def is_locked() -> bool:
        """Check if a scraper job is currently executing."""
        return _scraper_lock.locked()

    @staticmethod
    def _scraper_job() -> None:
        """Scheduled job wrapper."""
        SchedulerService.execute_scraper_run(trigger_type="scheduled")

    @classmethod
    def execute_scraper_run(
        cls,
        trigger_type: str = "scheduled",
        admin_id: Optional[int] = None,
        source_id: Optional[int] = None,
        max_articles: Optional[int] = None,
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        """
        Thread-safe execution of the scraping pipeline with ScraperRun telemetry.

        Returns (success, message, run_data_dict)
        """
        if not _scraper_lock.acquire(blocking=False):
            logger.warning("[SKIP] Scraper execution requested but lock is currently held.")
            return False, "A scraper job is already running.", None

        app = cls._app
        if not app:
            _scraper_lock.release()
            logger.error("[ERROR] No Flask app reference available for scraper job")
            return False, "Application context not available.", None

        run_id = None
        scraper = None
        try:
            with app.app_context():
                run = ScraperRun(
                    trigger_type=trigger_type,
                    triggered_by_id=admin_id,
                    status="running",
                    started_at=vietnam_now(),
                )
                db.session.add(run)
                db.session.commit()
                run_id = run.id

                logger.info("[INFO] ScraperRun #%d started (%s)", run_id, trigger_type)

                scraped_count = 0
                created_count = 0
                duplicate_count = 0
                error_count = 0

                def persist_progress() -> None:
                    """Expose committed counters to the admin polling endpoint."""
                    run_obj = db.session.get(ScraperRun, run_id)
                    if not run_obj:
                        return
                    run_obj.articles_scraped = scraped_count
                    run_obj.articles_created = created_count
                    run_obj.duplicates_found = duplicate_count
                    run_obj.error_count = error_count
                    db.session.commit()

                # Query all active sources
                query = ScraperConfig.query.filter_by(is_enabled=True)
                if source_id:
                    query = query.filter_by(id=source_id)
                active_configs = query.all()
                
                if not active_configs:
                    logger.info("[INFO] No active scraper configurations found.")
                
                validated_articles = []
                article_categories_map = []
                
                for config in active_configs:
                    try:
                        logger.info("[INFO] Running scraper for source: %s", config.source_name)
                        def report_scraped_article(_article: dict) -> None:
                            nonlocal scraped_count
                            scraped_count += 1
                            persist_progress()

                        scraper = DynamicScraper(
                            config,
                            max_articles_override=max_articles,
                            progress_callback=report_scraped_article,
                        )
                        raw_articles = scraper.scrape()
                        
                        for article in raw_articles:
                            if scraper.validate_data(article):
                                try:
                                    categories = article.get("categories", ["General"])
                                    normalized = scraper.transform(article)
                                    validated_articles.append(normalized)
                                    article_categories_map.append(categories)
                                except Exception as exc:
                                    logger.warning("[WARNING] Failed to transform article: %s", exc)
                        persist_progress()
                    except Exception as exc:
                        logger.error("[ERROR] Scraper %s failed: %s", config.source_name, exc)
                        error_count += 1
                        persist_progress()

                if validated_articles:
                    summary = ScraperService.bulk_save_raw_articles(validated_articles)
                    created_count = summary.get("created", 0)
                    duplicate_count = summary.get("duplicates", 0)
                    error_count += summary.get("errors", 0)
                    persist_progress()

                # Auto-promote: process pending RawArticles
                pending_raw = RawArticle.query.filter_by(status="pending").all()
                promoted_count = 0

                for raw_article in pending_raw:
                    categories = ["General"]
                    for i, va in enumerate(validated_articles):
                        if va.get("source_url") == raw_article.source_url:
                            categories = article_categories_map[i] if i < len(article_categories_map) else ["General"]
                            break

                    success, _ = ScraperService.process_raw_article(
                        raw_article.id, categories=categories
                    )
                    if success:
                        promoted_count += 1
                    else:
                        error_count += 1
                    # Article promotion can take noticeably longer than the
                    # network scrape, so publish intermediate counts as well.
                    persist_progress()

                # Complete run record
                run_obj = db.session.get(ScraperRun, run_id)
                if run_obj:
                    run_obj.status = "completed"
                    run_obj.completed_at = vietnam_now()
                    run_obj.articles_scraped = scraped_count
                    run_obj.articles_created = created_count
                    run_obj.duplicates_found = duplicate_count
                    run_obj.error_count = error_count
                    run_obj.summary_json = json.dumps({
                        "promoted_count": promoted_count,
                        "validated_count": len(validated_articles),
                    })
                    db.session.commit()

                logger.info(
                    "[SUCCESS] ScraperRun #%d completed: %d scraped, %d created, %d dupes",
                    run_id, scraped_count, created_count, duplicate_count
                )

                return True, "Scraper run completed successfully.", {
                    "id": run_id,
                    "status": "completed",
                    "articles_scraped": scraped_count,
                    "articles_created": created_count,
                    "duplicates_found": duplicate_count,
                    "error_count": error_count,
                }

        except Exception as exc:
            logger.error("[ERROR] ScraperRun failed: %s", exc, exc_info=True)
            if run_id:
                try:
                    with app.app_context():
                        run_obj = db.session.get(ScraperRun, run_id)
                        if run_obj:
                            run_obj.status = "failed"
                            run_obj.completed_at = vietnam_now()
                            run_obj.summary_json = json.dumps({"error": str(exc)})
                            db.session.commit()
                except Exception:
                    pass
            return False, f"Scraper execution failed: {str(exc)}", None

        finally:
            if scraper:
                try:
                    scraper.close()
                except Exception:
                    pass
            _scraper_lock.release()

    @staticmethod
    def _cleanup_job() -> None:
        """
        Execute the database cleanup job (runs in background thread).
        Deletes old articles based on SCRAPER_RETENTION_DAYS.
        """
        job_id = "database_cleanup_daily"
        logger.info("[INFO] Starting %s", job_id)

        app = SchedulerService._app
        if not app:
            logger.error("[ERROR] No Flask app reference available for cleanup job")
            return

        try:
            with app.app_context():
                retention_days = int(os.getenv("SCRAPER_RETENTION_DAYS", "30"))
                logger.info(
                    "[INFO] Running database retention policy (keeping last %d days)",
                    retention_days,
                )

                deleted_count = ScraperService.cleanup_old_articles(retention_days)
                logger.info(
                    "[SUCCESS] Completed database cleanup. Removed %d old articles.",
                    deleted_count,
                )
        except Exception as exc:
            logger.error(
                "[ERROR] Database cleanup job failed: %s",
                exc,
                exc_info=True,
            )
        finally:
            logger.info("[INFO] Completed %s", job_id)

    @staticmethod
    def _daily_brief_job() -> None:
        """Generate enabled users' daily briefs inside a Flask context."""
        if not SchedulerService._app:
            return
        try:
            with SchedulerService._app.app_context():
                from services.brief_service import generate_all_daily_briefs
                generate_all_daily_briefs()
        except Exception:
            logger.exception("[ERROR] Daily brief generation failed")

    @staticmethod
    def _truth_score_maintenance_job() -> None:
        """Refresh recent score clusters as independent coverage arrives."""
        if not SchedulerService._app:
            return
        try:
            with SchedulerService._app.app_context():
                from services.truth_score_service import rescore_recent_articles
                result = rescore_recent_articles(hours=72)
                logger.info("[SUCCESS] Truth-score maintenance: %s", result)
        except Exception:
            logger.exception("[ERROR] Truth-score maintenance failed")

    @staticmethod
    def _story_cluster_maintenance_job() -> None:
        if not SchedulerService._app:
            return
        try:
            with SchedulerService._app.app_context():
                from models import Article, StoryCluster
                from services.story_cluster_service import recalculate_cluster
                from services.truth_score_service import ARTICLE_SCORING_COLUMNS, score_article
                from sqlalchemy.orm import load_only
                from datetime import timedelta
                since = vietnam_now() - timedelta(hours=72)
                for cluster in StoryCluster.query.filter(StoryCluster.last_covered_at >= since).all():
                    recalculate_cluster(cluster)
                    for membership in cluster.memberships:
                        if membership.status != "accepted":
                            continue
                        article = Article.query.options(
                            load_only(*ARTICLE_SCORING_COLUMNS)
                        ).filter_by(id=membership.article_id).first()
                        if article:
                            score_article(article)
                db.session.commit()
        except Exception:
            db.session.rollback()
            logger.exception("[ERROR] Story-cluster maintenance failed")

    @staticmethod
    def get_scheduler() -> Optional[BackgroundScheduler]:
        """
        Get the current scheduler instance.

        Returns:
            BackgroundScheduler instance or None if not initialized
        """
        return SchedulerService._scheduler

    @staticmethod
    def is_running() -> bool:
        """
        Check if scheduler is currently running.

        Returns:
            True if scheduler is running, False otherwise
        """
        if not SchedulerService._scheduler:
            return False
        return SchedulerService._scheduler.running
