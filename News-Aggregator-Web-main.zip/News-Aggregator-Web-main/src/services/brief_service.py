"""Daily-brief persistence and resilient article-title fallback generation."""
from datetime import datetime, time, timedelta
import json
import logging
from models import Article, Category, DailyBrief, User, UserBriefPreference, db
from services.ai_service import generate_daily_brief as generate_daily_brief_content
from services.email_service import send_daily_brief_email
from services.time_service import vietnam_now, vietnam_today

logger = logging.getLogger(__name__)

def _serialize(brief):
    if not brief: return None
    return {"id":brief.id,"content":brief.content,"source_article_ids":json.loads(brief.source_article_ids or "[]"),"generated_at":brief.generated_at.isoformat(),"brief_date":brief.brief_date.isoformat(),"is_today":brief.brief_date == vietnam_today(),"is_read":brief.is_read}

def get_latest_brief(user_id): return _serialize(DailyBrief.query.filter_by(user_id=user_id).order_by(DailyBrief.brief_date.desc()).first())

def get_todays_brief(user_id):
    """Return today's brief only, so manual generation cannot overwrite it."""
    return DailyBrief.query.filter_by(user_id=user_id, brief_date=vietnam_today()).first()

def get_brief_history(user_id, limit=30):
    """Return recent briefs for one user, newest first."""
    return [_serialize(brief) for brief in DailyBrief.query.filter_by(user_id=user_id).order_by(
        DailyBrief.brief_date.desc(), DailyBrief.generated_at.desc()
    ).limit(max(1, min(int(limit), 100))).all()]

def generate_daily_brief(user_id):
    brief_date = vietnam_today()
    existing=get_todays_brief(user_id)
    if existing: return existing
    user=db.session.get(User,user_id); since=vietnam_now()-timedelta(days=1)
    query=Article.query.filter(Article.is_deleted.is_(False), Article.published_at >= since)
    if user and (user.subscribed_categories or user.subscribed_sources):
        # A selected topic and a selected source are both explicit constraints.
        # If the user selects only one kind of preference, filter by that one.
        if user.subscribed_categories:
            query = query.filter(
                Article.categories.any(
                    Category.id.in_([item.id for item in user.subscribed_categories])
                )
            )
        if user.subscribed_sources:
            query = query.filter(
                db.or_(
                    *(Article.source_url.ilike(f"%{item.source_domain}%")
                      for item in user.subscribed_sources)
                )
            )
    candidates = query.order_by(Article.published_at.desc(), Article.id.desc()).all()
    def brief_rank(article):
        cluster = article.story_membership.cluster if article.story_membership and article.story_membership.status == "accepted" else None
        return (.55 * (cluster.trending_score if cluster else 0)) + (.45 * (article.truth_score or 0))
    candidates.sort(key=lambda article: (brief_rank(article), article.published_at or datetime.min, article.id), reverse=True)
    canonical = [article for article in candidates if article.primary_article_id is None]
    fallback_articles = [article for article in candidates if article.primary_article_id is not None]
    articles = (canonical + fallback_articles)[:5]
    logger.info("Daily brief candidates user_id=%s articles=%s", user_id, [(a.id, a.truth_score) for a in articles])
    context = "\n\n".join(
        f"ARTICLE ID: {article.id}\nTITLE: {article.title}\nSOURCE: {article.source_url}\n"
        f"SUMMARY: {article.description or article.raw_content or 'No description available.'}"
        for article in articles
    )
    fallback = f"Daily Brief — {brief_date.isoformat()}\n" + "\n".join(
        f"- {article.title}: {article.description or 'Read the latest coverage.'}"
        for article in articles
    ) or "- Your next personalized brief is being prepared."
    content = generate_daily_brief_content(context, brief_date.isoformat()) or fallback
    article_ids = [article.id for article in articles]
    brief=DailyBrief(user_id=user_id,content=content,source_article_ids=json.dumps(article_ids),brief_date=brief_date)
    db.session.add(brief); db.session.commit()
    preference = UserBriefPreference.query.filter_by(user_id=user_id).first()
    if preference and preference.email_delivery and user:
        send_daily_brief_email(user.email, brief.content, brief_date.isoformat(), article_ids)
    return brief

def mark_brief_read(user_id, brief_id):
    brief=DailyBrief.query.filter_by(id=brief_id,user_id=user_id).first()
    if not brief:return {"status":"error","message":"Brief not found."},404
    brief.is_read=True; db.session.commit(); return {"status":"success","brief":_serialize(brief)},200

def get_brief_preferences(user_id):
    pref=UserBriefPreference.query.filter_by(user_id=user_id).first()
    if not pref: return {"is_enabled":False,"delivery_time":"07:00","frequency":"daily","email_delivery":False}
    return {"is_enabled":pref.is_enabled,"delivery_time":pref.delivery_time.strftime("%H:%M"),"frequency":pref.frequency,"email_delivery":pref.email_delivery}

def update_brief_preferences(user_id, prefs):
    try: delivery=time.fromisoformat(str(prefs.get("delivery_time","07:00")))
    except ValueError:return {"status":"error","message":"Delivery time must use HH:MM."},400
    frequency=prefs.get("frequency","daily")
    if frequency not in {"daily","weekly"}:return {"status":"error","message":"Frequency must be daily or weekly."},400
    pref=UserBriefPreference.query.filter_by(user_id=user_id).first() or UserBriefPreference(user_id=user_id)
    pref.delivery_time=delivery; pref.frequency=frequency; pref.is_enabled=bool(prefs.get("is_enabled",True)); pref.email_delivery=bool(prefs.get("email_delivery",False)); db.session.add(pref);db.session.commit()
    return {"status":"success","data":get_brief_preferences(user_id)},200

def generate_all_daily_briefs():
    for pref in UserBriefPreference.query.filter_by(is_enabled=True).all():
        try: generate_daily_brief(pref.user_id)
        except Exception: db.session.rollback()
