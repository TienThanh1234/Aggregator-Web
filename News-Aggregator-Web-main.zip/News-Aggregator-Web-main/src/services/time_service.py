"""Shared wall-clock helpers for Vietnam business time (UTC+7)."""

from datetime import date, datetime
from zoneinfo import ZoneInfo

VIETNAM_TIMEZONE = ZoneInfo("Asia/Ho_Chi_Minh")


def vietnam_now() -> datetime:
    """Return Vietnam local time without tzinfo for the existing naive DB columns."""
    return datetime.now(VIETNAM_TIMEZONE).replace(tzinfo=None)


def vietnam_today() -> date:
    """Return the current calendar date in Vietnam, independent of Render's host timezone."""
    return datetime.now(VIETNAM_TIMEZONE).date()
