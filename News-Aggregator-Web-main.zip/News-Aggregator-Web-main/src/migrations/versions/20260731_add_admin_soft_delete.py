"""Add soft delete for admin article management."""

from alembic import op
import sqlalchemy as sa


revision = "20260731_admin"

# migration search hiện tại của repo bạn
down_revision = "20260731_search"

branch_labels = None
depends_on = None


def upgrade():
    """Add soft-delete fields, tolerating schemas created before migration."""
    inspector = sa.inspect(op.get_bind())
    columns = {column["name"] for column in inspector.get_columns("articles")}
    indexes = {index["name"] for index in inspector.get_indexes("articles")}

    if "is_deleted" not in columns:
        op.add_column(
            "articles",
            sa.Column(
                "is_deleted",
                sa.Boolean(),
                nullable=False,
                server_default=sa.false(),
            ),
        )
    if "ix_articles_is_deleted" not in indexes:
        op.create_index("ix_articles_is_deleted", "articles", ["is_deleted"])


def downgrade():
    inspector = sa.inspect(op.get_bind())
    indexes = {index["name"] for index in inspector.get_indexes("articles")}
    columns = {column["name"] for column in inspector.get_columns("articles")}
    if "ix_articles_is_deleted" in indexes:
        op.drop_index("ix_articles_is_deleted", table_name="articles")
    if "is_deleted" in columns:
        op.drop_column("articles", "is_deleted")
