"""Create schema required by the Admin Operations dashboard.

Revision ID: 20260803_admin_operations
Revises: 20260803_article_cascade
Create Date: 2026-08-03
"""

from alembic import op
import sqlalchemy as sa


revision = "20260803_admin_operations"
down_revision = "20260803_article_cascade"
branch_labels = None
depends_on = None


def _columns(inspector, table_name):
    return {column["name"] for column in inspector.get_columns(table_name)}


def _indexes(inspector, table_name):
    return {index["name"] for index in inspector.get_indexes(table_name)}


def upgrade() -> None:
    """Add duplicate-moderation fields plus scraper and audit telemetry."""
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    article_columns = _columns(inspector, "articles")
    article_indexes = _indexes(inspector, "articles")

    if "content_hash" not in article_columns:
        op.add_column("articles", sa.Column("content_hash", sa.String(64), nullable=True))
    if "title_fingerprint" not in article_columns:
        op.add_column("articles", sa.Column("title_fingerprint", sa.String(128), nullable=True))
    if "canonical_url" not in article_columns:
        op.add_column("articles", sa.Column("canonical_url", sa.String(1000), nullable=True))
    if "primary_article_id" not in article_columns:
        op.add_column("articles", sa.Column("primary_article_id", sa.Integer(), nullable=True))

    if "ix_articles_content_hash" not in article_indexes:
        op.create_index("ix_articles_content_hash", "articles", ["content_hash"])
    if "ix_articles_title_fingerprint" not in article_indexes:
        op.create_index("ix_articles_title_fingerprint", "articles", ["title_fingerprint"])

    foreign_keys = {fk.get("name") for fk in inspector.get_foreign_keys("articles")}
    if (
        bind.dialect.name != "sqlite"
        and "fk_articles_primary_article_id" not in foreign_keys
    ):
        op.create_foreign_key(
            "fk_articles_primary_article_id",
            "articles",
            "articles",
            ["primary_article_id"],
            ["id"],
            ondelete="SET NULL",
        )

    tables = set(inspector.get_table_names())
    if "admin_audit_logs" not in tables:
        op.create_table(
            "admin_audit_logs",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("admin_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
            sa.Column("action", sa.String(50), nullable=False),
            sa.Column("target_type", sa.String(30), nullable=False),
            sa.Column("target_id", sa.Integer(), nullable=True),
            sa.Column("details", sa.Text(), nullable=True),
            sa.Column("created_at", sa.DateTime(), nullable=False),
        )
        op.create_index("ix_admin_audit_logs_action", "admin_audit_logs", ["action"])
        op.create_index("ix_admin_audit_logs_created_at", "admin_audit_logs", ["created_at"])

    if "scraper_runs" not in tables:
        op.create_table(
            "scraper_runs",
            sa.Column("id", sa.Integer(), primary_key=True),
            sa.Column("trigger_type", sa.String(20), nullable=False),
            sa.Column("triggered_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
            sa.Column("status", sa.String(20), nullable=False),
            sa.Column("started_at", sa.DateTime(), nullable=False),
            sa.Column("completed_at", sa.DateTime(), nullable=True),
            sa.Column("articles_scraped", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("articles_created", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("duplicates_found", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("error_count", sa.Integer(), nullable=False, server_default="0"),
            sa.Column("summary_json", sa.Text(), nullable=True),
        )
        op.create_index("ix_scraper_runs_status", "scraper_runs", ["status"])
        op.create_index("ix_scraper_runs_started_at", "scraper_runs", ["started_at"])


def downgrade() -> None:
    """Remove Admin Operations schema additions."""
    bind = op.get_bind()
    inspector = sa.inspect(bind)
    tables = set(inspector.get_table_names())

    if "scraper_runs" in tables:
        op.drop_table("scraper_runs")
    if "admin_audit_logs" in tables:
        op.drop_table("admin_audit_logs")

    article_indexes = _indexes(inspector, "articles")
    foreign_keys = {fk.get("name") for fk in inspector.get_foreign_keys("articles")}
    if bind.dialect.name != "sqlite" and "fk_articles_primary_article_id" in foreign_keys:
        op.drop_constraint("fk_articles_primary_article_id", "articles", type_="foreignkey")
    if "ix_articles_content_hash" in article_indexes:
        op.drop_index("ix_articles_content_hash", table_name="articles")
    if "ix_articles_title_fingerprint" in article_indexes:
        op.drop_index("ix_articles_title_fingerprint", table_name="articles")

    article_columns = _columns(inspector, "articles")
    for column_name in (
        "primary_article_id",
        "canonical_url",
        "title_fingerprint",
        "content_hash",
    ):
        if column_name in article_columns:
            op.drop_column("articles", column_name)
