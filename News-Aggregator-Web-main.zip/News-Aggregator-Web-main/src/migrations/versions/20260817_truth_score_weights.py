"""Update truth score weights and source reliability defaults.

Revision ID: 20260817_truth_weights
Revises: 20260817_story_clusters
"""
from alembic import op

revision = "20260817_truth_weights"
down_revision = "20260817_story_clusters"
branch_labels = None
depends_on = None


def upgrade():
    op.execute("UPDATE scraper_configs SET reliability_score = 100")


def downgrade():
    op.execute("UPDATE scraper_configs SET reliability_score = 50")
