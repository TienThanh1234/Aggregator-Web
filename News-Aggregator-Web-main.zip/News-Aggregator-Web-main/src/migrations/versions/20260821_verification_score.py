"""Add cached evidence-verification fields to Truth Score details.

Revision ID: 20260821_verification_score
Revises: 20260821_lazy_clarity
"""

from alembic import op
import sqlalchemy as sa


revision = "20260821_verification_score"
down_revision = "20260821_lazy_clarity"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("article_truth_scores", sa.Column("verification_score", sa.Integer(), nullable=False, server_default="0"))
    op.add_column("article_truth_scores", sa.Column("ambiguity_penalty", sa.Integer(), nullable=False, server_default="0"))
    op.add_column("article_truth_scores", sa.Column("verification_source_type", sa.String(length=20), nullable=True))
    op.add_column("article_truth_scores", sa.Column("verification_article_ids", sa.Text(), nullable=False, server_default="[]"))
    op.add_column("article_truth_scores", sa.Column("verification_citations_json", sa.Text(), nullable=False, server_default="[]"))
    op.add_column("article_truth_scores", sa.Column("verification_claims_json", sa.Text(), nullable=False, server_default="[]"))
    op.add_column("article_truth_scores", sa.Column("verification_report", sa.Text(), nullable=True))
    op.add_column("article_truth_scores", sa.Column("verification_checked_at", sa.DateTime(), nullable=True))


def downgrade():
    for column in ("verification_checked_at", "verification_report", "verification_claims_json", "verification_citations_json", "verification_article_ids", "verification_source_type", "ambiguity_penalty", "verification_score"):
        op.drop_column("article_truth_scores", column)
