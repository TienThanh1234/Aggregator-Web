"""Disable scheduled Daily Brief generation by default.

Revision ID: 20260822_brief_off
Revises: 20260822_admin_mod
"""

from alembic import op
import sqlalchemy as sa


revision = "20260822_brief_off"
down_revision = "20260822_admin_mod"
branch_labels = None
depends_on = None


def upgrade():
    op.alter_column(
        "user_brief_preferences",
        "is_enabled",
        existing_type=sa.Boolean(),
        server_default=sa.false(),
    )


def downgrade():
    op.alter_column(
        "user_brief_preferences",
        "is_enabled",
        existing_type=sa.Boolean(),
        server_default=sa.true(),
    )
