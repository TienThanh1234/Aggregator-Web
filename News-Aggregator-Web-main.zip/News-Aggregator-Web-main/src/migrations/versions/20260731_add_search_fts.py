"""add PostgreSQL full-text search support

Revision ID: 20260731_search
Revises: 20260727_avatar
Create Date: 2026-07-31
"""

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql


revision = "20260731_search"
down_revision = "20260727_avatar"
branch_labels = None
depends_on = None


def upgrade() -> None:
    inspector = sa.inspect(op.get_bind())
    article_columns = {column["name"] for column in inspector.get_columns("articles")}
    if "search_vector" not in article_columns:
        op.add_column("articles", sa.Column("search_vector", postgresql.TSVECTOR(), nullable=True))
    if "search_logs" not in inspector.get_table_names():
        op.create_table("search_logs", sa.Column("id", sa.Integer(), primary_key=True), sa.Column("keyword", sa.String(length=255), nullable=False), sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True), sa.Column("results_count", sa.Integer(), nullable=False, server_default="0"), sa.Column("searched_at", sa.DateTime(), nullable=False, server_default=sa.text("CURRENT_TIMESTAMP")))
    op.execute("CREATE FUNCTION articles_search_vector_update() RETURNS trigger AS $$ BEGIN NEW.search_vector := setweight(to_tsvector('simple', COALESCE(NEW.title, '')), 'A') || setweight(to_tsvector('simple', COALESCE(NEW.description, '')), 'B') || setweight(to_tsvector('simple', COALESCE(NEW.raw_content, '')), 'C'); RETURN NEW; END; $$ LANGUAGE plpgsql")
    op.execute("CREATE TRIGGER trg_articles_search_vector_update BEFORE INSERT OR UPDATE OF title, description, raw_content ON articles FOR EACH ROW EXECUTE FUNCTION articles_search_vector_update()")
    op.execute("UPDATE articles SET search_vector = setweight(to_tsvector('simple', COALESCE(title, '')), 'A') || setweight(to_tsvector('simple', COALESCE(description, '')), 'B') || setweight(to_tsvector('simple', COALESCE(raw_content, '')), 'C')")
    op.execute("CREATE INDEX idx_articles_search_vector ON articles USING GIN (search_vector)")
    op.create_index("idx_search_logs_searched_at", "search_logs", ["searched_at"])
    op.create_index("idx_search_logs_keyword", "search_logs", ["keyword"])
    op.create_index("idx_search_logs_user_id", "search_logs", ["user_id", "searched_at"])


def downgrade() -> None:
    op.drop_index("idx_search_logs_user_id", table_name="search_logs")
    op.drop_index("idx_search_logs_keyword", table_name="search_logs")
    op.drop_index("idx_search_logs_searched_at", table_name="search_logs")
    op.drop_table("search_logs")
    op.execute("DROP TRIGGER IF EXISTS trg_articles_search_vector_update ON articles")
    op.execute("DROP FUNCTION IF EXISTS articles_search_vector_update()")
    op.execute("DROP INDEX IF EXISTS idx_articles_search_vector")
    op.drop_column("articles", "search_vector")
