"""add password reset state

Revision ID: f8b01e29c734
Revises: d659acfe36a9
Create Date: 2026-07-23
"""

from alembic import op
import sqlalchemy as sa


revision = "f8b01e29c734"
down_revision = "d659acfe36a9"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Add reset-token and session-version columns to users."""
    with op.batch_alter_table("users", schema=None) as batch_op:
        batch_op.add_column(sa.Column("password_reset_token_hash", sa.String(length=255), nullable=True))
        batch_op.add_column(sa.Column("password_reset_expires_at", sa.DateTime(), nullable=True))
        batch_op.add_column(
            sa.Column("session_version", sa.Integer(), nullable=False, server_default=sa.text("0"))
        )


def downgrade() -> None:
    """Remove reset-token and session-version columns from users."""
    with op.batch_alter_table("users", schema=None) as batch_op:
        batch_op.drop_column("session_version")
        batch_op.drop_column("password_reset_expires_at")
        batch_op.drop_column("password_reset_token_hash")
