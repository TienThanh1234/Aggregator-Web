"""Add raw_articles staging table for ETL pipeline

Revision ID: 20260626_raw_article_stage
Revises: 20260626_initial_schema
Create Date: 2026-06-26 00:10:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "20260626_raw_article_stage"
down_revision = "20260626_initial_schema"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table(
        "raw_articles",
        sa.Column("id", sa.Integer(), nullable=False),
        sa.Column("source_url", sa.String(length=1000), nullable=False),
        sa.Column("source_name", sa.String(length=255), nullable=True),
        sa.Column("title", sa.String(length=500), nullable=True),
        sa.Column("description", sa.Text(), nullable=True),
        sa.Column("raw_content", sa.Text(), nullable=True),
        sa.Column("raw_html", sa.Text(), nullable=True),
        sa.Column("cover_image_url", sa.String(length=1000), nullable=True),
        sa.Column("published_at", sa.DateTime(), nullable=True),
        sa.Column("scraped_at", sa.DateTime(), nullable=False),
        sa.Column("status", sa.String(length=50), nullable=False),
        sa.Column("error_message", sa.Text(), nullable=True),
        sa.Column("article_id", sa.Integer(), nullable=True),
        sa.Column("processed_at", sa.DateTime(), nullable=True),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(["article_id"], ["articles.id"]),
        sa.UniqueConstraint("source_url"),
    )
    op.create_index(op.f("ix_raw_articles_source_url"), "raw_articles", ["source_url"], unique=True)


def downgrade():
    op.drop_index(op.f("ix_raw_articles_source_url"), table_name="raw_articles")
    op.drop_table("raw_articles")
