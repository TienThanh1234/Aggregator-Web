"""Store ordered article text and image blocks.

Revision ID: 20260819_content_blocks
Revises: 20260817_truth_weights
"""
from alembic import op
import sqlalchemy as sa


revision = "20260819_content_blocks"
down_revision = "20260817_truth_weights"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("articles", sa.Column("content_blocks_json", sa.Text(), nullable=True))
    op.add_column("raw_articles", sa.Column("content_blocks_json", sa.Text(), nullable=True))


def downgrade():
    op.drop_column("raw_articles", "content_blocks_json")
    op.drop_column("articles", "content_blocks_json")
