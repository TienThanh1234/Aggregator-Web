"""Add avatar metadata fields to users.

Revision ID: 20260727_avatar
Revises: f8b01e29c734
Create Date: 2026-07-27
"""

from alembic import op
import sqlalchemy as sa


revision = "20260727_avatar"
down_revision = "f8b01e29c734"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Add nullable avatar columns without affecting existing users."""
    with op.batch_alter_table("users", schema=None) as batch_op:
        batch_op.add_column(sa.Column("avatar_url", sa.String(length=1000), nullable=True))
        batch_op.add_column(sa.Column("avatar_mime_type", sa.String(length=120), nullable=True))
        batch_op.add_column(sa.Column("avatar_uploaded_at", sa.DateTime(), nullable=True))


def downgrade() -> None:
    """Remove avatar metadata fields from users."""
    with op.batch_alter_table("users", schema=None) as batch_op:
        batch_op.drop_column("avatar_uploaded_at")
        batch_op.drop_column("avatar_mime_type")
        batch_op.drop_column("avatar_url")
