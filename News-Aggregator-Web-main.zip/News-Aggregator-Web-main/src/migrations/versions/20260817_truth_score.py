"""Add auditable article truth-score persistence.

Revision ID: 20260817_truth_score
Revises: 20260810_user_dashboard
"""

from alembic import op
import sqlalchemy as sa


revision = "20260817_truth_score"
down_revision = "20260810_user_dashboard"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("articles", sa.Column("truth_score_updated_at", sa.DateTime(), nullable=True))
    op.add_column("articles", sa.Column("truth_score_version", sa.String(length=20), nullable=True))
    op.add_column("scraper_configs", sa.Column("reliability_score", sa.Integer(), nullable=False, server_default="50"))
    op.create_check_constraint("ck_scraper_configs_reliability_score", "scraper_configs", "reliability_score >= 0 AND reliability_score <= 100")
    op.create_table(
        "article_truth_scores",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("article_id", sa.Integer(), sa.ForeignKey("articles.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("total_score", sa.Integer(), nullable=False),
        sa.Column("source_reliability_score", sa.Integer(), nullable=False),
        sa.Column("corroboration_score", sa.Integer(), nullable=False),
        sa.Column("metadata_score", sa.Integer(), nullable=False),
        sa.Column("content_score", sa.Integer(), nullable=False),
        sa.Column("corroborating_article_ids", sa.Text(), nullable=False, server_default="[]"),
        sa.Column("corroborating_domains", sa.Text(), nullable=False, server_default="[]"),
        sa.Column("calculation_version", sa.String(length=20), nullable=False),
        sa.Column("calculated_at", sa.DateTime(), nullable=False),
        sa.CheckConstraint("total_score >= 0 AND total_score <= 100", name="ck_article_truth_scores_total"),
    )
    op.create_index("ix_articles_truth_score", "articles", ["truth_score"])
    op.create_index("ix_articles_truth_score_updated_at", "articles", ["truth_score_updated_at"])
    op.create_index("ix_articles_primary_article_id", "articles", ["primary_article_id"])


def downgrade():
    op.drop_index("ix_articles_primary_article_id", table_name="articles")
    op.drop_index("ix_articles_truth_score_updated_at", table_name="articles")
    op.drop_index("ix_articles_truth_score", table_name="articles")
    op.drop_table("article_truth_scores")
    op.drop_constraint("ck_scraper_configs_reliability_score", "scraper_configs", type_="check")
    op.drop_column("scraper_configs", "reliability_score")
    op.drop_column("articles", "truth_score_version")
    op.drop_column("articles", "truth_score_updated_at")
