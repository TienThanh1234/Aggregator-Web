"""Add per-source selectors for excluding embedded HTML from article content.

Revision ID: 20260821_excl_html
Revises: 20260821_verification_score
"""

from alembic import op
import sqlalchemy as sa


revision = "20260821_excl_html"
down_revision = "20260821_verification_score"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "scraper_configs",
        sa.Column("excluded_html_selectors", sa.Text(), nullable=False, server_default=""),
    )
    op.execute(
        "UPDATE scraper_configs SET excluded_html_selectors = "
        "'aside, .kbwscwl-relatedbox, .VCSortableInPreviewMode' "
        "WHERE lower(source_domain) = 'tuoitre.vn'"
    )


def downgrade():
    op.drop_column("scraper_configs", "excluded_html_selectors")
