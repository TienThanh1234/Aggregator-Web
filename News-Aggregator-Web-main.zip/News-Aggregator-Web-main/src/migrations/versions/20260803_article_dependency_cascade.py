"""Cascade deletion of article-dependent records.

Revision ID: 20260803_article_cascade
Revises: 20260731_admin
Create Date: 2026-08-03
"""

from alembic import op


revision = "20260803_article_cascade"
down_revision = "20260731_admin"
branch_labels = None
depends_on = None


def upgrade() -> None:
    """Allow a database-level article delete to remove dependent records."""
    op.drop_constraint(
        "raw_articles_article_id_fkey", "raw_articles", type_="foreignkey"
    )
    op.create_foreign_key(
        "raw_articles_article_id_fkey",
        "raw_articles",
        "articles",
        ["article_id"],
        ["id"],
        ondelete="CASCADE",
    )
    op.drop_constraint("bookmarks_article_id_fkey", "bookmarks", type_="foreignkey")
    op.create_foreign_key(
        "bookmarks_article_id_fkey",
        "bookmarks",
        "articles",
        ["article_id"],
        ["id"],
        ondelete="CASCADE",
    )


def downgrade() -> None:
    op.drop_constraint(
        "raw_articles_article_id_fkey", "raw_articles", type_="foreignkey"
    )
    op.create_foreign_key(
        "raw_articles_article_id_fkey",
        "raw_articles",
        "articles",
        ["article_id"],
        ["id"],
    )
    op.drop_constraint("bookmarks_article_id_fkey", "bookmarks", type_="foreignkey")
    op.create_foreign_key(
        "bookmarks_article_id_fkey",
        "bookmarks",
        "articles",
        ["article_id"],
        ["id"],
    )
