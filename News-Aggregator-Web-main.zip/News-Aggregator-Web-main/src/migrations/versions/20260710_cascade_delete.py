"""Add cascade delete to article_categories

Revision ID: 20260710_cascade_delete
Revises: 20260626_raw_article_stage
Create Date: 2026-07-10 18:43:00.000000

"""
from alembic import op
import sqlalchemy as sa


revision = "20260710_cascade_delete"
down_revision = "20260626_raw_article_stage"
branch_labels = None
depends_on = None


def upgrade():
    # Drop existing foreign key constraints without cascade delete
    op.drop_constraint("article_categories_article_id_fkey", "article_categories", type_="foreignkey")
    op.drop_constraint("article_categories_category_id_fkey", "article_categories", type_="foreignkey")
    
    # Create new foreign key constraints with ON DELETE CASCADE
    op.create_foreign_key(
        "article_categories_article_id_fkey",
        "article_categories",
        "articles",
        ["article_id"],
        ["id"],
        ondelete="CASCADE"
    )
    op.create_foreign_key(
        "article_categories_category_id_fkey",
        "article_categories",
        "categories",
        ["category_id"],
        ["id"],
        ondelete="CASCADE"
    )


def downgrade():
    op.drop_constraint("article_categories_article_id_fkey", "article_categories", type_="foreignkey")
    op.drop_constraint("article_categories_category_id_fkey", "article_categories", type_="foreignkey")
    
    op.create_foreign_key(
        "article_categories_article_id_fkey",
        "article_categories",
        "articles",
        ["article_id"],
        ["id"]
    )
    op.create_foreign_key(
        "article_categories_category_id_fkey",
        "article_categories",
        "categories",
        ["category_id"],
        ["id"]
    )
