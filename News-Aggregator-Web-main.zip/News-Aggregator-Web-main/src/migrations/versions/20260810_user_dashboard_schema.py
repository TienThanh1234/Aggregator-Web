"""Add user dashboard persistence.

Revision ID: 20260810_user_dashboard
Revises: 1d4334e8cb6b
"""
from alembic import op
import sqlalchemy as sa

revision = "20260810_user_dashboard"
down_revision = "1d4334e8cb6b"
branch_labels = None
depends_on = None

def upgrade():
    op.create_table("user_category_subscriptions", sa.Column("user_id",sa.Integer(),sa.ForeignKey("users.id",ondelete="CASCADE"),primary_key=True),sa.Column("category_id",sa.Integer(),sa.ForeignKey("categories.id",ondelete="CASCADE"),primary_key=True),sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_table("user_source_subscriptions", sa.Column("user_id",sa.Integer(),sa.ForeignKey("users.id",ondelete="CASCADE"),primary_key=True),sa.Column("source_id",sa.Integer(),sa.ForeignKey("scraper_configs.id",ondelete="CASCADE"),primary_key=True),sa.Column("created_at",sa.DateTime(),nullable=False))
    op.create_table("comments",sa.Column("id",sa.Integer(),primary_key=True),sa.Column("user_id",sa.Integer(),sa.ForeignKey("users.id",ondelete="CASCADE"),nullable=False),sa.Column("article_id",sa.Integer(),sa.ForeignKey("articles.id",ondelete="CASCADE"),nullable=False),sa.Column("content",sa.Text(),nullable=False),sa.Column("is_deleted",sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column("created_at",sa.DateTime(),nullable=False),sa.Column("updated_at",sa.DateTime()))
    op.create_index("ix_comments_created_at","comments",["created_at"]);op.create_index("ix_comments_user_id","comments",["user_id"]);op.create_index("ix_comments_article_id","comments",["article_id"])
    op.create_table("reactions",sa.Column("id",sa.Integer(),primary_key=True),sa.Column("user_id",sa.Integer(),sa.ForeignKey("users.id",ondelete="CASCADE"),nullable=False),sa.Column("article_id",sa.Integer(),sa.ForeignKey("articles.id",ondelete="CASCADE"),nullable=False),sa.Column("reaction_type",sa.String(20),nullable=False),sa.Column("created_at",sa.DateTime(),nullable=False),sa.UniqueConstraint("user_id","article_id",name="uq_user_article_reaction"))
    op.create_table("daily_briefs",sa.Column("id",sa.Integer(),primary_key=True),sa.Column("user_id",sa.Integer(),sa.ForeignKey("users.id",ondelete="CASCADE"),nullable=False),sa.Column("content",sa.Text(),nullable=False),sa.Column("source_article_ids",sa.Text()),sa.Column("generated_at",sa.DateTime(),nullable=False),sa.Column("brief_date",sa.Date(),nullable=False),sa.Column("is_read",sa.Boolean(),nullable=False,server_default=sa.false()),sa.UniqueConstraint("user_id","brief_date",name="uq_user_brief_date"))
    op.create_table("user_brief_preferences",sa.Column("id",sa.Integer(),primary_key=True),sa.Column("user_id",sa.Integer(),sa.ForeignKey("users.id",ondelete="CASCADE"),nullable=False,unique=True),sa.Column("is_enabled",sa.Boolean(),nullable=False,server_default=sa.true()),sa.Column("delivery_time",sa.Time(),nullable=False),sa.Column("frequency",sa.String(20),nullable=False),sa.Column("email_delivery",sa.Boolean(),nullable=False,server_default=sa.false()),sa.Column("updated_at",sa.DateTime()))

def downgrade():
    op.drop_table("user_brief_preferences");op.drop_table("daily_briefs");op.drop_table("reactions");op.drop_table("comments");op.drop_table("user_source_subscriptions");op.drop_table("user_category_subscriptions")
