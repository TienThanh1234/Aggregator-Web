"""Add Story Clusters and Trending Score.

Revision ID: 20260817_story_clusters
Revises: 20260817_truth_score
"""
from alembic import op
import sqlalchemy as sa

revision = "20260817_story_clusters"
down_revision = "20260817_truth_score"
branch_labels = None
depends_on = None


def upgrade():
    op.create_table("story_clusters",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("canonical_article_id", sa.Integer(), sa.ForeignKey("articles.id", ondelete="SET NULL")),
        sa.Column("trending_score", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("source_coverage_score", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("velocity_score", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("recency_score", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("source_quality_score", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("accepted_article_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("independent_domain_count", sa.Integer(), nullable=False, server_default="0"),
        sa.Column("last_covered_at", sa.DateTime()), sa.Column("score_updated_at", sa.DateTime()),
        sa.Column("created_at", sa.DateTime(), nullable=False), sa.Column("updated_at", sa.DateTime(), nullable=False))
    op.create_index("ix_story_clusters_last_covered_at", "story_clusters", ["last_covered_at"])
    op.create_table("article_story_memberships",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("article_id", sa.Integer(), sa.ForeignKey("articles.id", ondelete="CASCADE"), nullable=False, unique=True),
        sa.Column("cluster_id", sa.Integer(), sa.ForeignKey("story_clusters.id", ondelete="CASCADE"), nullable=False),
        sa.Column("match_confidence", sa.Float(), nullable=False), sa.Column("status", sa.String(20), nullable=False),
        sa.Column("match_signals_json", sa.Text(), nullable=False, server_default="{}"), sa.Column("matched_at", sa.DateTime(), nullable=False),
        sa.Column("reviewed_at", sa.DateTime()), sa.Column("reviewed_by_user_id", sa.Integer(), sa.ForeignKey("users.id", ondelete="SET NULL")))
    op.create_index("ix_article_story_memberships_cluster_id", "article_story_memberships", ["cluster_id"])
    op.create_index("ix_article_story_memberships_status", "article_story_memberships", ["status"])


def downgrade():
    op.drop_table("article_story_memberships")
    op.drop_table("story_clusters")
