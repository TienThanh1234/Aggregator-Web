"""Add lazy AI clarity analysis and a bilingual ambiguity dictionary.

Revision ID: 20260821_lazy_clarity
Revises: 20260820_image_cdn_domains
"""

from alembic import op
import sqlalchemy as sa
from datetime import datetime


revision = "20260821_lazy_clarity"
down_revision = "20260820_image_cdn_domains"
branch_labels = None
depends_on = None


AMBIGUOUS_WORDS = [
    ("có thể", "vi", "medium", "Khẳng định mang tính khả năng, chưa nêu điều kiện hoặc bằng chứng."),
    ("nhiều khả năng", "vi", "medium", "Dự đoán không kèm mức độ chắc chắn hoặc nguồn xác nhận."),
    ("được cho là", "vi", "high", "Quy nguồn không xác định cho một khẳng định quan trọng."),
    ("theo nguồn tin", "vi", "high", "Nguồn tin chưa được định danh hoặc liên kết."),
    ("một số", "vi", "medium", "Số lượng không được định lượng."),
    ("đáng kể", "vi", "low", "Mức độ không có mốc so sánh hoặc số liệu."),
    ("có dấu hiệu", "vi", "medium", "Dấu hiệu chưa được nêu rõ bằng chứng."),
    ("được biết", "vi", "medium", "Thông tin quy nguồn mơ hồ."),
    ("may", "en", "medium", "Possibility claim without stated conditions or evidence."),
    ("might", "en", "medium", "Possibility claim without stated conditions or evidence."),
    ("reportedly", "en", "high", "Attribution is not identified."),
    ("sources say", "en", "high", "Unnamed-source attribution."),
    ("some", "en", "medium", "Quantity or population is not specified."),
    ("significant", "en", "low", "Magnitude lacks a comparative measure."),
    ("appears to", "en", "medium", "Observation is presented without supporting basis."),
    ("likely", "en", "medium", "Probability is asserted without calibration or evidence."),
]


def upgrade():
    op.add_column("article_truth_scores", sa.Column("base_score", sa.Integer(), nullable=False, server_default="0"))
    op.add_column("article_truth_scores", sa.Column("linguistic_clarity_score", sa.Integer(), nullable=False, server_default="0"))
    op.add_column("article_truth_scores", sa.Column("clarity_status", sa.String(length=20), nullable=False, server_default="pending"))
    op.add_column("article_truth_scores", sa.Column("clarity_content_hash", sa.String(length=64), nullable=True))
    op.add_column("article_truth_scores", sa.Column("clarity_model_version", sa.String(length=40), nullable=True))
    op.add_column("article_truth_scores", sa.Column("clarity_findings_json", sa.Text(), nullable=False, server_default="[]"))
    op.add_column("article_truth_scores", sa.Column("clarity_report", sa.Text(), nullable=True))
    op.add_column("article_truth_scores", sa.Column("clarity_analyzed_at", sa.DateTime(), nullable=True))
    op.create_index("ix_article_truth_scores_clarity_status", "article_truth_scores", ["clarity_status"])
    op.create_table(
        "ambiguous_words",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("term", sa.String(length=120), nullable=False, unique=True),
        sa.Column("language", sa.String(length=8), nullable=False),
        sa.Column("severity", sa.String(length=10), nullable=False, server_default="medium"),
        sa.Column("explanation", sa.String(length=500), nullable=False),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_ambiguous_words_term", "ambiguous_words", ["term"])
    op.create_index("ix_ambiguous_words_language", "ambiguous_words", ["language"])
    op.create_index("ix_ambiguous_words_is_active", "ambiguous_words", ["is_active"])
    op.bulk_insert(
        sa.table(
            "ambiguous_words",
            sa.column("term", sa.String()), sa.column("language", sa.String()),
            sa.column("severity", sa.String()), sa.column("explanation", sa.String()),
            sa.column("is_active", sa.Boolean()), sa.column("created_at", sa.DateTime()),
        ),
        [
            {"term": term, "language": language, "severity": severity, "explanation": explanation, "is_active": True, "created_at": datetime.utcnow()}
            for term, language, severity, explanation in AMBIGUOUS_WORDS
        ],
    )


def downgrade():
    op.drop_table("ambiguous_words")
    op.drop_index("ix_article_truth_scores_clarity_status", table_name="article_truth_scores")
    for column in ("clarity_analyzed_at", "clarity_report", "clarity_findings_json", "clarity_model_version", "clarity_content_hash", "clarity_status", "linguistic_clarity_score", "base_score"):
        op.drop_column("article_truth_scores", column)
