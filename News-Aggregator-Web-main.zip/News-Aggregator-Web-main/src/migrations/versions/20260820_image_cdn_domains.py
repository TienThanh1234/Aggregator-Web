"""Add per-source image CDN allowlists.

Revision ID: 20260820_image_cdn_domains
Revises: 20260819_content_blocks
"""
from alembic import op
import sqlalchemy as sa


revision = "20260820_image_cdn_domains"
down_revision = "20260819_content_blocks"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column(
        "scraper_configs",
        sa.Column("image_cdn_domains", sa.Text(), nullable=False, server_default=""),
    )
    op.execute(
        "UPDATE scraper_configs SET image_cdn_domains = 'thanhnien.mediacdn.vn' "
        "WHERE lower(source_domain) = 'thanhnien.vn'"
    )


def downgrade():
    op.drop_column("scraper_configs", "image_cdn_domains")
