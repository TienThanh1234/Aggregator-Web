"""Add comment moderation, reports, and prohibited-term filtering.

Revision ID: 20260822_admin_mod
Revises: 20260821_excl_html
"""

from alembic import op
import sqlalchemy as sa


revision = "20260822_admin_mod"
down_revision = "20260821_excl_html"
branch_labels = None
depends_on = None


def upgrade():
    op.add_column("comments", sa.Column("is_hidden", sa.Boolean(), nullable=False, server_default=sa.false()))
    op.add_column("comments", sa.Column("moderation_reason", sa.String(length=100), nullable=True))
    op.add_column("comments", sa.Column("moderation_note", sa.Text(), nullable=True))
    op.add_column("comments", sa.Column("moderated_by_id", sa.Integer(), nullable=True))
    op.add_column("comments", sa.Column("moderated_at", sa.DateTime(), nullable=True))
    op.create_foreign_key("fk_comments_moderated_by", "comments", "users", ["moderated_by_id"], ["id"])
    op.create_index("ix_comments_is_hidden", "comments", ["is_hidden"])
    op.create_index("ix_comments_moderated_at", "comments", ["moderated_at"])

    op.create_table(
        "comment_moderation_actions",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("comment_id", sa.Integer(), sa.ForeignKey("comments.id", ondelete="CASCADE"), nullable=False),
        sa.Column("admin_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("action", sa.String(length=30), nullable=False),
        sa.Column("reason", sa.String(length=100), nullable=False),
        sa.Column("note", sa.Text(), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    op.create_index("ix_comment_moderation_actions_comment_id", "comment_moderation_actions", ["comment_id"])
    op.create_index("ix_comment_moderation_actions_admin_id", "comment_moderation_actions", ["admin_id"])
    op.create_index("ix_comment_moderation_actions_action", "comment_moderation_actions", ["action"])
    op.create_index("ix_comment_moderation_actions_created_at", "comment_moderation_actions", ["created_at"])

    op.create_table(
        "comment_reports",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("comment_id", sa.Integer(), sa.ForeignKey("comments.id", ondelete="CASCADE"), nullable=False),
        sa.Column("reporter_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("reason", sa.String(length=50), nullable=False),
        sa.Column("explanation", sa.Text(), nullable=True),
        sa.Column("status", sa.String(length=20), nullable=False, server_default="open"),
        sa.Column("resolution_action_id", sa.Integer(), sa.ForeignKey("comment_moderation_actions.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("resolved_at", sa.DateTime(), nullable=True),
        sa.UniqueConstraint("comment_id", "reporter_id", name="uq_comment_reporter"),
    )
    for column in ("comment_id", "reporter_id", "reason", "status", "created_at"):
        op.create_index(f"ix_comment_reports_{column}", "comment_reports", [column])

    op.create_table(
        "comment_prohibited_terms",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("display_term", sa.String(length=255), nullable=False),
        sa.Column("normalized_term", sa.String(length=255), nullable=False, unique=True),
        sa.Column("category", sa.String(length=80), nullable=True),
        sa.Column("is_active", sa.Boolean(), nullable=False, server_default=sa.true()),
        sa.Column("created_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("updated_by_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=True),
        sa.Column("created_at", sa.DateTime(), nullable=False),
        sa.Column("updated_at", sa.DateTime(), nullable=True),
    )
    op.create_index("ix_comment_prohibited_terms_normalized_term", "comment_prohibited_terms", ["normalized_term"])
    op.create_index("ix_comment_prohibited_terms_is_active", "comment_prohibited_terms", ["is_active"])

    op.create_table(
        "comment_filter_events",
        sa.Column("id", sa.Integer(), primary_key=True),
        sa.Column("user_id", sa.Integer(), sa.ForeignKey("users.id"), nullable=False),
        sa.Column("article_id", sa.Integer(), sa.ForeignKey("articles.id"), nullable=False),
        sa.Column("prohibited_term_id", sa.Integer(), sa.ForeignKey("comment_prohibited_terms.id"), nullable=True),
        sa.Column("outcome", sa.String(length=30), nullable=False, server_default="blocked"),
        sa.Column("created_at", sa.DateTime(), nullable=False),
    )
    for column in ("user_id", "article_id", "prohibited_term_id", "created_at"):
        op.create_index(f"ix_comment_filter_events_{column}", "comment_filter_events", [column])


def downgrade():
    for column in ("created_at", "prohibited_term_id", "article_id", "user_id"):
        op.drop_index(f"ix_comment_filter_events_{column}", table_name="comment_filter_events")
    op.drop_table("comment_filter_events")
    op.drop_index("ix_comment_prohibited_terms_is_active", table_name="comment_prohibited_terms")
    op.drop_index("ix_comment_prohibited_terms_normalized_term", table_name="comment_prohibited_terms")
    op.drop_table("comment_prohibited_terms")
    for column in ("created_at", "status", "reason", "reporter_id", "comment_id"):
        op.drop_index(f"ix_comment_reports_{column}", table_name="comment_reports")
    op.drop_table("comment_reports")
    for column in ("created_at", "action", "admin_id", "comment_id"):
        op.drop_index(f"ix_comment_moderation_actions_{column}", table_name="comment_moderation_actions")
    op.drop_table("comment_moderation_actions")
    op.drop_index("ix_comments_moderated_at", table_name="comments")
    op.drop_index("ix_comments_is_hidden", table_name="comments")
    op.drop_constraint("fk_comments_moderated_by", "comments", type_="foreignkey")
    op.drop_column("comments", "moderated_at")
    op.drop_column("comments", "moderated_by_id")
    op.drop_column("comments", "moderation_note")
    op.drop_column("comments", "moderation_reason")
    op.drop_column("comments", "is_hidden")
