import logging
from app import create_app
from models import db, Category, KeywordRule

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def seed_vn_rules():
    app = create_app()
    with app.app_context():
        # Danh sách từ khóa tiếng Việt mở rộng theo từng Category
        vn_rules = {
            "Technology": [
                "điện thoại", "máy tính", "công nghệ", "phần mềm", "trí tuệ nhân tạo", 
                "smartphone", "laptop", "apple", "samsung", "phần cứng", "viễn thông", 
                "bảo mật", "ai", "mạng xã hội", "internet", "tin học", "thiết bị", "ứng dụng",
                "chatgpt", "chip", "màn hình"
            ],
            "Sports": [
                "bóng đá", "thể thao", "quần vợt", "tennis", "bóng rổ", "ngoại hạng anh", 
                "vô địch", "huy chương", "olympic", "cầu thủ", "huấn luyện viên", "sea games",
                "world cup", "euro", "v-league", "giải đấu", "bóng chuyền", "đội tuyển"
            ],
            "Business": [
                "kinh doanh", "tài chính", "chứng khoán", "ngân hàng", "bất động sản", 
                "doanh nghiệp", "thị trường", "cổ phiếu", "đầu tư", "kinh tế", "xuất nhập khẩu", 
                "lạm phát", "tỷ giá", "vàng", "doanh thu", "lợi nhuận", "startup", "khởi nghiệp"
            ],
            "Health": [
                "sức khỏe", "y tế", "bệnh viện", "bác sĩ", "ung thư", "vắc xin", 
                "dịch bệnh", "dinh dưỡng", "thuốc", "chữa bệnh", "y khoa", "phẫu thuật",
                "bệnh nhân", "virus", "chăm sóc", "phòng khám", "tiêm chủng"
            ],
            "Entertainment": [
                "giải trí", "showbiz", "điện ảnh", "ca sĩ", "diễn viên", "phim", 
                "âm nhạc", "nghệ sĩ", "hoa hậu", "truyền hình", "nghệ thuật", "liveshow",
                "nhạc trẻ", "sân khấu", "vpop", "kpop", "hollywood", "gameshow"
            ],
            "Science": [
                "khoa học", "vũ trụ", "nasa", "nghiên cứu", "phát minh", "sinh học", 
                "hóa học", "vật lý", "hành tinh", "thiên văn", "khảo cổ", "công nghệ sinh học",
                "phát hiện", "động vật", "thực vật", "biến đổi khí hậu", "môi trường"
            ]
        }
        
        rules_added = 0
        rules_skipped = 0
        
        for category_name, keywords in vn_rules.items():
            cat = Category.query.filter_by(name=category_name).first()
            if not cat:
                logger.warning(f"Category '{category_name}' không tồn tại. Bỏ qua.")
                continue
                
            for kw in keywords:
                # Đảm bảo từ khóa luôn là chữ thường (lowercase)
                keyword_lower = kw.lower()
                
                # Kiểm tra xem từ khóa đã tồn tại chưa
                existing_rule = KeywordRule.query.filter_by(keyword=keyword_lower).first()
                if not existing_rule:
                    rule = KeywordRule(keyword=keyword_lower, category_id=cat.id)
                    db.session.add(rule)
                    rules_added += 1
                else:
                    rules_skipped += 1
                    
        db.session.commit()
        
        logger.info(f"Đã thêm thành công {rules_added} rules tiếng Việt.")
        logger.info(f"Đã bỏ qua {rules_skipped} rules (vì đã tồn tại).")

if __name__ == "__main__":
    seed_vn_rules()
