---
agent: speckit.git.remote
---
