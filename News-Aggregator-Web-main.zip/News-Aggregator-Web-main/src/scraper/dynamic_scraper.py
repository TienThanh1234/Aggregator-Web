import json
import logging
import os
import re
from datetime import datetime
from typing import Callable, List, Dict, Any, Optional
from urllib.parse import urljoin, urlparse

from bs4 import BeautifulSoup
from scraper.base_scraper import BaseScraper
from services.scraper_service import ScraperService
from services.time_service import vietnam_now

logger = logging.getLogger(__name__)


class DynamicScraper(BaseScraper):
    """
    Concrete implementation of BaseScraper that uses configuration-driven
    selectors instead of hardcoded constants.
    """

    def __init__(
        self,
        config,
        max_articles_override: Optional[int] = None,
        progress_callback: Optional[Callable[[Dict[str, Any]], None]] = None,
    ):
        """
        Initialize scraper from a ScraperConfig model instance or dict.
        """
        # Accept either SQLAlchemy model or dictionary
        config_dict = config if isinstance(config, dict) else {
            "source_name": config.source_name,
            "source_domain": config.source_domain,
            "target_url": config.target_url,
            "max_articles_per_run": max_articles_override if max_articles_override is not None else config.max_articles_per_run,
            "article_list_selector": config.article_list_selector,
            "title_selector": config.title_selector,
            "description_selector": config.description_selector,
            "content_selector": config.content_selector,
            "excluded_html_selectors": config.excluded_html_selectors,
            "image_selector": config.image_selector,
            "published_date_selector": config.published_date_selector,
        }

        super().__init__(
            source_name=config_dict.get("source_name", "DynamicScraper"),
            base_url=f"https://{config_dict.get('source_domain', '')}",
            timeout=10,
            max_retries=3,
        )
        self.config = config_dict
        self.target_url = config_dict.get("target_url", "")
        self.article_list_selector = config_dict.get("article_list_selector", "")
        self.title_selector = config_dict.get("title_selector", "")
        self.description_selector = config_dict.get("description_selector", "")
        self.content_selector = config_dict.get("content_selector", "")
        self.excluded_html_selectors = config_dict.get("excluded_html_selectors", "")
        self.image_selector = config_dict.get("image_selector", "")
        self.published_date_selector = config_dict.get("published_date_selector", "")
        self.progress_callback = progress_callback

    def scrape(self) -> List[Dict[str, Any]]:
        """Orchestrate the full scraping flow using dynamic selectors."""
        articles = []
        try:
            logger.info("[INFO] Starting dynamic scrape for %s", self.source_name)
            
            listing_html = self.fetch_page(self.target_url)
            if not listing_html:
                logger.warning("[WARNING] Failed to fetch listing page for %s", self.source_name)
                return articles
            
            links = self._extract_article_links(listing_html)
            logger.info("[INFO] Found %d article links from %s", len(links), self.source_name)
            
            limit = max(0, int(self.config.get("max_articles_per_run", 10)))

            # Do not stop after inspecting `limit` links: a listing often starts
            # with articles already stored from an earlier run.  Continue through
            # the remaining links until we have `limit` *new* valid articles.
            for link in links:
                if len(articles) >= limit:
                    break
                if ScraperService.article_exists(link) or ScraperService.raw_article_exists(link):
                    logger.info("[SKIP] Existing article: %s", link)
                    continue
                try:
                    detail_html = self.fetch_page(link)
                    if not detail_html:
                        continue
                    
                    data = self._extract_article_data(link, detail_html)
                    if data and self.validate_data(data):
                        articles.append(data)
                        if self.progress_callback:
                            try:
                                self.progress_callback(data)
                            except Exception as exc:
                                # Progress reporting must never interrupt the
                                # actual ingestion pipeline.
                                logger.warning("[WARNING] Scraper progress callback failed: %s", exc)
                except Exception as exc:
                    logger.error("[ERROR] Failed to process %s: %s", link, exc)
                    
            logger.info("[SUCCESS] Scraped %d articles from %s", len(articles), self.source_name)
        except Exception as exc:
            logger.error("[ERROR] Scrape failed for %s: %s", self.source_name, exc)
            
        return articles

    def _extract_article_links(self, html: str) -> List[str]:
        """Extract article links using configured selector and domain filtering."""
        soup = self.parse_html(html)
        if not soup or not self.article_list_selector:
            return []
            
        base_domain = urlparse(self.base_url).netloc
        links = []
        seen_links = set()
        
        try:
            for elem in soup.select(self.article_list_selector):
                href = elem.get("href")
                if not href:
                    continue
                
                if not href.startswith("http"):
                    href = urljoin(self.base_url, href)
                    
                parsed_href = urlparse(href)
                
                # Filter logic: must be http/https, on base domain, and have a valid path
                if href.startswith("http") and base_domain in parsed_href.netloc:
                    path = parsed_href.path
                    if path.endswith(".html") or path.endswith(".htm") or (path and path != "/"):
                        if href not in seen_links:
                            seen_links.add(href)
                            links.append(href)
        except Exception as exc:
            logger.error("[ERROR] Failed to extract links: %s", exc)
                    
        return list(links)

    def _extract_article_data(self, url: str, html: str) -> Optional[Dict[str, Any]]:
        """Extract article metadata using configured selectors."""
        soup = self.parse_html(html)
        if not soup:
            return None
            
        try:
            title = None
            if self.title_selector:
                title_elem = soup.select_one(self.title_selector)
                if title_elem:
                    title = title_elem.get_text(strip=True)
                    
            description = None
            if self.description_selector:
                desc_elem = soup.select_one(self.description_selector)
                if desc_elem:
                    if desc_elem.name == "meta":
                        description = desc_elem.get("content", "").strip()
                    else:
                        description = desc_elem.get_text(strip=True)
                        
            if not description:
                og_desc = soup.find("meta", property="og:description")
                if not og_desc:
                    og_desc = soup.find("meta", attrs={"name": "description"})
                if og_desc:
                    description = og_desc.get("content", "").strip()
                    
            cover_image_url = None
            og_meta = soup.find("meta", property="og:image")
            if og_meta:
                cover_image_url = og_meta.get("content", "").strip()
                
            if not cover_image_url and self.image_selector:
                img_elem = soup.select_one(self.image_selector)
                if img_elem:
                    cover_image_url = img_elem.get("data-src", "").strip()
                    if not cover_image_url:
                        src = img_elem.get("src", "").strip()
                        if src and "data:image" not in src:
                            cover_image_url = src
                            
            if cover_image_url and not cover_image_url.startswith("http"):
                cover_image_url = urljoin(self.base_url, cover_image_url)
                
            raw_content = None
            content_blocks_json = None
            if self.content_selector:
                content_elem = soup.select_one(self.content_selector)
                if content_elem:
                    blocks = self._extract_content_blocks(content_elem, url)
                    content_blocks_json = json.dumps(blocks, ensure_ascii=False) if blocks else None
                    raw_content = "\n\n".join(
                        block["text"] for block in blocks if block["type"] == "paragraph"
                    )
                    # The first in-article image is the reader thumbnail. This
                    # is more faithful than an unrelated og:image on some sites.
                    first_image = next((block["url"] for block in blocks if block["type"] == "image"), None)
                    if first_image:
                        cover_image_url = first_image
                    
            published_at = self._parse_date_heuristic(soup)
            categories = self._extract_categories(soup)
            
            return {
                "source_url": url,
                "source_name": self.source_name,
                "title": title,
                "description": description,
                "cover_image_url": cover_image_url,
                "raw_content": raw_content,
                "content_blocks_json": content_blocks_json,
                "raw_html": html,
                "published_at": published_at,
                "categories": categories,
                "status": "pending",
            }
        except Exception as exc:
            logger.error("[ERROR] Failed to extract data from %s: %s", url, exc)
            
        return None

    @staticmethod
    def _image_url(image, article_url: str) -> str | None:
        """Return a usable source image URL, including lazy-loaded images."""
        for attribute in ("data-src", "data-original", "data-lazy-src", "src"):
            value = (image.get(attribute) or "").strip()
            if value and not value.startswith("data:"):
                return urljoin(article_url, value)
        return None

    def _extract_content_blocks(self, content_elem, article_url: str) -> list[dict[str, str]]:
        """Extract paragraphs and figures in document order without captions in text.

        Sites commonly wrap article photos in ``figure``/``figcaption`` but some
        use caption classes instead, so both patterns are supported.

        The configured content selector is intentionally permissive because it
        must work across several publishers.  It can therefore also contain
        widgets injected by the publisher ("read more", related-news cards,
        adverts, etc.).  Those widgets look like normal paragraphs and images
        to BeautifulSoup, so exclude their complete subtree before extracting
        blocks.  This keeps the article text used by summaries and fact checks
        limited to the actual report.
        """
        blocks: list[dict[str, str]] = []
        handled_images: set[int] = set()
        ignored_text = {"figcaption", "caption", "photo-caption", "image-caption"}
        configured_exclusions = self._configured_exclusions(content_elem)

        for element in content_elem.find_all(["p", "h2", "h3", "h4", "figure", "img"], recursive=True):
            if id(element) in configured_exclusions or self._is_non_article_descendant(element, content_elem):
                continue
            classes = " ".join(element.get("class", []))
            if element.name in {"p", "h2", "h3", "h4"}:
                if element.find_parent("figure") or any(token in classes.lower() for token in ignored_text):
                    continue
                # A photo wrapper may be a paragraph; render its image instead
                # of treating the caption as prose.
                if element.find("img"):
                    continue
                text = element.get_text(" ", strip=True)
                if text:
                    blocks.append({"type": "paragraph", "text": text})
                continue

            image = element if element.name == "img" else element.find("img")
            if not image or id(image) in handled_images:
                continue
            handled_images.add(id(image))
            image_url = self._image_url(image, article_url)
            if not image_url:
                continue
            figure = image.find_parent("figure") or element
            caption = figure.find("figcaption")
            if not caption:
                caption = figure.find(class_=re.compile(r"(?:photo|image)[-_ ]?caption|caption", re.I))
            caption_text = caption.get_text(" ", strip=True) if caption else ""
            blocks.append({
                "type": "image",
                "url": image_url,
                "alt": (image.get("alt") or caption_text or "Article image").strip(),
                "caption": caption_text,
            })
        return blocks

    def _configured_exclusions(self, content_elem) -> set[int]:
        """Return descendants matched by the source-configured exclusion CSS."""
        selectors = str(self.excluded_html_selectors or "").strip()
        if not selectors:
            return set()
        try:
            excluded = content_elem.select(selectors)
        except Exception as exc:
            logger.warning("[WARNING] Ignoring invalid excluded HTML selector for %s: %s", self.source_name, exc)
            return set()

        # Every extracted candidate can be nested inside a matched wrapper.
        matched_ids: set[int] = set()
        for wrapper in excluded:
            matched_ids.add(id(wrapper))
            matched_ids.update(id(descendant) for descendant in wrapper.descendants)
        return matched_ids

    @staticmethod
    def _is_non_article_descendant(element, content_root) -> bool:
        """Return whether *element* belongs to an embedded, non-body widget."""
        ignored_tags = {"aside", "nav", "footer", "form", "script", "style", "noscript"}
        # Keep the terms specific to UI/widget naming; do not match ordinary
        # prose, which may itself mention a related event or advertisement.
        ignored_marker = re.compile(
            r"(?:^|[-_\s])(?:related(?:box)?|recommend(?:ed)?|other-news|news-other|"
            r"article-other|article-related|read-more|readmore|suggest(?:ion)?|"
            r"advert(?:isement)?|ads?|banner|native-ad|promotion|social|share|"
            r"comment|newsletter|callout|vcsortableinpreviewmode)(?:$|[-_\s])",
            re.I,
        )

        current = element
        while current is not None:
            if getattr(current, "name", None) in ignored_tags:
                return True
            marker = " ".join(
                str(value) for value in (
                    current.get("id"),
                    " ".join(current.get("class", [])),
                    current.get("data-testid"),
                    current.get("role"),
                ) if value
            )
            if ignored_marker.search(marker):
                return True
            if current is content_root:
                break
            current = current.parent
        return False

    def _parse_date_heuristic(self, soup: BeautifulSoup) -> Optional[datetime]:
        """Extract and parse publication date using various heuristics."""
        if not self.published_date_selector:
            return None
            
        try:
            date_elem = soup.select_one(self.published_date_selector)
            if not date_elem:
                return None
                
            text = date_elem.get_text(strip=True)
            
            # ISO 8601: YYYY-MM-DDTHH:MM:SS
            iso_match = re.search(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})", text)
            if iso_match:
                try:
                    return datetime.fromisoformat(iso_match.group(1))
                except ValueError:
                    pass
                
            # yyyy-mm-dd HH:MM
            match = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})\s+(\d{1,2}):(\d{2})", text)
            if match:
                y, m, d, h, mn = map(int, match.groups())
                return datetime(y, m, d, h, mn)
                
            # yyyy-mm-dd
            match = re.search(r"(\d{4})-(\d{1,2})-(\d{1,2})", text)
            if match:
                y, m, d = map(int, match.groups())
                return datetime(y, m, d)
                
            # dd/mm/yyyy, HH:MM or dd/m/yyyy HH:MM
            match = re.search(r"(\d{1,2})/(\d{1,2})/(\d{4})[^\d]*(\d{1,2}):(\d{2})", text)
            if match:
                d, m, y, h, mn = map(int, match.groups())
                return datetime(y, m, d, h, mn)
                
            # dd/mm/yyyy
            match = re.search(r"(\d{1,2})/(\d{1,2})/(\d{4})", text)
            if match:
                d, m, y = map(int, match.groups())
                return datetime(y, m, d)
        except Exception as exc:
            logger.warning("[WARNING] Failed to parse date heuristic: %s", exc)
            
        return None

    def _extract_categories(self, soup: BeautifulSoup) -> List[str]:
        """Extract categories/tags using meta keywords or breadcrumbs."""
        categories = []
        meta_keywords = soup.find("meta", {"name": "keywords"})
        if meta_keywords and meta_keywords.get("content"):
            categories.extend([k.strip() for k in meta_keywords["content"].split(",") if k.strip()])
        return categories

    def validate_data(self, data: Dict[str, Any]) -> bool:
        """Validate required fields."""
        if not data.get("source_url"):
            logger.warning("[WARNING] Article missing source_url")
            return False
            
        if not data.get("title"):
            logger.warning("[WARNING] Article missing title for %s", data.get("source_url"))
            return False
            
        return True

    def transform(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """Normalize raw extracted data."""
        return {
            "source_url": data.get("source_url", "").strip(),
            "source_name": data.get("source_name", self.source_name),
            "title": data.get("title", "").strip()[:500],
            "description": (data.get("description", "") or "").strip(),
            "raw_content": (data.get("raw_content", "") or "").strip(),
            "content_blocks_json": data.get("content_blocks_json"),
            "cover_image_url": (data.get("cover_image_url", "") or "").strip(),
            "published_at": data.get("published_at"),
            "scraped_at": vietnam_now(),
            "status": "pending",
        }

    @staticmethod
    def test_selectors(url: str, selectors_dict: Dict[str, str]) -> Dict[str, Any]:
        """
        Test the given selectors on a URL without persisting data.
        
        Args:
            url: URL to test against.
            selectors_dict: Dictionary of CSS selectors.
            
        Returns:
            Dictionary with preview results of selectors.
        """
        # Create a transient subclass to use fetch_page
        class TempScraper(BaseScraper):
            def scrape(self): pass
            def validate_data(self, data): pass
            def transform(self, data): pass
            
        preview = {}
        with TempScraper("TestScraper", url) as scraper:
            html = scraper.fetch_page(url)
            if not html:
                return {"error": f"Failed to fetch page: {url}"}
                
            soup = scraper.parse_html(html)
            if not soup:
                return {"error": "Failed to parse HTML"}
                
            for key, selector in selectors_dict.items():
                if not selector:
                    preview[key] = None
                    continue
                    
                try:
                    if key == "article_list_selector":
                        elems = soup.select(selector)
                        preview[key] = [e.get("href") for e in elems if e.get("href")][:5]
                    elif key == "image_selector":
                        elem = soup.select_one(selector)
                        preview[key] = elem.get("data-src") or elem.get("src") if elem else None
                    else:
                        elem = soup.select_one(selector)
                        preview[key] = elem.get_text(strip=True) if elem else None
                except Exception as exc:
                    preview[key] = f"Error: {str(exc)}"
                    
        return preview
