"""
Base Scraper Abstract Class

Defines the contract and shared logic for all news source scrapers.
All concrete scrapers must inherit from BaseScraper and implement the required methods.
"""

import logging
from abc import ABC, abstractmethod
from datetime import datetime
from typing import List, Optional, Dict, Any

import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry
from bs4 import BeautifulSoup

logger = logging.getLogger(__name__)


class BaseScraper(ABC):
    """
    Abstract base class for all news source scrapers.

    Provides:
    - HTTP request handling with retry logic
    - Error handling and logging
    - Data validation framework
    - Database interaction patterns

    Subclasses must implement:
    - scrape(): Full ingestion flow
    - validate_data(): Data validation before persistence
    - transform(): Normalize data into internal representation
    """

    def __init__(
        self,
        source_name: str,
        base_url: str,
        timeout: int = 10,
        max_retries: int = 3,
    ):
        """
        Initialize the scraper.

        Args:
            source_name: Human-readable name of the news source
            base_url: Base URL of the news source
            timeout: HTTP request timeout in seconds
            max_retries: Number of retries for transient failures
        """
        self.source_name = source_name
        self.base_url = base_url
        self.timeout = timeout
        self.max_retries = max_retries
        self.session = self._create_session()

    def _create_session(self) -> requests.Session:
        """
        Create a requests session with retry strategy.

        Returns:
            Configured requests.Session with exponential backoff.
        """
        session = requests.Session()
        retry_strategy = Retry(
            total=self.max_retries,
            backoff_factor=1,
            status_forcelist=[429, 500, 502, 503, 504],
            allowed_methods=["GET", "HEAD"],
        )
        adapter = HTTPAdapter(max_retries=retry_strategy)
        session.mount("http://", adapter)
        session.mount("https://", adapter)
        session.headers.update({
            "User-Agent": (
                "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                "AppleWebKit/537.36 (KHTML, like Gecko) "
                "Chrome/126.0.0.0 Safari/537.36"
            ),
            "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8",
            "Accept-Language": "vi-VN,vi;q=0.9,en-US;q=0.8,en;q=0.7",
            "Accept-Encoding": "gzip, deflate",
            "Referer": "https://vnexpress.net/",
            "Connection": "keep-alive",
            "Sec-Fetch-Dest": "document",
            "Sec-Fetch-Mode": "navigate",
            "Sec-Fetch-Site": "same-origin",
        })
        return session

    def fetch_page(self, url: str) -> Optional[str]:
        """
        Fetch HTML content from a URL with error handling.

        Args:
            url: URL to fetch

        Returns:
            HTML content as string, or None on failure

        Logs errors without raising exceptions to allow graceful degradation.
        """
        try:
            response = self.session.get(url, timeout=self.timeout)
            response.raise_for_status()
            return response.text
        except requests.exceptions.Timeout:
            logger.error(
                "[ERROR] Timeout fetching %s from %s",
                url,
                self.source_name,
            )
        except requests.exceptions.ConnectionError:
            logger.error(
                "[ERROR] Connection error fetching %s from %s",
                url,
                self.source_name,
            )
        except requests.exceptions.HTTPError as exc:
            logger.error(
                "[ERROR] HTTP %s error fetching %s from %s: %s",
                exc.response.status_code,
                url,
                self.source_name,
                exc,
            )
        except requests.exceptions.RequestException as exc:
            logger.error(
                "[ERROR] Request failed for %s from %s: %s",
                url,
                self.source_name,
                exc,
            )
        return None

    def parse_html(self, html: str) -> Optional[BeautifulSoup]:
        """
        Parse HTML content into a BeautifulSoup object.

        Args:
            html: Raw HTML content

        Returns:
            BeautifulSoup object, or None on parsing failure
        """
        try:
            return BeautifulSoup(html, "html.parser")
        except Exception as exc:
            logger.error(
                "[ERROR] Failed to parse HTML from %s: %s",
                self.source_name,
                exc,
            )
        return None

    @abstractmethod
    def scrape(self) -> List[Dict[str, Any]]:
        """
        Orchestrate the full scraping flow.

        Must be implemented by subclass.

        Returns:
            List of raw article dictionaries ready for validation and transformation.
        """
        pass

    @abstractmethod
    def validate_data(self, data: Dict[str, Any]) -> bool:
        """
        Validate that raw scraped data meets minimum requirements.

        Must be implemented by subclass.

        Args:
            data: Raw scraped article dictionary

        Returns:
            True if data passes validation, False otherwise
        """
        pass

    @abstractmethod
    def transform(self, data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Normalize and transform raw data into internal representation.

        Must be implemented by subclass.

        Args:
            data: Raw scraped article dictionary

        Returns:
            Transformed dictionary ready for database persistence
        """
        pass

    def close(self) -> None:
        """Clean up resources (e.g., close HTTP session)."""
        self.session.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        """Context manager exit."""
        self.close()
