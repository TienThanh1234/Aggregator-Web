import logging
from app import create_app
from models import db, ScraperConfig, SystemSetting, Category, KeywordRule

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def seed():
    app = create_app()
    with app.app_context():
        db.create_all()

        # Seed System Settings
        settings = [
            SystemSetting(key="scraping_interval_minutes", value="60", description="Scraper interval in minutes"),
            SystemSetting(key="cleanup_interval_days", value="1", description="Cleanup interval in days"),
            SystemSetting(key="retention_days", value="30", description="Data retention period in days"),
        ]

        for s in settings:
            existing = db.session.get(SystemSetting, s.key)
            if not existing:
                db.session.add(s)
                logger.info(f"Added setting {s.key}")

        # Seed VnExpress
        vnexpress = ScraperConfig.query.filter_by(source_domain="vnexpress.net").first()
        if not vnexpress:
            vnexpress = ScraperConfig(
                source_name="VNExpress - Technology",
                source_domain="vnexpress.net",
                target_url="https://vnexpress.net/so-hoa/cong-nghe",
                is_enabled=True,
                max_articles_per_run=10,
                article_list_selector=".title-news a, h2.title-news a, h3.title-news a, a.article-link",
                title_selector="h1.title-detail, h2.title-news, h3.title-news, .title-news",
                description_selector="p.description, .desc, p.summary",
                content_selector="article.fck_detail, .fck_detail, article, .articlebody",
                excluded_html_selectors="aside, .box-related, .related-news, .item-related, .banner-ads, .advertisement, .social-share",
                image_selector="img.image-news, .image-news img, meta[property='og:image']",
                published_date_selector="span.date, .header-content .date, .datePublished",
            )
            db.session.add(vnexpress)
            logger.info("Added VNExpress config")

        # Seed TuoiTre
        tuoitre = ScraperConfig.query.filter_by(source_domain="tuoitre.vn").first()
        if not tuoitre:
            tuoitre = ScraperConfig(
                source_name="Tuổi Trẻ - Tech",
                source_domain="tuoitre.vn",
                target_url="https://tuoitre.vn/cong-nghe.htm",
                is_enabled=True,
                max_articles_per_run=10,
                article_list_selector="h3.title-news a, h2.title-news a, .box-category-item .title-news a",
                title_selector="h1.article-title, h1.detail-title",
                description_selector="h2.sapo, p.sapo, .detail-sapo",
                content_selector="div.detail-content, .detail-c, article",
                excluded_html_selectors="aside, .kbwscwl-relatedbox, .VCSortableInPreviewMode",
                image_selector=".detail-content img, meta[property='og:image']",
                published_date_selector=".detail-time, .date, meta[property='article:published_time']",
            )
            db.session.add(tuoitre)
            logger.info("Added TuoiTre config")

        db.session.commit()

        # Seed Categories
        categories_to_seed = ["Technology", "Sports", "Business", "Health", "Entertainment", "Science", "General"]
        category_objects = {}
        for cat_name in categories_to_seed:
            cat = Category.query.filter_by(name=cat_name).first()
            if not cat:
                cat = Category(name=cat_name)
                db.session.add(cat)
                logger.info(f"Added category: {cat_name}")
            category_objects[cat_name] = cat
        db.session.commit()

        # Seed Keyword Rules
        keyword_rules_to_seed = [
            ("smartphone", "Technology"),
            ("software", "Technology"),
            ("ai", "Technology"),
            ("football", "Sports"),
            ("tennis", "Sports"),
            ("finance", "Business"),
            ("medicine", "Health"),
            ("movie", "Entertainment"),
            ("research", "Science")
        ]
        
        for keyword, target_category in keyword_rules_to_seed:
            cat = Category.query.filter_by(name=target_category).first()
            if cat:
                rule = KeywordRule.query.filter_by(keyword=keyword.lower()).first()
                if not rule:
                    rule = KeywordRule(keyword=keyword.lower(), category_id=cat.id)
                    db.session.add(rule)
                    logger.info(f"Added rule: '{keyword}' -> {target_category}")
                    
        db.session.commit()

        logger.info("Database seeding completed.")

if __name__ == "__main__":
    seed()
