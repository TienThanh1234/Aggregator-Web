import logging
from app import create_app
from models import db, Category, KeywordRule

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def seed_en_rules():
    app = create_app()
    with app.app_context():
        # Comprehensive list of English keywords mapped to fixed Categories
        en_rules = {
            "Technology": [
                "smartphone", "phone", "laptop", "computer", "software", "hardware", 
                "ai", "artificial intelligence", "machine learning", "tech", "internet", 
                "cyber", "cybersecurity", "network", "device", "gadget", "apple", 
                "samsung", "microsoft", "google"
            ],
            "Sports": [
                "soccer", "football", "basketball", "tennis", "nba", "premier league", 
                "olympics", "medal", "tournament", "coach", "athlete", "sports", 
                "championship", "stadium", "cricket"
            ],
            "Business": [
                "business", "finance", "stock", "market", "economy", "investment", 
                "trading", "bank", "real estate", "inflation", "interest rate", 
                "startup", "revenue", "profit", "corporate", "commerce"
            ],
            "Health": [
                "health", "medical", "medicine", "doctor", "hospital", "cancer", 
                "vaccine", "virus", "disease", "nutrition", "diet", "surgery", 
                "clinic", "patient", "wellness", "fitness"
            ],
            "Entertainment": [
                "entertainment", "movies", "hollywood", "music", "singer", "actor", 
                "actress", "film", "theater", "showbiz", "celebrity", "concert", 
                "pop", "rock", "art", "television"
            ],
            "Science": [
                "science", "space", "nasa", "biology", "chemistry", "physics", 
                "research", "discovery", "astronomy", "galaxy", "dna", "climate change", 
                "environment", "fossil", "archaeology"
            ]
        }
        
        rules_added = 0
        rules_skipped = 0
        
        for category_name, keywords in en_rules.items():
            cat = Category.query.filter_by(name=category_name).first()
            if not cat:
                logger.warning(f"Category '{category_name}' does not exist. Skipping.")
                continue
                
            for kw in keywords:
                # Ensure lowercase for consistency
                keyword_lower = kw.lower()
                
                # Check if rule already exists
                existing_rule = KeywordRule.query.filter_by(keyword=keyword_lower).first()
                if not existing_rule:
                    rule = KeywordRule(keyword=keyword_lower, category_id=cat.id)
                    db.session.add(rule)
                    rules_added += 1
                else:
                    rules_skipped += 1
                    
        db.session.commit()
        
        logger.info(f"Successfully added {rules_added} English rules.")
        logger.info(f"Skipped {rules_skipped} rules (already existed).")

if __name__ == "__main__":
    seed_en_rules()
