/** Optional refresh behavior for the server-rendered recommendation panel. */
(() => {
  "use strict";

  const byId = id => document.getElementById(id);

  function setStatus(message) {
    const status = byId("recommendations-status");
    if (status) status.textContent = message;
  }

  function emptyMessage(meta) {
    if (meta?.empty_state === "no_profile") {
      return "Follow topics or save articles to start receiving recommendations.";
    }
    return "No new recommendations are available yet.";
  }

  function renderItems(items, meta) {
    const list = byId("recommendation-list");
    if (!list) return;
    list.replaceChildren();
    if (!items.length) {
      const empty = document.createElement("p");
      empty.className = "recommendation-empty";
      empty.textContent = emptyMessage(meta);
      list.append(empty);
      return;
    }
    items.forEach(item => {
      const article = item.article || {};
      const row = document.createElement("article");
      row.className = "recommendation-item";
      const link = document.createElement("a");
      link.className = "recommendation-link";
      link.href = article.canonical_path || `/articles/${article.id}`;

      const image = document.createElement("img");
      image.className = "recommendation-image";
      image.src = article.image || "/api/image-proxy?default=1";
      image.alt = article.image_alt || article.title || "Recommended article";
      image.loading = "lazy";

      const copy = document.createElement("span");
      copy.className = "recommendation-copy";
      const category = document.createElement("span");
      category.className = "recommendation-category";
      category.textContent = article.category || "General";
      const title = document.createElement("strong");
      title.className = "recommendation-title";
      title.textContent = article.title || "Untitled article";
      const source = document.createElement("span");
      source.className = "recommendation-source";
      source.textContent = article.author || "News source";
      const reason = document.createElement("span");
      reason.className = "recommendation-reason";
      reason.textContent = item.reason || "Recommended based on your interests";
      copy.append(category, title, source, reason);
      link.append(image, copy);
      row.append(link);
      list.append(row);
    });
    window.lucide?.createIcons();
  }

  async function refresh() {
    const button = byId("recommendations-refresh");
    if (!button || !window.TMM) return;
    button.disabled = true;
    button.setAttribute("aria-busy", "true");
    setStatus("Refreshing recommendations.");
    try {
      const response = await fetch("/api/recommendations?limit=5", {
        headers: { Accept: "application/json" },
      });
      const { data, ok } = await window.TMM.readApiResponse(response);
      if (!ok) throw new Error(data.message || "Unable to refresh recommendations.");
      renderItems(data.data.items || [], data.data.meta || {});
      setStatus("Recommendations refreshed.");
    } catch (error) {
      window.TMM.showToast(error.message || "Unable to refresh recommendations.", "error");
      setStatus("Recommendations could not be refreshed.");
    } finally {
      button.disabled = false;
      button.removeAttribute("aria-busy");
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    byId("recommendations-refresh")?.addEventListener("click", refresh);
  });
})();
