(() => {
  "use strict";

  const ICONS = {
    eyeOff: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>',
    eye: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>',
    ban: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="4.93" y1="4.93" x2="19.07" y2="19.07"></line></svg>',
    checkCircle: '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path><polyline points="22 4 12 14.01 9 11.01"></polyline></svg>',
    alertCircle: '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="8" x2="12" y2="12"></line><line x1="12" y1="16" x2="12.01" y2="16"></line></svg>',
    info: '<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><line x1="12" y1="16" x2="12" y2="12"></line><line x1="12" y1="8" x2="12.01" y2="8"></line></svg>',
    userCheck: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><polyline points="17 11 19 13 23 9"></polyline></svg>',
    trash: '<svg xmlns="http://www.w3.org/2000/svg" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path></svg>',
  };

  const byId = id => document.getElementById(id);

  const state = {
    tab: "overview",
    articlePage: 1,
    userPage: 1,
    moderationPage: 1,
  };
  const SCRAPER_POLL_INTERVAL_MS = 2500;
  let scraperPollTimer = null;
  let scraperPollInFlight = false;

  // ========================================================
  // UTILS
  // ========================================================

  function showLoading() {
    const loader = byId("admin-loading");
    if (loader) loader.classList.add("visible");
  }

  function hideLoading() {
    const loader = byId("admin-loading");
    if (loader) loader.classList.remove("visible");
  }

  function showToast(message, type = "info") {
    const container = byId("admin-toast-container");
    if (!container) return;

    const toast = document.createElement("div");
    toast.className = `admin-toast admin-toast-${type}`;

    let icon = ICONS.info;
    if (type === "success") icon = ICONS.checkCircle;
    if (type === "error") icon = ICONS.alertCircle;

    toast.innerHTML = `${icon}<span>${message}</span>`;
    container.appendChild(toast);

    setTimeout(() => {
      toast.classList.add("removing");
      setTimeout(() => {
        if (toast.parentNode) toast.parentNode.removeChild(toast);
      }, 300);
    }, 4000);
  }

  function confirmAction(title, message, btnLabel, btnClass) {
    return new Promise(resolve => {
      const modal = byId("admin-confirm-modal");
      if (!modal) return resolve(false);

      byId("confirm-title").textContent = title;
      byId("confirm-message").textContent = message;
      
      const actionBtn = byId("confirm-action-btn");
      actionBtn.textContent = btnLabel;
      actionBtn.className = btnClass;

      modal.classList.add("visible");

      const cancelBtn = byId("confirm-cancel-btn");

      const cleanup = () => {
        actionBtn.removeEventListener("click", onConfirm);
        cancelBtn.removeEventListener("click", onCancel);
        document.removeEventListener("keydown", onEscape);
        modal.classList.remove("visible");
      };

      const onConfirm = () => {
        cleanup();
        resolve(true);
      };

      const onCancel = () => {
        cleanup();
        resolve(false);
      };

      const onEscape = (e) => {
        if (e.key === "Escape") {
          cleanup();
          resolve(false);
        }
      };

      actionBtn.addEventListener("click", onConfirm);
      if (cancelBtn) cancelBtn.addEventListener("click", onCancel);
      document.addEventListener("keydown", onEscape);
    });
  }

  // ========================================================
  // REQUEST
  // ========================================================

  async function requestJson(url, options = {}) {
    const response = await fetch(url, {
      cache: "no-store",
      headers: {
        Accept: "application/json",
        ...options.headers,
      },
      ...options,
    });

    const responseText = await response.text();
    let data = {};

    try {
      data = responseText ? JSON.parse(responseText) : {};
    } catch {
      throw new Error(
        `Server returned HTTP ${response.status} instead of JSON. ` +
        "Check the server log and run the latest database migrations."
      );
    }

    if (!response.ok) {
      if (response.status === 401 || response.status === 403) {
        window.location.assign("/");
      }
      throw new Error(data.message || "Admin request failed.");
    }

    return data;
  }

  // ========================================================
  // DASHBOARD
  // ========================================================

  async function loadScraperSources() {
    try {
      const response = await requestJson("/api/admin/pipeline/config");
      const { sources = [] } = response.data || {};
      const select = byId("manual-scraper-source");
      if (select) {
        let html = '<option value="all">All Sources</option>';
        sources.forEach(source => {
          const sourceName = source.source_name || "Untitled Source";
          const label = source.is_enabled === false ? `${sourceName} (disabled)` : sourceName;
          html += `<option value="${source.id}">${label}</option>`;
        });
        select.innerHTML = html;
      }
    } catch (err) {
      console.error("Failed to load scraper sources:", err);
    }
  }

  function renderMetrics(data) {
    byId("metric-total-articles").textContent = data.total_articles;
    byId("metric-visible-articles").textContent = data.visible_articles;
    byId("metric-hidden-articles").textContent = data.hidden_articles;
    byId("metric-total-users").textContent = data.total_users;
    byId("metric-active-users").textContent = data.active_users;
    byId("metric-banned-users").textContent = data.banned_users;
  }

  async function loadMetrics({ silent = false, refreshSources = true } = {}) {
    try {
      if (!silent) showLoading();
      const response = await requestJson("/api/admin/metrics");
      renderMetrics(response.data);

      if (refreshSources) await loadScraperSources();
      await loadScraperRuns();
    } catch (err) {
      if (!silent) showToast(err.message, "error");
      else console.warn("Failed to refresh scraper progress:", err);
    } finally {
      if (!silent) hideLoading();
    }
  }

  function stopScraperPolling() {
    if (scraperPollTimer !== null) {
      window.clearInterval(scraperPollTimer);
      scraperPollTimer = null;
    }
  }

  function startScraperPolling() {
    if (scraperPollTimer !== null) return;
    scraperPollTimer = window.setInterval(async () => {
      if (scraperPollInFlight || document.hidden || state.tab !== "overview") return;
      scraperPollInFlight = true;
      try {
        await loadMetrics({ silent: true, refreshSources: false });
      } finally {
        scraperPollInFlight = false;
      }
    }, SCRAPER_POLL_INTERVAL_MS);
  }

  function syncScraperPolling(isRunning) {
    if (isRunning && state.tab === "overview") startScraperPolling();
    else stopScraperPolling();
  }

  function formatRunDuration(startedAt, completedAt) {
    if (!startedAt) return "—";
    const start = new Date(startedAt).getTime();
    const end = completedAt ? new Date(completedAt).getTime() : Date.now();
    const seconds = Math.max(0, Math.floor((end - start) / 1000));
    const minutes = Math.floor(seconds / 60);
    return minutes ? `${minutes}m ${seconds % 60}s` : `${seconds}s`;
  }

  async function loadScraperRuns() {
    try {
      const response = await requestJson("/api/admin/scraper/runs");
      const { is_running, runs } = response.data;
      syncScraperPolling(is_running);

      const badge = byId("scraper-status-badge");
      if (badge) {
        if (is_running) {
          badge.className = "badge badge-banned";
          badge.textContent = "Running...";
        } else {
          badge.className = "badge badge-visible";
          badge.textContent = "Idle";
        }
      }

      const btn = byId("admin-trigger-scraper");
      if (btn) {
        btn.disabled = is_running;
      }

      const tbody = byId("admin-scraper-runs-body");
      if (!tbody) return;

      if (!runs || runs.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5">No scraper run logs found.</td></tr>`;
        return;
      }

      tbody.innerHTML = runs.map(run => {
        const isSuccess = run.status === "completed";
        const isRunning = run.status === "running";
        const badgeClass = isRunning ? "badge-role-admin" : (isSuccess ? "badge-visible" : "badge-hidden");
        
        let startedLabel = "—";
        if (run.started_at) {
          startedLabel = new Date(run.started_at).toLocaleString();
        }

        return `
          <tr>
            <td><strong>${run.trigger_type.toUpperCase()}</strong><small>${run.triggered_by}</small></td>
            <td><span class="badge ${badgeClass}">${run.status}</span></td>
            <td><small>${startedLabel}</small></td>
            <td><strong>${formatRunDuration(run.started_at, run.completed_at)} · ${run.articles_scraped}</strong><small>items parsed</small></td>
            <td><span style="color:#059669">+${run.articles_created} new</span> / <span style="color:#64748b">${run.duplicates_found} dupes</span></td>
          </tr>
        `;
      }).join("");

    } catch (err) {
      console.warn("Failed to load scraper runs:", err);
    }
  }

  async function triggerScraper() {
    const sourceSelect = byId("manual-scraper-source");
    const limitInput = byId("manual-scraper-limit");
    
    let sourceId = sourceSelect ? sourceSelect.value : "all";
    let limit = limitInput && limitInput.value ? parseInt(limitInput.value) : null;
    
    let confirmMsg = "Do you want to launch a background scraping job now?";
    if (sourceId !== "all") {
        const sourceName = sourceSelect.options[sourceSelect.selectedIndex].text;
        confirmMsg = `Do you want to scrape from ${sourceName} now?`;
    }
    if (limit) {
        confirmMsg += ` (Limit: ${limit} articles)`;
    }

    const confirmed = await confirmAction(
      "Trigger Manual Scraper",
      confirmMsg,
      "Run Scraper",
      "modal-btn-success"
    );
    if (!confirmed) return;

    try {
      showLoading();
      
      const payload = {};
      if (sourceId !== "all") payload.source_id = parseInt(sourceId);
      if (limit) payload.max_articles = limit;
      
      const response = await requestJson("/api/admin/scraper/runs", { 
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(payload)
      });
      showToast(response.message, "success");
      await loadScraperRuns();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  // ========================================================
  // ARTICLES
  // ========================================================

  async function loadArticles(page = 1) {
    try {
      showLoading();
      state.articlePage = page;

      const params = new URLSearchParams({
        page: page,
        per_page: 10,
        status: byId("article-admin-status").value,
        q: byId("article-admin-query").value.trim(),
      });

      const response = await requestJson(`/api/admin/articles?${params}`);
      const { articles, pagination } = response.data;

      const tbody = byId("admin-articles-body");

      if (articles.length === 0) {
        tbody.innerHTML = `<tr><td colspan="4">No articles found.</td></tr>`;
        renderArticlePagination(pagination);
        return;
      }

      tbody.innerHTML = articles.map(article => {
        let domain = article.source_url;
        try {
          domain = new URL(article.source_url).hostname;
        } catch (e) {
          // Ignore invalid URLs
        }

        const isHidden = article.is_deleted;
        const statusBadge = isHidden 
          ? '<span class="badge badge-hidden">Hidden</span>' 
          : '<span class="badge badge-visible">Visible</span>';

        const btnClass = isHidden ? "btn-action btn-restore" : "btn-action btn-hide";
        const btnIcon = isHidden ? ICONS.eye : ICONS.eyeOff;
        const btnText = isHidden ? "Restore" : "Hide";

        return `
          <tr>
            <td>
              <strong>${article.title}</strong>
              <br>
              <small>${domain}</small>
            </td>
            <td>
              ${article.published_at ? new Date(article.published_at).toLocaleString() : "—"}
            </td>
            <td>
              ${statusBadge}
            </td>
            <td>
              <div style="display: flex; flex-direction: column; align-items: center; gap: 8px;">
                <button
                  type="button"
                  class="${btnClass}"
                  data-article-id="${article.id}"
                  data-article-action="${isHidden ? "restore" : "hide"}"
                >
                  ${btnIcon} ${btnText}
                </button>
                <button
                  type="button"
                  class="btn-action btn-ban"
                  data-article-id="${article.id}"
                  data-article-action="delete"
                >
                  ${ICONS.trash} Delete
                </button>
              </div>
            </td>
          </tr>
        `;
      }).join("");

      renderArticlePagination(pagination);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  function renderArticlePagination(pagination) {
    const container = byId("admin-articles-pagination");
    if (!container) return;

    const { page, total_pages } = pagination;

    if (total_pages <= 1) {
      container.innerHTML = "";
      return;
    }

    container.innerHTML = `
      <button type="button" ${page <= 1 ? "disabled" : ""} data-article-page="${page - 1}">Previous</button>
      <span>Page ${page} of ${total_pages}</span>
      <button type="button" ${page >= total_pages ? "disabled" : ""} data-article-page="${page + 1}">Next</button>
    `;
  }

  async function changeArticle(button) {
    const articleId = button.dataset.articleId;
    const action = button.dataset.articleAction;

    let title, message, btnLabel, btnClass;
    if (action === "hide") {
      title = "Hide Article";
      message = "This article will be hidden from public view. You can restore it later.";
      btnLabel = "Hide Article";
      btnClass = "modal-btn-danger";
    } else if (action === "delete") {
      title = "Delete Article Permanently";
      message = "Are you sure you want to PERMANENTLY delete this article? This action cannot be undone!";
      btnLabel = "Delete Permanently";
      btnClass = "modal-btn-danger";
    } else {
      title = "Restore Article";
      message = "This article will be visible to the public again.";
      btnLabel = "Restore";
      btnClass = "modal-btn-success";
    }

    const confirmed = await confirmAction(title, message, btnLabel, btnClass);
    if (!confirmed) return;

    try {
      showLoading();
      if (action === "delete") {
        await requestJson(`/api/admin/articles/${articleId}`, { method: "DELETE" });
        showToast("Article permanently deleted.", "success");
      } else {
        await requestJson(`/api/admin/articles/${articleId}/${action}`, { method: "PATCH" });
        showToast(`Article successfully ${action === 'hide' ? 'hidden' : 'restored'}.`, "success");
      }
      await loadArticles(state.articlePage);
      await loadMetrics();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  // ========================================================
  // USERS
  // ========================================================

  async function loadUsers(page = 1) {
    try {
      showLoading();
      state.userPage = page;

      const params = new URLSearchParams({
        page: page,
        per_page: 10,
        status: byId("user-admin-status").value,
        q: byId("user-admin-query").value.trim(),
      });

      const response = await requestJson(`/api/admin/users?${params}`);
      const { users, pagination } = response.data;

      const tbody = byId("admin-users-body");
      const adminShell = document.querySelector(".admin-shell");
      const adminId = adminShell ? Number(adminShell.dataset.adminId) : -1;

      if (users.length === 0) {
        tbody.innerHTML = `<tr><td colspan="5">No users found.</td></tr>`;
        renderUserPagination(pagination);
        return;
      }

      tbody.innerHTML = users.map(user => {
        const protectedUser = user.role === "admin" || user.id === adminId;
        const displayName = user.full_name || user.username || "User";
        const initial = displayName.charAt(0).toUpperCase();

        const roleBadge = user.role === "admin"
          ? '<span class="badge badge-role-admin">admin</span>'
          : '<span class="badge badge-role">user</span>';

        const statusBadge = user.is_active
          ? '<span class="badge badge-active">Active</span>'
          : '<span class="badge badge-banned">Banned</span>';

        const isActive = user.is_active;
        const btnClass = isActive ? "btn-action btn-ban" : "btn-action btn-unban";
        const btnIcon = isActive ? ICONS.ban : ICONS.userCheck;
        const btnText = isActive ? "Ban" : "Unban";

        return `
          <tr>
            <td>
              <div class="admin-user-info">
                <span class="admin-user-avatar">${initial}</span>
                <div>
                  <strong>${displayName}</strong>
                  <br>
                  <small>${user.email}</small>
                </div>
              </div>
            </td>
            <td>${roleBadge}</td>
            <td>
              ${user.created_at ? new Date(user.created_at).toLocaleDateString() : "—"}
            </td>
            <td>${statusBadge}</td>
            <td>
              <button
                class="${btnClass}"
                data-user-id="${user.id}"
                data-user-action="${isActive ? "ban" : "unban"}"
                ${protectedUser ? "disabled" : ""}
              >
                ${btnIcon} ${btnText}
              </button>
            </td>
          </tr>
        `;
      }).join("");

      renderUserPagination(pagination);
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  function renderUserPagination(pagination) {
    const container = byId("admin-users-pagination");
    if (!container) return;
    container.innerHTML = "";

    if (pagination.page > 1) {
      container.innerHTML += `
        <button data-user-page="${pagination.page - 1}">Previous</button>
      `;
    }

    container.innerHTML += `
      <span>Page ${pagination.page} / ${pagination.total_pages}</span>
    `;

    if (pagination.page < pagination.total_pages) {
      container.innerHTML += `
        <button data-user-page="${pagination.page + 1}">Next</button>
      `;
    }
  }

  async function changeUser(button) {
    const userId = button.dataset.userId;
    const action = button.dataset.userAction;

    let title, message, btnLabel, btnClass;
    if (action === "ban") {
      title = "Ban User";
      message = "This user will be banned and their active sessions invalidated. They will not be able to log in.";
      btnLabel = "Ban User";
      btnClass = "modal-btn-danger";
    } else {
      title = "Unban User";
      message = "This user will be able to log in and use the platform again.";
      btnLabel = "Unban";
      btnClass = "modal-btn-success";
    }

    const confirmed = await confirmAction(title, message, btnLabel, btnClass);
    if (!confirmed) return;

    try {
      showLoading();
      await requestJson(`/api/admin/users/${userId}/${action}`, { method: "PATCH" });
      showToast(`User successfully ${action === 'ban' ? 'banned' : 'unbanned'}.`, "success");
      await loadUsers(state.userPage);
      await loadMetrics();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  // ========================================================
  // TAB
  // ========================================================

  async function loadModeration() {
    const params = new URLSearchParams({page: String(state.moderationPage), per_page: "20"});
    const q = byId("moderation-q")?.value.trim();
    const status = byId("moderation-status")?.value;
    const reportState = byId("moderation-report-state")?.value;
    if (q) params.set("q", q); if (status && status !== "all") params.set("status", status); if (reportState && reportState !== "all") params.set("report_state", reportState);
    const [summary, response, terms, events] = await Promise.all([
      requestJson("/api/admin/moderation/summary"), requestJson(`/api/admin/moderation/comments?${params}`), requestJson("/api/admin/moderation/prohibited-terms?per_page=50"), requestJson("/api/admin/moderation/filter-events?per_page=10"),
    ]);
    const badge = byId("moderation-open-count"); if (badge) badge.textContent = summary.data.open_reports || 0;
    const container = byId("moderation-comments-list"); const items = response.data.items || [];
    if (container) container.innerHTML = items.length ? `<div class="admin-table-scroll"><table class="admin-table moderation-table"><thead><tr><th>Comment</th><th>Author / Article</th><th>Reports</th><th>Status</th><th>Actions</th></tr></thead><tbody>${items.map(item => {
      const status = item.is_deleted ? "Deleted" : item.is_hidden ? "Hidden" : "Visible";
      const statusClass = item.is_deleted ? "badge-deleted" : item.is_hidden ? "badge-hidden" : "badge-visible";
      const actions = item.is_deleted
        ? '<span class="moderation-removed">Permanently removed</span>'
        : `<div class="moderation-actions"><button type="button" class="btn-action ${item.is_hidden ? "btn-restore" : "btn-hide"}" data-moderation-action="${item.is_hidden ? "restore" : "hide"}" data-comment-id="${item.id}">${item.is_hidden ? ICONS.eye : ICONS.eyeOff}<span>${item.is_hidden ? "Restore" : "Hide"}</span></button><button type="button" class="btn-action btn-ban" data-moderation-action="delete" data-comment-id="${item.id}">${ICONS.trash}<span>Delete</span></button>${item.reports.open_ids?.[0] ? ` <button type="button" class="btn-action btn-dismiss-report" data-report-dismiss="${item.reports.open_ids[0]}">${ICONS.checkCircle}<span>Dismiss</span></button>` : ""}</div>`;
      return `<tr><td class="moderation-comment-content">${escapeHtml(item.content)}</td><td><strong>${escapeHtml(item.author.full_name || item.author.username || item.author.email)}</strong><small>${escapeHtml(item.article.title)}</small></td><td><span class="report-count ${item.reports.open_count ? "has-open-reports" : ""}">${item.reports.open_count} open</span></td><td><span class="badge ${statusClass}">${status}</span></td><td>${actions}</td></tr>`;
    }).join("")}</tbody></table></div>` : "<p class=\"discussion-empty\">No comments match these filters.</p>";
    const termsNode = byId("prohibited-terms-list"); const termItems = terms.data.items || [];
    if (termsNode) termsNode.innerHTML = termItems.length ? `<div class="prohibited-term-list">${termItems.map(term => `<div class="prohibited-term-row"><div><strong>${escapeHtml(term.term)}</strong>${term.category ? `<small>${escapeHtml(term.category)}</small>` : ""}</div><div class="moderation-actions"><span class="badge ${term.is_active ? "badge-visible" : "badge-role"}">${term.is_active ? "Active" : "Inactive"}</span><button type="button" class="btn-action btn-hide" data-term-toggle="${term.id}" data-active="${term.is_active}">${term.is_active ? "Deactivate" : "Activate"}</button><button type="button" class="btn-action btn-ban" data-term-delete="${term.id}">Remove</button></div></div>`).join("")}</div>` : "<p class=\"discussion-empty\">No prohibited terms configured.</p>";
    const eventNode = byId("moderation-filter-events"); const eventItems = events.data.items || [];
    if (eventNode) eventNode.innerHTML = eventItems.length ? `<ul>${eventItems.map(item => `<li>${escapeHtml(item.user.name)} · ${escapeHtml(item.article.title)} · ${escapeHtml(item.term?.category || "prohibited term")} · ${new Date(item.created_at).toLocaleString()}</li>`).join("")}</ul>` : "<p class=\"discussion-empty\">No blocked submissions.</p>";
  }

  async function mutateModeration(commentId, action) {
    const reason = window.prompt(`Reason for ${action}:`); if (!reason?.trim()) return;
    const options = {method: action === "delete" ? "DELETE" : "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify(action === "delete" ? {reason, confirmed: true} : {reason})};
    await requestJson(`/api/admin/moderation/comments/${commentId}${action === "delete" ? "" : `/${action}`}`, options);
    showToast("Moderation action saved.", "success"); await loadModeration();
  }

  async function switchTab(tab) {
    try {
      state.tab = tab;
      if (tab !== "overview") stopScraperPolling();

      document.querySelectorAll(".admin-panel").forEach(panel => {
        panel.classList.add("hide");
      });

      document.querySelectorAll(".admin-nav-item").forEach(button => {
        button.classList.toggle("active", button.dataset.tab === tab);
      });

      const activePanel = byId(`admin-panel-${tab}`);
      if (activePanel) activePanel.classList.remove("hide");

      const title = byId("admin-page-title");
      if (title) title.textContent = tab.charAt(0).toUpperCase() + tab.slice(1);

      if (tab === "overview") {
        await loadMetrics();
      } else if (tab === "articles") {
        await loadArticles();
      } else if (tab === "users") {
        await loadUsers();
      } else if (tab === "duplicates") {
        await loadDuplicates();
      } else if (tab === "moderation") {
        await loadModeration();
      } else if (tab === "pipeline") {
        await loadPipelineConfig();
      }
    } catch (err) {
      showToast(err.message, "error");
    }
  }

  async function loadDuplicates() {
    try {
      showLoading();
      const response = await requestJson("/api/admin/duplicates");
      const { clusters } = response.data;

      const container = byId("admin-duplicates-list");
      if (!container) return;

      if (!clusters || clusters.length === 0) {
        container.innerHTML = `
          <div style="background: var(--surface); border: 1px solid var(--outline); padding: 32px; border-radius: var(--radius); text-align: center;">
            <p style="color: var(--emerald); font-weight: 600;">✓ No duplicate clusters detected!</p>
            <p style="color: var(--muted); font-size: 0.8125rem; margin-top: 4px;">All active articles have unique titles and content fingerprints.</p>
          </div>
        `;
        return;
      }

      container.innerHTML = clusters.map((cluster, cIdx) => `
        <div style="background: var(--surface); border: 1px solid var(--outline); border-radius: var(--radius); padding: 20px; margin-bottom: 20px;">
          <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 16px;">
            <div>
              <span class="badge badge-role-admin">Match: ${cluster.match_type}</span>
              <strong style="margin-left: 8px; font-size: 0.875rem;">${cluster.match_key}</strong>
            </div>
            <span class="badge badge-banned">${cluster.count} suspect records</span>
          </div>

          <table class="admin-table" style="margin-bottom: 16px;">
            <thead>
              <tr>
                <th style="width: 50px;">Primary</th>
                <th>Article Title & Source</th>
                <th>Published</th>
              </tr>
            </thead>
            <tbody>
              ${cluster.articles.map((art, aIdx) => `
                <tr>
                  <td>
                    <input type="radio" name="primary_cluster_${cIdx}" value="${art.id}" ${aIdx === 0 ? "checked" : ""}>
                  </td>
                  <td>
                    <strong>#${art.id} — ${art.title}</strong>
                    <small>${art.source_url}</small>
                  </td>
                  <td><small>${art.published_at ? new Date(art.published_at).toLocaleString() : "—"}</small></td>
                </tr>
              `).join("")}
            </tbody>
          </table>

          <div style="display: flex; justify-content: flex-end;">
            <button type="button" class="btn-action btn-hide" data-resolve-cluster="${cIdx}">
              Soft-Hide Secondary Duplicates
            </button>
          </div>
        </div>
      `).join("");

      // Attach click listeners for resolve buttons
      clusters.forEach((cluster, cIdx) => {
        const btn = document.querySelector(`[data-resolve-cluster="${cIdx}"]`);
        if (btn) {
          btn.addEventListener("click", () => resolveDuplicateCluster(cluster, cIdx));
        }
      });

    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  async function resolveDuplicateCluster(cluster, cIdx) {
    const selectedRadio = document.querySelector(`input[name="primary_cluster_${cIdx}"]:checked`);
    if (!selectedRadio) return;

    const primaryId = parseInt(selectedRadio.value, 10);
    const duplicateIds = cluster.articles.map(a => a.id).filter(id => id !== primaryId);

    const confirmed = await confirmAction(
      "Resolve Duplicate Cluster",
      `Designate Article #${primaryId} as primary and soft-hide the other ${duplicateIds.length} duplicate record(s)?`,
      "Resolve Duplicates",
      "modal-btn-danger"
    );
    if (!confirmed) return;

    try {
      showLoading();
      const response = await requestJson("/api/admin/duplicates/resolve", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ primary_id: primaryId, duplicate_ids: duplicateIds }),
      });
      showToast(response.message, "success");
      await loadDuplicates();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  // PIPELINE CONFIG
  // ========================================================

  function escapeHtml(value) {
    return String(value ?? "")
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;")
      .replace(/\"/g, "&quot;")
      .replace(/'/g, "&#39;");
  }

  function getSourceHTML(source = {}) {
    const sourceId = source.id || `new_${Date.now()}_${Math.random().toString(16).slice(2)}`;
    const sourceName = escapeHtml(source.source_name || "");
    const targetUrl = escapeHtml(source.target_url || "");
    const enabled = source.is_enabled !== false;
    const maxArticles = source.max_articles_per_run || 10;

    return `
      <div class="admin-source-item" style="background: var(--surface); padding: 20px; border-radius: var(--radius); border: 1px solid var(--outline); margin-bottom: 20px;" data-id="${escapeHtml(sourceId)}">
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
          <h4 style="margin: 0; display: flex; align-items: center; gap: 10px;">
            <input type="text" class="source-name-input admin-input-block" value="${sourceName}" placeholder="Source Name (e.g. VNExpress)" style="font-weight: bold; width: 250px; padding: 6px 10px;" />
            <span class="badge ${enabled ? 'badge-visible' : 'badge-hidden'}">${enabled ? 'Enabled' : 'Disabled'}</span>
          </h4>
          <div>
            <label style="margin-right: 15px;">
              <input type="checkbox" class="source-enabled" ${enabled ? 'checked' : ''} /> Enable
            </label>
            <label>
              Max Articles:
              <input type="number" class="source-max-articles admin-input-block" value="${escapeHtml(maxArticles)}" min="1" style="width: 60px; display: inline-block; padding: 4px;" />
            </label>
          </div>
        </div>

        <div class="admin-toolbar" style="margin-bottom: 15px;">
          <input type="text" class="source-target-url admin-input-block" value="${targetUrl}" placeholder="Target URL" style="width: 100%;" />
        </div>

        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 15px;">
          <div>
            <label>Article List Selector</label>
            <input type="text" class="source-list-selector admin-input-block" value="${escapeHtml(source.article_list_selector || '')}" style="width: 100%; margin-top: 5px;" />
          </div>
          <div>
            <label>Title Selector</label>
            <input type="text" class="source-title-selector admin-input-block" value="${escapeHtml(source.title_selector || '')}" style="width: 100%; margin-top: 5px;" />
          </div>
          <div>
            <label>Description Selector</label>
            <input type="text" class="source-description-selector admin-input-block" value="${escapeHtml(source.description_selector || '')}" style="width: 100%; margin-top: 5px;" />
          </div>
          <div>
            <label>Content Selector</label>
            <input type="text" class="source-content-selector admin-input-block" value="${escapeHtml(source.content_selector || '')}" style="width: 100%; margin-top: 5px;" />
          </div>
          <div>
            <label>Excluded HTML Selectors</label>
            <input type="text" class="source-excluded-html-selectors admin-input-block" value="${escapeHtml(source.excluded_html_selectors || '')}" placeholder="e.g. aside, .related-box, .advertisement" style="width: 100%; margin-top: 5px;" />
          </div>
          <div>
            <label>Image Selector</label>
            <input type="text" class="source-image-selector admin-input-block" value="${escapeHtml(source.image_selector || '')}" style="width: 100%; margin-top: 5px;" />
          </div>
          <div>
            <label>Image CDN domains</label>
            <input type="text" class="source-image-cdn-domains admin-input-block" value="${escapeHtml(source.image_cdn_domains || '')}" placeholder="e.g. cdn.example.com, images.example.com" style="width: 100%; margin-top: 5px;" />
          </div>
          <div>
            <label>Published Date Selector</label>
            <input type="text" class="source-date-selector admin-input-block" value="${escapeHtml(source.published_date_selector || '')}" style="width: 100%; margin-top: 5px;" />
          </div>
        </div>
        <div style="display: flex; justify-content: flex-end; margin-top: 20px;">
          <button type="button" class="admin-btn-danger source-delete-btn" data-delete-source="${escapeHtml(sourceId)}">
            Delete source
          </button>
        </div>
      </div>
    `;
  }

  async function deleteSource(button) {
    const sourceBox = button.closest(".admin-source-item");
    const sourceId = sourceBox?.dataset.id;
    if (!sourceBox || !sourceId) return;

    const sourceName = sourceBox.querySelector(".source-name-input")?.value || "this source";
    const isNewSource = sourceId.startsWith("new_");
    const confirmed = await confirmAction(
      "Delete source",
      isNewSource
        ? `Remove ${sourceName} from this form?`
        : `Permanently delete ${sourceName}? This cannot be undone.`,
      "Delete source",
      "modal-btn-danger"
    );
    if (!confirmed) return;

    try {
      showLoading();
      if (!isNewSource) {
        await requestJson(`/api/admin/pipeline/config/${encodeURIComponent(sourceId)}`, {
          method: "DELETE",
        });
      }
      sourceBox.remove();
      showToast("Source deleted.", "success");
      await loadScraperSources();
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  async function loadPipelineConfig() {
    try {
      showLoading();
      const response = await requestJson("/api/admin/pipeline/config");
      const payload = response?.data || {};
      const sources = Array.isArray(payload.sources) ? payload.sources : [];
      const settings = payload.settings || {};

      const intervalInput = byId("config-scraping-interval");
      const retentionInput = byId("config-retention-days");

      if (intervalInput) {
        intervalInput.value = settings.scraping_interval_minutes ?? 60;
      }
      if (retentionInput) {
        retentionInput.value = settings.retention_days ?? 30;
      }

      const container = byId("admin-sources-list");
      if (!container) return;

      const html = [
        ...sources.map(source => getSourceHTML(source)),
        `
        <div style="text-align: center; margin-top: 20px;">
          <button type="button" id="btn-add-source" class="admin-btn-primary" style="background: transparent; color: var(--primary); box-shadow: none; border: 1px dashed var(--outline); width: 100%;">
            + Add New Source
          </button>
        </div>
        `,
      ].join("");

      container.innerHTML = html;

      const btnAddSource = byId("btn-add-source");
      if (btnAddSource) {
        btnAddSource.addEventListener("click", () => {
          const newSourceHtml = getSourceHTML({ is_enabled: true });
          btnAddSource.parentElement.insertAdjacentHTML("beforebegin", newSourceHtml);
        });
      }

      container.querySelectorAll("[data-delete-source]").forEach(button => {
        button.addEventListener("click", () => deleteSource(button));
      });
    } catch (err) {
      showToast(err.message, "error");
    } finally {
      hideLoading();
    }
  }

  async function savePipelineConfig() {
      try {
          const sourcesData = [];
          document.querySelectorAll(".admin-source-item").forEach(item => {
              sourcesData.push({
                  id: item.dataset.id,
                  source_name: item.querySelector(".source-name-input").value,
                  is_enabled: item.querySelector(".source-enabled").checked,
                  max_articles_per_run: parseInt(item.querySelector(".source-max-articles").value) || 10,
                  target_url: item.querySelector(".source-target-url").value,
                  article_list_selector: item.querySelector(".source-list-selector").value,
                  title_selector: item.querySelector(".source-title-selector").value,
                  description_selector: item.querySelector(".source-description-selector").value,
                  content_selector: item.querySelector(".source-content-selector").value,
                  excluded_html_selectors: item.querySelector(".source-excluded-html-selectors").value,
                  image_selector: item.querySelector(".source-image-selector").value,
                  image_cdn_domains: item.querySelector(".source-image-cdn-domains").value,
                  published_date_selector: item.querySelector(".source-date-selector").value,
              });
          });
          
          const settingsData = {
              scraping_interval_minutes: byId("config-scraping-interval").value,
              retention_days: byId("config-retention-days").value,
          };
          
          showLoading();
          
          const response = await requestJson("/api/admin/pipeline/config", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ sources: sourcesData, settings: settingsData })
          });
          
          showToast(response.message, "success");
          await loadPipelineConfig();
          
      } catch (err) {
          showToast(err.message, "error");
      } finally {
          hideLoading();
      }
  }

  async function testScraperSelectors() {
      const url = byId("test-url").value;
      const resultBox = byId("test-result");
      
      if (!url) {
          showToast("Please enter a URL to test", "error");
          return;
      }
      
      try {
          showLoading();
          const response = await requestJson("/api/admin/scraper/test", {
              method: "POST",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({
                  test_url: url,
                  article_list_selector: byId("test-article-list").value,
                  title_selector: byId("test-title").value,
                  description_selector: byId("test-description").value,
                  content_selector: byId("test-content").value,
                  image_selector: byId("test-image").value,
                  published_date_selector: byId("test-date").value
              })
          });
          
          resultBox.textContent = JSON.stringify(response.preview, null, 2);
          showToast("Test completed", "success");
      } catch (err) {
          showToast(err.message, "error");
          resultBox.textContent = `Error: ${err.message}`;
      } finally {
          hideLoading();
      }
  }

  // ========================================================
  // EVENT
  // ========================================================

  document.addEventListener("DOMContentLoaded", () => {
    document.querySelectorAll(".admin-nav-item").forEach(btn => {
      btn.addEventListener("click", () => switchTab(btn.dataset.tab));
    });

    const refreshBtn = byId("admin-refresh");
    if (refreshBtn) {
      refreshBtn.addEventListener("click", () => switchTab(state.tab));
    }

    const triggerScraperBtn = byId("admin-trigger-scraper");
    if (triggerScraperBtn) {
      triggerScraperBtn.addEventListener("click", triggerScraper);
    }
    
    const savePipelineBtn = byId("admin-save-pipeline");
    if (savePipelineBtn) {
      savePipelineBtn.addEventListener("click", savePipelineConfig);
    }
    
    const testSelectorsBtn = byId("btn-test-selectors");
    if (testSelectorsBtn) {
      testSelectorsBtn.addEventListener("click", testScraperSelectors);
    }

    switchTab("overview");

    loadPipelineConfig().catch(() => {});

    const pipelineTabBtn = document.querySelector('.admin-nav-item[data-tab="pipeline"]');
    if (pipelineTabBtn) {
      pipelineTabBtn.addEventListener("click", async () => {
        await loadPipelineConfig();
      });
    }

    const articleFilter = byId("article-admin-filter");
    if (articleFilter) {
      articleFilter.addEventListener("submit", event => {
        event.preventDefault();
        loadArticles(1);
      });
    }

    const userFilter = byId("user-admin-filter");
    if (userFilter) {
      userFilter.addEventListener("submit", event => {
        event.preventDefault();
        loadUsers(1);
      });
    }

    byId("moderation-filter")?.addEventListener("submit", event => { event.preventDefault(); state.moderationPage = 1; loadModeration().catch(error => showToast(error.message, "error")); });
    byId("prohibited-term-form")?.addEventListener("submit", async event => { event.preventDefault(); try { await requestJson("/api/admin/moderation/prohibited-terms", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({term:byId("prohibited-term-input").value, category:byId("prohibited-term-category").value})}); event.target.reset(); showToast("Prohibited term added.", "success"); await loadModeration(); } catch (error) { showToast(error.message, "error"); } });

    document.addEventListener("click", event => {
      const articleButton = event.target.closest("[data-article-action]");
      if (articleButton) {
        changeArticle(articleButton);
      }

      const userButton = event.target.closest("[data-user-action]");
      if (userButton) {
        changeUser(userButton);
      }

      const articlePage = event.target.closest("[data-article-page]");
      if (articlePage) {
        loadArticles(Number(articlePage.dataset.articlePage));
      }

      const userPage = event.target.closest("[data-user-page]");
      if (userPage) {
        loadUsers(Number(userPage.dataset.userPage));
      }

      const moderationButton = event.target.closest("[data-moderation-action]");
      if (moderationButton) mutateModeration(moderationButton.dataset.commentId, moderationButton.dataset.moderationAction).catch(error => showToast(error.message, "error"));
      const toggleTerm = event.target.closest("[data-term-toggle]");
      if (toggleTerm) requestJson(`/api/admin/moderation/prohibited-terms/${toggleTerm.dataset.termToggle}`, {method:"PATCH", headers:{"Content-Type":"application/json"}, body:JSON.stringify({is_active: toggleTerm.dataset.active !== "true"})}).then(loadModeration).catch(error => showToast(error.message, "error"));
      const deleteTerm = event.target.closest("[data-term-delete]");
      if (deleteTerm && window.confirm("Remove this prohibited term?")) requestJson(`/api/admin/moderation/prohibited-terms/${deleteTerm.dataset.termDelete}`, {method:"DELETE"}).then(loadModeration).catch(error => showToast(error.message, "error"));
      const dismissReport = event.target.closest("[data-report-dismiss]");
      if (dismissReport) { const reason = window.prompt("Reason for dismissing this report:"); if (reason?.trim()) requestJson(`/api/admin/moderation/reports/${dismissReport.dataset.reportDismiss}/dismiss`, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({reason})}).then(loadModeration).catch(error => showToast(error.message, "error")); }
    });
  });

})();
