(() => {
  "use strict";
  const input = document.getElementById("global-search-input");
  const box = document.getElementById("search-suggestions");
  const advancedToggle = document.getElementById("advanced-search-toggle");
  const advancedPanel = document.getElementById("advanced-search-panel");
  if (!input || !box) return;
  document.addEventListener("keydown", event => {
    if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === "k") { event.preventDefault(); input.focus(); }
    if (event.key === "Escape") { box.classList.add("hide"); }
  });
  document.addEventListener("click", event => {
    if (!input.contains(event.target) && !box.contains(event.target)) {
      box.classList.add("hide");
    }
  });
  async function loadSuggestions() {
    if (input.value.trim()) {
      box.classList.add("hide");
      return;
    }
    try {
      const response = await fetch("/api/search/trending?limit=5", { cache: "no-store" });
      const payload = await response.json();
      if (!response.ok) return;
      const recent = (payload.data.recent_searches || []).map(item => ({ ...item, kind: "recent" }));
      const recentKeywords = new Set(recent.map(item => item.keyword));
      const trending = (payload.data.trending || [])
        .filter(item => !recentKeywords.has(item.keyword))
        .map(item => ({ ...item, kind: "trending" }));
      const terms = [...recent, ...trending];
      if (!terms.length) return;
      box.replaceChildren(...terms.map(item => {
        const row = document.createElement("div");
        row.className = "search-suggestion-row";
        const button = document.createElement("button");
        button.type = "button";
        button.textContent = item.keyword;
        button.addEventListener("click", () => { input.value = item.keyword; input.form.submit(); });
        row.append(button);
        if (item.kind === "recent") {
          const remove = document.createElement("button");
          remove.type = "button";
          remove.className = "search-history-delete";
          remove.setAttribute("aria-label", `Delete ${item.keyword} from search history`);
          remove.textContent = "×";
          remove.addEventListener("click", async event => {
            event.stopPropagation();
            const response = await fetch("/api/search/history", {
              method: "DELETE",
              headers: { "Content-Type": "application/json" },
              body: JSON.stringify({ keyword: item.keyword }),
            });
            if (!response.ok) return;
            // Remove immediately so the deleted item never remains visible
            // while the refreshed suggestions request is in flight.
            row.remove();
            if (!box.childElementCount) box.classList.add("hide");
            await loadSuggestions();
          });
          row.append(remove);
        }
        return row;
      }));
      box.classList.remove("hide");
    } catch { /* Search remains usable without suggestions. */ }
  }
  input.addEventListener("focus", loadSuggestions);
  input.addEventListener("input", () => box.classList.add("hide"));
  document.addEventListener("auth:changed", () => {
    box.replaceChildren();
    box.classList.add("hide");
  });
  advancedToggle?.addEventListener("click", () => {
    const open = advancedPanel?.classList.toggle("hide") === false;
    advancedToggle.setAttribute("aria-expanded", String(open));
  });
  document.getElementById("advanced-search-clear")?.addEventListener("click", () => {
    window.setTimeout(() => input.focus(), 0);
  });
})();
