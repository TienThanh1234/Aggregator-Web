/**
 * Shared progressive enhancement for authentication, navigation, and toasts.
 */
(() => {
  "use strict";

  const byId = id => document.getElementById(id);
  const authForms = [
    "form-login",
    "form-register",
    "form-reset-request",
    "form-reset-confirm",
  ];
  let currentUser = null;

  async function readApiResponse(response) {
    let data = {};
    try {
      data = await response.json();
    } catch {
      data = { message: "The server returned an unreadable response." };
    }
    return { data, ok: response.ok };
  }

  function setSubmitting(button, active) {
    if (!button) return;
    button.disabled = active;
    button.setAttribute("aria-busy", String(active));
  }

  function showToast(message, type = "success") {
    const container = byId("toast-container");
    if (!container) return;
    const toast = document.createElement("div");
    toast.className = `toast-item toast-${type}`;
    toast.textContent = message;
    container.appendChild(toast);
    window.setTimeout(() => {
      toast.classList.add("fade-out");
      window.setTimeout(() => toast.remove(), 300);
    }, 4000);
  }

  function showAuthAlert(message = "") {
    const box = byId("auth-alert-box");
    const text = byId("auth-alert-message");
    if (!box || !text) return;
    text.textContent = message;
    box.classList.toggle("hide", !message);
  }

  function showAuthForm(formId) {
    authForms.forEach(id => byId(id)?.classList.toggle("hide", id !== formId));
    byId("tab-auth-login")?.classList.toggle("active", formId === "form-login");
    byId("tab-auth-register")?.classList.toggle("active", formId === "form-register");
    showAuthAlert();
  }

  function switchAuthTab(formId) {
    showAuthForm(formId);
  }

  function openAuthModal(tab = "login") {
    byId("auth-modal-overlay")?.classList.remove("hide");
    showAuthForm(tab === "register" ? "form-register" : "form-login");
    const focusTarget = tab === "register" ? byId("reg-fullname") : byId("login-identity");
    window.setTimeout(() => focusTarget?.focus(), 0);
  }

  function closeAuthModal() {
    byId("auth-modal-overlay")?.classList.add("hide");
    showAuthAlert();
  }

  function getInitials(name) {
    return (name || "U")
      .trim()
      .split(/\s+/)
      .slice(0, 2)
      .map(part => part[0])
      .join("")
      .toUpperCase() || "U";
  }

  function renderAvatar(avatarUrl, displayName) {
    const image = byId("nav-user-avatar-image");
    const fallback = byId("nav-user-avatar-fallback");
    const hasAvatar = Boolean(avatarUrl);
    if (image) {
      image.src = hasAvatar ? avatarUrl : "";
      image.classList.toggle("hide", !hasAvatar);
    }
    if (fallback) {
      fallback.textContent = getInitials(displayName);
      fallback.classList.toggle("hide", hasAvatar);
    }
  }

  function updateHeaderAuthUI() {
    const guest = byId("nav-guest-actions");
    const user = byId("nav-user-actions");
    guest?.classList.toggle("hide", Boolean(currentUser));
    user?.classList.toggle("hide", !currentUser);
    if (!currentUser) return;

    const profile = currentUser.profile || currentUser;
    const displayName = profile.full_name || profile.username || "Reader";
    const role = (profile.role || "user").toLowerCase();
    const adminDashboardMenu = document.getElementById("menu-item-admin-dashboard");
    const userDashboardMenu = document.getElementById("menu-item-user-dashboard");
  if (adminDashboardMenu) {
    if (role === "admin") {
      adminDashboardMenu.classList.remove("hide");
    } else {
      adminDashboardMenu.classList.add("hide");
    }
  }
    userDashboardMenu?.classList.toggle("hide", role !== "user");
    const name = byId("nav-user-display-name");
    const badge = byId("nav-user-role-badge");
    if (name) name.textContent = displayName;
    if (badge) {
      badge.textContent = role.toUpperCase();
      badge.className = `role-badge badge-${role}`;
    }
    renderAvatar(profile.avatar_url, displayName);
  }

  async function checkAuthState() {
    try {
      const response = await fetch("/api/auth/me", {
        headers: { Accept: "application/json" },
      });
      const { data, ok } = await readApiResponse(response);
      currentUser = ok && data.authenticated ? data.user : null;
    } catch {
      currentUser = null;
    }
    updateHeaderAuthUI();
    refreshBookmarkButtons();
    return currentUser;
  }

  async function refreshBookmarkButtons() {
    const buttons = [...document.querySelectorAll("[data-bookmark-article]")];
    if (!buttons.length) return;
    if (!currentUser) { buttons.forEach(button => button.classList.remove("saved")); return; }
    try {
      const ids = buttons.map(button => button.dataset.bookmarkArticle).join(",");
      const response = await fetch(`/api/articles/bookmarks/status?article_ids=${encodeURIComponent(ids)}`);
      const { data, ok } = await readApiResponse(response);
      if (!ok) return;
      const saved = new Set(data.data.article_ids.map(String));
      buttons.forEach(button => {
        const isSaved = saved.has(button.dataset.bookmarkArticle);
        button.classList.toggle("saved", isSaved);
        button.setAttribute("aria-label", isSaved ? "Remove bookmark" : "Save article");
        button.title = isSaved ? "Remove bookmark" : "Save article";
      });
    } catch { /* Optional progressive enhancement. */ }
  }

  function wireBookmarkButtons() {
    document.querySelectorAll("[data-bookmark-article]").forEach(button => button.addEventListener("click", async event => {
      event.preventDefault(); event.stopPropagation();
      if (!currentUser) { openAuthModal("login"); return; }
      button.disabled = true;
      try {
        const response = await fetch(`/api/articles/${button.dataset.bookmarkArticle}/bookmark`, { method: "POST" });
        const { data, ok } = await readApiResponse(response);
        if (!ok) throw new Error(data.message || "Unable to update bookmark.");
        button.classList.toggle("saved", data.is_bookmarked);
        button.setAttribute("aria-label", data.is_bookmarked ? "Remove bookmark" : "Save article");
        button.title = data.is_bookmarked ? "Remove bookmark" : "Save article";
        showToast(data.is_bookmarked ? "Article saved to bookmarks." : "Bookmark removed.");
      } catch (error) { showToast(error.message, "error"); }
      finally { button.disabled = false; }
    }));
  }

  function wireStoryClusterButtons() {
    document.querySelectorAll("[data-story-cluster-url]").forEach(button => {
      button.addEventListener("click", event => {
        event.preventDefault();
        event.stopPropagation();
        window.location.assign(button.dataset.storyClusterUrl);
      });
    });
  }

  async function handleRegister(event) {
    event.preventDefault();
    const button = byId("btn-submit-register");
    setSubmitting(button, true);
    try {
      const response = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          full_name: byId("reg-fullname").value.trim(),
          username: byId("reg-username").value.trim(),
          email: byId("reg-email").value.trim(),
          password: byId("reg-password").value,
        }),
      });
      const { data, ok } = await readApiResponse(response);
      if (!ok) throw new Error(data.message || "Registration failed.");
      showToast(data.message || "Account created. Please sign in.");
      showAuthForm("form-login");
    } catch (error) {
      showAuthAlert(error.message);
    } finally {
      setSubmitting(button, false);
    }
  }

  function safeNextPath() {
    const next = new URLSearchParams(window.location.search).get("next");
    return next && next.startsWith("/") && !next.startsWith("//") ? next : null;
  }

  async function handleLogin(event) {
    event.preventDefault();
    const button = byId("btn-submit-login");
    setSubmitting(button, true);
    try {
      const response = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          identity: byId("login-identity").value.trim(),
          password: byId("login-password").value,
        }),
      });
      const { data, ok } = await readApiResponse(response);
      if (!ok) throw new Error(data.message || "Sign in failed.");
      currentUser = data.user;
      updateHeaderAuthUI();
      document.dispatchEvent(new CustomEvent("auth:changed"));
      closeAuthModal();
      showToast(data.message || "Signed in.");
      const nextPath = safeNextPath();
      if (nextPath) window.location.assign(nextPath);
    } catch (error) {
      showAuthAlert(error.message);
    } finally {
      setSubmitting(button, false);
    }
  }

  async function handleLogout() {
    try {
      await fetch("/api/auth/logout", { method: "POST" });
    } finally {
      currentUser = null;
      updateHeaderAuthUI();
      document.dispatchEvent(new CustomEvent("auth:changed"));
      showToast("Signed out.");
      if (window.location.pathname === "/profile") window.location.assign("/");
    }
  }

  async function handlePasswordResetRequest(event) {
    event.preventDefault();
    const button = byId("btn-submit-reset-request");
    setSubmitting(button, true);
    try {
      const response = await fetch("/api/auth/password-reset/request", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: byId("reset-request-email").value.trim() }),
      });
      const { data, ok } = await readApiResponse(response);
      if (!ok) throw new Error(data.message || "Unable to request reset.");
      showToast(data.message || "If the account exists, a reset link was sent.");
      showAuthForm("form-login");
    } catch (error) {
      showAuthAlert(error.message);
    } finally {
      setSubmitting(button, false);
    }
  }

  function getResetToken() {
    return new URLSearchParams(window.location.search).get("reset_token") || "";
  }

  async function handlePasswordResetConfirm(event) {
    event.preventDefault();
    const password = byId("reset-new-password").value;
    const confirmPassword = byId("reset-confirm-password").value;
    if (password !== confirmPassword) {
      showAuthAlert("Passwords do not match.");
      return;
    }
    const button = byId("btn-submit-reset-confirm");
    setSubmitting(button, true);
    try {
      const response = await fetch("/api/auth/password-reset/confirm", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ token: getResetToken(), password }),
      });
      const { data, ok } = await readApiResponse(response);
      if (!ok) throw new Error(data.message || "Unable to reset password.");
      window.history.replaceState({}, document.title, window.location.pathname);
      showToast(data.message || "Password reset. Please sign in.");
      showAuthForm("form-login");
    } catch (error) {
      showAuthAlert(error.message);
    } finally {
      setSubmitting(button, false);
    }
  }

  function togglePasswordVisibility() {
    const input = byId("login-password");
    const button = byId("toggle-login-pass");
    if (!input || !button) return;
    const showing = input.type === "text";
    input.type = showing ? "password" : "text";
    button.setAttribute("aria-label", showing ? "Show password" : "Hide password");
  }

  function wireAuthEvents() {
    byId("nav-login-btn")?.addEventListener("click", () => openAuthModal("login"));
    byId("nav-register-btn")?.addEventListener("click", () => openAuthModal("register"));
    byId("auth-modal-close")?.addEventListener("click", closeAuthModal);
    byId("auth-modal-overlay")?.addEventListener("click", event => {
      if (event.target === byId("auth-modal-overlay")) closeAuthModal();
    });
    byId("tab-auth-login")?.addEventListener("click", () => switchAuthTab("form-login"));
    byId("tab-auth-register")?.addEventListener("click", () => switchAuthTab("form-register"));
    byId("form-login")?.addEventListener("submit", handleLogin);
    byId("form-register")?.addEventListener("submit", handleRegister);
    byId("forgot-pass-trigger")?.addEventListener("click", () => showAuthForm("form-reset-request"));
    byId("form-reset-request")?.addEventListener("submit", handlePasswordResetRequest);
    byId("form-reset-confirm")?.addEventListener("submit", handlePasswordResetConfirm);
    byId("back-to-login-request")?.addEventListener("click", () => showAuthForm("form-login"));
    byId("back-to-login-confirm")?.addEventListener("click", () => showAuthForm("form-login"));
    byId("btn-action-logout")?.addEventListener("click", handleLogout);
    byId("toggle-login-pass")?.addEventListener("click", togglePasswordVisibility);

    const menu = byId("user-profile-menu");
    const trigger = byId("user-profile-trigger");
    trigger?.addEventListener("click", event => {
      event.stopPropagation();
      const hidden = byId("user-dropdown-card")?.classList.toggle("hide");
      menu?.setAttribute("aria-expanded", String(!hidden));
    });
    document.addEventListener("click", () => {
      byId("user-dropdown-card")?.classList.add("hide");
      menu?.setAttribute("aria-expanded", "false");
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape") closeAuthModal();
    });

    if (getResetToken()) {
      openAuthModal("login");
      showAuthForm("form-reset-confirm");
    }
  }

  window.TMM = {
    checkAuthState,
    closeAuthModal,
    openAuthModal,
    readApiResponse,
    setSubmitting,
    showToast,
  };

  document.addEventListener("DOMContentLoaded", () => {
    wireAuthEvents();
    wireBookmarkButtons();
    wireStoryClusterButtons();
    checkAuthState();
  });
})();
