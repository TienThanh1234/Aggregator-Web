/**
 * Progressive enhancement for the protected profile settings page.
 */
(() => {
  "use strict";

  const byId = id => document.getElementById(id);
  const api = window.TMM;
  if (!api) return;

  function initials(name) {
    return (name || "U").trim().split(/\s+/).slice(0, 2).map(part => part[0]).join("").toUpperCase();
  }

  function renderAvatar(avatarUrl, displayName) {
    const image = byId("settings-avatar-image");
    const fallback = byId("settings-avatar-fallback");
    const hasAvatar = Boolean(avatarUrl);
    image.src = hasAvatar ? avatarUrl : "";
    image.classList.toggle("hide", !hasAvatar);
    fallback.textContent = initials(displayName);
    fallback.classList.toggle("hide", hasAvatar);
  }

  async function handleProfileUpdate(event) {
    event.preventDefault();
    const button = byId("btn-profile-save");
    api.setSubmitting(button, true);
    try {
      const response = await fetch("/api/profile", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          full_name: byId("profile-full-name").value.trim(),
          email: byId("profile-email").value.trim(),
        }),
      });
      const { data, ok } = await api.readApiResponse(response);
      if (!ok) throw new Error(data.message || "Unable to update profile.");
      api.showToast(data.message || "Profile updated.");
      await api.checkAuthState();
    } catch (error) {
      api.showToast(error.message, "error");
    } finally {
      api.setSubmitting(button, false);
    }
  }

  async function handlePasswordChange(event) {
    event.preventDefault();
    const button = byId("btn-password-save");
    api.setSubmitting(button, true);
    try {
      const response = await fetch("/api/profile/password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          current_password: byId("profile-current-password").value,
          new_password: byId("profile-new-password").value,
          confirm_password: byId("profile-confirm-password").value,
        }),
      });
      const { data, ok } = await api.readApiResponse(response);
      if (!ok) throw new Error(data.message || "Unable to change password.");
      window.location.assign("/");
    } catch (error) {
      api.showToast(error.message, "error");
      api.setSubmitting(button, false);
    }
  }

  async function handleAvatarUpload(event) {
    event.preventDefault();
    const avatar = byId("profile-avatar-file").files[0];
    if (!avatar) return;
    const button = byId("btn-avatar-upload");
    api.setSubmitting(button, true);
    try {
      const body = new FormData();
      body.append("avatar", avatar);
      const response = await fetch("/api/profile/avatar", { method: "POST", body });
      const { data, ok } = await api.readApiResponse(response);
      if (!ok) throw new Error(data.message || "Unable to upload picture.");
      renderAvatar(data.avatar_url, byId("profile-full-name").value);
      byId("form-avatar-upload").reset();
      api.showToast(data.message || "Profile picture updated.");
      await api.checkAuthState();
    } catch (error) {
      api.showToast(error.message, "error");
    } finally {
      api.setSubmitting(button, false);
    }
  }

  document.addEventListener("DOMContentLoaded", () => {
    byId("form-profile-details")?.addEventListener("submit", handleProfileUpdate);
    byId("form-password-change")?.addEventListener("submit", handlePasswordChange);
    byId("form-avatar-upload")?.addEventListener("submit", handleAvatarUpload);
  });
})();
