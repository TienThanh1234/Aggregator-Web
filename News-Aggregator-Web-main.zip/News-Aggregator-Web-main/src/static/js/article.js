/**
 * Article-only Summary, Fact-check, and contextual dialogue enhancements.
 */
(() => {
  "use strict";

  const reader = document.querySelector("[data-article-id]");
  if (!reader) return;

  const articleId = reader.dataset.articleId;
  const title = document.querySelector(".article-headline")?.textContent.trim() || "";
  const text = [...document.querySelectorAll(".article-body-text p")]
    .map(paragraph => paragraph.textContent.trim())
    .filter(Boolean)
    .join("\n\n");
  const controllers = new Map();
  let factCheckCache = null;
  let factCheckRetryTimer = null;
  let truthScoreDetailCache = null;
  const history = [
    {
      sender: "assistant",
      text: `I have analyzed “${title}”. Ask about its context, evidence, or implications.`,
    },
  ];

  function beginRequest(surface) {
    controllers.get(surface)?.abort();
    const controller = new AbortController();
    controllers.set(surface, controller);
    return controller;
  }

  function isCurrent(controller) {
    return (
      !controller.signal.aborted &&
      document.querySelector("[data-article-id]")?.dataset.articleId === articleId
    );
  }

  function appendTextList(container, values, className = "") {
    container.replaceChildren();
    values.forEach(value => {
      const item = document.createElement("li");
      if (className) item.className = className;
      item.textContent = value;
      container.appendChild(item);
    });
  }

  async function fetchSummary() {
    const bullets = document.getElementById("panel-summary-bullets");
    const takeaways = document.getElementById("panel-summary-takeaways");
    if (!bullets || !takeaways) return;
    appendTextList(bullets, ["Distilling facts and implications…"]);
    const controller = beginRequest("summary");
    try {
      const response = await fetch("/api/gemini/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ title, text, article_id: articleId }),
        signal: controller.signal,
      });
      if (!response.ok) throw new Error("Summary is temporarily unavailable.");
      const data = await response.json();
      if (!isCurrent(controller)) return;
      appendTextList(bullets, data.summary || []);
      appendTextList(takeaways, data.keyTakeaways || []);
    } catch (error) {
      if (error.name === "AbortError") return;
      appendTextList(bullets, [error.message]);
      takeaways.replaceChildren();
    }
  }

  async function fetchFactCheck() {
    const verified = document.getElementById("panel-factcheck-verified");
    const box = document.getElementById("panel-factcheck-unverified-container");
    if (!verified || !box) return;
    if (factCheckCache && factCheckCache.status !== "processing") {
      renderFactCheck(factCheckCache);
      return;
    }
    appendTextList(verified, ["Evaluating claims…"]);
    const controller = beginRequest("factcheck");
    try {
      const response = await fetch(`/api/articles/${articleId}/fact-check`, {
        method: "POST",
        signal: controller.signal,
      });
      if (!response.ok) throw new Error("Fact-check is temporarily unavailable.");
      const payload = await response.json();
      if (!isCurrent(controller)) return;
      const data = payload.data;
      renderFactCheck(data);
      if (data.status === "processing") {
        factCheckCache = null;
        window.clearTimeout(factCheckRetryTimer);
        factCheckRetryTimer = window.setTimeout(fetchFactCheck, data.retry_after_ms || 1200);
        return;
      }
      factCheckCache = data;
    } catch (error) {
      if (error.name === "AbortError") return;
      appendTextList(verified, [error.message]);
      box.classList.add("hide");
    }
  }

  function appendScoreRow(container, label, value, className = "") {
    const row = document.createElement("div");
    row.className = `truth-score-row ${className}`.trim();
    const name = document.createElement("span");
    const score = document.createElement("span");
    name.textContent = label;
    score.textContent = value;
    row.append(name, score);
    container.appendChild(row);
  }

  function renderTruthScoreDetails(data) {
    const container = document.getElementById("truth-score-details");
    if (!container) return;
    container.replaceChildren();
    if (!data || data.detail === null) {
      const message = document.createElement("p");
      message.className = "truth-score-loading";
      message.textContent = "Score details are not available yet.";
      container.appendChild(message);
      return;
    }
    const total = Number(data.total_score ?? data.truth_score ?? 0);
    const totalRow = document.createElement("div");
    totalRow.className = "truth-score-total";
    const label = document.createElement("span");
    const score = document.createElement("strong");
    label.textContent = "Final Truth Score";
    score.textContent = `${Number.isFinite(total) ? total : 0}/100`;
    totalRow.append(label, score);
    container.appendChild(totalRow);
    appendScoreRow(container, "Base Score", `${data.base_score || 0}/80`, "is-highlighted");
    appendScoreRow(container, "Source reliability", `${data.source_reliability_score || 0}/50`);
    appendScoreRow(container, "Corroboration", `${data.corroboration_score || 0}/10`);
    appendScoreRow(container, "Metadata / provenance", `${data.metadata_score || 0}/10`);
    appendScoreRow(container, "Content completeness", `${data.content_score || 0}/10`);
    const subtitle = document.createElement("p");
    subtitle.className = "truth-score-subtitle";
    subtitle.textContent = "On-demand clarity";
    container.appendChild(subtitle);
    appendScoreRow(container, "Clarity contribution", `${data.linguistic_clarity_score || 0}/20`, "is-highlighted");
    appendScoreRow(container, "Verification", `${data.verification_score || 0}/100`);
    appendScoreRow(container, "Ambiguity penalty", `-${data.ambiguity_penalty || 0}/20`);
  }

  async function fetchTruthScoreDetails() {
    const container = document.getElementById("truth-score-details");
    if (!container) return;
    if (truthScoreDetailCache) {
      renderTruthScoreDetails(truthScoreDetailCache);
      return;
    }
    container.replaceChildren();
    const loading = document.createElement("p");
    loading.className = "truth-score-loading";
    loading.textContent = "Loading score details…";
    container.appendChild(loading);
    try {
      const response = await fetch(`/api/articles/${articleId}/truth-score`);
      if (!response.ok) throw new Error("Truth Score details are temporarily unavailable.");
      const payload = await response.json();
      truthScoreDetailCache = payload.data;
      renderTruthScoreDetails(truthScoreDetailCache);
    } catch (error) {
      loading.textContent = error.message;
    }
  }

  function initTruthScorePopover() {
    const trigger = document.getElementById("truth-score-trigger");
    const popover = document.getElementById("truth-score-popover");
    if (!trigger || !popover) return;
    trigger.addEventListener("click", () => {
      const open = popover.classList.toggle("hide") === false;
      trigger.setAttribute("aria-expanded", String(open));
      if (open) fetchTruthScoreDetails();
    });
    document.addEventListener("click", event => {
      if (!popover.classList.contains("hide") && !popover.contains(event.target) && !trigger.contains(event.target)) {
        popover.classList.add("hide");
        trigger.setAttribute("aria-expanded", "false");
      }
    });
    document.addEventListener("keydown", event => {
      if (event.key === "Escape") {
        popover.classList.add("hide");
        trigger.setAttribute("aria-expanded", "false");
      }
    });
  }

  function highlightAmbiguousWords(findings) {
    const terms = [...new Set((findings || []).map(item => item.term).filter(Boolean))]
      .sort((a, b) => b.length - a.length);
    if (!terms.length) return;
    const escaped = terms.map(term => term.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"));
    const matcher = new RegExp(`(?<!\\w)(${escaped.join("|")})(?!\\w)`, "giu");
    const details = new Map((findings || []).map(item => [item.term.toLocaleLowerCase(), item]));
    const walker = document.createTreeWalker(document.querySelector(".article-body-text"), NodeFilter.SHOW_TEXT);
    const nodes = [];
    while (walker.nextNode()) nodes.push(walker.currentNode);
    nodes.forEach(node => {
      if (!node.nodeValue.trim() || node.parentElement.closest("mark.ambiguous-word")) return;
      matcher.lastIndex = 0;
      if (!matcher.test(node.nodeValue)) return;
      matcher.lastIndex = 0;
      const fragment = document.createDocumentFragment();
      let cursor = 0;
      node.nodeValue.replace(matcher, (match, _term, index) => {
        fragment.append(document.createTextNode(node.nodeValue.slice(cursor, index)));
        const mark = document.createElement("mark");
        mark.className = "ambiguous-word";
        mark.textContent = match;
        const finding = details.get(match.toLocaleLowerCase());
        mark.title = finding?.explanation || "Ambiguous wording";
        fragment.append(mark);
        cursor = index + match.length;
        return match;
      });
      fragment.append(document.createTextNode(node.nodeValue.slice(cursor)));
      node.replaceWith(fragment);
    });
  }

  function renderFactCheck(data) {
    const verified = document.getElementById("panel-factcheck-verified");
    const box = document.getElementById("panel-factcheck-unverified-container");
    if (!verified || !box) return;
    if (data.status === "processing") {
      appendTextList(verified, ["Verification is still running. Final score will update automatically…"]);
      box.classList.add("hide");
      return;
    }
    const findings = data.findings || [];
    appendTextList(verified, [
      `Verification: ${data.verification_score}/100 (${data.verification_source_type || "unavailable"})`,
      `Ambiguity penalty: -${data.ambiguity_penalty || 0}/20`,
      `Clarity: ${data.clarity_score}/100`,
      data.verification_report || data.report || "No report is available.",
      ...(data.citations || []).map(item => `Evidence: ${item.title}${item.url ? ` — ${item.url}` : ""}`),
    ]);
    const first = findings[0];
    box.classList.toggle("hide", !first);
    document.getElementById("panel-factcheck-claim-text").textContent = first ? `Needs clarification: “${first.term}”` : "No configured ambiguous wording was detected.";
    document.getElementById("panel-factcheck-claim-analysis").textContent = first?.explanation || "";
    highlightAmbiguousWords(findings);
    updateFinalScoreGauge(data.final_truth_score);
    truthScoreDetailCache = null;
    if (!document.getElementById("truth-score-popover")?.classList.contains("hide")) fetchTruthScoreDetails();
  }

  function updateFinalScoreGauge(score) {
    const scoreNode = document.getElementById("gauge-percentage-text");
    if (!scoreNode || !Number.isFinite(Number(score))) return;
    scoreNode.textContent = `${score}%`;
    document.getElementById("gauge-score-label").textContent = "Final evidence score";
    const circle = document.getElementById("gauge-progress-circle");
    if (circle) circle.style.strokeDashoffset = String(113.1 * (1 - Number(score) / 100));
  }

  function renderChat() {
    const container = document.getElementById("panel-dialogue-messages");
    if (!container) return;
    container.replaceChildren();
    history.forEach(message => {
      const bubble = document.createElement("div");
      bubble.className = `chat-bubble ${message.sender}`;
      bubble.textContent = message.text;
      container.appendChild(bubble);
    });
    container.scrollTop = container.scrollHeight;
  }

  async function handleChat(event) {
    event.preventDefault();
    const input = document.getElementById("dialogue-chat-input");
    const query = input.value.trim();
    if (!query) return;
    history.push({ sender: "user", text: query });
    input.value = "";
    renderChat();
    const controller = beginRequest("chat");
    try {
      const response = await fetch("/api/gemini/summarize", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title: `Dialogue Context: ${query}`,
          text: `Article ID: ${articleId}. Article: ${title}.\nText: ${text}\nUser message: ${query}`,
        }),
        signal: controller.signal,
      });
      if (!response.ok) throw new Error("Tememo could not answer right now.");
      const data = await response.json();
      if (!isCurrent(controller)) return;
      history.push({
        sender: "assistant",
        text: (data.summary || []).join(" ") || "No analysis returned.",
      });
    } catch (error) {
      if (error.name === "AbortError") return;
      history.push({ sender: "assistant", text: error.message });
    }
    renderChat();
  }

  function switchTab(tab) {
    document.querySelectorAll(".tememo-tab").forEach(button => {
      button.classList.toggle("active", button.dataset.tab === tab);
    });
    document.querySelectorAll(".tememo-tab-panels .tab-panel").forEach(panel => {
      panel.classList.toggle("hide", panel.id !== `panel-${tab}`);
    });
    if (tab === "summary") fetchSummary();
    if (tab === "factcheck") fetchFactCheck();
  }

  function init() {
    const score = Number(document.getElementById("gauge-percentage-text")?.textContent.replace("%", "")) || 0;
    const circle = document.getElementById("gauge-progress-circle");
    if (circle) circle.style.strokeDashoffset = String(113.1 * (1 - score / 100));
    document.querySelectorAll(".tememo-tab").forEach(button => {
      button.addEventListener("click", () => switchTab(button.dataset.tab));
    });
    document.getElementById("dialogue-input-form")?.addEventListener("submit", handleChat);
    renderChat();
    initTruthScorePopover();
    fetchSummary();
    fetchFactCheck();
    initInteractions();
  }

  async function initInteractions() {
    const comments = document.getElementById("article-comment-list");
    const form = document.getElementById("article-comment-form");
    const note = document.getElementById("comment-login-note");
    const likeButton = document.getElementById("reaction-like");
    const dislikeButton = document.getElementById("reaction-dislike");
    if (!comments) return;
    const user = await window.TMM?.checkAuthState();
    form?.classList.toggle("hide", !user); note?.classList.toggle("hide", Boolean(user));
    const load = async () => { const r=await fetch(`/api/articles/${articleId}/comments`); const d=await r.json(); const items=d.data.items||[]; comments.innerHTML=items.map(c=>`<article class="article-comment"><div class="comment-avatar">${(c.author.full_name||c.author.username||"R")[0]}</div><div><strong>${c.author.full_name||c.author.username||"Reader"}</strong><p>${c.content}</p><small>${new Date(c.created_at).toLocaleString()}</small>${user && c.author.id !== user.id ? `<button class="comment-report-btn" type="button" data-report-comment="${c.id}">Report</button>` : ""}</div></article>`).join("")||"<p class=\"discussion-empty\">No comments yet. Be the first to add perspective.</p>"; const count=document.getElementById("article-comment-count"); if(count) count.textContent=d.data.total||0; };
    const summary = async () => { const r=await fetch(`/api/articles/${articleId}/reactions/summary`);const d=await r.json();const s=d.data; document.getElementById("reaction-like-count").textContent=s.like_count;document.getElementById("reaction-dislike-count").textContent=s.dislike_count;likeButton?.classList.toggle("active",s.user_reaction_type==="like");dislikeButton?.classList.toggle("active",s.user_reaction_type==="dislike"); };
    form?.addEventListener("submit", async e=>{e.preventDefault();const input=document.getElementById("article-comment-content");const r=await fetch(`/api/articles/${articleId}/comments`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({content:input.value})});if(r.ok){input.value="";load();}else {const data=await r.json().catch(()=>({}));window.TMM.showToast(data.message||"Unable to post comment.","error");}});
    const react = async reactionType => {if(!user){window.TMM.openAuthModal("login");return;}const r=await fetch(`/api/articles/${articleId}/reactions`,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({reaction_type:reactionType})});if(r.ok)summary();else window.TMM.showToast("Unable to save your reaction.","error");};
    likeButton?.addEventListener("click",()=>react("like"));
    dislikeButton?.addEventListener("click",()=>react("dislike"));
    comments.addEventListener("click", async event => { const button = event.target.closest("[data-report-comment]"); if (!button) return; const reason = window.prompt("Report reason: spam, harassment, hate_or_abuse, misinformation, off_topic, or other"); if (!reason) return; const response = await fetch(`/api/comments/${button.dataset.reportComment}/reports`, {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({reason})}); const data = await response.json().catch(()=>({})); window.TMM.showToast(data.message || (response.ok ? "Report received." : "Unable to submit report."), response.ok ? "success" : "error"); });
    load(); summary();
  }

  if (document.readyState === "loading") {
    document.addEventListener("DOMContentLoaded", init);
  } else {
    init();
  }
})();
