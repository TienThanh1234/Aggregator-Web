"""
Real Scraper Trigger Script

Runs the actual VNExpressScraper to fetch live articles and populate the database
with real URLs (including working cover images) for testing.

Usage:
    python real_trigger_scraper.py
"""

import sys
import logging
from pathlib import Path

# Setup logging
logging.basicConfig(
    level=logging.INFO,
    format="[%(levelname)s] %(message)s",
    handlers=[logging.StreamHandler()],
)
logger = logging.getLogger(__name__)

# Add src directory to path
sys.path.insert(0, str(Path(__file__).parent))

from app import create_app, db
from services.scheduler_service import SchedulerService
from scraper.vnexpress_scraper import VNExpressScraper


def main():
    logger.info("=" * 60)
    logger.info("REAL LIVE SCRAPER JOB TRIGGER")
    logger.info("=" * 60)

    # Create Flask app
    app = create_app()

    if SchedulerService._app is None:
        SchedulerService._app = app

    logger.info("\n[STEP 1] Running live scraper job...")
    logger.info("-" * 60)
    try:
        # Run the real scraper job (this will fetch real pages from VnExpress)
        SchedulerService._scraper_job()
        logger.info("[SUCCESS] Real scraper job executed successfully")
    except Exception as exc:
        logger.error(f"[ERROR] Real scraper job failed: {exc}", exc_info=True)
        return 1

    logger.info("\n[STEP 2] Check database state")
    logger.info("-" * 60)
    with app.app_context():
        from models import Article, RawArticle

        raw_count = RawArticle.query.count()
        article_count = Article.query.count()

        logger.info(f"Raw articles total:     {raw_count}")
        logger.info(f"Articles (final):       {article_count}")

        # Show latest 5 articles with their cover image URLs
        latest = Article.query.order_by(Article.scraped_at.desc()).limit(5).all()
        if latest:
            logger.info("\nLatest real articles in DB:")
            for a in latest:
                logger.info(f"  [{a.id}] {a.title[:60]}...")
                logger.info(f"       Category: {[c.name for c in a.categories]}")
                logger.info(f"       Cover Image URL: {a.cover_image_url}")
                logger.info(f"       Scraped At: {a.scraped_at}")
                logger.info("-" * 40)

    return 0


if __name__ == "__main__":
    try:
        sys.exit(main())
    except Exception as exc:
        logger.error(f"[ERROR] Script failed: {exc}", exc_info=True)
        sys.exit(1)
