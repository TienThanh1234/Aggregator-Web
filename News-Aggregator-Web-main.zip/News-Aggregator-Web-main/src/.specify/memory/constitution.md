# News Aggregator Web Application Constitution

## Project Overview

The **News Aggregator Web Application** is a full-stack web service designed to automatically scrape news articles from multiple specified news websites, store them in a PostgreSQL database, and present them to users through a clean, responsive web interface. The system prioritizes reliability, code maintainability, and extensibility through object-oriented design patterns.

**Primary Goal:** Build an MVP that demonstrates the complete ETL (Extract, Transform, Load) pipeline—from scraping articles to persisting them in a database and displaying them on a web UI—before implementing advanced features.

---

## Core Tech Stack

### Backend & Application Layer
- **Framework:** Python 3.11+ with Flask
- **Runtime & Build:** WSGI-compliant server (Gunicorn for production)

### Data Layer
- **Database:** PostgreSQL (hosted via Supabase for cloud scalability)
- **ORM:** Flask-SQLAlchemy for object-relational mapping and schema management
- **Migrations:** Alembic (integrated with Flask-SQLAlchemy) for versioned schema changes

### Web Scraping & Data Acquisition
- **HTTP Client:** Requests library
- **HTML Parsing:** BeautifulSoup4
- **Task Scheduling:** APScheduler for cron-like automated scraping jobs

### Frontend & UI
- **Template Engine:** Jinja2 (built into Flask)
- **Markup:** HTML5
- **Styling:** CSS3 (BEM methodology recommended)
- **Interactivity:** Vanilla JavaScript (ES6+)
- **No external frameworks required** for MVP phase

### Infrastructure & Configuration
- **Environment Management:** Python-dotenv (loads `.env` for secrets and config)
- **Logging:** Python stdlib `logging` module with structured output

---

## Architectural & Design Principles

### I. Modular Scraping via Object-Oriented Design (NON-NEGOTIABLE)
- **Base Scraper Class:** All news source scrapers must inherit from a single abstract `BaseScraper` class
- **Contract:** Every scraper subclass must implement `scrape()`, `validate_data()`, and `transform()` methods
- **Reusability:** Shared logic (retry logic, rate limiting, error handling) lives in the base class
- **Extensibility:** Adding a new news source requires only creating a new scraper subclass—no modifications to core framework code
- **Organization:** All scraper implementations reside in `/src/scraper/` directory, one file per source

### II. Strict MVC Pattern Enforcement
- **Models** (`/src/models.py`): SQLAlchemy ORM definitions for Articles, Sources, Users, etc. No business logic beyond schema definition
- **Views** (`/src/templates/`): Jinja2 template files for HTML rendering. No data processing logic; only iterate and display
- **Controllers** (`/src/routes.py`): Flask route handlers that orchestrate models, services, and render views. Keep route handlers thin; delegate to service functions
- **Services** (`/src/services/`): Business logic, data transformation, and inter-model coordination lives here, not in routes

### III. Environment Configuration Compliance (NON-NEGOTIABLE)
- **No Hardcoding:** All sensitive data—database URLs, API keys, secret keys, credentials—must be loaded from `.env` file
- **`.env` Template:** Maintain a `.env.example` file showing all required variables with placeholder values (no real secrets)
- **Validation:** Application startup must verify all required environment variables are present; fail fast if any are missing
- **File Location:** `.env` file must be in the project root, and MUST be in `.gitignore` to prevent accidental commits

### IV. Data Integrity & Duplicate Prevention (NON-NEGOTIABLE)
- **Unique Constraints:** Articles table includes a composite unique constraint (e.g., `source_id + article_url + published_date`) to prevent duplicates at the database level
- **Pre-Insert Validation:** Before storing an article, check if it already exists in the database
- **Content Hashing (Optional, Post-MVP):** For exact duplicate detection, store a hash of article content; compare new articles against existing hashes
- **Soft Deletes (Post-MVP):** Implement soft delete flags for audit trails instead of hard deletes
- **Logging:** All duplicate-skipping events must be logged for monitoring and debugging

### V. Code Organization & Naming Conventions
- **Modules:** Clear, lowercase module names matching their responsibility (e.g., `models.py`, `routes.py`, `scraper/`)
- **Classes:** PascalCase for class names (e.g., `BaseScraper`, `Article`)
- **Functions/Methods:** snake_case for function and method names
- **Database:** snake_case for table and column names
- **Constants:** UPPER_SNAKE_CASE for module-level constants

### VI. Error Handling & Resilience
- **Graceful Degradation:** Scraper failures on one news source must not crash the entire application
- **Retry Logic:** Implement exponential backoff for transient HTTP errors (429, 503, timeouts)
- **Logging:** Use structured logging (include context: source, timestamp, error type) for troubleshooting
- **No Silent Failures:** Every caught exception must be logged; critical issues must raise alerts (post-MVP)

### VII. Testing & Quality Assurance
- **Unit Tests:** Each scraper subclass must have unit tests mocking HTTP requests
- **Integration Tests:** Test the full ETL pipeline (scrape → transform → insert) with a test database
- **Fixture Data:** Maintain sample HTML files for scrapers to parse in tests (prevents brittle live-website tests)
- **Test Database:** Use PostgreSQL with transaction rollback for test isolation
- **Coverage Target:** Minimum 80% code coverage for critical paths (scraping, data validation, routes)

### VIII. Environment Governance (Development Workflow)
- **Environment Activation Policy:** All CLI operations involving Flask commands, scraping scripts, database migrations, or other runtime scripts MUST be executed inside an activated Python virtual environment (`venv`).
- **Automation Requirement:** The development environment MUST be configured to recognize and activate the virtual environment automatically wherever possible.
- **VS Code Configuration:** For VS Code users, `python.terminal.useEnvFile` MUST be enabled and `python.envFile` MUST point to the local `.env` file so that terminal sessions receive environment variables automatically.
- **Manual Activation Check:** Before running any command, the terminal MUST show the `(venv)` prefix. If it does not, the developer or AI agent MUST activate the virtual environment first using `venv\Scripts\Activate.ps1` on Windows or `source venv/bin/activate` on Linux/macOS.
- **Dependency Synchronization:** Whenever a new package is installed, the change MUST be reflected immediately in `requirements.txt` by updating the dependency list so the environment stays synchronized across the team.

---

## Spec Kit & Repository Constraints

### Documentation Location (NON-NEGOTIABLE)
- **All Spec Kit artifacts** (specs, plans, tasks, checklists, constitution, etc.) **MUST be generated and placed strictly inside the `/src` directory**
- **Feature Artifact Root:** All feature-specific artifacts MUST live under `/src/specs/`
- **Feature Directory Naming:** Each feature MUST use `/src/specs/<NNN-kebab-case-feature-name>/`, where `NNN` is a unique three-digit sequential number
- **Canonical Feature Files:**
  - `/src/specs/<NNN-feature-name>/spec.md` (functional specification)
  - `/src/specs/<NNN-feature-name>/plan.md` (implementation plan)
  - `/src/specs/<NNN-feature-name>/tasks.md` (task breakdown)
  - `/src/specs/<NNN-feature-name>/checklists/*.md` (feature checklists, when generated)
- **Spec Kit Configuration:** Templates, scripts, extension configuration, workflow metadata, and the constitution MUST remain under `/src/.specify/`
- **Naming Consistency:** A feature's directory name and numeric prefix MUST be identical across its specification, plan, tasks, checklist references, and feature metadata. Artifact filenames MUST use the canonical names above rather than feature-specific suffixes such as `_specs.md`, `_plan.md`, or `_tasks.md`
- **Active Feature Pointer:** `/src/.specify/feature.json` MUST reference the active feature directory relative to `/src`
- **Rationale:** Keeps project documentation co-located with source code; facilitates code review and keeps specs in sync with implementation
- **Consistency Requirement:** Documentation and source code are one system; spec changes must trigger code reviews, and code changes must update specs

### Version Control
- **`.gitignore`:** Must exclude `.env`, `__pycache__/`, `.venv/`, `.pytest_cache/`, and database migration snapshots
- **Commit Messages:** Follow conventional commits pattern (feat:, fix:, docs:, test:, refactor:)
- **Feature Branches:** Create feature branches for each news source scraper or major feature; merge via PR with spec review

---

## Development Phasing

### Phase 1: Minimum Viable Product (MVP) — Core ETL Pipeline
**Goal:** Deliver a working news scraper and basic UI to stakeholders

**Scope:**
1. Design and implement `BaseScraper` abstract class
2. Implement scrapers for 2–3 primary news sources (e.g., BBC, CNN, TechCrunch)
3. Database schema for articles, sources, categories
4. APScheduler integration for hourly scraping jobs
5. Basic Flask routes: `/articles`, `/articles/<id>`, `/sources`
6. Simple HTML/CSS/JS UI to list and display articles
7. Duplicate detection at database level

**Out of Scope (Post-MVP):**
- User authentication & authorization
- Article search & advanced filtering
- Admin dashboards
- Email notifications
- Caching layer (Redis)
- Article recommendation engine

### Phase 2: Enhancement & Scalability
- Add 5+ additional news sources
- Implement full-text search
- User accounts and personalized feeds
- Advanced error recovery & circuit breakers

### Phase 3: Advanced Features
- Admin dashboard for monitoring scraper health
- Email digest of trending articles
- Machine learning-based categorization
- Performance optimization & database indexing

---

## Code Quality & Compliance Standards

### Type Hinting
- All function signatures must include type hints (Python 3.11+ feature)
- Use `Optional`, `List`, `Dict` from `typing` module for clarity

### Docstrings
- All public methods and classes must have docstrings (Google or NumPy style)
- Document parameters, return types, and potential exceptions

### Logging
- Use Python's `logging` module; configure in app startup
- Log at INFO level for important state changes, DEBUG for detailed flow
- Include context (e.g., article title, source name) in log messages

### Security
- **Input Validation:** Sanitize all user inputs; validate article URLs before storing
- **SQL Injection:** Never use string formatting for SQL; rely on SQLAlchemy ORM
- **CSRF Protection:** Enable Flask-WTF CSRF tokens on all forms (post-MVP)
- **Rate Limiting:** Implement rate limiting on scraper jobs to respect target websites' robots.txt and Terms of Service

### Performance
- **Database Indexing:** Index frequently queried columns (`source_id`, `published_date`, `category`)
- **Pagination:** Paginate article listings (e.g., 20 per page)
- **Caching (Post-MVP):** Cache expensive queries (most recent articles, source list)

---

## Governance

### Constitution Authority
- **Supersedes:** This constitution supersedes all other practices, guidelines, and verbal agreements
- **PRs & Code Review:** Every pull request must verify compliance with architectural principles (MVC, modular scraping, environment config, data integrity)
- **Violations:** Architectural violations (e.g., hardcoded secrets, business logic in views, scrapers not inheriting from base class) must be flagged and rejected in review

### Amendment Process
1. Identify need for amendment (new constraint, design evolution, or lessons learned)
2. Document proposed change with rationale
3. Get team consensus (code review discussion)
4. Update constitution with version bump and amendment date
5. Create or update related specs and plans to reflect change

### Enforcement
- **Automated Checks:** Use pre-commit hooks to detect `.env` file exposure
- **Linting:** Enforce code style (Black for formatting, Flake8 for linting)
- **Review Checklist:** Code reviewers verify:
  - No hardcoded secrets
  - Scrapers inherit from `BaseScraper`
  - MVC boundaries respected
  - Unit and integration tests pass
  - Duplicate prevention logic present (if adding article sources)

---

## Key Metrics & Success Criteria

| Criterion | Target | Phase |
|-----------|--------|-------|
| Scraper Success Rate | ≥ 95% on each run | MVP |
| Duplicate Detection Accuracy | 100% (no false negatives) | MVP |
| Page Load Time (Articles List) | < 500ms (p95) | MVP |
| Code Coverage | ≥ 80% on critical paths | MVP |
| Test Execution Time | < 10s for unit tests | MVP |
| New Source Onboarding Time | ≤ 2 hours (after MVP) | Phase 2 |

---

## Related Documentation

- **[Feature artifacts](../../specs):** Specifications, plans, tasks, and checklists grouped by numbered feature directory
- **[Spec Kit templates](../templates):** Canonical templates used to generate feature artifacts
- **[Spec Kit workflows](../workflows):** Workflow definitions for specification, planning, and task generation

---

**Version:** 1.0.2 | **Ratified:** 2026-06-26 | **Last Amended:** 2026-07-30

---

*This constitution is the foundational governance document for the News Aggregator Web Application project. All team members, contributors, and stakeholders are expected to uphold these principles and constraints.*
