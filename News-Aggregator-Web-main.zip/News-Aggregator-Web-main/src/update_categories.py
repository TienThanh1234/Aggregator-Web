import logging
import os
from app import create_app
from models import db, Category, KeywordRule, Article
from services.classification_service import ClassificationService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

def update_keywords_and_reclassify():
    app = create_app()
    with app.app_context():
        vn_rules = {
            "Technology": [
                "điện thoại", "máy tính", "công nghệ", "phần mềm", "trí tuệ nhân tạo", "smartphone", "laptop", "apple", "samsung", "phần cứng", 
                "viễn thông", "bảo mật", "ai", "mạng xã hội", "internet", "tin học", "thiết bị", "ứng dụng", "chatgpt", "chip", "màn hình", 
                "vi xử lý", "lập trình", "mã nguồn", "thuật toán", "robot", "tự động hóa", "iot", "5g", "6g", "blockchain", "tiền ảo", "bitcoin", 
                "tiền điện tử", "thực tế ảo", "vr", "ar", "siêu máy tính", "trung tâm dữ liệu", "điện toán đám mây", "cloud", "hacker", "mã độc", 
                "virus máy tính", "phần mềm độc hại", "an ninh mạng", "windows", "ios", "android", "macos", "ubuntu"
            ][:50],
            "Sports": [
                "bóng đá", "thể thao", "quần vợt", "tennis", "bóng rổ", "ngoại hạng anh", "vô địch", "huy chương", "olympic", "cầu thủ", 
                "huấn luyện viên", "sea games", "world cup", "euro", "v-league", "giải đấu", "bóng chuyền", "đội tuyển", "điền kinh", "bơi lội", 
                "đua xe", "f1", "quyền anh", "boxing", "võ thuật", "mma", "ufc", "cầu lông", "bóng bàn", "cờ vua", "cờ tướng", "golf", "thể hình", 
                "marathon", "á vận hội", "asiad", "bảng xếp hạng", "cúp c1", "champions league", "la liga", "serie a", "bundesliga", "ligue 1", 
                "fifa", "uefa", "vòng loại", "tứ kết", "bán kết", "chung kết", "giao hữu"
            ][:50],
            "Business": [
                "kinh doanh", "tài chính", "chứng khoán", "ngân hàng", "bất động sản", "doanh nghiệp", "thị trường", "cổ phiếu", "đầu tư", 
                "kinh tế", "xuất nhập khẩu", "lạm phát", "tỷ giá", "vàng", "doanh thu", "lợi nhuận", "startup", "khởi nghiệp", "cổ phần", 
                "cổ đông", "trái phiếu", "lãi suất", "tín dụng", "vay vốn", "nợ xấu", "phá sản", "sáp nhập", "mua lại", "m&a", "thương mại", 
                "bán lẻ", "tiêu dùng", "chuỗi cung ứng", "logistics", "công ty", "tập đoàn", "giám đốc", "ceo", "tài sản", "vn-index", "dow jones", 
                "gdp", "thuế", "hải quan", "đấu thầu", "cổ tức", "giải ngân", "vốn fdi", "kinh tế vĩ mô", "kinh tế vi mô"
            ][:50],
            "Health": [
                "sức khỏe", "y tế", "bệnh viện", "bác sĩ", "ung thư", "vắc xin", "dịch bệnh", "dinh dưỡng", "thuốc", "chữa bệnh", "y khoa", 
                "phẫu thuật", "bệnh nhân", "virus", "chăm sóc", "phòng khám", "tiêm chủng", "vi khuẩn", "nhiễm trùng", "miễn dịch", "huyết áp", 
                "tiểu đường", "tim mạch", "đột quỵ", "béo phì", "giảm cân", "tập thể dục", "yoga", "gym", "thai kỳ", "nhi khoa", "nha khoa", 
                "da liễu", "đông y", "tây y", "dược phẩm", "thực phẩm chức năng", "cấp cứu", "y tá", "điều dưỡng", "khám bệnh", "xét nghiệm", 
                "siêu âm", "x-quang", "mri", "nội soi", "chẩn đoán", "điều trị", "phục hồi chức năng", "tâm lý"
            ][:50],
            "Entertainment": [
                "giải trí", "showbiz", "điện ảnh", "ca sĩ", "diễn viên", "phim", "âm nhạc", "nghệ sĩ", "hoa hậu", "truyền hình", "nghệ thuật", 
                "liveshow", "nhạc trẻ", "sân khấu", "vpop", "kpop", "hollywood", "gameshow", "rap", "hip hop", "bolero", "cải lương", "chèo", 
                "tuồng", "kịch", "múa", "xiếc", "ảo thuật", "người mẫu", "thời trang", "thảm đỏ", "scandal", "tin đồn", "hẹn hò", "kết hôn", 
                "ly hôn", "fan hâm mộ", "thần tượng", "idol", "concert", "đạo diễn", "kịch bản", "rạp chiếu phim", "box office", "doanh thu phòng vé", 
                "netflix", "truyền hình thực tế", "talkshow", "hài kịch", "danh hài"
            ][:50],
            "Science": [
                "khoa học", "vũ trụ", "nasa", "nghiên cứu", "phát minh", "sinh học", "hóa học", "vật lý", "hành tinh", "thiên văn", "khảo cổ", 
                "công nghệ sinh học", "phát hiện", "động vật", "thực vật", "biến đổi khí hậu", "môi trường", "hố đen", "dải ngân hà", "sao hỏa", 
                "sao mộc", "sao kim", "sao thổ", "trái đất", "mặt trăng", "mặt trời", "tiểu hành tinh", "sao chổi", "vi sinh vật", "gen", "adn", 
                "tiến hóa", "khủng long", "hóa thạch", "lượng tử", "nguyên tử", "phân tử", "năng lượng", "điện từ", "quang học", "toán học", 
                "nhà khoa học", "nobel", "bài báo khoa học", "thí nghiệm", "phòng thí nghiệm", "vệ tinh", "tàu vũ trụ", "kính viễn vọng", "trạm vũ trụ"
            ][:50],
            "Education": [
                "giáo dục", "trường học", "đại học", "học sinh", "sinh viên", "giáo viên", "giảng viên", "giáo sư", "tiến sĩ", "thạc sĩ", "cử nhân", 
                "tốt nghiệp", "tuyển sinh", "thi cử", "điểm chuẩn", "học bổng", "du học", "đào tạo", "môn học", "giáo trình", "sách giáo khoa", 
                "học phí", "bằng cấp", "chứng chỉ", "tiếng anh", "ielts", "toeic", "ngoại ngữ", "trực tuyến", "elearning", "sư phạm", "mầm non", 
                "tiểu học", "trung học", "phổ thông", "hướng nghiệp", "dạy thêm", "học thêm", "bạo lực học đường", "kỷ luật", "thi đại học", 
                "xét tuyển", "nguyện vọng", "luận văn", "đồ án", "nghiên cứu sinh", "thư viện", "ký túc xá", "lớp học", "học kỳ"
            ][:50],
            "World": [
                "thế giới", "quốc tế", "ngoại giao", "liên hợp quốc", "mỹ", "trung quốc", "nga", "châu âu", "châu á", "châu phi", "chiến tranh", 
                "xung đột", "hòa bình", "hiệp ước", "tổng thống", "thủ tướng", "chính phủ", "bầu cử", "chính trị", "khủng bố", "tị nạn", "nhân quyền", 
                "nato", "eu", "asean", "đại sứ quán", "cấm vận", "trừng phạt", "đàm phán", "biểu tình", "bạo loạn", "đảo chính", "quân sự", "vũ khí", 
                "tên lửa", "hạt nhân", "lãnh thổ", "biên giới", "hải quân", "không quân", "lục quân", "ngoại trưởng", "quan hệ quốc tế", "thượng đỉnh", 
                "toàn cầu hóa", "biến động", "khủng hoảng", "hiệp định", "đại hội đồng", "hội đồng bảo an"
            ][:50],
            "Travel": [
                "du lịch", "khách sạn", "chuyến bay", "hàng không", "resort", "tour", "du khách", "điểm đến", "vé máy bay", "visa", "hộ chiếu", 
                "nghỉ dưỡng", "khám phá", "phượt", "danh lam", "thắng cảnh", "di sản", "unesco", "bãi biển", "núi rừng", "hang động", "vịnh", 
                "đảo", "ẩm thực", "đặc sản", "nhà hàng", "quán ăn", "homestay", "bnb", "cắm trại", "trekking", "leo núi", "lặn biển", "bảo tàng", 
                "công viên", "lễ hội", "văn hóa", "phong tục", "check-in", "sống ảo", "vali", "hành lý", "hướng dẫn viên", "đại lý du lịch", 
                "hành trình", "lịch trình", "máy bay", "tàu hỏa", "xe khách", "phà"
            ][:50],
            "Crime": [
                "tội phạm", "pháp luật", "công an", "cảnh sát", "tòa án", "xét xử", "bản án", "luật sư", "bị cáo", "nạn nhân", "giết người", 
                "cướp", "trộm cắp", "ma túy", "buôn lậu", "lừa đảo", "tham nhũng", "hối lộ", "bắt giữ", "khởi tố", "điều tra", "vi phạm", 
                "hình sự", "dân sự", "án mạng", "bạo hành", "hiếp dâm", "tống tiền", "bắt cóc", "đe dọa", "hành hung", "gây rối", "ma túy đá", 
                "heroin", "cocain", "buôn bán người", "rửa tiền", "trốn thuế", "vi phạm bản quyền", "tội phạm mạng", "hacker", "an ninh", 
                "giam giữ", "tù giam", "chung thân", "tử hình", "kháng cáo", "giám đốc thẩm", "viện kiểm sát", "pháp y"
            ][:50]
        }

        rules_added = 0
        rules_skipped = 0

        # Step 1: Add Keywords
        for category_name, keywords in vn_rules.items():
            cat = Category.query.filter_by(name=category_name).first()
            if not cat:
                logger.warning(f"Category '{category_name}' không tồn tại. Bỏ qua.")
                continue

            for kw in keywords:
                keyword_lower = kw.lower()
                existing_rule = KeywordRule.query.filter_by(keyword=keyword_lower).first()
                if not existing_rule:
                    rule = KeywordRule(keyword=keyword_lower, category_id=cat.id)
                    db.session.add(rule)
                    rules_added += 1
                else:
                    rules_skipped += 1
        db.session.commit()
        logger.info(f"Đã thêm thành công {rules_added} rules. Đã bỏ qua {rules_skipped} rules (đã tồn tại).")

        # Step 2: Re-classify existing articles
        articles = Article.query.all()
        logger.info(f"Đang phân loại lại {len(articles)} bài báo...")
        
        reclassified_count = 0
        for article in articles:
            # We clear existing categories first
            article.categories = []
            
            # Reclassify
            # According to classification_service, it takes title, description, tags
            matched_categories = ClassificationService.classify(article.title, article.description)
            
            for cat in matched_categories:
                article.categories.append(cat)
            
            reclassified_count += 1
            if reclassified_count % 100 == 0:
                db.session.commit()
                logger.info(f"Đã phân loại xong {reclassified_count} bài báo...")
                
        db.session.commit()
        logger.info("Hoàn tất phân loại lại bài báo.")

if __name__ == "__main__":
    update_keywords_and_reclassify()
