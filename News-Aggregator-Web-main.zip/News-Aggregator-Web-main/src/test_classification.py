from app import create_app
from services.scraper_service import ScraperService
from models import Article, db, Category, KeywordRule

def test():
    app = create_app()
    with app.app_context():
        # Mock article data containing "smartphone"
        article_data_tech = {
            "source_url": "http://example.com/tech-news-1234",
            "source_name": "Tech Mock",
            "title": "New smartphone released today",
            "description": "It features an amazing screen.",
            "raw_content": "Full text...",
            "published_at": "2024-01-01"
        }
        
        # Mock article data containing "football" and "smartphone"
        article_data_both = {
            "source_url": "http://example.com/sports-tech-1234",
            "source_name": "Mixed Mock",
            "title": "Football app on new smartphone",
            "description": "App review.",
            "raw_content": "Full text...",
            "published_at": "2024-01-01"
        }
        
        # Mock article data containing no known keywords
        article_data_misc = {
            "source_url": "http://example.com/other-news-1234",
            "source_name": "Misc Mock",
            "title": "Some random event",
            "description": "Nothing special.",
            "raw_content": "Full text...",
            "published_at": "2024-01-01"
        }
        
        # Create raw articles (ScraperService.process_parsed_article requires RawArticle, wait, it creates RawArticle or processes dict?
        # Actually in scraper_service.py we saw process_article or we saw it took raw_article_id.
        # Oh, the quickstart script assumes ScraperService.process_article... wait, does process_article exist?
        print("Checking classification service...")
        from services.classification_service import ClassificationService
        tech_cats = ClassificationService.classify("New smartphone released today", "It features an amazing screen.")
        both_cats = ClassificationService.classify("Football app on new smartphone", "App review.")
        misc_cats = ClassificationService.classify("Some random event", "Nothing special.")
        
        print("Tech Article Categories:", [c.name for c in tech_cats])
        print("Both Article Categories:", [c.name for c in both_cats])
        print("Misc Article Categories:", [c.name for c in misc_cats])

if __name__ == "__main__":
    test()
