from datetime import date, datetime, time

from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.dialects.postgresql import TSVECTOR
from werkzeug.security import generate_password_hash, check_password_hash
from services.time_service import vietnam_now, vietnam_today


db = SQLAlchemy()


article_categories = db.Table(
    "article_categories",
    db.Column("article_id", db.Integer, db.ForeignKey("articles.id", ondelete="CASCADE"), primary_key=True),
    db.Column("category_id", db.Integer, db.ForeignKey("categories.id", ondelete="CASCADE"), primary_key=True),
)

user_category_subscriptions = db.Table(
    "user_category_subscriptions",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    db.Column("category_id", db.Integer, db.ForeignKey("categories.id", ondelete="CASCADE"), primary_key=True),
    db.Column("created_at", db.DateTime, nullable=False, default=vietnam_now),
)

user_source_subscriptions = db.Table(
    "user_source_subscriptions",
    db.Column("user_id", db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), primary_key=True),
    db.Column("source_id", db.Integer, db.ForeignKey("scraper_configs.id", ondelete="CASCADE"), primary_key=True),
    db.Column("created_at", db.DateTime, nullable=False, default=vietnam_now),
)


class User(db.Model):
    """Represents a system user who can bookmark articles and authenticate."""

    __tablename__ = "users"

    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(50), unique=True, nullable=True, index=True)
    email = db.Column(db.String(255), unique=True, nullable=False, index=True)
    password_hash = db.Column(db.String(255), nullable=False)
    full_name = db.Column(db.String(100), nullable=True)
    role = db.Column(db.String(50), nullable=False, default="user")
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)
    last_login = db.Column(db.DateTime, nullable=True)
    password_reset_token_hash = db.Column(db.String(255), nullable=True)
    password_reset_expires_at = db.Column(db.DateTime, nullable=True)
    session_version = db.Column(db.Integer, nullable=False, default=0)
    avatar_url = db.Column(db.String(1000), nullable=True)
    avatar_mime_type = db.Column(db.String(120), nullable=True)
    avatar_uploaded_at = db.Column(db.DateTime, nullable=True)

    bookmarks = db.relationship("Bookmark", backref="user", lazy=True, cascade="all, delete-orphan")
    subscribed_categories = db.relationship("Category", secondary=user_category_subscriptions, lazy="subquery", backref=db.backref("subscribed_users", lazy="dynamic"))
    subscribed_sources = db.relationship("ScraperConfig", secondary=user_source_subscriptions, lazy="subquery", backref=db.backref("subscribed_users", lazy="dynamic"))

    def set_password(self, password: str) -> None:
        """Hash and store the given plaintext password using Werkzeug PBKDF2."""
        self.password_hash = generate_password_hash(password)

    def check_password(self, password: str) -> bool:
        """Verify a plaintext password against the stored hash."""
        return check_password_hash(self.password_hash, password)


class Article(db.Model):
    """Represents the normalized article persisted after ETL processing."""

    __tablename__ = "articles"

    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(500), nullable=False)
    description = db.Column(db.Text, nullable=True)
    raw_content = db.Column(db.Text, nullable=True)
    # Ordered text/image blocks extracted from the source article.  Keeping this
    # separately from raw_content lets the reader reproduce the source layout.
    content_blocks_json = db.Column(db.Text, nullable=True)
    source_url = db.Column(db.String(1000), unique=True, nullable=False, index=True)
    cover_image_url = db.Column(db.String(1000), nullable=True)
    published_at = db.Column(db.DateTime, nullable=True)
    scraped_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)
    ai_summary = db.Column(db.Text, nullable=True)
    truth_score = db.Column(db.Float, nullable=True)
    truth_score_updated_at = db.Column(db.DateTime, nullable=True, index=True)
    truth_score_version = db.Column(db.String(20), nullable=True)
    is_deleted = db.Column(db.Boolean,nullable=False,default=False,index=True)
    content_hash = db.Column(db.String(64), nullable=True, index=True)
    title_fingerprint = db.Column(db.String(128), nullable=True, index=True)
    canonical_url = db.Column(db.String(1000), nullable=True)
    primary_article_id = db.Column(db.Integer, db.ForeignKey("articles.id", ondelete="SET NULL"), nullable=True)
    search_vector = db.Column(TSVECTOR().with_variant(db.Text(), "sqlite"), nullable=True)

    categories = db.relationship(
        "Category",
        secondary=article_categories,
        backref=db.backref("articles", lazy="dynamic"),
        lazy="subquery",
    )
    bookmarks = db.relationship("Bookmark", backref="article", lazy=True, cascade="all, delete-orphan")
    raw_articles = db.relationship("RawArticle", backref="article", lazy=True, cascade="all, delete-orphan")
    truth_score_detail = db.relationship("ArticleTruthScore", backref="article", uselist=False, lazy=True, cascade="all, delete-orphan")
    story_membership = db.relationship("ArticleStoryMembership", backref="article", uselist=False, lazy=True, cascade="all, delete-orphan")


class RawArticle(db.Model):
    """Represents the raw scraped payload before normalization and persistence."""

    __tablename__ = "raw_articles"

    id = db.Column(db.Integer, primary_key=True)
    source_url = db.Column(db.String(1000), unique=True, nullable=False, index=True)
    source_name = db.Column(db.String(255), nullable=True)
    title = db.Column(db.String(500), nullable=True)
    description = db.Column(db.Text, nullable=True)
    raw_content = db.Column(db.Text, nullable=True)
    content_blocks_json = db.Column(db.Text, nullable=True)
    raw_html = db.Column(db.Text, nullable=True)
    cover_image_url = db.Column(db.String(1000), nullable=True)
    published_at = db.Column(db.DateTime, nullable=True)
    scraped_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)
    status = db.Column(db.String(50), nullable=False, default="pending")
    error_message = db.Column(db.Text, nullable=True)
    article_id = db.Column(
        db.Integer,
        db.ForeignKey("articles.id", ondelete="CASCADE"),
        nullable=True,
    )
    processed_at = db.Column(db.DateTime, nullable=True)


class Category(db.Model):
    """Represents a topical category used to classify articles."""

    __tablename__ = "categories"

    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), unique=True, nullable=False, index=True)


class KeywordRule(db.Model):
    """Represents a mapping between a specific keyword phrase and a fixed Category."""

    __tablename__ = "keyword_rules"

    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(255), unique=True, nullable=False, index=True)
    category_id = db.Column(
        db.Integer,
        db.ForeignKey("categories.id", ondelete="CASCADE"),
        nullable=False,
        index=True
    )
    is_active = db.Column(db.Boolean, nullable=False, default=True)
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)
    updated_at = db.Column(db.DateTime, default=vietnam_now, onupdate=vietnam_now)

    category = db.relationship("Category", backref=db.backref("keyword_rules", lazy=True, cascade="all, delete-orphan"))


class Bookmark(db.Model):
    """Represents a user’s saved article reference."""

    __tablename__ = "bookmarks"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    article_id = db.Column(
        db.Integer,
        db.ForeignKey("articles.id", ondelete="CASCADE"),
        nullable=False,
    )
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)


class Comment(db.Model):
    __tablename__ = "comments"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id", ondelete="CASCADE"), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    is_deleted = db.Column(db.Boolean, nullable=False, default=False)
    # A moderator can remove a comment from public views without permanently
    # deleting it.  ``is_deleted`` remains reserved for self/permanent removal.
    is_hidden = db.Column(db.Boolean, nullable=False, default=False, index=True)
    moderation_reason = db.Column(db.String(100), nullable=True)
    moderation_note = db.Column(db.Text, nullable=True)
    moderated_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    moderated_at = db.Column(db.DateTime, nullable=True, index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now, index=True)
    updated_at = db.Column(db.DateTime, nullable=True, onupdate=vietnam_now)
    user = db.relationship(
        "User",
        foreign_keys=[user_id],
        backref=db.backref("comments", lazy=True, cascade="all, delete-orphan", foreign_keys="Comment.user_id"),
    )
    article = db.relationship("Article", backref=db.backref("comments", lazy=True, cascade="all, delete-orphan"))
    moderated_by = db.relationship("User", foreign_keys=[moderated_by_id])
    reports = db.relationship("CommentReport", backref="comment", lazy=True, cascade="all, delete-orphan")
    moderation_actions = db.relationship("CommentModerationAction", backref="comment", lazy=True, cascade="all, delete-orphan")


class CommentModerationAction(db.Model):
    """An auditable admin decision made against one public comment."""

    __tablename__ = "comment_moderation_actions"

    id = db.Column(db.Integer, primary_key=True)
    comment_id = db.Column(db.Integer, db.ForeignKey("comments.id", ondelete="CASCADE"), nullable=False, index=True)
    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    action = db.Column(db.String(30), nullable=False, index=True)
    reason = db.Column(db.String(100), nullable=False)
    note = db.Column(db.Text, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now, index=True)

    admin = db.relationship("User", foreign_keys=[admin_id])


class CommentReport(db.Model):
    """A reader report of a comment, kept private from public clients."""

    __tablename__ = "comment_reports"
    __table_args__ = (db.UniqueConstraint("comment_id", "reporter_id", name="uq_comment_reporter"),)

    id = db.Column(db.Integer, primary_key=True)
    comment_id = db.Column(db.Integer, db.ForeignKey("comments.id", ondelete="CASCADE"), nullable=False, index=True)
    reporter_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    reason = db.Column(db.String(50), nullable=False, index=True)
    explanation = db.Column(db.Text, nullable=True)
    status = db.Column(db.String(20), nullable=False, default="open", index=True)
    resolution_action_id = db.Column(db.Integer, db.ForeignKey("comment_moderation_actions.id"), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now, index=True)
    resolved_at = db.Column(db.DateTime, nullable=True)

    reporter = db.relationship("User", foreign_keys=[reporter_id])
    resolution_action = db.relationship("CommentModerationAction", foreign_keys=[resolution_action_id])


class CommentProhibitedTerm(db.Model):
    """Administrator-managed deterministic term used before comment creation."""

    __tablename__ = "comment_prohibited_terms"

    id = db.Column(db.Integer, primary_key=True)
    display_term = db.Column(db.String(255), nullable=False)
    normalized_term = db.Column(db.String(255), nullable=False, unique=True, index=True)
    category = db.Column(db.String(80), nullable=True)
    is_active = db.Column(db.Boolean, nullable=False, default=True, index=True)
    created_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    updated_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now, index=True)
    updated_at = db.Column(db.DateTime, nullable=True, onupdate=vietnam_now)


class CommentFilterEvent(db.Model):
    """Metadata-only record of a blocked comment; rejected text is never stored."""

    __tablename__ = "comment_filter_events"

    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False, index=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id"), nullable=False, index=True)
    prohibited_term_id = db.Column(db.Integer, db.ForeignKey("comment_prohibited_terms.id"), nullable=True, index=True)
    outcome = db.Column(db.String(30), nullable=False, default="blocked")
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now, index=True)

    user = db.relationship("User", foreign_keys=[user_id])
    article = db.relationship("Article", foreign_keys=[article_id])
    prohibited_term = db.relationship("CommentProhibitedTerm", foreign_keys=[prohibited_term_id])


class Reaction(db.Model):
    __tablename__ = "reactions"
    __table_args__ = (db.UniqueConstraint("user_id", "article_id", name="uq_user_article_reaction"),)
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id", ondelete="CASCADE"), nullable=False, index=True)
    reaction_type = db.Column(db.String(20), nullable=False, default="like")
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)
    user = db.relationship("User", backref=db.backref("reactions", lazy=True, cascade="all, delete-orphan"))
    article = db.relationship("Article", backref=db.backref("reactions", lazy=True, cascade="all, delete-orphan"))


class DailyBrief(db.Model):
    __tablename__ = "daily_briefs"
    __table_args__ = (db.UniqueConstraint("user_id", "brief_date", name="uq_user_brief_date"),)
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    content = db.Column(db.Text, nullable=False)
    source_article_ids = db.Column(db.Text, nullable=True)
    generated_at = db.Column(db.DateTime, nullable=False, default=vietnam_now, index=True)
    brief_date = db.Column(db.Date, nullable=False, default=vietnam_today, index=True)
    is_read = db.Column(db.Boolean, nullable=False, default=False)
    user = db.relationship("User", backref=db.backref("daily_briefs", lazy=True, cascade="all, delete-orphan"))


class UserBriefPreference(db.Model):
    __tablename__ = "user_brief_preferences"
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="CASCADE"), unique=True, nullable=False)
    # Brief generation and email delivery require an explicit opt-in.
    is_enabled = db.Column(db.Boolean, nullable=False, default=False)
    delivery_time = db.Column(db.Time, nullable=False, default=lambda: time(7, 0))
    frequency = db.Column(db.String(20), nullable=False, default="daily")
    email_delivery = db.Column(db.Boolean, nullable=False, default=False)
    updated_at = db.Column(db.DateTime, default=vietnam_now, onupdate=vietnam_now)
    user = db.relationship("User", backref=db.backref("brief_preference", uselist=False))


class SearchLog(db.Model):
    """Record a completed article search for trends and personal history."""

    __tablename__ = "search_logs"

    id = db.Column(db.Integer, primary_key=True)
    keyword = db.Column(db.String(255), nullable=False, index=True)
    user_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    results_count = db.Column(db.Integer, nullable=False, default=0)
    searched_at = db.Column(
        db.DateTime,
        nullable=False,
        default=vietnam_now,
        index=True,
    )

    user = db.relationship("User", backref=db.backref("search_logs", lazy=True))



class AdminAuditLog(db.Model):
    """Immutable audit trail for administrative actions."""

    __tablename__ = "admin_audit_logs"

    id = db.Column(db.Integer, primary_key=True)
    admin_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=False)
    action = db.Column(db.String(50), nullable=False, index=True)
    target_type = db.Column(db.String(30), nullable=False)
    target_id = db.Column(db.Integer, nullable=True)
    details = db.Column(db.Text, nullable=True)
    created_at = db.Column(
        db.DateTime,
        nullable=False,
        default=vietnam_now,
        index=True,
    )

    admin = db.relationship("User", backref=db.backref("audit_logs", lazy=True))


class ScraperRun(db.Model):
    """Telemetry log recording scheduled and manual scraper executions."""

    __tablename__ = "scraper_runs"

    id = db.Column(db.Integer, primary_key=True)
    trigger_type = db.Column(db.String(20), nullable=False, default="scheduled")
    triggered_by_id = db.Column(db.Integer, db.ForeignKey("users.id"), nullable=True)
    status = db.Column(db.String(20), nullable=False, default="running", index=True)
    started_at = db.Column(
        db.DateTime,
        nullable=False,
        default=vietnam_now,
        index=True,
    )
    completed_at = db.Column(db.DateTime, nullable=True)
    articles_scraped = db.Column(db.Integer, nullable=False, default=0)
    articles_created = db.Column(db.Integer, nullable=False, default=0)
    duplicates_found = db.Column(db.Integer, nullable=False, default=0)
    error_count = db.Column(db.Integer, nullable=False, default=0)
    summary_json = db.Column(db.Text, nullable=True)

    triggered_by = db.relationship("User", backref=db.backref("scraper_runs", lazy=True))


class ScraperConfig(db.Model):
    """Stores BeautifulSoup CSS selectors and pipeline limits per news source."""

    __tablename__ = "scraper_configs"

    id = db.Column(db.Integer, primary_key=True)
    source_name = db.Column(db.String(100), nullable=False)
    source_domain = db.Column(db.String(100), nullable=False, index=True)
    target_url = db.Column(db.String(500), nullable=False)
    is_enabled = db.Column(db.Boolean, nullable=False, default=True)
    max_articles_per_run = db.Column(db.Integer, nullable=False, default=10)
    reliability_score = db.Column(db.Integer, nullable=False, default=100)
    
    # CSS Selectors
    article_list_selector = db.Column(db.String(255), nullable=False)
    title_selector = db.Column(db.String(255), nullable=False)
    description_selector = db.Column(db.String(255), nullable=False)
    content_selector = db.Column(db.String(255), nullable=False)
    # Optional CSS selector list for embedded widgets/HTML that must not be
    # promoted into the normalized article content.
    excluded_html_selectors = db.Column(db.Text, nullable=False, default="")
    image_selector = db.Column(db.String(255), nullable=True)
    # Comma-separated first-party CDN hostnames permitted by the image proxy.
    image_cdn_domains = db.Column(db.Text, nullable=False, default="")
    published_date_selector = db.Column(db.String(255), nullable=True)
    
    # Audit
    created_at = db.Column(db.DateTime, default=vietnam_now)
    updated_at = db.Column(db.DateTime, default=vietnam_now, onupdate=vietnam_now)


class SystemSetting(db.Model):
    """Stores key-value system settings like dynamic scheduler intervals."""

    __tablename__ = "system_settings"

    key = db.Column(db.String(50), primary_key=True)
    value = db.Column(db.Text, nullable=False)
    description = db.Column(db.String(255), nullable=True)
    updated_at = db.Column(db.DateTime, default=vietnam_now, onupdate=vietnam_now)


class ArticleTruthScore(db.Model):
    """Stores the current, explainable truth-score calculation for an article."""

    __tablename__ = "article_truth_scores"

    id = db.Column(db.Integer, primary_key=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    total_score = db.Column(db.Integer, nullable=False)
    source_reliability_score = db.Column(db.Integer, nullable=False)
    corroboration_score = db.Column(db.Integer, nullable=False)
    metadata_score = db.Column(db.Integer, nullable=False)
    content_score = db.Column(db.Integer, nullable=False)
    base_score = db.Column(db.Integer, nullable=False, default=0)
    linguistic_clarity_score = db.Column(db.Integer, nullable=False, default=0)
    verification_score = db.Column(db.Integer, nullable=False, default=0)
    ambiguity_penalty = db.Column(db.Integer, nullable=False, default=0)
    verification_source_type = db.Column(db.String(20), nullable=True)
    verification_article_ids = db.Column(db.Text, nullable=False, default="[]")
    verification_citations_json = db.Column(db.Text, nullable=False, default="[]")
    verification_claims_json = db.Column(db.Text, nullable=False, default="[]")
    verification_report = db.Column(db.Text, nullable=True)
    verification_checked_at = db.Column(db.DateTime, nullable=True)
    clarity_status = db.Column(db.String(20), nullable=False, default="pending", index=True)
    clarity_content_hash = db.Column(db.String(64), nullable=True)
    clarity_model_version = db.Column(db.String(40), nullable=True)
    clarity_findings_json = db.Column(db.Text, nullable=False, default="[]")
    clarity_report = db.Column(db.Text, nullable=True)
    clarity_analyzed_at = db.Column(db.DateTime, nullable=True)
    corroborating_article_ids = db.Column(db.Text, nullable=False, default="[]")
    corroborating_domains = db.Column(db.Text, nullable=False, default="[]")
    calculation_version = db.Column(db.String(20), nullable=False)
    calculated_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)


class AmbiguousWord(db.Model):
    """Versioned Vietnamese/English ambiguity dictionary used by fact-checking."""

    __tablename__ = "ambiguous_words"

    id = db.Column(db.Integer, primary_key=True)
    term = db.Column(db.String(120), nullable=False, unique=True, index=True)
    language = db.Column(db.String(8), nullable=False, index=True)
    severity = db.Column(db.String(10), nullable=False, default="medium")
    explanation = db.Column(db.String(500), nullable=False)
    is_active = db.Column(db.Boolean, nullable=False, default=True, index=True)
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)


class StoryCluster(db.Model):
    """A group of independently written reports about the same event."""
    __tablename__ = "story_clusters"
    id = db.Column(db.Integer, primary_key=True)
    canonical_article_id = db.Column(db.Integer, db.ForeignKey("articles.id", ondelete="SET NULL"), nullable=True, index=True)
    trending_score = db.Column(db.Integer, nullable=False, default=0)
    source_coverage_score = db.Column(db.Integer, nullable=False, default=0)
    velocity_score = db.Column(db.Integer, nullable=False, default=0)
    recency_score = db.Column(db.Integer, nullable=False, default=0)
    source_quality_score = db.Column(db.Integer, nullable=False, default=0)
    accepted_article_count = db.Column(db.Integer, nullable=False, default=0)
    independent_domain_count = db.Column(db.Integer, nullable=False, default=0)
    last_covered_at = db.Column(db.DateTime, nullable=True, index=True)
    score_updated_at = db.Column(db.DateTime, nullable=True)
    created_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)
    updated_at = db.Column(db.DateTime, nullable=False, default=vietnam_now, onupdate=vietnam_now)
    canonical_article = db.relationship("Article", foreign_keys=[canonical_article_id], lazy=True)


class ArticleStoryMembership(db.Model):
    """The current cluster decision and evidence for a single article."""
    __tablename__ = "article_story_memberships"
    id = db.Column(db.Integer, primary_key=True)
    article_id = db.Column(db.Integer, db.ForeignKey("articles.id", ondelete="CASCADE"), nullable=False, unique=True, index=True)
    cluster_id = db.Column(db.Integer, db.ForeignKey("story_clusters.id", ondelete="CASCADE"), nullable=False, index=True)
    match_confidence = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), nullable=False, default="accepted", index=True)
    match_signals_json = db.Column(db.Text, nullable=False, default="{}")
    matched_at = db.Column(db.DateTime, nullable=False, default=vietnam_now)
    reviewed_at = db.Column(db.DateTime, nullable=True)
    reviewed_by_user_id = db.Column(db.Integer, db.ForeignKey("users.id", ondelete="SET NULL"), nullable=True)
    cluster = db.relationship("StoryCluster", backref=db.backref("memberships", lazy=True, cascade="all, delete-orphan"))
    reviewed_by = db.relationship("User", foreign_keys=[reviewed_by_user_id])




